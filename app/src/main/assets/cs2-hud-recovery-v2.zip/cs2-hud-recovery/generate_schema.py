import json,pathlib,struct
r=pathlib.Path(__file__).resolve().parent
j=lambda name:json.loads((r/(name+'.json')).read_text())
def st(s):return json.dumps(s,ensure_ascii=True)
def fl(f):return float(f).hex()+'f'
def array(xs):return '{'+','.join(fl(v) for v in xs)+'}'
with (r/'ui_data.cpp').open('w') as f:
 f.write('#include "ui_schema.hpp"\nnamespace recovered_hud {\nconst std::array<NodeData,524> nodes = {{\n')
 for n in j('nodes'):
  active=bool(struct.unpack_from('<I',bytes.fromhex(n['raw']),16)[0])
  vals=[st(n['name']),str(n['parent']),str(n['subtree_end']),str(active).lower()]+[array(n[k]) for k in ['anchor_min','anchor_max','anchored_position','size_delta','pivot']]+['{'+','.join(map(str,n['components']))+'}']
  f.write(' {'+','.join(vals)+'},\n')
 f.write('}};\nconst std::array<SpriteData,105> sprites = {{\n')
 for s in j('sprites'):f.write(' {'+st(s['name'])+','+','.join(fl(x) for x in s['rect'])+'},\n')
 f.write('}};\nconst std::array<ImageData,170> images = {{\n')
 for x in j('images'):f.write(' {'+str(x['sprite_index'])+','+array(x['color'])+'},\n')
 f.write('}};\nconst std::array<TextData,234> texts = {{\n')
 for x in j('texts'):f.write(' {'+str(x['font_index'])+','+fl(x['font_size'])+','+array(x['color'])+','+st(x['text'])+'},\n')
 f.write('}};\n}\n')
