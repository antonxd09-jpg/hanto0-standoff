typedef struct st_254eb8_3 {
    char padding_0[208];
    struct st_254eb8_4 *field_d0;
} st_254eb8_3;

typedef struct st_254eb8_2 {
    char padding_0[220];
    unsigned long long field_dc;
} st_254eb8_2;

typedef struct st_254eb8_6 {
    unsigned long long field_0;
    unsigned long long field_8;
    unsigned long long field_10;
    unsigned long long field_18;
    unsigned long long field_20;
    unsigned long long field_28;
    char padding_30[2640];
    uint128_t field_a80;
    uint128_t field_a90;
    unsigned int field_aa0;
    uint128_t field_aa4;
    uint128_t field_ab4;
    unsigned long long field_ac4;
    unsigned long long field_acc;
    char padding_ad4[4];
    unsigned long long field_ad8;
    char field_ae0;
    char padding_ae1[3];
    unsigned int field_ae4;
    unsigned short field_ae8;
    char padding_aea[2];
    unsigned int field_aec;
    uint128_t field_af0;
    char padding_b00[4];
    unsigned long long field_b04;
    unsigned long long field_b0c;
    unsigned long long field_b14;
    unsigned long long field_b1c;
    unsigned long long field_b24;
    unsigned long long field_b2c;
    unsigned long long field_b34;
    unsigned long long field_b3c;
    unsigned long long field_b44;
    unsigned long long field_b4c;
    unsigned long long field_b54;
    unsigned long long field_b5c;
    unsigned long long field_b64;
    unsigned long long field_b6c;
    unsigned long long field_b74;
    unsigned long long field_b7c;
    unsigned long long field_b84;
    unsigned long long field_b8c;
    unsigned long long field_b94;
    unsigned long long field_b9c;
    unsigned int field_ba4;
    unsigned int field_ba8;
    unsigned long long field_bac;
    unsigned long long field_bb4;
    unsigned long long field_bbc;
    unsigned int field_bc4;
    char padding_bc8[4];
    unsigned long long field_bcc;
} st_254eb8_6;

typedef struct st_254eb8_5 {
    uint128_t field_0;
    char padding_10[8];
    unsigned long long field_18;
    unsigned long long field_20;
    unsigned int field_28;
    char padding_2c[4];
    unsigned long long field_30;
    unsigned int field_38;
    unsigned int field_3c[3];
    unsigned int field_40[2];
    char field_44;
    char padding_45[3];
    unsigned long long field_48;
    unsigned int field_50;
    char padding_54[12];
    unsigned long long field_60;
    unsigned long long field_68;
    unsigned long long field_70;
    unsigned long long field_78;
    unsigned long long field_80;
    unsigned long long field_88;
    unsigned long long field_90;
    unsigned long long field_98;
    unsigned long long field_a0;
    unsigned long long field_a8;
    unsigned long long field_b0;
    unsigned long long field_b8;
    unsigned long long field_c0;
    unsigned long long field_c8;
    unsigned long long field_d0;
    unsigned long long field_d8;
    unsigned long long field_e0;
    unsigned long long field_e8;
    unsigned long long field_f0;
    unsigned long long field_f8;
    unsigned long long field_100;
    unsigned long long field_108;
    unsigned int field_110;
    unsigned int field_114;
    unsigned int field_118;
    unsigned int field_11c;
    unsigned int field_120;
    unsigned int field_124;
    unsigned int field_128;
    unsigned int field_12c;
    unsigned int field_130;
    unsigned long long field_134;
    unsigned long long field_13c;
    unsigned long long field_144;
    unsigned long long field_14c;
    unsigned long long field_154;
    unsigned long long field_15c;
    char padding_164[2640];
    uint128_t field_bb4;
    uint128_t field_bc4;
    unsigned int field_bd4;
    uint128_t field_bd8;
    uint128_t field_be8;
    unsigned long long field_bf8;
    unsigned long long field_c00;
    char padding_c08[4];
    unsigned long long field_c0c;
    char field_c14;
    char padding_c15[3];
    unsigned int field_c18;
    unsigned short field_c1c;
    char padding_c1e[2];
    unsigned int field_c20;
    uint128_t field_c24;
    char padding_c34[4];
    unsigned long long field_c38;
    unsigned long long field_c40;
    unsigned long long field_c48;
    unsigned long long field_c50;
    unsigned long long field_c58;
    unsigned long long field_c60;
    unsigned long long field_c68;
    unsigned long long field_c70;
    unsigned long long field_c78;
    unsigned long long field_c80;
    unsigned long long field_c88;
    unsigned long long field_c90;
    unsigned long long field_c98;
    unsigned long long field_ca0;
    unsigned long long field_ca8;
    unsigned long long field_cb0;
    unsigned long long field_cb8;
    unsigned long long field_cc0;
    unsigned long long field_cc8;
    unsigned long long field_cd0;
    unsigned int field_cd8;
    unsigned int field_cdc;
    unsigned long long field_ce0;
    unsigned long long field_ce8;
    unsigned long long field_cf0;
    unsigned int field_cf8;
    char padding_cfc[4];
    unsigned long long field_d00;
} st_254eb8_5;

typedef struct st_254eb8_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_254eb8_0;

typedef struct st_254eb8_4 {
    unsigned long long field_0;
} st_254eb8_4;

extern char g_700b39;
extern char g_700bd3;
extern char g_700cf3;

unsigned int sub_254eb8(void* a0, st_254eb8_3 *a1)
{
    st_254eb8_0 *v10;  // tpidr_el0
    st_254eb8_0 *v11;  // x20
    unsigned long long v20;  // x0
    unsigned long v21;  // x0
    unsigned long v22;  // x0
    unsigned long v23;  // x0
    unsigned long v24;  // x0
    unsigned long v25;  // x0
    unsigned long v26;  // x0
    unsigned long v27;  // x0
    unsigned long v28;  // x0
    unsigned long v29;  // x0
    unsigned long long v12;  // x22
    unsigned long v30;  // x0
    unsigned long v31;  // x0
    unsigned long v32;  // x0
    unsigned long v33;  // x0
    unsigned long v34;  // x0
    unsigned long v35;  // x0
    unsigned long v36;  // x0
    unsigned long v37;  // x0
    unsigned long long v38;  // x2
    st_254eb8_3 *v39;  // x28
    unsigned int v13;  // w0
    unsigned long v40;  // x0
    unsigned long v41;  // x0
    unsigned long v42;  // x0
    unsigned long v43;  // x0
    unsigned long long *v44;  // x25
    unsigned long v45;  // x0
    unsigned long v46;  // x0
    unsigned long v47;  // x0
    unsigned long v48;  // x0
    unsigned long v49;  // x0
    void* v14;  // x25
    unsigned long long v50;  // x26
    unsigned long long j;  // x27
    long long *v52;  // x20
    unsigned long long *v53;  // x24
    unsigned long long v54;  // x0
    unsigned long long *v55;  // x21
    unsigned long v56;  // x1
    unsigned long long v57;  // x0
    unsigned long long *v58;  // x28
    unsigned long v59;  // x1
    unsigned long long i;  // x20
    unsigned long long v60;  // x0
    unsigned long long v61;  // x1
    st_254eb8_3 *v62;  // x28
    unsigned long long *v63;  // q0
    unsigned long v64;  // x0
    unsigned long long *v65;  // x1
    unsigned long long v66;  // x22
    unsigned long v67;  // x8
    unsigned int v68;  // w9
    unsigned int v69;  // w10
    void* v16;  // x26
    unsigned long v70;  // x8
    unsigned int v71;  // w10
    unsigned long v72;  // x8
    unsigned int v73;  // w10
    unsigned long v74;  // x8
    unsigned int v75;  // w10
    unsigned long v76;  // x8
    unsigned int v77;  // w10
    unsigned long v78;  // x8
    unsigned int v79;  // w23
    unsigned long long v17;  // x27
    unsigned long long v81;  // x0
    unsigned long long v82;  // x0
    unsigned long long v83;  // x0
    unsigned long long v84;  // x0
    unsigned int v85;  // s2
    unsigned int v86;  // s3
    double v87;  // d0
    double v88;  // d1
    st_254eb8_2 *v89;  // x1
    void* ptr;  // x26
    double v90;  // d1
    double v91;  // d2
    st_254eb8_2 *v92;  // x8
    st_254eb8_3 *v93;  // x21
    st_254eb8_2 *v94;  // x8
    double v95;  // d0
    double v96;  // d2
    st_254eb8_2 *v97;  // x8
    st_254eb8_2 *v98;  // x8
    double v99;  // d1
    unsigned long long k;  // x23
    double v100;  // d2
    st_254eb8_2 *v101;  // x8
    st_254eb8_2 *v102;  // x8
    long long v103;  // x8
    uint128_t v104;  // q0
    uint128_t v105;  // q0
    unsigned long v0;  // [bp-0xa0]
    st_254eb8_5 *v1;  // [bp-0x98]
    void* v2;  // [bp-0x90]
    st_254eb8_6 *v3;  // [bp-0x88]
    st_254eb8_0 *v4;  // [bp-0x80]
    int v5;  // [bp-0x70]
    unsigned int v6;  // [bp-0x6c]
    unsigned long v7;  // [bp-0x68]
    char *v8;  // [bp-0x60]
    char v9;  // [bp+0x0]

    v8 = &v9;
    v11 = v10;
    v7 = v11->field_28;
    v12 = sub_23cbf0(7335019, 6951467, 0) & 0xffffffff;
    *(unsigned int *)&a0[480] = sub_23cbf0(7335019, 7091881, 24);
    *(unsigned int *)&a0[484] = sub_23cbf0(7335019, 0x6bbff6, 31);
    *(unsigned int *)&a0[488] = sub_23cbf0(7335019, 7169938, 28);
    v13 = 0;
    *(unsigned int *)&a0[4720] = sub_23cbf0(7335019, 6895114, 0x11);
    if (!(v12 >> 31 & 1) && (int)a0[480] >= 0)
    {
        v14 = a0 + 728;
        v3 = a0 + 1708;
        v4 = v11;
        i = 728;
        v1 = a0 + 1400;
        v2 = v14;
        do
        {
            v16 = v14;
            *(unsigned int *)v14 = 0xffffffff;
            v17 = (long long)v16[8];
            ptr = v16 + 8;
            if (v17)
            {
                k = (long long)v14[16];
                v20 = v17;
                if ((long long)v14[16] != v20)
                {
                    do
                    {
                        k -= 288;
                        sub_215c38(k);
                    } while (k != v17);
                    v20 = *(long long *)ptr;
                }
                *(unsigned long long *)&v14[16] = v17;
                sub_6790c8(v20);
            }
            i += 128;
            *(unsigned int *)&v14[112] = 0;
            *(unsigned long long *)&v14[116] = 0xffffffffc2c80000;
            *(unsigned long long *)&v14[72] = 0xffffffffffffffff;
            *(uint128_t *)&v14[80] = 0;
            *(uint128_t *)&v14[96] = 0;
            v14 = a0 + i;
            memset(ptr, 0, 64);
        } while (i != 1496);
        v5 = (int)a0[480];
        v6 = (int)a0[4720];
        v11 = v4;
        v13 = 0;
        if (sub_22bf2c() & 1)
        {
            *(unsigned long long *)&a0[496] = sub_23d928(a0 + 448, v12 & 0xffffffff);
            *(unsigned long long *)&a0[504] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7218028, 8) & 0xffffffff);
            *(unsigned long long *)&a0[0x200] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6995696, 5) & 0xffffffff);
            *(unsigned long long *)&a0[520] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6978507, 11) & 0xffffffff);
            *(unsigned long long *)&a0[528] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7091906, 0x11) & 0xffffffff);
            *(unsigned long long *)&a0[536] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7061526, 21) & 0xffffffff);
            *(unsigned long long *)&a0[544] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7028370, 23) & 0xffffffff);
            *(unsigned long long *)&a0[552] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7152007, 13) & 0xffffffff);
            *(unsigned long long *)&a0[560] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7091924, 13) & 0xffffffff);
            *(unsigned long long *)&a0[568] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7076206, 19) & 0xffffffff);
            *(unsigned long long *)&a0[576] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6847517, 18) & 0xffffffff);
            *(unsigned long long *)&a0[584] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6948304, 12) & 0xffffffff);
            *(unsigned long long *)&a0[592] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6879364, 22) & 0xffffffff);
            *(unsigned long long *)&a0[600] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6948317, 18) & 0xffffffff);
            *(unsigned long long *)&a0[608] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7137744, 18) & 0xffffffff);
            *(unsigned long long *)&a0[616] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6879387, 23) & 0xffffffff);
            *(unsigned long long *)&a0[624] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7280411, 24) & 0xffffffff);
            *(unsigned long long *)&a0[632] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7265042, 16) & 0xffffffff);
            *(unsigned long long *)&a0[640] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7201692, 21) & 0xffffffff);
            *(unsigned long long *)&a0[648] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7091938, 11) & 0xffffffff);
            *(unsigned long long *)&a0[656] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6895132, 16) & 0xffffffff);
            *(unsigned long long *)&a0[664] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7169967, 0x11) & 0xffffffff);
            *(unsigned long long *)&a0[672] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7265059, 10) & 0xffffffff);
            *(unsigned long long *)&a0[680] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7152021, 19) & 0xffffffff);
            *(unsigned long long *)&a0[688] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7152041, 15) & 0xffffffff);
            *(unsigned long long *)&a0[696] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6996096, 18) & 0xffffffff);
            *(unsigned long long *)&a0[704] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6932155, 23) & 0xffffffff);
            *(unsigned long long *)&a0[712] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7201714, 18) & 0xffffffff);
            *(unsigned long long *)&a0[720] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7312516, 22) & 0xffffffff);
            v21 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6996115, 25) & 0xffffffff);
            v22 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7185381, 25) & 0xffffffff);
            v23 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6978519, 25) & 0xffffffff);
            v24 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6895149, 26) & 0xffffffff);
            v25 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 6847536, 26) & 0xffffffff);
            v26 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 0x6aff10, 26) & 0xffffffff);
            v27 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7061548, 22) & 0xffffffff);
            v28 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7297077, 22) & 0xffffffff);
            *(unsigned long long *)&a0[4592] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7297100, 22) & 0xffffffff);
            *(unsigned long *)&a0[4528] = v21;
            *(unsigned long *)&a0[4536] = v22;
            *(unsigned long *)&a0[4544] = v23;
            *(unsigned long *)&a0[4552] = v24;
            *(unsigned long *)&a0[4560] = v25;
            *(unsigned long *)&a0[4568] = v26;
            *(unsigned long *)&a0[4576] = v27;
            *(unsigned long *)&a0[4584] = v28;
            v0 = sub_23d184(7169547, 11);
            v29 = sub_23d184(7327606, 11);
            v30 = sub_23d184(&g_700b39, 11);
            v31 = sub_23d184(6847086, 11);
            v32 = sub_23d184(6947708, 11);
            v33 = sub_23d184(7108818, 11);
            v34 = sub_23d184(7184962, 11);
            v35 = sub_23d184(7249036, 11);
            v36 = sub_23d184(7184974, 11);
            *(unsigned long long *)&a0[4672] = sub_23d184(6847098, 11);
            *(unsigned long *)&a0[4600] = v0;
            *(unsigned long *)&a0[0x1200] = v29;
            *(unsigned long *)&a0[4616] = v30;
            *(unsigned long *)&a0[4624] = v31;
            *(unsigned long *)&a0[4632] = v32;
            *(unsigned long *)&a0[4640] = v33;
            *(unsigned long *)&a0[4648] = v34;
            *(unsigned long *)&a0[4656] = v35;
            *(unsigned long *)&a0[4664] = v36;
            sub_23d338(7169817, 16, 0);
            *(unsigned int *)&a0[4692] = 0;
            *(unsigned int *)&a0[4688] = 0xffffffff;
            *(unsigned long long *)&a0[4680] = 0xffffffffffffffff;
            *(unsigned long long *)&a0[4696] = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7091950, 22) & 0xffffffff);
            v37 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7061571, 8) & 0xffffffff);
            v38 = (long long)a0[496];
            v13 = 0;
            *(unsigned long *)&a0[4728] = v37;
            if (v38 && (long long)a0[0x200])
            {
                v11 = v4;
                v39 = a1;
                if ((long long)a0[520])
                {
                    sub_23dc40(v39, a0 + 8);
                    sub_28ce90(v39, (long long)a0[4728]);
                    v40 = sub_23d184(6931759, 10);
                    v41 = sub_23d184(7169615, 10);
                    v42 = sub_23d184(7232877, 10);
                    v43 = sub_23d184(6878935, 10);
                    *(unsigned long long *)&a0[1528] = sub_23d184(6847179, 10);
                    *(unsigned long *)&a0[1496] = v40;
                    v44 = a0 + 1496;
                    *(unsigned long *)&a0[1504] = v41;
                    *(unsigned long *)&a0[1512] = v42;
                    *(unsigned long *)&a0[1520] = v43;
                    v45 = sub_23d184(6947720, 20);
                    v46 = sub_23d184(7217977, 21);
                    v47 = sub_23d184(7123129, 18);
                    v48 = sub_23d184(7028125, 0x11);
                    v49 = sub_23d184(7327635, 18);
                    v50 = 0;
                    j = 0;
                    *(unsigned long *)&a0[1552] = v47;
                    *(unsigned long *)&a0[1560] = v48;
                    *(unsigned long *)&a0[0x600] = v45;
                    *(unsigned long *)&a0[1544] = v46;
                    *(unsigned long *)&a0[1568] = v49;
                    do
                    {
                        v52 = (char *)v44 + v50;
                        v53 = (char *)v52 - 0x300;
                        if (!(sub_22bf2c() & 1))
                        {
                            if (v4->field_28 == v7)
                                return 0;
                            6813312();
                        }
                        v54 = sub_23d928(v53, (int)a0[480]);
                        v55 = (char *)v52 - 736;
                        v56 = (int)a0[484];
                        *v55 = v54;
                        v57 = sub_23d928(v53, v56);
                        v58 = (char *)v52 - 728;
                        v59 = (int)a0[488];
                        *v58 = v57;
                        *(unsigned long long *)((char *)v52 - 720) = sub_23d928(v53, v59);
                        v60 = sub_23d928(v53, sub_23cbf0(7335019, 6879411, 0x22) & 0xffffffff);
                        v61 = *v55;
                        *(unsigned long long *)((char *)v52 - 704) = v60;
                        sub_22cf38(a1, v61);
                        sub_22ce80(a1, *v55, 1);
                        v62 = a1;
                        sub_22d40c(v62, *v58, *(long long *)((char *)v44 + j));
                        j += 8;
                        v50 += 128;
                    } while (j != 40);
                    v63 = (unsigned long long *)(int128_t)a0[528];
                    *(long long *)&a0[1424] = (long long)a0[544];
                    v1->field_0 = (uint128_t)v63;
                    v64 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7312539, 27) & 0xffffffff);
                    v65 = (long long)a0[528];
                    *(unsigned long *)&a0[1432] = v64;
                    if (v65)
                    {
                        sub_22cf38(v62);
                        sub_22ce80(v62, (long long)a0[528], 1);
                        if (!*(long long *)((long long)a0[528] + 16))
                            v66 = 0;
                        else
                            v66 = *(long long *)((long long)a0[528] + 24);
                        if (sub_198128() & 1 && v66)
                            v62->field_d0(v66, 0);
                    }
                    *(unsigned int *)&a0[820] = 0;
                    *(unsigned int *)&a0[948] = 0;
                    *(double *)&a0[824] = *(double *)0x683dd8;
                    v67 = (long long)a0[820];
                    *(double *)&a0[952] = *(double *)0x683dd8;
                    v68 = (int)a0[828];
                    v69 = (int)a0[956];
                    *(double *)&a0[1080] = *(double *)0x683dd8;
                    *(unsigned long *)&a0[808] = v67;
                    *(unsigned long *)&a0[832] = v67;
                    v70 = (long long)a0[948];
                    *(unsigned int *)&a0[816] = v68;
                    *(unsigned int *)&a0[840] = v68;
                    *(unsigned int *)&a0[1076] = 0;
                    *(unsigned int *)&a0[944] = v69;
                    *(unsigned long *)&a0[936] = v70;
                    *(unsigned int *)&a0[968] = v69;
                    v71 = (int)a0[1084];
                    *(unsigned long *)&a0[960] = v70;
                    v72 = (long long)a0[1076];
                    *(double *)&a0[1208] = *(double *)0x683dd8;
                    *(unsigned int *)&a0[1204] = 0;
                    *(unsigned int *)&a0[1072] = v71;
                    *(unsigned long *)&a0[1064] = v72;
                    *(unsigned int *)&a0[1096] = v71;
                    v73 = (int)a0[1212];
                    *(unsigned long *)&a0[1088] = v72;
                    v74 = (long long)a0[1204];
                    *(double *)&a0[1336] = *(double *)0x683dd8;
                    *(unsigned int *)&a0[1332] = 0;
                    *(unsigned int *)&a0[1200] = v73;
                    *(unsigned long *)&a0[1192] = v74;
                    *(unsigned int *)&a0[1224] = v73;
                    v75 = (int)a0[1340];
                    *(unsigned long *)&a0[1216] = v74;
                    v76 = (long long)a0[1332];
                    *(double *)&a0[1464] = *(double *)0x683dd8;
                    *(unsigned int *)&a0[1460] = 0;
                    *(unsigned int *)&a0[1328] = v75;
                    *(unsigned long *)&a0[1320] = v76;
                    *(unsigned int *)&a0[1352] = v75;
                    v77 = (int)a0[1468];
                    *(unsigned long *)&a0[1344] = v76;
                    v78 = (long long)a0[1460];
                    *(unsigned int *)&a0[1456] = v77;
                    *(unsigned long *)&a0[1448] = v78;
                    *(unsigned int *)&a0[1480] = v77;
                    *(unsigned long *)&a0[1472] = v78;
                    v79 = sub_23cbf0(7335019, 6963827, 27);
                    *(unsigned int *)&a0[800] = sub_246b10(v62, sub_23d928(v2, v79), 1);
                    *(unsigned int *)&a0[928] = sub_246b10(v62, sub_23d928(a0 + 856, v79), 1);
                    *(unsigned int *)&a0[1056] = sub_246b10(v62, sub_23d928(a0 + 984, v79), 1);
                    *(unsigned int *)&a0[1184] = sub_246b10(v62, sub_23d928(a0 + 1112, v79), 1);
                    *(unsigned int *)&a0[1312] = sub_246b10(v62, sub_23d928(a0 + 1240, v79), 1);
                    *(unsigned int *)&a0[1440] = sub_246b10(v62, sub_23d928(a0 + 448, sub_23cbf0(7335019, 6879446, 22) & 0xffffffff), 1);
                    sub_246b10(v62, sub_23d928(a0 + 448, sub_23cbf0(7335019, 0x6aff2b, 12) & 0xffffffff), 2);
                    sub_22b5e4(v62, (long long)a0[520], 0);
                    *(unsigned long long *)&a0[1576] = sub_23d184(7296842, 9);
                    *(unsigned long long *)&a0[1584] = sub_23d184(7061164, 16);
                    v81 = sub_23d184(7137328, 25);
                    v82 = sub_23d184(6977952, 30);
                    v83 = sub_23d184(7061143, 20);
                    v84 = sub_23d184(6977903, 27);
                    *(unsigned long long *)&a0[1664] = sub_23d184(6977931, 20);
                    *(unsigned long long *)&a0[1592] = 7137328;
                    *(unsigned long long *)&a0[1600] = v81;
                    *(unsigned long long *)&a0[1608] = 6977952;
                    *(unsigned long long *)&a0[1616] = v82;
                    *(unsigned long long *)&a0[1624] = 7061143;
                    *(unsigned long long *)&a0[1632] = v83;
                    *(unsigned long long *)&a0[1640] = 6977903;
                    *(unsigned long long *)&a0[1648] = v84;
                    *(unsigned long long *)&a0[1656] = 6977931;
                    sub_23d5c0(7312270, 10);
                    *(unsigned int *)&a0[1672] = *(unsigned int *)&*0x683dd8;
                    *(unsigned int *)&a0[1676] = 0xffffffff;
                    *(unsigned int *)&a0[1680] = v85;
                    *(unsigned int *)&a0[1684] = v86;
                    sub_23d5c0(0x6e23fd, 11);
                    *(unsigned int *)&a0[1688] = *(unsigned int *)&*0x683dd8;
                    *(unsigned int *)&a0[1692] = 0xffffffff;
                    *(unsigned int *)&a0[1696] = v85;
                    *(unsigned int *)&a0[1700] = v86;
                    sub_23d338(6947960, 20, 0);
                    *(unsigned int *)&a0[1704] = *(unsigned int *)&*0x683dd8;
                    sub_252ad4(a0 + 1756, 6963463, 7109031, 0, 6847563, 0);
                    sub_252ad4(a0 + 2020, 6947895, 7044373, 0, 6895176, 3);
                    sub_252ad4(a0 + 2284, &g_700bd3, 7061580, 0, 7044390, 3);
                    sub_252ad4(a0 + 2548, 6931832, 6978545, 4, 7233225, 4);
                    sub_252ad4(a0 + 2812, 7232970, 7201733, 4, 6879469, 4);
                    sub_252ad4(a0 + 3076, 7076015, 6879489, 4, 6996141, 4);
                    sub_252ad4(a0 + 3340, 7151708, 7218329, 4, 7061594, 4);
                    sub_252ad4(a0 + 3604, 7151773, 7265070, 2, 7152057, 0);
                    sub_252ad4(a0 + 3868, 7185132, 0x6aff38, 4, &g_700cf3, 0);
                    sub_252ad4(a0 + 4132, 6863408, 6915361, 5, 7233240, 5);
                    v87 = 0;
                    v88 = 0;
                    if ((long long)a0[600])
                        v88 = *(double *)((long long)a0[600] + 220);
                    v11 = v4;
                    v89 = (long long)a0[608];
                    *(double *)&v3->field_0 = v88;
                    if (v89)
                        v87 = *(double *)&(v89->padding_0)[1];
                    v90 = 0;
                    v91 = 0;
                    v92 = (long long)a0[632];
                    v93 = a1;
                    *(double *)&v3->field_8 = v87;
                    if (v92)
                        v91 = *(double *)&(v92->padding_0)[1];
                    v94 = (long long)a0[688];
                    *(double *)&v3->field_10 = v91;
                    if (v94)
                        v90 = *(double *)&(v94->padding_0)[1];
                    v95 = 0;
                    v96 = 0;
                    v97 = (long long)a0[720];
                    *(double *)&v3->field_18 = v90;
                    if (v97)
                        v96 = *(double *)&(v97->padding_0)[1];
                    v98 = (long long)a0[656];
                    *(double *)&v3->field_20 = v96;
                    if (v98)
                        v95 = *(double *)&(v98->padding_0)[1];
                    v99 = 0;
                    v100 = 0;
                    v101 = (long long)a0[592];
                    *(double *)&v3->field_28 = v95;
                    if (v101)
                        v100 = *(double *)&(v101->padding_0)[1];
                    v102 = (long long)a0[680];
                    *(double *)&a0[4704] = v100;
                    if (v102)
                        v99 = *(double *)&(v102->padding_0)[1];
                    v103 = (long long)a0[504];
                    *(double *)&a0[4712] = v99;
                    if (v103)
                        sub_22d238(v93, v103);
                    sub_22cf38(v93);
                    v104 = CONCAT(0xffffffffffffffff, 0xffffffffffffffff);
                    v13 = 1;
                    *(unsigned long long *)&a0[4484] = 0xfffffffeffffffff;
                    *(double *)&a0[4464] = *0x683260;
                    *(uint128_t *)&a0[4448] = v104;
                    *(uint128_t *)&a0[4432] = v104;
                    *(unsigned long long *)&a0[4472] = 0;
                    *(unsigned short *)&v3->field_ad8 = 0;
                    v3->padding_ad4[0] = 0;
                    *(uint128_t *)&v3->field_ae0 = CONCAT(0x3f8000003f800000, 0x3f8000003f800000);
                    v105 = CONCAT(0xc2c80000c2c80000, 0xc2c80000c2c80000);
                    *(unsigned int *)&a0[4496] = 0;
                    *(unsigned int *)&a0[4504] = 0xffffffff;
                    v3->field_a80 = v105;
                    v3->field_a90 = v105;
                    *(unsigned int *)&a0[4428] = 0xc2c80000;
                }
            }
            else
            {
                v11 = v4;
            }
        }
    }
    if (v11->field_28 == v7)
        return v13;
    6813312();
}
