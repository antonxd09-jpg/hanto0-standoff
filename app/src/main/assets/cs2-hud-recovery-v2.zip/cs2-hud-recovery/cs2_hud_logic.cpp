#include "cs2_hud_logic.hpp"
#include <cmath>
#include <cstring>
namespace recovered_hud {
// ELF VA 0x2980554; channel order established by 0x23e7cc..0x23e7fc.
const std::array<std::uint32_t,11> palette_rgba = {
 0xe8e8e8ff,0xffffffff,0x96c8ffff,0x2478ffff,0xc864ffff,0xff2924ff,
 0xff7124ff,0xfff724ff,0x3eff24ff,0x70ffdbff,0xff9ccdff
};
Color decode_rgba(std::uint32_t c) noexcept {
 return {float(c>>24)/255.f,float((c>>16)&255)/255.f,float((c>>8)&255)/255.f,float(c&255)/255.f};
}
// Recovered branch at 0x258744..0x2587cc. IDs belong to this input build.
const char* ammo_icon(std::int32_t id) noexcept {
 const std::uint32_t delta=std::uint32_t(id)-42u;
 if(delta<=23) {
  const std::uint32_t bit=1u<<delta;
  if(bit&0xdu) return "hud/ammo_reserve_banana_mag";
  if(bit&0xb00000u) return "hud/ammo_reserve_shotgun_shell";
  if(delta==22) return "hud/ammo_reserve_box";
 }
 if(id==35) return "hud/ammo_reserve_p90";
 return "hud/ammo_reserve_magazine";
}
static float bits(std::uint32_t x) noexcept { float f;std::memcpy(&f,&x,4);return f; }
struct Control { float x1,x2,dx,y1; };
struct Terms { float u,v,t2,x; };
static Terms sample(float t,const Control& c) noexcept {
 const float inv=1.f-t;
 const float three_inv=inv*3.f;
 const float tv=t*three_inv;
 const float ii=inv*three_inv;
 const float v=t*tv,u=t*ii,t2=t*t;
 return {u,v,t2,std::fma(t2,t,std::fma(u,c.x1,v*c.x2))};
}
static float value(float t,const Terms& s,const Control& c) noexcept {
 return std::fma(s.t2,t,std::fma(s.u,c.y1,s.v));
}
// ELF VA 0x254534 dispatches 1..5 to cubic Bezier solvers. Original tolerances,
// float constants, Newton iteration count and bisection fallback are retained.
float animation_curve(std::int32_t mode,float x) noexcept {
 if(x>1.f)x=1.f;
 if(x<0.f)x=0.f;
 Control c;
 switch(mode) {
  case 1:c={.25f,.25f,0.f,bits(0x3dcccccd)};break;
  case 2:c={bits(0x3ed70a3d),1.f,bits(0x3f147ae2),0.f};break;
  case 3:c={0.f,bits(0x3f147ae1),bits(0x3f147ae1),0.f};break;
  case 4:c={bits(0x3ed70a3d),bits(0x3f147ae1),bits(0x3e23d70a),0.f};break;
  case 5:c={bits(0x3f666666),bits(0x3dcccccd),bits(0xbf4ccccc),bits(0x3c23d70a)};break;
  default:return x;
 }
 if(x<=0.f)return 0.f;
 if(x>=1.f)return 1.f;
 if(std::isnan(x))return x;
 const float eps=bits(0x3727c5ac),small=bits(0x358637bd);
 float t=x;
 for(int k=0;k<8;++k) {
  const Terms s=sample(t,c);
  if(std::fabs(s.x-x)<eps)return value(t,s,c);
  const float inv=1.f-t;
  const float a=inv*3.f;
  const float u2=inv*a;
  const float mid=(t*(inv*6.f))*c.dx;
  const float tt=t*(t*3.f);
  const float derivative=std::fma(tt,1.f-c.x2,std::fma(u2,c.x1,mid));
  if(std::fabs(derivative)<small)break;
  t=t-(s.x-x)/derivative;
  if(!(t>=0.f&&t<=1.f))break;
 }
 float lo=0.f,hi=1.f;t=x;
 for(int k=0;k<40;++k) {
  const Terms s=sample(t,c);
  if(std::fabs(s.x-x)<eps)return value(t,s,c);
  if(s.x<x)lo=t;else hi=t;
  t=(lo+hi)*.5f;
 }
 return value(t,sample(t,c),c);
}
}
extern "C" const char* hud_ammo_icon(std::int32_t id) {return recovered_hud::ammo_icon(id);}
extern "C" float hud_animation_curve(std::int32_t mode,float progress) {return recovered_hud::animation_curve(mode,progress);}
