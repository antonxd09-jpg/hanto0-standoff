#!/usr/bin/env python3
import argparse,json,struct,pathlib,hashlib,zlib,io
from elftools.elf.elffile import ELFFile
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('out');a=p.parse_args();out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
raw=pathlib.Path(a.input).read_bytes()
with open(a.input,'rb') as f:
 e=ELFFile(f);segs=[s for s in e.iter_segments() if s['p_type']=='PT_LOAD'];rels={r['r_offset']:r['r_addend'] for r in e.get_section_by_name('.rela.dyn').iter_relocations()}
 def read(addr,n):
  for s in segs:
   if s['p_vaddr']<=addr and addr+n<=s['p_vaddr']+s['p_filesz']:
    pos=addr-s['p_vaddr']+s['p_offset'];return raw[pos:pos+n]
  raise ValueError(hex(addr))
 def ptr(addr):return rels.get(addr,struct.unpack('<Q',read(addr,8))[0])
 def cstr(addr):
  b=read(addr,512);return b.split(b'\0',1)[0].decode('utf8')
 root=0x642eb60;nodesptr=ptr(root+8);count=ptr(root+16);nodes=[]
 for i in range(count):
  addr=nodesptr+128*i;b=read(addr,128);name=cstr(ptr(addr));parent,end=struct.unpack_from('<ii',b,8)
  fields=struct.unpack_from('<16f',b,20)
  nodes.append(dict(index=i,name=name,parent=parent,subtree_end=end,raw=b.hex(),anchor_min=list(fields[0:2]),anchor_max=list(fields[2:4]),anchored_position=list(fields[4:6]),size_delta=list(fields[6:8]),pivot=list(fields[8:10]),remaining_floats=list(fields[10:]),components=list(struct.unpack_from('<9i',b,88))))
 for n in nodes:n['path']=nodes[n['parent']]['path']+'/'+n['name'] if n['parent']>=0 else n['name']
 sprites=[];sp=ptr(root+0x70);sc=ptr(root+0x78)
 for i in range(sc):
  addr=sp+48*i;b=read(addr,48);vals=struct.unpack_from('<10f',b,8)
  sprites.append(dict(index=i,name=cstr(ptr(addr)),rect=list(vals[:4]),remaining_floats=list(vals[4:]),raw=b.hex()))
 ap=ptr(root+0x80);length=ptr(root+0x88);atlas=read(ap,length)
 image=Image.open(io.BytesIO(atlas));image.load();(out/'assets').mkdir(exist_ok=True);(out/'assets'/'atlas.png').write_bytes(atlas)
 for s in sprites:
  x,y,w,h=s['rect']
  if not all(v.is_integer() for v in [x,y,w,h]):continue
  x,y,w,h=map(int,(x,y,w,h))
  if not (x>=0 and y>=0 and w>0 and h>0 and x+w<=image.width and y+h<=image.height):raise ValueError(s)
  filename=s['name']+'.png';path=out/'assets'/filename;path.parent.mkdir(parents=True,exist_ok=True)
  image.crop((x,image.height-y-h,x+w,image.height-y)).save(path);s['file']='assets/'+filename
 (out/'nodes.json').write_text(json.dumps(nodes,ensure_ascii=False,indent=2))
 (out/'sprites.json').write_text(json.dumps(sprites,ensure_ascii=False,indent=2))
 # Every static image record is 52 bytes; node component 0 indexes this table.
 images=[]
 for i in range(170):
  addr=ptr(root+0x18)+i*52;b=read(addr,52)
  images.append(dict(index=i,sprite_index=struct.unpack_from('<i',b)[0],color=list(struct.unpack_from('<4f',b,4)),raw=b.hex()))
 (out/'images.json').write_text(json.dumps(images,indent=2))
 # Text accessor 0x2504e4 copies 80-byte records at 0x64276b8, count 234.
 texts=[]
 for i in range(234):
  addr=0x64276b8+i*80;b=read(addr,80);textptr=ptr(addr+64)
  texts.append(dict(index=i,font_index=struct.unpack_from('<i',b)[0],font_size=struct.unpack_from('<f',b,4)[0],color=list(struct.unpack_from('<4f',b,48)),text=cstr(textptr) if textptr else '',raw=b.hex()))
 (out/'texts.json').write_text(json.dumps(texts,ensure_ascii=False,indent=2))
 fonts=[];addr=root+0xb8
 while addr in rels:
  name=cstr(ptr(addr))
  if not name.endswith(('.otf','.ttf')):break
  index=ptr(addr+8);data=read(ptr(addr+16),ptr(addr+24));unpacked=zlib.decompress(data)
  assert len(unpacked)==ptr(addr+32)
  folder=out/'assets'/'fonts';folder.mkdir(exist_ok=True)
  (folder/name).write_bytes(unpacked)
  fonts.append(dict(index=index,name=name,file='assets/fonts/'+name,size=len(unpacked),sha256=hashlib.sha256(unpacked).hexdigest()))
  addr+=40
 (out/'fonts.json').write_text(json.dumps(fonts,indent=2))
 components={}
 for typ,offset,stride in [(0,0x18,52),(3,0x30,36),(4,0x38,36),(5,0x40,12),(6,0x48,8),(7,0x50,3)]:
  count_records=max(n['components'][typ] for n in nodes)+1
  table=ptr(root+offset)
  components[str(typ)]=dict(address=table,stride=stride,count=count_records,records=[read(table+i*stride,stride).hex() for i in range(count_records)])
 (out/'component_tables.json').write_text(json.dumps(components,indent=2))
 language_count=ptr(root+0xa0);languages=[cstr(ptr(ptr(root+0x98)+i*8)) for i in range(language_count)]
 translations=[]
 for i in range(ptr(root+0xb0)):
  table=ptr(root+0xa8)+i*(language_count+1)*8
  translations.append(dict(key=cstr(ptr(table)),values={lang:cstr(ptr(table+(j+1)*8)) for j,lang in enumerate(languages)}))
 (out/'translations.json').write_text(json.dumps(translations,ensure_ascii=False,indent=2))
 meta=dict(input_sha256=hashlib.sha256(raw).hexdigest(),schema_va=root,node_count=count,sprite_count=sc,atlas_va=ap,atlas_length=length,atlas_sha256=hashlib.sha256(atlas).hexdigest(),atlas_dimensions=list(image.size),warning='Node field names are inferred; raw records preserved. Sprite crops use Unity bottom-left rect coordinates.')
 (out/'extraction.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
 print('Images',len(images),'Text styles',len(texts),'Fonts',len(fonts))
 for n in nodes:
  if n['parent']==-1:print('ROOT',n['index'],n['name'],'end',n['subtree_end'])
