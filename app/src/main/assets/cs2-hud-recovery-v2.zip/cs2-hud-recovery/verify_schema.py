import ctypes,json,pathlib,struct,subprocess,sys
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
r=pathlib.Path(__file__).resolve().parent
src=pathlib.Path(sys.argv[1])
subprocess.run(['c++','-std=c++17','-O2','-shared','-fPIC',str(r/'ui_schema.cpp'),str(r/'ui_data.cpp'),'-o',str(r/'ui_schema.host.so')],check=True)
lib=ctypes.CDLL(str(r/'ui_schema.host.so'));lib.hud_find_path.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_size_t];lib.hud_find_path.restype=ctypes.c_int
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
with src.open('rb') as f:
 e=ELFFile(f)
 for name in ['.text','.rodata','.data.rel.ro']:
  sec=e.get_section_by_name(name);a=sec['sh_addr'];data=sec.data()
  if name=='.rodata':data=data[:0x90000]
  start=a&~4095;length=((a-start+len(data)+4095)//4096)*4096
  u.mem_map(start,length);u.mem_write(a,data)
  if name=='.data.rel.ro':dlo,dhi=a,a+len(data)
 for rel in e.get_section_by_name('.rela.dyn').iter_relocations():
  a=rel['r_offset']
  if dlo<=a<dhi and rel['r_info_type']==1027:u.mem_write(a,struct.pack('<Q',rel['r_addend']))
u.mem_map(0x10000000,0x10000);stop=0x1000f000
hooks=0
def cstr(a):
 b=bytes(u.mem_read(a,1024));return b.split(b'\0',1)[0]
def hook(uc,address,size,data):
 global hooks
 a,b,n=[uc.reg_read(reg) for reg in [UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2]]
 if address==0x67f6f0:result=len(cstr(a))
 elif address==0x67f6e0:
  chunk=bytes(uc.mem_read(a,n));pos=chunk.find(bytes([b&255]));result=a+pos if pos>=0 else 0
 elif address==0x67f6c0:
  left=bytes(uc.mem_read(a,n));right=bytes(uc.mem_read(b,n));result=next((x-y for x,y in zip(left,right) if x!=y),0)
 else:raise ValueError(hex(address))
 uc.reg_write(UC_ARM64_REG_X0,result&0xffffffffffffffff);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30));hooks+=1
for a in [0x67f6f0,0x67f6e0,0x67f6c0]:u.hook_add(UC_HOOK_CODE,hook,begin=a,end=a)
nodes=json.loads((r/'nodes.json').read_text());cases=0
for node in nodes:
 root=node
 while root['parent']>=0:root=nodes[root['parent']]
 relative=node['path'][len(root['name']):].lstrip('/')
 for path in [relative,relative+'/' if relative else '',relative+'/__missing__']:
  b=path.encode();ptr=ctypes.create_string_buffer(b);u.mem_write(0x10000000,b+b'\0')
  for reg,v in [(UC_ARM64_REG_X0,0x642eb60),(UC_ARM64_REG_X1,root['index']),(UC_ARM64_REG_X2,0x10000000),(UC_ARM64_REG_X3,len(b)),(UC_ARM64_REG_X30,stop),(UC_ARM64_REG_SP,0x1000e000)]:u.reg_write(reg,v)
  u.emu_start(0x22a934,stop,count=100000)
  assert u.reg_read(UC_ARM64_REG_PC)==stop
  expected=ctypes.c_int32(u.reg_read(UC_ARM64_REG_W0)).value;actual=lib.hud_find_path(root['index'],ptr,len(b))
  assert actual==expected,(node['path'],path,actual,expected)
  cases+=1
result={'status':'passed','schema_nodes':len(nodes),'path_differential_cases':cases,'original_function':'0x22a934','method':'C++ lookup compared against original ARM64; memchr/strlen/memcmp supplied by bounded Python hooks','libc_hook_calls':hooks,'limitations':['No Android runtime/UI render comparison','Out-of-range positive root indexes not passed to original because original does not validate them']}
(r/'schema_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
