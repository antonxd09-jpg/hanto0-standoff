import json,pathlib,hashlib
from PIL import Image,ImageFont
r=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((r/(n+'.json')).read_text())
nodes,sprites,images,texts,fonts=[read(n) for n in ['nodes','sprites','images','texts','fonts']]
for n in nodes:
 i=n['index'];assert i<n['subtree_end']<=len(nodes)
 if n['parent']>=0:assert n['parent']<i<nodes[n['parent']]['subtree_end']
 assert n['components'][0]<len(images)
 assert n['components'][2]<len(texts)
for x in images:assert -1<=x['sprite_index']<len(sprites)
for t in texts:assert 0<=t['font_index']<len(fonts)
atlas=Image.open(r/'assets/atlas.png').convert('RGBA')
for s in sprites:
 x,y,w,h=map(int,s['rect']);crop=Image.open(r/s['file']).convert('RGBA')
 assert crop.size==(w,h)
 assert crop.tobytes()==atlas.crop((x,atlas.height-y-h,x+w,atlas.height-y)).tobytes()
for f in fonts:
 b=(r/f['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'];assert len(b)==f['size']
 ImageFont.truetype(str(r/f['file']),20)
result=dict(status='passed',nodes=len(nodes),sprites_with_exact_atlas_pixels=len(sprites),fonts_opened=len(fonts),image_records=len(images),text_records=len(texts),translations=len(read('translations')),limits=['Static checks only; no game renderer or live HUD test'])
(r/'resource_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
