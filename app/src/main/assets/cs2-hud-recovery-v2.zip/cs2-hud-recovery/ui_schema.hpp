#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>
namespace recovered_hud {
struct Vec2 { float x,y; };
struct NodeData {
 std::string_view name; std::int32_t parent,subtree_end;
 bool active; Vec2 anchor_min,anchor_max,position,size,pivot;
 std::array<std::int32_t,9> components;
};
struct SpriteData {std::string_view name;float x,y,width,height;};
struct ImageData {std::int32_t sprite;std::array<float,4> color;};
struct TextData {std::int32_t font;float size;std::array<float,4> color;std::string_view text;};
extern const std::array<NodeData,524> nodes;
extern const std::array<SpriteData,105> sprites;
extern const std::array<ImageData,170> images;
extern const std::array<TextData,234> texts;
std::int32_t find_template(std::string_view name) noexcept;
std::int32_t find_path(std::int32_t root,std::string_view path) noexcept;
std::int32_t find_sprite(std::string_view name) noexcept;
}
extern "C" int hud_find_path(int root,const char* path,std::size_t length);
