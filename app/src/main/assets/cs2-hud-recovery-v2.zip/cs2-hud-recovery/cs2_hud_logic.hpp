#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
namespace recovered_hud {
struct Color { float r,g,b,a; };
struct Binding { std::uint32_t object_offset; const char* path; };
extern const std::array<std::uint32_t,11> palette_rgba;
Color decode_rgba(std::uint32_t packed) noexcept;
const char* ammo_icon(std::int32_t weapon_id) noexcept;
float animation_curve(std::int32_t mode,float progress) noexcept;
extern const Binding bottom_bindings[];
extern const std::size_t bottom_binding_count;
}
extern "C" {
const char* hud_ammo_icon(std::int32_t id);
float hud_animation_curve(std::int32_t mode,float progress);
}
