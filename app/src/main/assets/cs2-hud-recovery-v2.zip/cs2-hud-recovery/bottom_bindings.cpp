#include "cs2_hud_logic.hpp"
namespace recovered_hud {
// Relative to Bottom, as passed to sub_23cbf0 in sub_254eb8.
const Binding bottom_bindings[] = {
 {0x1f0, ""},
 {0x1f8, "Gradient"},
 {0x200, "Strip"},
 {0x208, "Strip/Cards"},
 {0x210, "Strip/Cards/Extra"},
 {0x218, "Strip/Cards/Extra/Art"},
 {0x220, "Strip/Cards/Extra/Count"},
 {0x228, "Strip/StripeL"},
 {0x230, "Strip/StripeR"},
 {0x238, "Strip/Circle/LogoCt"},
 {0x240, "Strip/Circle/LogoT"},
 {0x248, "Strip/Health"},
 {0x250, "Strip/Health/ValueGlow"},
 {0x258, "Strip/Health/Value"},
 {0x260, "Strip/Health/Ghost"},
 {0x268, "Strip/Health/Ghost/Glow"},
 {0x270, "Strip/Health/Ghost/Value"},
 {0x278, "Strip/Health/Bar"},
 {0x280, "Strip/Health/Bar/Fill"},
 {0x288, "Strip/Armor"},
 {0x290, "Strip/Armor/Icon"},
 {0x298, "Strip/Armor/Value"},
 {0x2a0, "Strip/Ammo"},
 {0x2a8, "Strip/Ammo/ClipGlow"},
 {0x2b0, "Strip/Ammo/Clip"},
 {0x2b8, "Strip/Ammo/ClipBar"},
 {0x2c0, "Strip/Ammo/ClipBar/Fill"},
 {0x2c8, "Strip/Ammo/Reserve"},
 {0x2d0, "Strip/Ammo/ReserveIcon"},
 {0x11f0, "Strip/Ammo/ClipGlow/D3"},
 {0x1258, "Strip/Ammo/ClipBarGlow"},
};
const std::size_t bottom_binding_count=sizeof(bottom_bindings)/sizeof(bottom_bindings[0]);
}
