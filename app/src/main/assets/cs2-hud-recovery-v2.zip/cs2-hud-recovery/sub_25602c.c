typedef struct st_25602c_1 {
    char padding_0[1286];
    char field_506;
    char padding_507[13];
    unsigned int field_514;
    unsigned int field_518;
    char field_51c;
    char padding_51d[3];
    int field_520;
    unsigned int field_524;
    char field_528;
    char padding_529[3];
    unsigned int field_52c;
    int field_530;
    unsigned int field_534;
    unsigned int field_538;
    unsigned int field_53c;
    char padding_540[168];
    unsigned int field_5e8;
    unsigned int field_5ec;
    unsigned int field_5f0;
    int field_5f4;
    int field_5f8;
    int field_5fc;
    int field_600;
    int field_604;
} st_25602c_1;

typedef struct st_25602c_10 {
    char padding_0[196];
    unsigned int field_c4;
} st_25602c_10;

typedef struct st_25602c_3 {
    char padding_0[12];
    float field_c;
    float field_10;
    unsigned int field_14;
} st_25602c_3;

typedef struct st_25602c_7 {
    char padding_0[32];
    unsigned int field_20;
} st_25602c_7;

typedef struct st_25602c_4 {
    char padding_0[24];
    float field_18;
    float field_1c;
    unsigned int field_20;
} st_25602c_4;

typedef struct st_25602c_6 {
    char padding_0[36];
    unsigned int field_24;
} st_25602c_6;

typedef struct st_25602c_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_25602c_0;

typedef struct st_25602c_5 {
    char padding_0[36];
    float field_24;
    float field_28;
    unsigned int field_2c;
} st_25602c_5;

typedef struct st_25602c_9 {
    char padding_0[72];
    unsigned int field_48;
} st_25602c_9;

typedef struct st_25602c_8 {
    char padding_0[112];
    unsigned int field_70;
} st_25602c_8;

typedef struct st_25602c_2 {
    float field_0;
    float field_4;
    unsigned int field_8;
} st_25602c_2;

unsigned long long sub_25602c(void* a0, st_25602c_1 *a1, float a2, float a3)
{
    st_25602c_0 *v24;  // tpidr_el0
    long long v25;  // x22
    unsigned long long v34;  // x23
    float v124;  // s1
    unsigned long v125;  // x11
    unsigned int v126;  // w12
    st_25602c_4 *v127;  // x10
    float v128;  // s2
    float v129;  // s4
    unsigned int v130;  // s3
    unsigned long v131;  // x10
    unsigned int v132;  // w11
    st_25602c_5 *v133;  // x11
    unsigned long v35;  // x22
    float v134;  // s3
    unsigned int v135;  // s2
    unsigned long v136;  // x11
    unsigned int v137;  // w12
    unsigned int v138;  // s3
    unsigned int *v139;  // x8
    unsigned int v140;  // s1
    unsigned int v141;  // s2
    unsigned int v142;  // w9
    unsigned long v143;  // x8
    unsigned long long v36;  // x0
    unsigned long v144;  // x9
    int v145;  // w8
    unsigned long long *v146;  // x21
    int v147;  // w8
    int v148;  // w8
    int v149;  // w8
    int v150;  // w8
    unsigned int v151;  // w8
    unsigned long v152;  // x0
    unsigned long v153;  // x22
    unsigned long long v37;  // x0
    float v154;  // s13
    float v155;  // s0
    unsigned long long v156;  // 4132
    float v157;  // s1
    unsigned long long v158;  // 4138
    float v159;  // s0
    unsigned long long v160;  // 4129
    float v161;  // s2
    float v162;  // s1
    unsigned long long v163;  // 4143
    long long v38;  // x0
    float v164;  // s0
    unsigned int v165;  // w8
    unsigned long long v166;  // 4137
    unsigned long v167;  // x9
    unsigned int *v168;  // x8
    unsigned int *v169;  // x12
    float v170;  // s0
    unsigned long long v171;  // 4132
    long long v172;  // x11
    unsigned int *node;  // x10
    float v39;  // s1
    unsigned long v174;  // x13
    unsigned long v175;  // x13
    float v176;  // s0
    unsigned long long v177;  // 4129
    float v178;  // s3
    float v179;  // s0
    unsigned long long v180;  // 4156
    unsigned long long v181;  // x22
    unsigned long v182;  // x23
    void* v183;  // x8
    float v40;  // s0
    float v184;  // s0
    unsigned long long v185;  // 4146
    float v186;  // s1
    unsigned long long v187;  // 4129
    float v188;  // s2
    float v189;  // s0
    unsigned long long v190;  // 4143
    float v191;  // s0
    unsigned int v192;  // w9
    unsigned long long v193;  // 4137
    unsigned int v41;  // s2
    void* v194;  // x8
    __m128 v195;  // q1
    float v196;  // s3
    __m128 v197;  // q2
    float v198;  // s4
    float v200;  // s0
    unsigned long v201;  // x9
    void* v202;  // x8
    void* v203;  // x28
    unsigned int v42;  // s3
    void* v204;  // x21
    __m128 v205;  // q0
    unsigned int v206;  // s2
    float v208;  // s1
    unsigned long long v209;  // 4142
    unsigned long long v210;  // 4127
    float v211;  // s0
    unsigned long long v212;  // 4149
    unsigned long long v213;  // 4134
    void* v43;  // x22
    float v214;  // s0
    __m128 v215;  // q12
    unsigned long long v216;  // 4140
    float v217;  // s2
    unsigned long long v218;  // 4138
    float v219;  // s0
    unsigned long long v220;  // 4129
    float v221;  // s3
    float v222;  // s2
    unsigned long long v223;  // 4143
    float v26;  // s0
    float v44;  // s0
    float v224;  // s0
    unsigned int v225;  // w8
    unsigned long long v226;  // 4137
    unsigned long v227;  // x9
    unsigned int *v228;  // x8
    unsigned int *v229;  // x12
    float v230;  // s0
    unsigned long long v231;  // 4132
    long long v232;  // x11
    unsigned int *iter;  // x10
    unsigned long long v45;  // 4142
    unsigned long v234;  // x13
    unsigned long v235;  // x13
    float v236;  // s0
    unsigned long long v237;  // 4129
    float v238;  // s3
    float v239;  // s0
    unsigned long long v240;  // 4156
    float v241;  // s0
    unsigned long long v242;  // 4132
    float v243;  // s2
    unsigned int v46;  // w8
    unsigned long long v244;  // 4138
    float v245;  // s0
    unsigned long long v246;  // 4129
    float v247;  // s3
    float v248;  // s2
    unsigned long long v249;  // 4143
    float v250;  // s0
    unsigned int v251;  // w8
    unsigned long long v252;  // 4137
    unsigned long v253;  // x9
    unsigned int v47;  // w0
    unsigned int *v254;  // x12
    float v255;  // s0
    unsigned long long v256;  // 4132
    long long v257;  // x11
    unsigned int *iter1;  // x10
    unsigned long v259;  // x13
    unsigned long v260;  // x13
    float v261;  // s0
    unsigned long long v262;  // 4129
    float v263;  // s3
    unsigned int v48;  // w0
    unsigned long long v264;  // 4156
    unsigned long v265;  // x21
    unsigned int *iter2;  // x26
    unsigned int v267;  // w22
    unsigned int v268;  // s9
    uint128_t v269;  // q0
    float v270;  // s0
    __m128 v271;  // q2
    unsigned int v272;  // w8
    unsigned long v273;  // x8
    unsigned int v49;  // w0
    unsigned int v274;  // w21
    unsigned int v275;  // w8
    unsigned long v276;  // x22
    float v277;  // s0
    float v278;  // s11
    unsigned long long v279;  // 4133
    float v280;  // s0
    unsigned long long v281;  // 4142
    float v282;  // s1
    unsigned long long v283;  // 4129
    unsigned int v50;  // w0
    float v284;  // s0
    unsigned long long v285;  // 4142
    float v286;  // s0
    unsigned int v287;  // w8
    unsigned long long v288;  // 4137
    unsigned int v289;  // w22
    unsigned long v290;  // x9
    unsigned int *v291;  // x12
    float v292;  // s0
    unsigned long long v293;  // 4132
    unsigned int v51;  // w0
    long long v294;  // x11
    st_25602c_6 *v295;  // x10
    unsigned long v296;  // x13
    unsigned long v297;  // x13
    float v298;  // s0
    unsigned long long v299;  // 4129
    float v300;  // s2
    unsigned long long v301;  // 4160
    unsigned long v302;  // x8
    unsigned int *v303;  // x22
    unsigned int v52;  // w0
    unsigned long long v304;  // 4108
    float v305;  // s0
    unsigned long long v306;  // 4129
    long long v307;  // x11
    st_25602c_7 *v308;  // x10
    unsigned long v309;  // x12
    unsigned long v310;  // x12
    float v311;  // s0
    unsigned long long v312;  // 4129
    float v313;  // s2
    unsigned int v53;  // w0
    unsigned long long v314;  // 4156
    float v315;  // s0
    unsigned long long v316;  // 4129
    long long v317;  // x11
    st_25602c_8 *v318;  // x10
    unsigned long long v319;  // x13
    unsigned long long v320;  // x13
    float v321;  // s0
    unsigned long long v322;  // 4129
    float v323;  // s2
    unsigned long long v27;  // 4129
    unsigned int v54;  // w0
    unsigned long long v324;  // 4156
    float v325;  // s0
    unsigned long long v326;  // 4129
    long long v327;  // x10
    st_25602c_9 *v328;  // x8
    unsigned long long v329;  // x12
    unsigned long long v330;  // x12
    float v331;  // s0
    unsigned long long v332;  // 4129
    float v333;  // s2
    unsigned int v55;  // w0
    unsigned long long v334;  // 4156
    float v335;  // s0
    unsigned long long v336;  // 4136
    float v337;  // s1
    unsigned long long v338;  // 4138
    float v339;  // s0
    unsigned long long v340;  // 4129
    float v341;  // s1
    float v342;  // s2
    unsigned long long v343;  // 4143
    unsigned int v56;  // w0
    float v344;  // s0
    unsigned int v345;  // w8
    unsigned long long v346;  // 4137
    unsigned long v347;  // x22
    unsigned long v348;  // x9
    float v349;  // s4
    unsigned int *v350;  // x12
    float v351;  // s0
    unsigned long long v352;  // 4132
    long long v353;  // x11
    unsigned int v57;  // w0
    unsigned int *v354;  // x10
    unsigned long v355;  // x13
    unsigned long v356;  // x13
    float v357;  // s0
    unsigned long long v358;  // 4129
    float v359;  // s2
    unsigned long long v360;  // 4166
    float v361;  // s3
    unsigned long long v362;  // 4130
    float v363;  // s0
    unsigned int v58;  // w0
    unsigned long long v364;  // 4134
    unsigned long long v365;  // 4125
    unsigned int v366;  // w8
    float v367;  // s2
    unsigned long long v368;  // 4164
    unsigned long v369;  // x9
    float v370;  // s3
    unsigned int *v371;  // x12
    float v372;  // s0
    unsigned long long v373;  // 4132
    unsigned int v59;  // w0
    long long v374;  // x11
    st_25602c_8 *v375;  // x10
    unsigned long v376;  // x13
    unsigned long v377;  // x13
    float v378;  // s0
    unsigned long long v379;  // 4129
    float v380;  // s2
    unsigned long long v381;  // 4160
    float v382;  // s1
    unsigned long long v383;  // 4135
    unsigned int v60;  // w0
    float v384;  // s1
    unsigned long long v385;  // 4138
    float v386;  // s2
    unsigned long long v387;  // 4129
    float v388;  // s10
    float v389;  // s0
    unsigned long long v390;  // 4144
    float v391;  // s1
    unsigned int v392;  // w8
    unsigned long long v393;  // 4138
    unsigned int v61;  // w0
    unsigned long v394;  // x8
    unsigned long long v395;  // 4105
    unsigned int *v396;  // x12
    float v397;  // s0
    unsigned long long v398;  // 4132
    long long v399;  // x11
    st_25602c_7 *v400;  // x10
    unsigned long v401;  // x13
    unsigned long v402;  // x13
    float v403;  // s0
    unsigned int v62;  // w0
    unsigned long long v404;  // 4129
    float v405;  // s2
    unsigned long long v406;  // 4156
    unsigned int *v407;  // x22
    float v408;  // s0
    unsigned long long v409;  // 4129
    long long v410;  // x11
    unsigned int *v411;  // x10
    unsigned long long v412;  // x13
    unsigned long long v413;  // x13
    unsigned long long i;  // x26
    float v414;  // s0
    unsigned long long v415;  // 4129
    float v416;  // s2
    unsigned long long v417;  // 4156
    float v418;  // s0
    unsigned long long v419;  // 4129
    long long v420;  // x10
    unsigned int *v421;  // x8
    unsigned long long v422;  // x12
    unsigned long long v423;  // x12
    long long v28;  // x0
    unsigned int v64;  // w21
    float v424;  // s0
    unsigned long long v425;  // 4129
    float v426;  // s2
    unsigned long long v427;  // 4156
    unsigned long v428;  // x9
    unsigned int *v429;  // x12
    float v430;  // s0
    unsigned long long v431;  // 4132
    long long v432;  // x11
    st_25602c_6 *v433;  // x10
    void* v65;  // x27
    unsigned long v434;  // x13
    unsigned long v435;  // x13
    float v436;  // s0
    unsigned long long v437;  // 4129
    float v438;  // s2
    unsigned long long v439;  // 4156
    unsigned int v440;  // w21
    unsigned long v441;  // x9
    unsigned int v442;  // w8
    unsigned long v443;  // x1
    unsigned int v66;  // w0
    unsigned long v444;  // x22
    float v445;  // s0
    __m128 v446;  // q11
    unsigned long long v447;  // 4132
    float v448;  // s0
    unsigned long long v449;  // 4138
    float v450;  // s1
    unsigned long long v451;  // 4129
    float v452;  // s10
    float v453;  // s0
    unsigned int v67;  // w0
    unsigned long long v454;  // 4143
    float v455;  // s0
    unsigned int v456;  // w8
    unsigned long long v457;  // 4137
    unsigned long v458;  // x8
    unsigned long long v459;  // 4107
    unsigned int *v460;  // x11
    float v461;  // s0
    unsigned long long v462;  // 4134
    long long v463;  // x12
    unsigned int v68;  // w0
    unsigned long v464;  // x13
    st_25602c_8 *v465;  // x10
    unsigned long v466;  // x13
    float v467;  // s0
    unsigned long long v468;  // 4129
    float v469;  // s2
    unsigned long long v470;  // 4156
    float v471;  // s0
    unsigned long long v472;  // 4129
    long long v473;  // x10
    unsigned int v69;  // w0
    st_25602c_9 *v474;  // x8
    unsigned long long v475;  // x13
    unsigned long long v476;  // x13
    float v477;  // s0
    unsigned long long v478;  // 4129
    float v479;  // s2
    unsigned long long v480;  // 4156
    unsigned long v481;  // x9
    unsigned int *v482;  // x11
    float v483;  // s0
    unsigned int v70;  // w28
    unsigned long long v484;  // 4134
    long long v485;  // x12
    unsigned long v486;  // x13
    st_25602c_7 *v487;  // x10
    unsigned long v488;  // x13
    float v489;  // s0
    unsigned long long v490;  // 4129
    float v491;  // s2
    unsigned long long v492;  // 4156
    __m128 v493;  // q11
    unsigned int v71;  // w21
    unsigned int v494;  // s0
    uint128_t v496;  // q1
    unsigned long v497;  // x21
    unsigned long long v498;  // x0
    unsigned int v499;  // w8
    unsigned long v500;  // x10
    unsigned int v501;  // w9
    unsigned long long v502;  // 4102
    unsigned int v503;  // w9
    unsigned int v72;  // w9
    unsigned long v504;  // x21
    unsigned int v505;  // w10
    unsigned long long *v506;  // x8
    void* v507;  // x8
    float v508;  // s1
    unsigned long long v509;  // 4142
    float v510;  // s1
    unsigned long long v511;  // 4138
    float v512;  // s2
    unsigned long long v513;  // 4129
    unsigned long v73;  // x23
    float v514;  // s3
    float v515;  // s1
    unsigned long long v516;  // 4143
    float v517;  // s1
    unsigned int v518;  // w8
    unsigned long long v519;  // 4137
    unsigned long v520;  // x9
    unsigned int *v521;  // x12
    float v522;  // s0
    unsigned long long v523;  // 4132
    long long v29;  // x22
    unsigned int v74;  // w8
    long long v524;  // x11
    st_25602c_10 *v525;  // x10
    unsigned long v526;  // x13
    unsigned long v527;  // x13
    float v528;  // s0
    unsigned long long v529;  // 4129
    float v530;  // s3
    unsigned long long v531;  // 4156
    unsigned long v532;  // x0
    unsigned int v533;  // w21
    unsigned int v75;  // w26
    int v534;  // w8
    unsigned long long v537;  // 4174
    unsigned long v538;  // x22
    float v539;  // s0
    unsigned long long v540;  // 4136
    float v541;  // s1
    unsigned long long v542;  // 4138
    float v543;  // s0
    unsigned long long v76;  // x25
    unsigned long long v544;  // 4129
    float v545;  // s9
    float v546;  // s1
    unsigned long long v547;  // 4143
    float v548;  // s0
    unsigned int v549;  // w8
    unsigned long long v550;  // 4137
    unsigned long v551;  // x9
    unsigned int *v552;  // x12
    float v553;  // s0
    float v77;  // s9
    unsigned long long v554;  // 4132
    long long v555;  // x11
    st_25602c_6 *v556;  // x10
    unsigned long v557;  // x13
    unsigned long v558;  // x13
    float v559;  // s0
    unsigned long long v560;  // 4129
    float v561;  // s2
    unsigned long long v562;  // 4160
    unsigned long v563;  // x8
    long long v78;  // x27
    unsigned long long v564;  // 4105
    unsigned int *v565;  // x12
    float v566;  // s0
    unsigned long long v567;  // 4132
    long long v568;  // x11
    st_25602c_7 *v569;  // x10
    unsigned long v570;  // x13
    unsigned long v571;  // x13
    float v572;  // s0
    unsigned long long v573;  // 4129
    unsigned int *v79;  // x23
    float v574;  // s2
    unsigned long long v575;  // 4156
    unsigned int *v576;  // x22
    float v577;  // s0
    unsigned long long v578;  // 4129
    long long v579;  // x11
    st_25602c_8 *v580;  // x10
    unsigned long long v581;  // x13
    unsigned long long v582;  // x13
    float v583;  // s0
    float v80;  // s12
    unsigned long long v584;  // 4129
    float v585;  // s2
    unsigned long long v586;  // 4156
    float v587;  // s0
    unsigned long long v588;  // 4129
    long long v589;  // x10
    st_25602c_9 *v590;  // x8
    unsigned long long v591;  // x12
    unsigned long long v592;  // x12
    float v593;  // s0
    float v81;  // s11
    unsigned long long v594;  // 4129
    float v595;  // s2
    unsigned long long v596;  // 4156
    unsigned long v597;  // x0
    unsigned long v598;  // x21
    float v599;  // s1
    unsigned long long v600;  // 4133
    float v601;  // s1
    unsigned long long v602;  // 4138
    float v603;  // s2
    float v82;  // s10
    unsigned long long v604;  // 4129
    float v605;  // s0
    float v606;  // s1
    unsigned long long v607;  // 4143
    float v608;  // s1
    unsigned int v609;  // w8
    unsigned long long v610;  // 4138
    unsigned long v611;  // x9
    unsigned int *v612;  // x12
    float v613;  // s0
    void* v83;  // x24
    unsigned long long v614;  // 4132
    long long v615;  // x11
    st_25602c_10 *v616;  // x10
    unsigned long v617;  // x13
    unsigned long v618;  // x13
    float v619;  // s0
    unsigned long long v620;  // 4129
    float v621;  // s3
    unsigned long long v622;  // 4156
    unsigned long v30;  // x0
    void* v84;  // x22
    float v85;  // s0
    unsigned long long v86;  // 4145
    float v87;  // s1
    unsigned long long v88;  // 4129
    float v89;  // s2
    float v90;  // s0
    unsigned long long v91;  // 4143
    float v92;  // s0
    unsigned int v93;  // w8
    unsigned long v31;  // x8
    unsigned long long v94;  // 4137
    unsigned int v95;  // w10
    void* v96;  // x9
    void* v97;  // x8
    __m128 v98;  // q2
    float v99;  // s3
    __m128 v100;  // q1
    float v101;  // s4
    void* v103;  // x8
    long long v32;  // x0
    unsigned long v104;  // x9
    unsigned int v105;  // w10
    unsigned int v106;  // w8
    unsigned int v107;  // w8
    unsigned long long v108;  // 4174
    unsigned long long v109;  // 4108
    unsigned int v110;  // w8
    float v111;  // s0
    unsigned long long v112;  // 4151
    float v113;  // s1
    unsigned long v33;  // x0
    float v114;  // s2
    float v115;  // s3
    unsigned int v116;  // s4
    unsigned int v117;  // w8
    st_25602c_2 *v118;  // x10
    unsigned long v119;  // x10
    unsigned int v120;  // w11
    st_25602c_3 *v121;  // x11
    float v122;  // s3
    unsigned int v123;  // s2
    unsigned int v0;  // [bp-0x164]
    unsigned int v1;  // [bp-0x160], Other Possible Types: unsigned long
    unsigned int v2;  // [bp-0x158]
    unsigned int v3;  // [bp-0x154]
    unsigned long v4;  // [bp-0x150]
    unsigned int v5;  // [bp-0x144]
    unsigned long v6;  // [bp-0x140]
    unsigned int v7;  // [bp-0x134]
    float v8;  // [bp-0x130]
    unsigned long v9;  // [bp-0x130]
    unsigned int v10;  // [bp-0x124]
    uint128_t v11;  // [bp-0x120], Other Possible Types: unsigned int, unsigned long
    float v12;  // [bp-0x120]
    unsigned int v13;  // [bp-0x104]
    long long v14;  // [bp-0xf8], Other Possible Types: unsigned long long
    void* v15;  // [bp-0xf0], Other Possible Types: unsigned int
    void* v16;  // [bp-0xe8], Other Possible Types: unsigned long
    uint128_t v17;  // [bp-0xe0], Other Possible Types: unsigned long
    char v18;  // [bp-0xc8], Other Possible Types: unsigned long
    unsigned long long v19;  // [bp-0xc0]
    long long v20;  // [bp-0xb8]
    unsigned long v21;  // [bp-0xb0]
    char *v22;  // [bp-0x60]
    char v23;  // [bp+0x0]

    v22 = &v23;
    v21 = v24->field_28;
    v16 = a0 + 240;
    v25 = (!(long long)a0[240] ? 0 : (long long)v16[8]);
    if (!(sub_198128(v25) & 1) || !v25)
    {
        v26 = __int_as_float((int)a0[440]);
        v27 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(v26), __float_as_int(a2))) >> 5 & 3 | v26 < a2) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v26, a2)) * 0x10000000, 0, 0);
        if (!(v27 & 1) && sub_22e288(a1) & 1)
        {
            *(float *)&a0[440] = a2 + 1.0f;
            sub_22f5c4(a1, v16);
            if (!(long long)a0[232])
                *(unsigned long long *)&a0[232] = sub_22dfb8(7098535);
            v28 = sub_22e050(a1);
            if (v28)
            {
                if ((!(long long)a0[240] ? 0 : (long long)a0[248]) != v28)
                {
                    v29 = v28;
                    v30 = sub_439970();
                    if (!v30)
                        goto LABEL_2561d0;
                    v31 = (long long)a0[240];
                    v32 = v29;
                    *(long long *)&a0[248] = 0;
                    if (v31)
                    {
                        *(unsigned long *)v16 = 0;
                        sub_439c54(v31);
                        v32 = v29;
                    }
                    *(unsigned long *)&a0[240] = v30;
                    *(long long *)&a0[248] = v32;
                }
                v33 = sub_197da4();
                v34 = (long long)a0[0x100];
                if ((!v34 ? 0 : (long long)a0[264]) != v33)
                {
                    v35 = v33;
                    if (v33)
                    {
                        v36 = sub_439970(v35);
                        if (!v36)
                            goto LABEL_2561d0;
                        v34 = v36;
                        v37 = (long long)a0[0x100];
                    }
                    else
                    {
                        v37 = v34;
                        v34 = 0;
                    }
                    *(unsigned long *)&a0[264] = 0;
                    if (v37)
                    {
                        *(unsigned long long *)&a0[0x100] = 0;
                        sub_439c54();
                    }
                    *(unsigned long long *)&a0[0x100] = v34;
                    *(unsigned long *)&a0[264] = v35;
                }
                else
                {
                    v35 = (long long)a0[264];
                }
                v38 = sub_197c20((!v34 ? 0 : v35), 7334264);
                if (v38)
                    sub_22ef70(a1, v16, v38, 0);
            }
        }
    }
LABEL_2561d0:
    v39 = a2 + a2;
    v40 = a2 - a3 + a2 - a3;
    if ((int)v39 != (int)v40)
        sub_22f40c(a1, v16);
    if ((int)a0[4504] != a1->field_514)
    {
        *(unsigned int *)&a0[4504] = a1->field_514;
        sub_23e358();
        *(float *)&a0[4508] = v40;
        *(float *)&a0[4512] = v39;
        *(unsigned int *)&a0[4516] = v41;
        *(unsigned int *)&a0[4520] = v42;
    }
    v43 = v16 + 3856;
    sub_22cf38(a1, (long long)a0[0x200]);
    if (a1->field_51c)
    {
        v44 = __int_as_float((int)a0[4496]);
        v13 = a1->field_506;
        v15 = v43;
        v45 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(v44), __float_as_int(a2))) >> 5 & 3 | v44 < a2) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v44, a2)) * 0x10000000, 0, 0);
        if (!(v45 & 1))
        {
            v46 = (char)v43[396];
            *(float *)&a0[4496] = a2 + 1.0f;
            if (!v46 || !(sub_24fd88() & 1))
            {
                v47 = sub_24f2f0();
                v1 = (long long)a0[640];
                v4 = (long long)a0[656];
                v6 = (long long)a0[664];
                v9 = (long long)a0[688];
                v11 = (long long)a0[704];
                v17 = (long long)a0[712];
                v14 = sub_23d928(a0 + 448, sub_23cbf0(7335019, 7201753, 0x11) & 0xffffffff);
                v10 = sub_24f5a4(a1, (long long)a0[552], 1);
                v7 = sub_24f5a4(a1, (long long)a0[560], 1);
                v5 = sub_24f5a4(a1, (long long)a0[568], 1);
                v3 = sub_24f5a4(a1, (long long)a0[576], 1);
                v2 = sub_24f5a4(a1, (long long)a0[600], 1);
                v0 = sub_24f5a4(a1, (long long)a0[624], 1);
                v1 = sub_24f5a4(a1, v1, 1);
                v48 = sub_24f5a4(a1, v4, 1);
                v49 = sub_24f5a4(a1, v6, 1);
                v50 = sub_24f5a4(a1, v9, 1);
                v51 = sub_24f5a4(a1, v11, 1);
                v52 = sub_24f5a4(a1, v17, 1);
                v53 = sub_24f5a4(a1, (long long)a0[720], 1);
                v54 = sub_24f5a4(a1, v14, 1);
                v55 = sub_24f5a4(a1, (long long)a0[4528], 1);
                v56 = sub_24f5a4(a1, (long long)a0[4536], 1);
                v57 = sub_24f5a4(a1, (long long)a0[4544], 1);
                v58 = sub_24f5a4(a1, (long long)a0[4552], 1);
                v59 = sub_24f5a4(a1, (long long)a0[4560], 1);
                v60 = sub_24f5a4(a1, (long long)a0[4568], 1);
                v61 = sub_24f5a4(a1, (long long)a0[4576], 1);
                v62 = sub_24f5a4(a1, (long long)a0[4584], 1);
                i = 0;
                v64 = v58 & v59 & v60 & v61 & v62 & sub_24f5a4(a1, (long long)a0[4592], 1) & v54 & v53 & v52 & v51 & v49 & v50 & v55 & v56 & v57 & v48 & v1 & v0 & v2 & v3 & v5 & v7 & v10 & v47;
                do
                {
                    v65 = a0 + i;
                    v66 = sub_24f5a4(a1, (long long)v65[0x300], 0);
                    v67 = sub_24f5a4(a1, (long long)v65[776], 0);
                    v68 = sub_24f5a4(a1, (long long)v65[784], 0);
                    v69 = sub_24f5a4(a1, (long long)v65[792], 0);
                    i += 128;
                    *(unsigned int *)&v65[804] = 0;
                    v64 &= v69 & v68 & v66 & v67;
                } while (i != 0x300);
                v43 = v15;
                *(unsigned int *)&a0[4488] = 0xfffffffe;
                *(char *)&v43[396] = (char)v64 & 1;
            }
        }
        v70 = a1->field_5ec;
        v71 = a1->field_5f0;
        v72 = (char)v43[404];
        v73 = a1->field_5e8;
        v74 = (char)v43[405];
        *(unsigned short *)&v43[404] = 1;
        if (v72 && !v74)
        {
            if ((unsigned int)v73 != (int)a0[4472])
            {
                v75 = (unsigned int)v73 - 1;
                v76 = 0;
                v77 = __int_as_float((5 < (int)(unsigned int)v73 ? 0 : -42.0f));
                v78 = 0;
                v17 = v73;
                v79 = 44368764 + v75 * 60 + 4;
                do
                {
                    v80 = __int_as_float(0);
                    v81 = __int_as_float(0);
                    v82 = v77;
                    if (v76 != 640)
                    {
                        v82 = -42.0f;
                        if (4 >= v75 && (int)v73 > v78)
                        {
                            v81 = *(float *)&v79[1];
                            v80 = *(float *)&*(int *)((char *)v79 - 4);
                            v82 = -*(float *)v79;
                        }
                    }
                    v83 = a0 + v76;
                    if ((int)v83[820] == v80 && (int)v83[824] == v82 && *(int *)((char *)a0 + v76 + 828) == v81)
                        continue;
                    v84 = v83 + 820;
                    v85 = a2 - (int)v83[844];
                    v86 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v85), 0.0f)) >> 5 & 3 | v85 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v85)) * 0x10000000, 0, 0);
                    if (v86 & 1 || (v87 = __int_as_float((int)a0[1756]), v88 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v87), 0.0f)) >> 5 & 3 | v87 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v87)) * 0x10000000, 0, 0), v88 & 1))
                    {
LABEL_256638:
                        v95 = (int)v84[8];
                        v96 = a0 + v76;
                        *(long long *)&v96[832] = *(long long *)v84;
                        *(unsigned int *)&v96[840] = v95;
                        goto LABEL_25664c;
                    }
                    else
                    {
                        v89 = v85 - (int)a0[1760];
                        v90 = 0;
                        v91 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v89), 0.0f)) >> 5 & 3 | v89 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v89)) * 0x10000000, 0, 0);
                        if (!(v91 & 1))
                        {
                            v92 = v89 / v87;
                            v93 = (int)a0[1768];
                            if ((int)v93 < 1 || (v94 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v92), __float_as_int((float)(int)v93))) >> 5 & 3 | v92 < (float)(int)v93) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v92, (float)(int)v93)) * 0x10000000, 0, 0), !(v94 & 1)))
                            {
                                v90 = v92 - floorf(v92);
                                goto LABEL_256740;
                            }
                            goto LABEL_256638;
                        }
                        else
                        {
LABEL_256740:
                            sub_254534((int)a0[1764]);
                            v97 = a0 + v76;
                            v98 = __double_as_longlong((double)v97[808]);
                            v99 = __int_as_float((int)v97[816]);
                            v100 = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_sub_ps(*(unsigned long long *)&*(double *)v84, v98));
                            v101 = __int_as_float((int)v97[828] - (int)v97[816]);
                            *(unsigned long long *)&v97[832] = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_add_ps(v98, _mm_mul_ps(v100, CONCAT(__float_as_int(v90) * 0x100000000 | __float_as_int(v90), __float_as_int(v90) * 0x100000000 | __float_as_int(v90)))));
                            *(float *)&v97[840] = v101 * v90 + v99;
LABEL_25664c:
                            v103 = a0 + v76;
                            *(float *)v84 = v80;
                            v104 = (long long)v103[832];
                            v105 = (int)v103[840];
                            *(float *)&v103[824] = v82;
                            *(float *)&v103[828] = v81;
                            *(unsigned long *)&v103[808] = v104;
                            *(unsigned int *)&v103[816] = v105;
                            *(float *)&v83[844] = a2;
                        }
                    }
                } while ((v76 += 128, v78 += 1, v79 += 3, v76 != 0x300));
                v73 = v17;
                if ((int)v73 > (int)a0[4472])
                {
                    *(float *)&a0[4400] = a2;
                    *(float *)&a0[4396] = a2;
                    *(unsigned int *)&a0[4484] = (5 < (int)v73 ? 5 : v75);
                    if (a1->field_506)
                    {
                        v106 = ((int)v70 < (int)v73 ? 0 : v71);
                        sub_28d8e0(v73 & 0xffffffff, (v106 == 2 ? 3 : v106 == 3 ? 4 : 1));
                    }
                    v107 = v71 & 0xfffffffe;
                    *(float *)&a0[4480] = a2;
                    v108 = arm64g_calculate_condition((v107 == 2 ? 3 : 0) | 160, (v107 == 2 ? v70 : 0x80000000), (v107 == 2 ? v73 & 0xffffffff : 0), 0);
                    *(unsigned int *)&a0[4476] = (v108 & 1 ? 0 : (unsigned int)v73);
                }
                else
                {
                    v109 = arm64g_calculate_condition(163, v73 & 0xffffffff, (int)a0[4472], 0);
                    if (!(v109 & 1))
                        sub_28dd44();
                }
                *(unsigned int *)&a0[4472] = v73;
            }
            if (a1->field_506 && !(v110 = (int)a0[4476], (int)v73 < (int)v110))
            {
                if (v110 && (int)v70 >= (int)v110 && (v71 >> 1 & 0x7fffffff) == 1)
                {
                    sub_28deb8((v71 == 2 ? 3 : 4));
                }
                else if (!(v110 && !(v111 = a2 - (int)a0[4480], v112 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v111), 0.15000000596046448f)) >> 5 & 3 | v111 < 0.15000000596046448f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v111)) * 0x10000000, 0, 0), !(v112 & 1))))
                {
                    goto LABEL_256a1c;
                }
            }
        }
        else
        {
            v113 = __int_as_float(0);
            v114 = -42.0f;
            v115 = __int_as_float(0);
            v116 = 0;
            v117 = (unsigned int)v73 - 1;
            if (4 >= v117)
            {
                v118 = 44368764 + v117 * 60;
                v115 = v118->field_0;
                v116 = v118->field_8;
                v114 = -v118->field_4;
            }
            *(float *)&a0[820] = v115;
            *(float *)&a0[824] = v114;
            *(unsigned int *)&a0[828] = v116;
            v119 = (long long)a0[820];
            v120 = (int)a0[828];
            *(unsigned long *)&a0[808] = v119;
            *(unsigned long *)&a0[832] = v119;
            *(unsigned int *)&a0[816] = v120;
            *(unsigned int *)&a0[840] = v120;
            *(unsigned int *)&a0[844] = 0xc2c80000;
            if (3 >= (unsigned int)v73 - 2)
            {
                v121 = 44368764 + v117 * 60;
                v113 = v121->field_c;
                v122 = -v121->field_10;
                v123 = v121->field_14;
            }
            else
            {
                v123 = 0;
                v122 = -42.0f;
            }
            *(float *)&a0[948] = v113;
            v124 = __int_as_float(0);
            *(float *)&a0[952] = v122;
            v125 = (long long)a0[948];
            *(unsigned int *)&a0[956] = v123;
            v126 = (int)a0[956];
            *(unsigned int *)&a0[972] = 0xc2c80000;
            *(unsigned long *)&a0[936] = v125;
            *(unsigned long *)&a0[960] = v125;
            *(unsigned int *)&a0[944] = v126;
            *(unsigned int *)&a0[968] = v126;
            if (2 >= (unsigned int)v73 - 3)
            {
                v127 = 44368764 + v117 * 60;
                v128 = v127->field_18;
                v129 = -v127->field_1c;
                v130 = v127->field_20;
            }
            else
            {
                v128 = 0;
                v130 = 0;
                v129 = -42.0f;
            }
            *(float *)&a0[1076] = v128;
            *(float *)&a0[1080] = v129;
            *(unsigned int *)&a0[1084] = v130;
            v131 = (long long)a0[1076];
            v132 = (int)a0[1084];
            *(unsigned long *)&a0[1064] = v131;
            *(unsigned long *)&a0[1088] = v131;
            *(unsigned int *)&a0[1072] = v132;
            *(unsigned int *)&a0[1096] = v132;
            *(unsigned int *)&a0[1100] = 0xc2c80000;
            if (((unsigned int)v73 & 0xfffffffe) == 4)
            {
                v133 = 44368764 + v117 * 60;
                v124 = v133->field_24;
                v134 = -v133->field_28;
                v135 = v133->field_2c;
            }
            else
            {
                v135 = 0;
                v134 = -42.0f;
            }
            *(float *)&a0[1204] = v124;
            *(float *)&a0[1208] = v134;
            *(unsigned int *)&a0[1212] = v135;
            v136 = (long long)a0[1204];
            v137 = (int)a0[1212];
            *(unsigned int *)&a0[1228] = 0xc2c80000;
            *(unsigned long *)&a0[1192] = v136;
            *(unsigned int *)&a0[1200] = v137;
            *(unsigned long *)&a0[1216] = v136;
            *(unsigned int *)&a0[1224] = v137;
            if ((unsigned int)v73 == 5)
            {
                v138 = 0x80000000;
                v139 = 44368764 + v117 * 60;
                v140 = v139[12];
                v141 = v139[14];
            }
            else
            {
                v140 = 0;
                v141 = 0;
                v138 = 0xc2280000;
            }
            *(unsigned int *)&a0[1340] = v141;
            v142 = (int)a0[1340];
            *(unsigned int *)&a0[1332] = v140;
            *(unsigned int *)&a0[1336] = v138;
            *(unsigned int *)&a0[1328] = v142;
            v143 = (long long)a0[1332];
            *(unsigned int *)&a0[1352] = v142;
            *(unsigned int *)&a0[1464] = (5 < (int)v73 ? 0 : -42.0f);
            *(unsigned long *)&a0[1456] = 0;
            v144 = (long long)a0[1460];
            *(unsigned long *)&a0[1320] = v143;
            *(unsigned long *)&a0[1344] = v143;
            *(unsigned long *)&a0[1448] = v144;
            *(unsigned long *)&a0[1472] = v144;
            *(unsigned int *)&a0[1356] = 0xc2c80000;
            *(unsigned int *)&a0[1468] = 0;
            *(unsigned int *)&a0[1480] = 0;
            *(unsigned int *)&a0[1484] = 0xc2c80000;
            *(unsigned int *)&a0[4484] = 0xffffffff;
            *(unsigned int *)&a0[4400] = 0xc2c80000;
            *(unsigned int *)&a0[4396] = 0xc2c80000;
            sub_28dd44();
            *(unsigned int *)&a0[4472] = v73;
        }
        *(unsigned int *)&a0[4476] = 0;
LABEL_256a1c:
        if ((int)v73 >= 1)
        {
            if ((int)v70 > 0)
                v145 = a1->field_5f4;
            else
                v145 = 0;
            v146 = a0 + 0x600;
            if ((int)a0[848] != v145)
            {
                *(int *)&a0[848] = v145;
                sub_22d40c(a1, (long long)a0[776], v146[v145]);
            }
            if ((unsigned int)v73 != 1)
            {
                if ((int)v70 >= 2)
                    v147 = a1->field_5f8;
                else
                    v147 = 0;
                if ((int)a0[976] != v147)
                {
                    *(int *)&a0[976] = v147;
                    sub_22d40c(a1, (long long)a0[904], v146[v147]);
                }
                if ((unsigned int)v73 != 2)
                {
                    if ((int)v70 >= 3)
                        v148 = a1->field_5fc;
                    else
                        v148 = 0;
                    if ((int)a0[1104] != v148)
                    {
                        *(int *)&a0[1104] = v148;
                        sub_22d40c(a1, (long long)a0[1032], v146[v148]);
                    }
                    if ((unsigned int)v73 != 3)
                    {
                        if ((int)v70 >= 4)
                            v149 = a1->field_600;
                        else
                            v149 = 0;
                        if ((int)a0[1232] != v149)
                        {
                            *(int *)&a0[1232] = v149;
                            sub_22d40c(a1, (long long)a0[1160], v146[v149]);
                        }
                        if ((unsigned int)v73 != 4)
                        {
                            if ((int)v70 >= 5)
                                v150 = a1->field_604;
                            else
                                v150 = 0;
                            if ((int)a0[1360] != v150)
                            {
                                *(int *)&a0[1360] = v150;
                                sub_22d40c(a1, (long long)a0[1288], v146[v150]);
                            }
                        }
                    }
                }
            }
        }
        v151 = (int)a0[4472];
        if ((int)v151 > 5)
        {
            v152 = (v151 < 99 ? v151 : 99);
            if ((int)a0[4468] != (unsigned int)v152)
            {
                v153 = (long long)a0[544];
                *(unsigned int *)&a0[4468] = v152;
                sub_63b560(v152);
                sub_22cfc0(a1, v153, &v18);
                if (*&v18 & 1)
                    sub_6790c8(v20);
            }
        }
        v154 = 1.0;
        if ((int)a0[4484] >= 0)
        {
            v155 = __int_as_float((int)a0[4400]);
            v156 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v155), -50.0f)) >> 5 & 3 | v155 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v155)) * 0x10000000, 0, 0);
            if (!(v156 & 1))
            {
                v157 = a2 - v155;
                v158 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v157), 0.0f)) >> 5 & 3 | v157 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v157)) * 0x10000000, 0, 0);
                if (!(v158 & 1))
                {
                    v159 = __int_as_float((int)a0[2020]);
                    v160 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v159), 0.0f)) >> 5 & 3 | v159 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v159)) * 0x10000000, 0, 0);
                    if (!(v160 & 1))
                    {
                        v161 = v157 - (int)a0[2024];
                        v162 = 0;
                        v163 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v161), 0.0f)) >> 5 & 3 | v161 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v161)) * 0x10000000, 0, 0);
                        if (!(v163 & 1))
                        {
                            v164 = v161 / v159;
                            v165 = (int)a0[2032];
                            if ((int)v165 >= 1 && !(v166 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v164), __float_as_int((float)(int)v165))) >> 5 & 3 | v164 < (float)(int)v165) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v164, (float)(int)v165)) * 0x10000000, 0, 0), !(v166 & 1)))
                                goto LABEL_256dd4;
                            v162 = v164 - floorf(v164);
                        }
                        v167 = (int)a0[0x7f8];
                        if ((unsigned int)v167)
                        {
                            if ((int)v167 >= 1)
                            {
                                v168 = a0 + 2244;
                                if ((unsigned int)v167 != 1 && !(v169 = a0 + 2204, v170 = *(float *)&*v169, v171 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v170), __float_as_int(v162))) >> 5 & 3 | v170 < v162) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v170, v162)) * 0x10000000, 0, 0), v171 & 1))
                                {
                                    v172 = 0;
                                    node = a0 + 2248;
                                    v174 = v167 - 1;
                                    do
                                    {
                                        v175 = v174;
                                        v176 = *(float *)&*(int *)((char *)node - 40);
                                        v177 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v176), __float_as_int(v162))) >> 5 & 3 | v176 < v162) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v176, v162)) * 0x10000000, 0, 0);
                                        if (v177 & 1)
                                        {
                                            v178 = v176 - *(int *)((char *)v169 + (v172 >> 30));
                                            v179 = 1.0f;
                                            v180 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v178), 9.999999974752427e-07f)) >> 5 & 3 | v178 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v178)) * 0x10000000, 0, 0);
                                            if (!(v180 & 1))
                                                v179 = (v162 - *(int *)((char *)v169 + (v172 >> 30))) / v178;
                                            sub_254534((int)a0[2028]);
                                            v154 = (*node - *(float *)&v168[v172 >> 32]) * v179 + *(float *)&v168[v172 >> 32];
                                            goto LABEL_256dd4;
                                        }
                                    } while ((v174 = v175 - 1, v172 += 0x100000000, node += 1, v175 != 1));
                                    v154 = *(float *)&*(int *)((char *)v168 + 4 * v167 - 4);
                                }
                                else
                                {
                                    v154 = *(float *)&*v168;
                                }
                            }
                            else
                            {
                                v154 = 0;
                            }
                        }
                    }
                }
            }
        }
LABEL_256dd4:
        v181 = 0;
        v182 = 0;
        do
        {
            v183 = a0 + v181;
            v184 = a2 - (int)v183[844];
            v185 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v184), 0.0f)) >> 5 & 3 | v184 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v184)) * 0x10000000, 0, 0);
            if (!(v185 & 1) && (v186 = __int_as_float((int)a0[1756]), v187 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v186), 0.0f)) >> 5 & 3 | v186 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v186)) * 0x10000000, 0, 0), !(v187 & 1)))
            {
                v188 = v184 - (int)a0[1760];
                v189 = 0;
                v190 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v188), 0.0f)) >> 5 & 3 | v188 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v188)) * 0x10000000, 0, 0);
                if (!(v190 & 1))
                {
                    v191 = v188 / v186;
                    v192 = (int)a0[1768];
                    if ((int)v192 >= 1 && !(v193 = arm64g_calculate_condition(176, (((((char)(CmpF(__float_as_int(v191), __float_as_int((float)(int)v192))) >> 5 & 3 | v191 < (float)(int)v192) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v191, (float)(int)v192)) * 0x10000000, 0, 0), v193 & 1))
                        goto LABEL_256ea8;
                    v189 = v191 - floorf(v191);
                }
                sub_254534((int)a0[1764]);
                v194 = a0 + v181;
                v195 = __double_as_longlong((double)v194[808]);
                v196 = __int_as_float((int)v194[816]);
                v197 = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_sub_ps(__double_as_longlong((double)v194[820]), v195));
                v198 = __int_as_float((int)v194[828] - (int)v194[816]);
                *(unsigned long long *)&v194[832] = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_add_ps(v195, _mm_mul_ps(v197, CONCAT(__float_as_int(v189) * 0x100000000 | __float_as_int(v189), __float_as_int(v189) * 0x100000000 | __float_as_int(v189)))));
                *(float *)&v194[840] = v198 * v189 + v196;
LABEL_256f44:
                v203 = a0 + 728 + v182 * 128 + 32;
LABEL_256f54:
                sub_22cf38(a1);
                v204 = a0 + v181;
                0x67f8c0();
                sub_22d590(a1, *(long long *)v203);
                sub_22d908(a1, *(long long *)v203);
                v205 = (long long)v16[4268];
                if (!(char)v15[396])
                {
                    v206 = __dirty_unsupported_Iop_ZeroHI96ofV128(_mm_max_ps((v182 == (int)a0[4484] ? __float_as_int(v154) : 0x3f800000), _mm_setzero_ps()));
                    v205 = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_min_ps(__dirty_unsupported_Iop_ZeroHI64ofV128(_mm_mul_ps(v205, CONCAT(__float_as_int(v206) * 0x100000000 | __float_as_int(v206), __float_as_int(v206) * 0x100000000 | __float_as_int(v206)))), _mm_castsi128_ps(_mm_set_epi32(0, 0, 0x3f800000, 0x3f800000))));
                }
                v17 = v205;
                sub_22d238(a1, (long long)v204[0x300]);
                sub_22d238(a1, (long long)v204[776]);
                sub_22d238(a1, (long long)v204[784]);
                if (v182 != (int)a0[4484] || !(v208 = a2 - (int)a0[4400], v209 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v208), 0.0f)) >> 5 & 3 | v208 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v208)) * 0x10000000, 0, 0), !(v209 & 1) && (v210 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v208), 0.699999988079071f)) >> 5 & 3 | v208 < 0.699999988079071f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v208)) * 0x10000000, 0, 0), !(v210 & 1))))
                {
LABEL_256e24:
                    sub_22cf38(a1);
                    sub_22d238(a1, (long long)v204[792]);
                }
                else
                {
                    v211 = v208 / 0.699999988079071f;
                    v212 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v211), 0.009999999776482582f)) >> 5 & 3 | v211 < 0.009999999776482582f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v211)) * 0x10000000, 0, 0);
                    if (v212 & 1)
                    {
                        sub_254a74();
                    }
                    else
                    {
                        v213 = arm64g_calculate_condition(144, (((((char)(CmpF(__float_as_int(v211), 0.30000001192092896f)) >> 5 & 3 | v211 < 0.30000001192092896f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v211)) * 0x10000000, 0, 0);
                        if (!(v213 & 1))
                            sub_254a74();
                        else
                            goto LABEL_256e24;
                    }
                    goto LABEL_256e24;
                }
            }
            else
            {
LABEL_256ea8:
                v200 = __int_as_float((int)v183[820]);
                v201 = (long long)v183[820];
                *(int *)&v183[840] = (int)v183[828];
                *(unsigned long *)&v183[832] = v201;
                if (v200 == 0.0f && !(v202 = a0 + v181, (int)v202[824] != -42.0f))
                {
                    if ((int)v202[828] != 0.0f)
                    {
                        v203 = v202 + 760;
                        goto LABEL_256f54;
                    }
                    else
                    {
                        sub_22cf38(a1);
                        continue;
                    }
                }
                goto LABEL_256f44;
            }
        } while ((v181 += 128, v182 += 1, v181 != 0x300));
        sub_28dfb8(a1, v13 != 0);
        v214 = __int_as_float((int)a0[4396]);
        v215 = _mm_castsi128_ps(_mm_set_epi64x(0, 0x3f800000));
        v216 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v214), -50.0f)) >> 5 & 3 | v214 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v214)) * 0x10000000, 0, 0);
        if (!(v216 & 1))
        {
            v217 = a2 - v214;
            v218 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v217), 0.0f)) >> 5 & 3 | v217 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v217)) * 0x10000000, 0, 0);
            if (!(v218 & 1))
            {
                v219 = __int_as_float((int)a0[2284]);
                v220 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v219), 0.0f)) >> 5 & 3 | v219 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v219)) * 0x10000000, 0, 0);
                if (!(v220 & 1))
                {
                    v221 = v217 - (int)a0[2288];
                    v222 = __int_as_float(0);
                    v223 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v221), 0.0f)) >> 5 & 3 | v221 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v221)) * 0x10000000, 0, 0);
                    if (!(v223 & 1))
                    {
                        v224 = v221 / v219;
                        v225 = (int)a0[2296];
                        if ((int)v225 >= 1 && !(v226 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v224), __float_as_int((float)(int)v225))) >> 5 & 3 | v224 < (float)(int)v225) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v224, (float)(int)v225)) * 0x10000000, 0, 0), !(v226 & 1)))
                            goto LABEL_257230;
                        v222 = v224 - floorf(v224);
                    }
                    v227 = (int)a0[0x900];
                    if ((unsigned int)v227)
                    {
                        if ((int)v227 >= 1)
                        {
                            v228 = a0 + 2508;
                            if ((unsigned int)v227 != 1 && !(v229 = a0 + 2468, v230 = *(float *)&*v229, v231 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v230), __float_as_int(v222))) >> 5 & 3 | v230 < v222) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v230, v222)) * 0x10000000, 0, 0), v231 & 1))
                            {
                                v232 = 0;
                                iter = a0 + 2512;
                                v234 = v227 - 1;
                                do
                                {
                                    v235 = v234;
                                    v236 = *(float *)&*(int *)((char *)iter - 40);
                                    v237 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v236), __float_as_int(v222))) >> 5 & 3 | v236 < v222) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v236, v222)) * 0x10000000, 0, 0);
                                    if (v237 & 1)
                                    {
                                        v238 = v236 - *(int *)((char *)v229 + (v232 >> 30));
                                        v239 = 1.0f;
                                        v240 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v238), 9.999999974752427e-07f)) >> 5 & 3 | v238 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v238)) * 0x10000000, 0, 0);
                                        if (!(v240 & 1))
                                            v239 = (v222 - *(int *)((char *)v229 + (v232 >> 30))) / v238;
                                        sub_254534((int)a0[2292]);
                                        v215 = __float_as_int((*iter - *(float *)&v228[v232 >> 32]) * v239 + *(float *)&v228[v232 >> 32]);
                                        goto LABEL_257230;
                                    }
                                } while ((v234 = v235 - 1, v232 += 0x100000000, iter += 1, v235 != 1));
                                v215 = *(int *)((char *)&v228[v227] - 4);
                            }
                            else
                            {
                                v215 = *v228;
                            }
                        }
                        else
                        {
                            v215 = _mm_setzero_ps();
                        }
                    }
                }
            }
        }
LABEL_257230:
        v241 = __int_as_float((int)a0[4400]);
        v242 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v241), -50.0f)) >> 5 & 3 | v241 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v241)) * 0x10000000, 0, 0);
        if (!(v242 & 1))
        {
            v243 = a2 - v241;
            v244 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v243), 0.0f)) >> 5 & 3 | v243 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v243)) * 0x10000000, 0, 0);
            if (!(v244 & 1))
            {
                v245 = __int_as_float((int)a0[2020]);
                v246 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v245), 0.0f)) >> 5 & 3 | v245 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v245)) * 0x10000000, 0, 0);
                if (!(v246 & 1))
                {
                    v247 = v243 - (int)a0[2024];
                    v248 = 0;
                    v249 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v247), 0.0f)) >> 5 & 3 | v247 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v247)) * 0x10000000, 0, 0);
                    if (!(v249 & 1))
                    {
                        v250 = v247 / v245;
                        v251 = (int)a0[2032];
                        if ((int)v251 >= 1 && !(v252 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v250), __float_as_int((float)(int)v251))) >> 5 & 3 | v250 < (float)(int)v251) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v250, (float)(int)v251)) * 0x10000000, 0, 0), !(v252 & 1)))
                            goto LABEL_257350;
                        v248 = v250 - floorf(v250);
                    }
                    v253 = (int)a0[0x7f8];
                    if ((unsigned int)v253 && (int)v253 >= 1 && (unsigned int)v253 != 1 && !(v254 = a0 + 2204, v255 = *(float *)&*v254, v256 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v255), __float_as_int(v248))) >> 5 & 3 | v255 < v248) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v255, v248)) * 0x10000000, 0, 0), v256 & 1))
                    {
                        v257 = 0;
                        iter1 = a0 + 2248;
                        v259 = v253 - 1;
                        do
                        {
                            v260 = v259;
                            v261 = *(float *)&*(int *)((char *)iter1 - 40);
                            v262 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v261), __float_as_int(v248))) >> 5 & 3 | v261 < v248) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v261, v248)) * 0x10000000, 0, 0);
                            if (v262 & 1)
                            {
                                v263 = v261 - *(int *)((char *)v254 + (v257 >> 30));
                                v264 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v263), 9.999999974752427e-07f)) >> 5 & 3 | v263 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v263)) * 0x10000000, 0, 0);
                                sub_254534((int)a0[2028]);
                                goto LABEL_257350;
                            }
                        } while ((v259 = v260 - 1, v257 += 0x100000000, iter1 += 1, v260 != 1));
                    }
                }
            }
        }
LABEL_257350:
        if ((char)v15[396])
        {
            sub_24f2f0();
            if ((int)a0[4488] != (int)a0[4484])
            {
                v265 = 0;
                iter2 = a0 + 804;
                *(int *)&a0[4488] = (int)a0[4484];
                do
                {
                    v267 = (v265 == (int)a0[4484]) * 2;
                    if (v267 != *iter2)
                    {
                        sub_24f5a4(a1, *(long long *)((char *)iter2 - 36), v267);
                        sub_24f5a4(a1, *(long long *)((char *)iter2 - 28), v267);
                        sub_24f5a4(a1, *(long long *)((char *)iter2 - 20), v267);
                        sub_24f5a4(a1, *(long long *)((char *)iter2 - 12), v267);
                        *iter2 = v267;
                    }
                } while ((sub_248648(*(int *)((char *)iter2 - 4), v267), v265 += 1, iter2 += 32, v265 != 6));
            }
            if (!(char)v15[396])
                goto LABEL_257390;
            v268 = (int)a0[4516];
            v269 = (long long)v16[4268];
        }
        else
        {
LABEL_257390:
            v270 = __int_as_float((unsigned int)__dirty_unsupported_Iop_ZeroHI96ofV128(_mm_max_ps(v215, _mm_setzero_ps())));
            v271 = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_mul_ps((long long)v16[4268], CONCAT(__float_as_int(v270) * 0x100000000 | __float_as_int(v270), __float_as_int(v270) * 0x100000000 | __float_as_int(v270))));
            v269 = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_min_ps(v271, _mm_castsi128_ps(_mm_set_epi32(0, 0, 0x3f800000, 0x3f800000))));
            v268 = __dirty_unsupported_Iop_ZeroHI96ofV128(_mm_min_ps(__float_as_int(v270 * (int)a0[4516]), _mm_castsi128_ps(_mm_set_epi32(0, 0, 0, 0x3f800000))));
        }
        v17 = v269;
        sub_22d238(a1, (long long)a0[552]);
        *(int *)&v16 = (int)a0[4520];
        sub_22d238(a1, (long long)a0[560]);
        v272 = a1->field_518;
        sub_22ce80(a1, (long long)a0[568], v272 == 2);
        sub_22ce80(a1, (long long)a0[576], a1->field_518 == 1);
        sub_23e9cc((v272 != 2 ? 1 : 2));
        sub_22d238(a1, *(long long *)(v272 == 2 ? a0 + 568 : a0 + 576));
        v273 = (int)a0[4432];
        v274 = a1->field_520 & ~(a1->field_520 >> 31);
        if (!(v273 >> 31 & 1) && (int)v273 > (int)v274)
        {
            *(float *)&a0[4404] = a2;
            *(float *)&a0[4408] = a2;
            *(float *)&a0[4416] = a2;
        }
        v275 = (int)a0[4448];
        *(unsigned int *)&a0[4432] = v274;
        if (v275 != v274)
        {
            v276 = (long long)a0[600];
            *(unsigned int *)&a0[4448] = v274;
            sub_63b560(v274);
            sub_22cfc0(a1, v276, &v18);
            if (*&v18 & 1)
                sub_6790c8(v20);
        }
        v13 = *(unsigned int *)((void*)&v269 + 4);
        sub_22ce80(a1, (long long)a0[592], 21 > v274);
        v277 = __int_as_float((int)a0[4408]);
        v278 = __int_as_float(0);
        v279 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v277), -50.0f)) >> 5 & 3 | v277 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v277)) * 0x10000000, 0, 0);
        if (!(v279 & 1))
        {
            v280 = a2 - v277;
            v281 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v280), 0.0f)) >> 5 & 3 | v280 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v280)) * 0x10000000, 0, 0);
            if (!(v281 & 1) && !(v282 = __int_as_float((int)a0[2812]), v283 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v282), 0.0f)) >> 5 & 3 | v282 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v282)) * 0x10000000, 0, 0), v283 & 1))
            {
                v284 = v280 - (int)a0[0xb00];
                v285 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v284), 0.0f)) >> 5 & 3 | v284 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v284)) * 0x10000000, 0, 0);
                if (!(v285 & 1))
                {
                    v286 = v284 / v282;
                    v287 = (int)a0[2824];
                    if ((int)v287 < 1 || (v288 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v286), __float_as_int((float)(int)v287))) >> 5 & 3 | v286 < (float)(int)v287) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v286, (float)(int)v287)) * 0x10000000, 0, 0), !(v288 & 1)))
                    {
                        v278 = v286 - floorf(v286);
                        goto LABEL_257574;
                    }
                }
                else
                {
LABEL_257574:
                    v289 = 1;
                    goto LABEL_257584;
                }
            }
        }
        v289 = 0;
LABEL_257584:
        v15 = v268;
        if (v289)
        {
            v290 = (int)a0[2832];
            if ((unsigned int)v290 && (int)v290 >= 1 && (unsigned int)v290 != 1 && !(v291 = a0 + 2996, v292 = *(float *)&*v291, v293 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v292), __float_as_int(v278))) >> 5 & 3 | v292 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v292, v278)) * 0x10000000, 0, 0), v293 & 1))
            {
                v294 = 0;
                v295 = a0 + 3040;
                v296 = v290 - 1;
                do
                {
                    v297 = v296;
                    v298 = *(float *)&*(int *)((char *)v295 - 40);
                    v299 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v298), __float_as_int(v278))) >> 5 & 3 | v298 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v298, v278)) * 0x10000000, 0, 0);
                    if (v299 & 1)
                    {
                        v300 = v298 - *(int *)((char *)v291 + (v294 >> 30));
                        v301 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v300), 9.999999974752427e-07f)) >> 5 & 3 | v300 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v300)) * 0x10000000, 0, 0);
                        sub_254534((int)a0[2820]);
                        goto LABEL_257728;
                    }
                } while ((v296 = v297 - 1, v294 += 0x100000000, v295 = &v295->padding_0[4], v297 != 1));
            }
        }
LABEL_257728:
        sub_22d238(a1);
        if (v289)
        {
            v302 = (int)a0[2828];
            if ((unsigned int)v302 && (int)v302 >= 1)
            {
                v303 = a0 + 2836;
                v304 = arm64g_calculate_condition(3, v302 & 0xffffffff, 1, 0);
                if (!(v304 & 1) && !(v305 = *(float *)&*v303, v306 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v305), __float_as_int(v278))) >> 5 & 3 | v305 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v305, v278)) * 0x10000000, 0, 0), v306 & 1))
                {
                    v307 = 0;
                    v308 = a0 + 2960;
                    v309 = v302 - 1;
                    while (1)
                    {
                        v310 = v309;
                        v311 = *(float *)&*(int *)((char *)v308 - 120);
                        v312 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v311), __float_as_int(v278))) >> 5 & 3 | v311 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v311, v278)) * 0x10000000, 0, 0);
                        if (v312 & 1)
                            break;
                        v309 = v310 - 1;
                        v307 += 0x100000000;
                        v308 = &v308->padding_0[4];
                        if (v310 == 1)
                        {
                            if (1 > (int)v302)
                                goto LABEL_257938;
                            goto LABEL_25782c;
                        }
                    }
                    v313 = v311 - *(int *)((char *)v303 + (v307 >> 30));
                    v314 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v313), 9.999999974752427e-07f)) >> 5 & 3 | v313 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v313)) * 0x10000000, 0, 0);
                    sub_254534((int)a0[2820]);
                    v302 = (int)a0[2828];
                    if ((int)v302 < 1)
                    {
LABEL_257938:
                        goto LABEL_257988;
                    }
                }
LABEL_25782c:
                if ((unsigned int)v302 != 1 && !(v315 = __int_as_float((int)a0[2836]), v316 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v315), __float_as_int(v278))) >> 5 & 3 | v315 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v315, v278)) * 0x10000000, 0, 0), v316 & 1))
                {
                    v317 = 0;
                    v318 = a0 + 2880;
                    v319 = (v302 & 0xffffffff) - 1;
                    do
                    {
                        v320 = v319;
                        v321 = *(float *)&*(int *)((char *)v318 - 40);
                        v322 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v321), __float_as_int(v278))) >> 5 & 3 | v321 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v321, v278)) * 0x10000000, 0, 0);
                        if (v322 & 1)
                        {
                            v323 = v321 - *(int *)((char *)v303 + (v317 >> 30));
                            v324 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v323), 9.999999974752427e-07f)) >> 5 & 3 | v323 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v323)) * 0x10000000, 0, 0);
                            sub_254534((int)a0[2820]);
                            v302 = (int)a0[2828];
                            goto LABEL_2578d4;
                        }
                    } while ((v319 = v320 - 1, v317 += 0x100000000, v318 = &v318->padding_0[4], v320 != 1));
LABEL_2578d4:
                    if ((int)v302 < 1)
                        goto LABEL_257988;
                }
                if ((unsigned int)v302 != 1 && !(v325 = __int_as_float((int)a0[2836]), v326 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v325), __float_as_int(v278))) >> 5 & 3 | v325 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v325, v278)) * 0x10000000, 0, 0), v326 & 1))
                {
                    v327 = 0;
                    v328 = a0 + 2920;
                    v329 = (v302 & 0xffffffff) - 1;
                    do
                    {
                        v330 = v329;
                        v331 = *(float *)&*(int *)((char *)v328 - 80);
                        v332 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v331), __float_as_int(v278))) >> 5 & 3 | v331 < v278) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v331, v278)) * 0x10000000, 0, 0);
                        if (v332 & 1)
                        {
                            v333 = v331 - *(int *)((char *)v303 + (v327 >> 30));
                            v334 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v333), 9.999999974752427e-07f)) >> 5 & 3 | v333 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v333)) * 0x10000000, 0, 0);
                            sub_254534((int)a0[2820]);
                            goto LABEL_257988;
                        }
                    } while ((v329 = v330 - 1, v327 += 0x100000000, v328 = &v328->padding_0[4], v330 != 1));
                }
            }
LABEL_257988:
        }
        sub_22d590(a1, (long long)a0[600]);
        sub_22d830(a1, (long long)a0[600]);
        if (20 >= v274)
        {
            sub_2592e4(a0, a1, 0, v274);
            sub_22d590(a1, (long long)a0[592]);
            sub_22d830(a1, (long long)a0[592]);
        }
        v335 = __int_as_float((int)a0[4404]);
        v14 = 0x3f8000003f800000;
        v336 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v335), -50.0f)) >> 5 & 3 | v335 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v335)) * 0x10000000, 0, 0);
        if (!(v336 & 1) && !(v337 = a2 - v335, v338 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v337), 0.0f)) >> 5 & 3 | v337 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v337)) * 0x10000000, 0, 0), v338 & 1 || (v339 = __int_as_float((int)a0[2548]), v340 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v339), 0.0f)) >> 5 & 3 | v339 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v339)) * 0x10000000, 0, 0), v340 & 1)))
        {
            v341 = v337 - (int)a0[2552];
            v342 = __int_as_float(0);
            v343 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v341), 0.0f)) >> 5 & 3 | v341 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v341)) * 0x10000000, 0, 0);
            if (!(v343 & 1))
            {
                v344 = v341 / v339;
                v345 = (int)a0[0xa00];
                if ((int)v345 >= 1 && !(v346 = arm64g_calculate_condition(176, (((((char)(CmpF(__float_as_int(v344), __float_as_int((float)(int)v345))) >> 5 & 3 | v344 < (float)(int)v345) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v344, (float)(int)v345)) * 0x10000000, 0, 0), v346 & 1))
                    goto LABEL_257a78;
                v342 = v344 - floorf(v344);
            }
            *(float *)&v11 = v342;
            if ((int)a0[4452] != v274)
            {
                v347 = (long long)a0[624];
                *(unsigned int *)&a0[4452] = v274;
                sub_63b560(v274);
                sub_22cfc0(a1, v347, &v18);
                if (*&v18 & 1)
                    sub_6790c8(v20);
            }
            v348 = (int)a0[2568];
            if ((unsigned int)v348 && (int)v348 >= 1)
            {
                v349 = *(float *)&v11;
                if ((unsigned int)v348 != 1 && !(v350 = a0 + 2732, v351 = *(float *)&*v350, v352 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v351), __float_as_int(v349))) >> 5 & 3 | v351 < v349) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v351, v349)) * 0x10000000, 0, 0), v352 & 1))
                {
                    v353 = 0;
                    v354 = a0 + 2776;
                    v355 = v348 - 1;
                    do
                    {
                        v356 = v355;
                        v357 = *(float *)&*(int *)((char *)v354 - 40);
                        v358 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v357), __float_as_int(v349))) >> 5 & 3 | v357 < v349) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v357, v349)) * 0x10000000, 0, 0);
                        if (v358 & 1)
                        {
                            v10 = (int)a0[1700];
                            v359 = v357 - *(int *)((char *)v350 + (v353 >> 30));
                            v360 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v359), 9.999999974752427e-07f)) >> 5 & 3 | v359 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v359)) * 0x10000000, 0, 0);
                            *(unsigned int *)&v8 = *v354 - *(int *)((char *)a0 + 4 * (v353 >> 32) + 2772);
                            sub_254534((int)a0[2556]);
                            goto LABEL_257d80;
                        }
                    } while ((v355 = v356 - 1, v353 += 0x100000000, v354 += 1, v356 != 1));
                }
            }
LABEL_257d80:
            sub_22d238(a1);
            sub_2592e4(a0, a1, 1, v274);
            sub_22d238(a1, (long long)a0[4552]);
            sub_22d238(a1, (long long)a0[4560]);
            sub_22d238(a1, (long long)a0[4568]);
            v361 = *(float *)&v11;
            v362 = arm64g_calculate_condition(144, (((((char)(CmpF(__float_as_int(v361), 0.0f)) >> 5 & 3 | v361 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v361)) * 0x10000000, 0, 0);
            if (!(v362 & 1))
            {
                v363 = 0.10000000149011612f;
                v364 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v361), 0.10000000149011612f)) >> 5 & 3 | v361 < 0.10000000149011612f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v361)) * 0x10000000, 0, 0);
                if (!(v364 & 1))
                {
                    v363 = 1.0f;
                    v365 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(v361), 1.0f)) >> 5 & 3 | v361 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v361)) * 0x10000000, 0, 0);
                    if (v365 & 1)
                        goto LABEL_257edc;
                    v366 = 2;
                }
                else
                {
                    v366 = 1;
                }
                v367 = v363 - *(int *)(4 * v366 + 44368736);
                v368 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v367), 9.999999974752427e-07f)) >> 5 & 3 | v367 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v367)) * 0x10000000, 0, 0);
                sub_254534((int)a0[2556]);
            }
LABEL_257edc:
            sub_22d590(a1, (long long)a0[608]);
            sub_22d830(a1, (long long)a0[608]);
            v369 = (int)a0[2564];
            if ((unsigned int)v369 && (int)v369 >= 1)
            {
                v370 = *(float *)&v11;
                if ((unsigned int)v369 != 1 && !(v371 = a0 + 2572, v372 = *(float *)&*v371, v373 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v372), __float_as_int(v370))) >> 5 & 3 | v372 < v370) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v372, v370)) * 0x10000000, 0, 0), v373 & 1))
                {
                    v374 = 0;
                    v375 = a0 + 2616;
                    v376 = v369 - 1;
                    do
                    {
                        v377 = v376;
                        v378 = *(float *)&*(int *)((char *)v375 - 40);
                        v379 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v378), __float_as_int(v370))) >> 5 & 3 | v378 < v370) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v378, v370)) * 0x10000000, 0, 0);
                        if (v379 & 1)
                        {
                            v380 = v378 - *(int *)((char *)v371 + (v374 >> 30));
                            v381 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v380), 9.999999974752427e-07f)) >> 5 & 3 | v380 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v380)) * 0x10000000, 0, 0);
                            sub_254534((int)a0[2556]);
                            goto LABEL_257ff8;
                        }
                    } while ((v376 = v377 - 1, v374 += 0x100000000, v375 = &v375->padding_0[4], v377 != 1));
                }
            }
LABEL_257ff8:
            sub_22cf38(a1);
        }
        else
        {
LABEL_257a78:
            sub_22cf38(a1, (long long)a0[608]);
        }
        v382 = __int_as_float((int)a0[4416]);
        v383 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v382), -50.0f)) >> 5 & 3 | v382 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v382)) * 0x10000000, 0, 0);
        if (!(v383 & 1))
        {
            v384 = a2 - v382;
            v385 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v384), 0.0f)) >> 5 & 3 | v384 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v384)) * 0x10000000, 0, 0);
            if (!(v385 & 1))
            {
                v386 = __int_as_float((int)a0[3340]);
                v387 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v386), 0.0f)) >> 5 & 3 | v386 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v386)) * 0x10000000, 0, 0);
                if (!(v387 & 1))
                {
                    v388 = __int_as_float(0);
                    v389 = v384 - (int)a0[3344];
                    v390 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v389), 0.0f)) >> 5 & 3 | v389 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v389)) * 0x10000000, 0, 0);
                    if (!(v390 & 1))
                    {
                        v391 = v389 / v386;
                        v392 = (int)a0[3352];
                        if ((int)v392 >= 1 && !(v393 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v391), __float_as_int((float)(int)v392))) >> 5 & 3 | v391 < (float)(int)v392) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v391, (float)(int)v392)) * 0x10000000, 0, 0), !(v393 & 1)))
                            goto LABEL_2581fc;
                        v388 = v391 - floorf(v391);
                    }
                    v394 = (int)a0[3356];
                    if ((unsigned int)v394 && (int)v394 >= 1)
                    {
                        v395 = arm64g_calculate_condition(3, v394 & 0xffffffff, 1, 0);
                        if (!(v395 & 1) && !(v396 = a0 + 3364, v397 = *(float *)&*v396, v398 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v397), __float_as_int(v388))) >> 5 & 3 | v397 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v397, v388)) * 0x10000000, 0, 0), v398 & 1))
                        {
                            v399 = 0;
                            v400 = a0 + 3488;
                            v401 = v394 - 1;
                            do
                            {
                                v402 = v401;
                                v403 = *(float *)&*(int *)((char *)v400 - 120);
                                v404 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v403), __float_as_int(v388))) >> 5 & 3 | v403 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v403, v388)) * 0x10000000, 0, 0);
                                if (v404 & 1)
                                {
                                    v405 = v403 - *(int *)((char *)v396 + (v399 >> 30));
                                    v406 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v405), 9.999999974752427e-07f)) >> 5 & 3 | v405 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v405)) * 0x10000000, 0, 0);
                                    sub_254534((int)a0[3348]);
                                    v394 = (int)a0[3356];
                                    goto LABEL_257cac;
                                }
                            } while ((v401 = v402 - 1, v399 += 0x100000000, v400 = &v400->padding_0[4], v402 != 1));
LABEL_257cac:
                            if ((int)v394 >= 1)
                                goto LABEL_257cb4;
                        }
                        else
                        {
LABEL_257cb4:
                            v407 = a0 + 3364;
                            if ((unsigned int)v394 != 1 && !(v408 = __int_as_float((int)a0[3364]), v409 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v408), __float_as_int(v388))) >> 5 & 3 | v408 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v408, v388)) * 0x10000000, 0, 0), v409 & 1))
                            {
                                v410 = 0;
                                v411 = a0 + 3408;
                                v412 = (v394 & 0xffffffff) - 1;
                                do
                                {
                                    v413 = v412;
                                    v414 = *(float *)&*(int *)((char *)v411 - 40);
                                    v415 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v414), __float_as_int(v388))) >> 5 & 3 | v414 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v414, v388)) * 0x10000000, 0, 0);
                                    if (v415 & 1)
                                    {
                                        v416 = v414 - *(int *)((char *)v407 + (v410 >> 30));
                                        v417 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v416), 9.999999974752427e-07f)) >> 5 & 3 | v416 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v416)) * 0x10000000, 0, 0);
                                        *(unsigned int *)&v12 = *v411 - *(int *)((char *)a0 + 4 * (v410 >> 32) + 3404);
                                        sub_254534((int)a0[3348]);
                                        v394 = (int)a0[3356];
                                        goto LABEL_25806c;
                                    }
                                } while ((v412 = v413 - 1, v410 += 0x100000000, v411 += 1, v413 != 1));
LABEL_25806c:
                                if ((int)v394 < 1)
                                    goto LABEL_258128;
                            }
                            if ((unsigned int)v394 != 1 && !(v418 = __int_as_float((int)a0[3364]), v419 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v418), __float_as_int(v388))) >> 5 & 3 | v418 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v418, v388)) * 0x10000000, 0, 0), v419 & 1))
                            {
                                v420 = 0;
                                v421 = a0 + 3448;
                                v422 = (v394 & 0xffffffff) - 1;
                                do
                                {
                                    v423 = v422;
                                    v424 = *(float *)&*(int *)((char *)v421 - 80);
                                    v425 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v424), __float_as_int(v388))) >> 5 & 3 | v424 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v424, v388)) * 0x10000000, 0, 0);
                                    if (v425 & 1)
                                    {
                                        v426 = v424 - *(int *)((char *)v407 + (v420 >> 30));
                                        v427 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v426), 9.999999974752427e-07f)) >> 5 & 3 | v426 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v426)) * 0x10000000, 0, 0);
                                        *(unsigned int *)&v12 = *v421 - *(int *)((char *)a0 + 4 * (v420 >> 32) + 3444);
                                        sub_254534((int)a0[3348]);
                                        goto LABEL_258128;
                                    }
                                } while ((v422 = v423 - 1, v420 += 0x100000000, v421 += 1, v423 != 1));
                            }
                        }
                    }
LABEL_258128:
                    v428 = (int)a0[3360];
                    if ((unsigned int)v428 && (int)v428 >= 1 && (unsigned int)v428 != 1 && !(v429 = a0 + 3524, v430 = *(float *)&*v429, v431 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v430), __float_as_int(v388))) >> 5 & 3 | v430 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v430, v388)) * 0x10000000, 0, 0), v431 & 1))
                    {
                        v432 = 0;
                        v433 = a0 + 3568;
                        v434 = v428 - 1;
                        do
                        {
                            v435 = v434;
                            v436 = *(float *)&*(int *)((char *)v433 - 40);
                            v437 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v436), __float_as_int(v388))) >> 5 & 3 | v436 < v388) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v436, v388)) * 0x10000000, 0, 0);
                            if (v437 & 1)
                            {
                                v438 = v436 - *(int *)((char *)v429 + (v432 >> 30));
                                v439 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v438), 9.999999974752427e-07f)) >> 5 & 3 | v438 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v438)) * 0x10000000, 0, 0);
                                sub_254534((int)a0[3348]);
                                goto LABEL_2581f4;
                            }
                        } while ((v434 = v435 - 1, v432 += 0x100000000, v433 = &v433->padding_0[4], v435 != 1));
                    }
LABEL_2581f4:
                }
            }
        }
LABEL_2581fc:
        sub_22d590(a1, (long long)a0[632]);
        sub_22d830(a1, (long long)a0[632]);
        sub_22d48c(a1, (long long)a0[640]);
        sub_22d238(a1, (long long)a0[640]);
        v440 = a1->field_524;
        v441 = (int)a0[4436];
        v442 = v440 & ~((int)(v440) >> 31);
        if (!(v441 >> 31 & 1) && (int)v442 > (int)v441)
            *(float *)&a0[4428] = a2;
        v443 = (long long)a0[648];
        *(unsigned int *)&a0[4436] = v442;
        sub_22ce80(a1, v443, (int)v440 > 0);
        if ((int)v440 >= 1)
        {
            sub_22d40c(a1, (long long)a0[656], (a1->field_528 != 0 & (long long)a0[1584] != 0 ? (long long)a0[1584] : (long long)a0[1576]));
            sub_22d77c(a1, (long long)a0[656]);
            sub_22d590(a1, (long long)a0[656]);
            if ((int)a0[4456] != v440)
            {
                v444 = (long long)a0[664];
                *(unsigned int *)&a0[4456] = v440;
                sub_63b560(v440);
                sub_22cfc0(a1, v444, &v18);
                if (*&v18 & 1)
                    sub_6790c8(v20);
            }
            v445 = __int_as_float((int)a0[4428]);
            v446 = _mm_castsi128_ps(_mm_set_epi64x(0, 0x3f800000));
            v447 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v445), -50.0f)) >> 5 & 3 | v445 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v445)) * 0x10000000, 0, 0);
            if (!(v447 & 1))
            {
                v448 = a2 - v445;
                v449 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v448), 0.0f)) >> 5 & 3 | v448 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v448)) * 0x10000000, 0, 0);
                if (!(v449 & 1))
                {
                    v450 = __int_as_float((int)a0[4132]);
                    v451 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v450), 0.0f)) >> 5 & 3 | v450 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v450)) * 0x10000000, 0, 0);
                    if (!(v451 & 1))
                    {
                        v452 = __int_as_float(0);
                        v453 = v448 - (int)a0[4136];
                        v454 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v453), 0.0f)) >> 5 & 3 | v453 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v453)) * 0x10000000, 0, 0);
                        if (!(v454 & 1))
                        {
                            v455 = v453 / v450;
                            v456 = (int)a0[4144];
                            if ((int)v456 >= 1 && !(v457 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v455), __float_as_int((float)(int)v456))) >> 5 & 3 | v455 < (float)(int)v456) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v455, (float)(int)v456)) * 0x10000000, 0, 0), !(v457 & 1)))
                                goto LABEL_258658;
                            v452 = v455 - floorf(v455);
                        }
                        v458 = (int)a0[4148];
                        if ((unsigned int)v458 && (int)v458 >= 1)
                        {
                            v459 = arm64g_calculate_condition(3, v458 & 0xffffffff, 1, 0);
                            if (!(v459 & 1) && !(v460 = a0 + 4156, v461 = *(float *)&*v460, v462 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v461), __float_as_int(v452))) >> 5 & 3 | v461 < v452) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v461, v452)) * 0x10000000, 0, 0), v462 & 1))
                            {
                                v463 = 0;
                                v464 = v458 - 1;
                                v465 = a0 + 4200;
                                do
                                {
                                    v466 = v464;
                                    v467 = *(float *)&*(int *)((char *)v465 - 40);
                                    v468 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v467), __float_as_int(v452))) >> 5 & 3 | v467 < v452) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v467, v452)) * 0x10000000, 0, 0);
                                    if (v468 & 1)
                                    {
                                        v469 = v467 - *(int *)((char *)v460 + (v463 >> 30));
                                        v470 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v469), 9.999999974752427e-07f)) >> 5 & 3 | v469 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v469)) * 0x10000000, 0, 0);
                                        sub_254534((int)a0[4140]);
                                        v458 = (int)a0[4148];
                                        goto LABEL_2584c4;
                                    }
                                } while ((v464 = v466 - 1, v463 += 0x100000000, v465 = &v465->padding_0[4], v466 != 1));
LABEL_2584c4:
                                if ((unsigned int)v458 && (int)v458 >= 1)
                                    goto LABEL_2584d0;
                            }
                            else
                            {
LABEL_2584d0:
                                if ((unsigned int)v458 != 1 && !(v471 = __int_as_float((int)a0[4156]), v472 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v471), __float_as_int(v452))) >> 5 & 3 | v471 < v452) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v471, v452)) * 0x10000000, 0, 0), v472 & 1))
                                {
                                    v473 = 0;
                                    v474 = a0 + 4240;
                                    v475 = (v458 & 0xffffffff) - 1;
                                    do
                                    {
                                        v476 = v475;
                                        v477 = *(float *)&*(int *)((char *)v474 - 80);
                                        v478 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v477), __float_as_int(v452))) >> 5 & 3 | v477 < v452) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v477, v452)) * 0x10000000, 0, 0);
                                        if (v478 & 1)
                                        {
                                            v479 = v477 - *(int *)((char *)a0 + (v473 >> 30) + 4156);
                                            v480 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v479), 9.999999974752427e-07f)) >> 5 & 3 | v479 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v479)) * 0x10000000, 0, 0);
                                            sub_254534((int)a0[4140]);
                                            goto LABEL_25858c;
                                        }
                                    } while ((v475 = v476 - 1, v473 += 0x100000000, v474 = &v474->padding_0[4], v476 != 1));
                                }
                            }
                        }
LABEL_25858c:
                        v481 = (int)a0[4152];
                        if ((unsigned int)v481 && (int)v481 >= 1 && (unsigned int)v481 != 1 && !(v482 = a0 + 4316, v483 = *(float *)&*v482, v484 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v483), __float_as_int(v452))) >> 5 & 3 | v483 < v452) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v483, v452)) * 0x10000000, 0, 0), v484 & 1))
                        {
                            v485 = 0;
                            v486 = v481 - 1;
                            v487 = a0 + 4360;
                            do
                            {
                                v488 = v486;
                                v489 = *(float *)&*(int *)((char *)v487 - 40);
                                v490 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v489), __float_as_int(v452))) >> 5 & 3 | v489 < v452) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v489, v452)) * 0x10000000, 0, 0);
                                if (v490 & 1)
                                {
                                    v491 = v489 - *(int *)((char *)v482 + (v485 >> 30));
                                    v492 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v491), 9.999999974752427e-07f)) >> 5 & 3 | v491 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v491)) * 0x10000000, 0, 0);
                                    sub_254534((int)a0[4140]);
                                    goto LABEL_258654;
                                }
                            } while ((v486 = v488 - 1, v485 += 0x100000000, v487 = &v487->padding_0[4], v488 != 1));
                        }
LABEL_258654:
                        v446 = v493;
                    }
                }
            }
LABEL_258658:
            v494 = __dirty_unsupported_Iop_ZeroHI96ofV128(_mm_max_ps(v446, _mm_setzero_ps()));
            v496 = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_min_ps(__dirty_unsupported_Iop_ZeroHI64ofV128(_mm_mul_ps(v17, CONCAT(__float_as_int(v494) * 0x100000000 | __float_as_int(v494), __float_as_int(v494) * 0x100000000 | __float_as_int(v494)))), v14));
            v11 = v496;
            sub_22d238(a1, (long long)a0[656]);
            sub_22d238(a1, (long long)a0[664]);
            sub_22d830(a1, (long long)a0[648]);
        }
        if (2 > a1->field_53c - 1)
        {
            v497 = a1->field_52c;
            v498 = sub_22ce80(a1, (long long)a0[672], ~(unsigned int)v497 >> 31);
            if (v497 >> 31 & 1)
                goto LABEL_258738;
            v499 = a1->field_538;
            if (v499 == (int)a0[4444])
            {
                v500 = (int)a0[4440];
                v501 = a1->field_52c;
                if (!(v500 >> 31 & 1))
                {
                    if ((int)v500 > (int)v501)
                    {
                        *(float *)&a0[4412] = a2;
                    }
                    else
                    {
                        v502 = arm64g_calculate_condition(211, v501, v500 & 0xffffffff, 0);
                        if (!(v502 & 1))
                            *(float *)&a0[4424] = a2;
                    }
                }
            }
            else
            {
                v503 = v499 - 42;
                v504 = (long long)a0[720];
                *(float *)&a0[4420] = a2;
                if (23 >= v503)
                {
                    v505 = 1 << ((char)v503 & 31);
                    if (!(v505 & 13) && !(v505 & 0xb00000) && v503 != 22)
                        goto LABEL_2587b0;
                }
                else
                {
LABEL_2587b0:
                }
                if ((long long)a0[1592] && !0x67f990())
                {
                    v506 = a0 + 1592;
                }
                else if ((long long)a0[1608] && !0x67f990())
                {
                    v506 = a0 + 1608;
                }
                else if ((long long)a0[1624] && !0x67f990())
                {
                    v506 = a0 + 1624;
                }
                else if ((long long)a0[1640] && !0x67f990())
                {
                    v506 = a0 + 1640;
                }
                else if (!(long long)a0[1656] || 0x67f990())
                {
                    v507 = a0 + 1600;
                    goto LABEL_258860;
                }
                else
                {
                    v506 = a0 + 1656;
                }
                v507 = v506 + 1;
LABEL_258860:
                sub_22d40c(a1, v504, *(long long *)v507);
                v499 = a1->field_538;
                v501 = a1->field_52c;
            }
            v508 = __int_as_float((int)a0[4420]);
            *(unsigned int *)&a0[4444] = v499;
            *(unsigned int *)&a0[4440] = v501;
            v509 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v508), -50.0f)) >> 5 & 3 | v508 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v508)) * 0x10000000, 0, 0);
            if (!(v509 & 1))
            {
                v510 = a2 - v508;
                v511 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v510), 0.0f)) >> 5 & 3 | v510 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v510)) * 0x10000000, 0, 0);
                if (!(v511 & 1))
                {
                    v512 = __int_as_float((int)a0[3604]);
                    v513 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v512), 0.0f)) >> 5 & 3 | v512 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v512)) * 0x10000000, 0, 0);
                    if (!(v513 & 1))
                    {
                        v514 = v510 - (int)a0[3608];
                        v515 = __int_as_float(0);
                        v516 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v514), 0.0f)) >> 5 & 3 | v514 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v514)) * 0x10000000, 0, 0);
                        if (!(v516 & 1))
                        {
                            v517 = v514 / v512;
                            v518 = (int)a0[3616];
                            if ((int)v518 >= 1 && !(v519 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v517), __float_as_int((float)(int)v518))) >> 5 & 3 | v517 < (float)(int)v518) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v517, (float)(int)v518)) * 0x10000000, 0, 0), !(v519 & 1)))
                                goto LABEL_2589a8;
                            v515 = v517 - floorf(v517);
                        }
                        v520 = (int)a0[3620];
                        if ((unsigned int)v520 && (int)v520 >= 1 && (unsigned int)v520 != 1 && !(v521 = a0 + 3628, v522 = *(float *)&*v521, v523 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v522), __float_as_int(v515))) >> 5 & 3 | v522 < v515) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v522, v515)) * 0x10000000, 0, 0), v523 & 1))
                        {
                            v524 = 0;
                            v525 = a0 + 3672;
                            v526 = v520 - 1;
                            do
                            {
                                v527 = v526;
                                v528 = *(float *)&*(int *)((char *)v525 - 40);
                                v529 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v528), __float_as_int(v515))) >> 5 & 3 | v528 < v515) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v528, v515)) * 0x10000000, 0, 0);
                                if (v529 & 1)
                                {
                                    v530 = v528 - *(int *)((char *)v521 + (v524 >> 30));
                                    v531 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v530), 9.999999974752427e-07f)) >> 5 & 3 | v530 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v530)) * 0x10000000, 0, 0);
                                    sub_254534((int)a0[3612]);
                                    goto LABEL_2589a8;
                                }
                            } while ((v526 = v527 - 1, v524 += 0x100000000, v525 = &v525->padding_0[4], v527 != 1));
                        }
                    }
                }
            }
LABEL_2589a8:
            sub_22d830(a1, (long long)a0[672]);
            v532 = a1->field_52c;
            v533 = 0;
            if (!(v532 >> 31 & 1))
            {
                v534 = a1->field_530;
                if (v534 >= 1)
                {
                    v537 = arm64g_calculate_condition(176, (((((char)(CmpF(__float_as_int((float)v534 * 0.20000000298023224f), __float_as_int((float)(int)(unsigned int)v532))) >> 5 & 3 | (float)v534 * 0.20000000298023224f < (float)(int)v532) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered((float)v534 * 0.20000000298023224f, (float)(int)v532)) * 0x10000000, 0, 0);
                    v533 = !(v537 & 1);
                }
            }
            if ((int)a0[4460] != (unsigned int)v532)
            {
                v538 = (long long)a0[688];
                *(unsigned int *)&a0[4460] = v532;
                sub_63b560();
                sub_22cfc0(a1, v538, &v18);
                if (*&v18 & 1)
                    sub_6790c8(v20);
            }
            sub_22ce80(a1, (long long)a0[680], v533);
            v539 = __int_as_float((int)a0[4412]);
            v540 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v539), -50.0f)) >> 5 & 3 | v539 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v539)) * 0x10000000, 0, 0);
            if (!(v540 & 1) && !(v541 = a2 - v539, v542 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v541), 0.0f)) >> 5 & 3 | v541 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v541)) * 0x10000000, 0, 0), v542 & 1 || (v543 = __int_as_float((int)a0[3076]), v544 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v543), 0.0f)) >> 5 & 3 | v543 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v543)) * 0x10000000, 0, 0), v544 & 1)))
            {
                v545 = __int_as_float(0);
                v546 = v541 - (int)a0[3080];
                v547 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v546), 0.0f)) >> 5 & 3 | v546 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v546)) * 0x10000000, 0, 0);
                if (!(v547 & 1))
                {
                    v548 = v546 / v543;
                    v549 = (int)a0[3088];
                    if ((int)v549 >= 1 && !(v550 = arm64g_calculate_condition(176, (((((char)(CmpF(__float_as_int(v548), __float_as_int((float)(int)v549))) >> 5 & 3 | v548 < (float)(int)v549) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v548, (float)(int)v549)) * 0x10000000, 0, 0), v550 & 1))
                        goto LABEL_258a9c;
                    v545 = v548 - floorf(v548);
                }
                v551 = (int)a0[3096];
                if ((unsigned int)v551 && (int)v551 >= 1 && (unsigned int)v551 != 1 && !(v552 = a0 + 3260, v553 = *(float *)&*v552, v554 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v553), __float_as_int(v545))) >> 5 & 3 | v553 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v553, v545)) * 0x10000000, 0, 0), v554 & 1))
                {
                    v555 = 0;
                    v556 = a0 + 3304;
                    v557 = v551 - 1;
                    do
                    {
                        v558 = v557;
                        v559 = *(float *)&*(int *)((char *)v556 - 40);
                        v560 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v559), __float_as_int(v545))) >> 5 & 3 | v559 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v559, v545)) * 0x10000000, 0, 0);
                        if (v560 & 1)
                        {
                            v561 = v559 - *(int *)((char *)v552 + (v555 >> 30));
                            v562 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v561), 9.999999974752427e-07f)) >> 5 & 3 | v561 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v561)) * 0x10000000, 0, 0);
                            sub_254534((int)a0[0xc0c]);
                            goto LABEL_258e4c;
                        }
                    } while ((v557 = v558 - 1, v555 += 0x100000000, v556 = &v556->padding_0[4], v558 != 1));
                }
LABEL_258e4c:
                sub_22d238(a1);
                v563 = (int)a0[3092];
                if ((unsigned int)v563 && (int)v563 >= 1)
                {
                    v564 = arm64g_calculate_condition(3, v563 & 0xffffffff, 1, 0);
                    if (!(v564 & 1) && !(v565 = a0 + 3100, v566 = *(float *)&*v565, v567 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v566), __float_as_int(v545))) >> 5 & 3 | v566 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v566, v545)) * 0x10000000, 0, 0), v567 & 1))
                    {
                        v568 = 0;
                        v569 = a0 + 3224;
                        v570 = v563 - 1;
                        do
                        {
                            v571 = v570;
                            v572 = *(float *)&*(int *)((char *)v569 - 120);
                            v573 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v572), __float_as_int(v545))) >> 5 & 3 | v572 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v572, v545)) * 0x10000000, 0, 0);
                            if (v573 & 1)
                            {
                                v574 = v572 - *(int *)((char *)v565 + (v568 >> 30));
                                v575 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v574), 9.999999974752427e-07f)) >> 5 & 3 | v574 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v574)) * 0x10000000, 0, 0);
                                sub_254534((int)a0[0xc0c]);
                                v563 = (int)a0[3092];
                                goto LABEL_258f34;
                            }
                        } while ((v570 = v571 - 1, v568 += 0x100000000, v569 = &v569->padding_0[4], v571 != 1));
LABEL_258f34:
                        if ((int)v563 >= 1)
                            goto LABEL_258f3c;
                    }
                    else
                    {
LABEL_258f3c:
                        v576 = a0 + 3100;
                        if ((unsigned int)v563 != 1 && !(v577 = __int_as_float((int)a0[3100]), v578 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v577), __float_as_int(v545))) >> 5 & 3 | v577 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v577, v545)) * 0x10000000, 0, 0), v578 & 1))
                        {
                            v579 = 0;
                            v580 = a0 + 3144;
                            v581 = (v563 & 0xffffffff) - 1;
                            do
                            {
                                v582 = v581;
                                v583 = *(float *)&*(int *)((char *)v580 - 40);
                                v584 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v583), __float_as_int(v545))) >> 5 & 3 | v583 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v583, v545)) * 0x10000000, 0, 0);
                                if (v584 & 1)
                                {
                                    v585 = v583 - *(int *)((char *)v576 + (v579 >> 30));
                                    v586 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v585), 9.999999974752427e-07f)) >> 5 & 3 | v585 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v585)) * 0x10000000, 0, 0);
                                    sub_254534((int)a0[0xc0c]);
                                    v563 = (int)a0[3092];
                                    goto LABEL_259088;
                                }
                            } while ((v581 = v582 - 1, v579 += 0x100000000, v580 = &v580->padding_0[4], v582 != 1));
LABEL_259088:
                            if ((int)v563 < 1)
                                goto LABEL_258ac4;
                        }
                        if ((unsigned int)v563 != 1 && !(v587 = __int_as_float((int)a0[3100]), v588 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v587), __float_as_int(v545))) >> 5 & 3 | v587 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v587, v545)) * 0x10000000, 0, 0), v588 & 1))
                        {
                            v589 = 0;
                            v590 = a0 + 3184;
                            v591 = (v563 & 0xffffffff) - 1;
                            do
                            {
                                v592 = v591;
                                v593 = *(float *)&*(int *)((char *)v590 - 80);
                                v594 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v593), __float_as_int(v545))) >> 5 & 3 | v593 < v545) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v593, v545)) * 0x10000000, 0, 0);
                                if (v594 & 1)
                                {
                                    v595 = v593 - *(int *)((char *)v576 + (v589 >> 30));
                                    v596 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v595), 9.999999974752427e-07f)) >> 5 & 3 | v595 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v595)) * 0x10000000, 0, 0);
                                    sub_254534((int)a0[0xc0c]);
                                    goto LABEL_258ac4;
                                }
                            } while ((v591 = v592 - 1, v589 += 0x100000000, v590 = &v590->padding_0[4], v592 != 1));
                        }
                    }
                }
            }
            else
            {
LABEL_258a9c:
                sub_22d238(a1, (long long)a0[688]);
            }
LABEL_258ac4:
            sub_22d590(a1, (long long)a0[688]);
            sub_22d830(a1, (long long)a0[688]);
            if (v533)
            {
                sub_2592e4(a0, a1, 2, a1->field_52c);
                sub_22d590(a1, (long long)a0[680]);
                sub_22d830(a1, (long long)a0[680]);
            }
            sub_22ce80(a1, (long long)a0[4696]);
            sub_22ce80(a1, (long long)a0[696], a1->field_530 > 0);
            if (a1->field_530 >= 1)
                sub_22d48c(a1, (long long)a0[704]);
            sub_22d238(a1, (long long)a0[704]);
            v597 = a1->field_534;
            if ((unsigned int)v597 != (int)a0[4464])
            {
                v598 = (long long)a0[712];
                *(unsigned int *)&a0[4464] = v597;
                if (!(v597 >> 31 & 1))
                {
                    sub_63b560();
                }
                else
                {
                    v18 = 0;
                    v19 = 0;
                    v20 = 0;
                }
                sub_22cfc0(a1, v598, &v18);
                if ((char)v18 & 1)
                    sub_6790c8(v20);
            }
            sub_22d238(a1, (long long)a0[712]);
            sub_22d238(a1, (long long)a0[720]);
            v599 = __int_as_float((int)a0[4424]);
            v600 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v599), -50.0f)) >> 5 & 3 | v599 < -50.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v599)) * 0x10000000, 0, 0);
            if (!(v600 & 1))
            {
                v601 = a2 - v599;
                v602 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v601), 0.0f)) >> 5 & 3 | v601 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v601)) * 0x10000000, 0, 0);
                if (!(v602 & 1))
                {
                    v603 = __int_as_float((int)a0[3868]);
                    v604 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v603), 0.0f)) >> 5 & 3 | v603 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v603)) * 0x10000000, 0, 0);
                    if (!(v604 & 1))
                    {
                        v605 = v601 - (int)a0[3872];
                        v606 = __int_as_float(0);
                        v607 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v605), 0.0f)) >> 5 & 3 | v605 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v605)) * 0x10000000, 0, 0);
                        if (!(v607 & 1))
                        {
                            v608 = v605 / v603;
                            v609 = (int)a0[3880];
                            if ((int)v609 >= 1 && !(v610 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v608), __float_as_int((float)(int)v609))) >> 5 & 3 | v608 < (float)(int)v609) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v608, (float)(int)v609)) * 0x10000000, 0, 0), !(v610 & 1)))
                                goto LABEL_258fe4;
                            v606 = v608 - floorf(v608);
                        }
                        v611 = (int)a0[3884];
                        if ((unsigned int)v611 && (int)v611 >= 1 && (unsigned int)v611 != 1 && !(v612 = a0 + 3892, v613 = *(float *)&*v612, v614 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v613), __float_as_int(v606))) >> 5 & 3 | v613 < v606) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v613, v606)) * 0x10000000, 0, 0), v614 & 1))
                        {
                            v615 = 0;
                            v616 = a0 + 3936;
                            v617 = v611 - 1;
                            do
                            {
                                v618 = v617;
                                v619 = *(float *)&*(int *)((char *)v616 - 40);
                                v620 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v619), __float_as_int(v606))) >> 5 & 3 | v619 < v606) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v619, v606)) * 0x10000000, 0, 0);
                                if (v620 & 1)
                                {
                                    v621 = v619 - *(int *)((char *)v612 + (v615 >> 30));
                                    v622 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v621), 9.999999974752427e-07f)) >> 5 & 3 | v621 < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v621)) * 0x10000000, 0, 0);
                                    sub_254534((int)a0[3876]);
                                    goto LABEL_258fe4;
                                }
                            } while ((v617 = v618 - 1, v615 += 0x100000000, v616 = &v616->padding_0[4], v618 != 1));
                        }
                    }
                }
            }
LABEL_258fe4:
            v498 = sub_22d590(a1, (long long)a0[720]);
        }
        else
        {
            v498 = sub_22ce80(a1, (long long)a0[672], 0);
LABEL_258738:
            *(unsigned long *)&a0[4440] = 0xffffffffffffffff;
        }
        if (v24->field_28 == v21)
            return v498;
    }
    else
    {
        *(unsigned int *)&a0[4476] = 0;
        *(unsigned long *)&a0[4432] = 0xffffffffffffffff;
        *(unsigned long *)&a0[4440] = 0xffffffffffffffff;
        *(char *)&v43[405] = 1;
        sub_28dd44();
        if (v24->field_28 == v21)
            return sub_28dfb8();
    }
    6813312();
}
