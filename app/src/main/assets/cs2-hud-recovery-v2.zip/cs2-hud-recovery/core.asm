
FUNCTION 0x254eb8
254eb8: sub sp, sp, #0xa0
254ebc: stp x29, x30, [sp, #0x40]
254ec0: stp x28, x27, [sp, #0x50]
254ec4: stp x26, x25, [sp, #0x60]
254ec8: stp x24, x23, [sp, #0x70]
254ecc: stp x22, x21, [sp, #0x80]
254ed0: stp x20, x19, [sp, #0x90]
254ed4: add x29, sp, #0x40
254ed8: mrs x20, tpidr_el0
254edc: adrp x21, #0x6fe000
254ee0: add x21, x21, #0xc6b
254ee4: ldr x8, [x20, #0x28]
254ee8: mov x28, x1
254eec: mov x19, x0
254ef0: adrp x1, #0x6a1000
254ef4: add x1, x1, #0x22b
254ef8: mov x0, x21
254efc: mov x2, xzr
254f00: stur x8, [x29, #-8]
254f04: bl #0x23cbf0
254f08: mov w22, w0
254f0c: adrp x1, #0x6c3000
254f10: add x1, x1, #0x6a9
254f14: mov x0, x21
254f18: mov w2, #0x18
254f1c: bl #0x23cbf0
254f20: str w0, [x19, #0x1e0]
254f24: adrp x1, #0x6bb000
254f28: add x1, x1, #0xff6
254f2c: mov x0, x21
254f30: mov w2, #0x1f
254f34: bl #0x23cbf0
254f38: str w0, [x19, #0x1e4]
254f3c: adrp x1, #0x6d6000
254f40: add x1, x1, #0x792
254f44: mov x0, x21
254f48: mov w2, #0x1c
254f4c: bl #0x23cbf0
254f50: str w0, [x19, #0x1e8]
254f54: adrp x1, #0x693000
254f58: add x1, x1, #0x60a
254f5c: mov x0, x21
254f60: mov w2, #0x11
254f64: bl #0x23cbf0
254f68: mov w8, w0
254f6c: mov w0, wzr
254f70: str w8, [x19, #0x1270]
254f74: tbnz w22, #0x1f, #0x255ff8
254f78: ldr w8, [x19, #0x1e0]
254f7c: tbnz w8, #0x1f, #0x255ff8
254f80: add x8, x19, #0x6ac
254f84: mov x24, #-0x10000
254f88: add x25, x19, #0x2d8
254f8c: stp x8, x20, [sp, #0x18]
254f90: add x8, x19, #0x578
254f94: mov w20, #0x2d8
254f98: mov w21, #-1
254f9c: movk x24, #0xc2c8, lsl #16
254fa0: stp x8, x25, [sp, #8]
254fa4: b #0x254fe0
254fa8: str x27, [x25, #0x10]
254fac: bl #0x6790c8
254fb0: movi v0.2d, #0000000000000000
254fb4: movi v1.2d, #0xffffffffffffffff
254fb8: add x20, x20, #0x80
254fbc: str wzr, [x25, #0x70]
254fc0: cmp x20, #0x5d8
254fc4: stur x24, [x25, #0x74]
254fc8: str d1, [x25, #0x48]
254fcc: stp q0, q0, [x25, #0x50]
254fd0: add x25, x19, x20
254fd4: stp q0, q0, [x26]
254fd8: stp q0, q0, [x26, #0x20]
254fdc: b.eq #0x25501c
254fe0: mov x26, x25
254fe4: str w21, [x25]
254fe8: ldr x27, [x26, #8]!
254fec: cbz x27, #0x254fb0
254ff0: ldr x23, [x25, #0x10]
254ff4: mov x0, x27
254ff8: cmp x23, x27
254ffc: b.eq #0x254fa8
255000: sub x23, x23, #0x120
255004: mov x0, x23
255008: bl #0x215c38
25500c: cmp x23, x27
255010: b.ne #0x255000
255014: ldr x0, [x26]
255018: b #0x254fa8
25501c: ldp x9, x10, [x19, #0x38]
255020: add x3, x19, #0x1c0
255024: ldr w8, [x19, #0x1e0]
255028: ldr w11, [x19, #0x1270]
25502c: sub x4, x29, #0x10
255030: mov x0, x28
255034: mov w1, w22
255038: mov w5, #2
25503c: cmp x9, #0
255040: mov w6, #1
255044: mov w7, wzr
255048: csel x2, xzr, x10, eq
25504c: stp w8, w11, [x29, #-0x10]
255050: bl #0x22bf2c
255054: ldr x20, [sp, #0x20]
255058: mov w8, w0
25505c: mov w0, wzr
255060: tbz w8, #0, #0x255ff8
255064: add x0, x19, #0x1c0
255068: mov w1, w22
25506c: stur x28, [x29, #-0x18]
255070: bl #0x23d928
255074: adrp x22, #0x6fe000
255078: add x22, x22, #0xc6b
25507c: str x0, [x19, #0x1f0]
255080: adrp x1, #0x6e2000
255084: add x1, x1, #0x36c
255088: mov x0, x22
25508c: mov w2, #8
255090: bl #0x23cbf0
255094: mov w1, w0
255098: add x0, x19, #0x1c0
25509c: bl #0x23d928
2550a0: str x0, [x19, #0x1f8]
2550a4: adrp x1, #0x6ab000
2550a8: add x1, x1, #0xef0
2550ac: mov x0, x22
2550b0: mov w2, #5
2550b4: bl #0x23cbf0
2550b8: mov w1, w0
2550bc: add x0, x19, #0x1c0
2550c0: bl #0x23d928
2550c4: str x0, [x19, #0x200]
2550c8: adrp x1, #0x6a7000
2550cc: add x1, x1, #0xbcb
2550d0: mov x0, x22
2550d4: mov w2, #0xb
2550d8: bl #0x23cbf0
2550dc: mov w1, w0
2550e0: add x0, x19, #0x1c0
2550e4: bl #0x23d928
2550e8: str x0, [x19, #0x208]
2550ec: adrp x1, #0x6c3000
2550f0: add x1, x1, #0x6c2
2550f4: mov x0, x22
2550f8: mov w2, #0x11
2550fc: bl #0x23cbf0
255100: mov w1, w0
255104: add x0, x19, #0x1c0
255108: bl #0x23d928
25510c: str x0, [x19, #0x210]
255110: adrp x1, #0x6bc000
255114: add x1, x1, #0x16
255118: mov x0, x22
25511c: mov w2, #0x15
255120: bl #0x23cbf0
255124: mov w1, w0
255128: add x0, x19, #0x1c0
25512c: bl #0x23d928
255130: str x0, [x19, #0x218]
255134: adrp x1, #0x6b3000
255138: add x1, x1, #0xe92
25513c: mov x0, x22
255140: mov w2, #0x17
255144: bl #0x23cbf0
255148: mov w1, w0
25514c: add x0, x19, #0x1c0
255150: bl #0x23d928
255154: str x0, [x19, #0x220]
255158: adrp x1, #0x6d2000
25515c: add x1, x1, #0x187
255160: mov x0, x22
255164: mov w2, #0xd
255168: bl #0x23cbf0
25516c: mov w1, w0
255170: add x0, x19, #0x1c0
255174: bl #0x23d928
255178: str x0, [x19, #0x228]
25517c: adrp x1, #0x6c3000
255180: add x1, x1, #0x6d4
255184: mov x0, x22
255188: mov w2, #0xd
25518c: bl #0x23cbf0
255190: mov w1, w0
255194: add x0, x19, #0x1c0
255198: bl #0x23d928
25519c: str x0, [x19, #0x230]
2551a0: adrp x1, #0x6bf000
2551a4: add x1, x1, #0x96e
2551a8: mov x0, x22
2551ac: mov w2, #0x13
2551b0: bl #0x23cbf0
2551b4: mov w1, w0
2551b8: add x0, x19, #0x1c0
2551bc: bl #0x23d928
2551c0: str x0, [x19, #0x238]
2551c4: adrp x1, #0x687000
2551c8: add x1, x1, #0xc1d
2551cc: mov x0, x22
2551d0: mov w2, #0x12
2551d4: bl #0x23cbf0
2551d8: mov w1, w0
2551dc: add x0, x19, #0x1c0
2551e0: bl #0x23d928
2551e4: str x0, [x19, #0x240]
2551e8: adrp x1, #0x6a0000
2551ec: add x1, x1, #0x5d0
2551f0: mov x0, x22
2551f4: mov w2, #0xc
2551f8: bl #0x23cbf0
2551fc: mov w1, w0
255200: add x0, x19, #0x1c0
255204: bl #0x23d928
255208: str x0, [x19, #0x248]
25520c: adrp x1, #0x68f000
255210: add x1, x1, #0x884
255214: mov x0, x22
255218: mov w2, #0x16
25521c: bl #0x23cbf0
255220: mov w1, w0
255224: add x0, x19, #0x1c0
255228: bl #0x23d928
25522c: str x0, [x19, #0x250]
255230: adrp x1, #0x6a0000
255234: add x1, x1, #0x5dd
255238: mov x0, x22
25523c: mov w2, #0x12
255240: bl #0x23cbf0
255244: mov w1, w0
255248: add x0, x19, #0x1c0
25524c: bl #0x23d928
255250: str x0, [x19, #0x258]
255254: adrp x1, #0x6ce000
255258: add x1, x1, #0x9d0
25525c: mov x0, x22
255260: mov w2, #0x12
255264: bl #0x23cbf0
255268: mov w1, w0
25526c: add x0, x19, #0x1c0
255270: bl #0x23d928
255274: str x0, [x19, #0x260]
255278: adrp x1, #0x68f000
25527c: add x1, x1, #0x89b
255280: mov x0, x22
255284: mov w2, #0x17
255288: bl #0x23cbf0
25528c: mov w1, w0
255290: add x0, x19, #0x1c0
255294: bl #0x23d928
255298: str x0, [x19, #0x268]
25529c: adrp x1, #0x6f1000
2552a0: add x1, x1, #0x71b
2552a4: mov x0, x22
2552a8: mov w2, #0x18
2552ac: bl #0x23cbf0
2552b0: mov w1, w0
2552b4: add x0, x19, #0x1c0
2552b8: bl #0x23d928
2552bc: str x0, [x19, #0x270]
2552c0: adrp x1, #0x6ed000
2552c4: add x1, x1, #0xb12
2552c8: mov x0, x22
2552cc: mov w2, #0x10
2552d0: bl #0x23cbf0
2552d4: mov w1, w0
2552d8: add x0, x19, #0x1c0
2552dc: bl #0x23d928
2552e0: str x0, [x19, #0x278]
2552e4: adrp x1, #0x6de000
2552e8: add x1, x1, #0x39c
2552ec: mov x0, x22
2552f0: mov w2, #0x15
2552f4: bl #0x23cbf0
2552f8: mov w1, w0
2552fc: add x0, x19, #0x1c0
255300: bl #0x23d928
255304: str x0, [x19, #0x280]
255308: adrp x1, #0x6c3000
25530c: add x1, x1, #0x6e2
255310: mov x0, x22
255314: mov w2, #0xb
255318: bl #0x23cbf0
25531c: mov w1, w0
255320: add x0, x19, #0x1c0
255324: bl #0x23d928
255328: str x0, [x19, #0x288]
25532c: adrp x1, #0x693000
255330: add x1, x1, #0x61c
255334: mov x0, x22
255338: mov w2, #0x10
25533c: bl #0x23cbf0
255340: mov w1, w0
255344: add x0, x19, #0x1c0
255348: bl #0x23d928
25534c: str x0, [x19, #0x290]
255350: adrp x1, #0x6d6000
255354: add x1, x1, #0x7af
255358: mov x0, x22
25535c: mov w2, #0x11
255360: bl #0x23cbf0
255364: mov w1, w0
255368: add x0, x19, #0x1c0
25536c: bl #0x23d928
255370: str x0, [x19, #0x298]
255374: adrp x1, #0x6ed000
255378: add x1, x1, #0xb23
25537c: mov x0, x22
255380: mov w2, #0xa
255384: bl #0x23cbf0
255388: mov w1, w0
25538c: add x0, x19, #0x1c0
255390: bl #0x23d928
255394: str x0, [x19, #0x2a0]
255398: adrp x1, #0x6d2000
25539c: add x1, x1, #0x195
2553a0: mov x0, x22
2553a4: mov w2, #0x13
2553a8: bl #0x23cbf0
2553ac: mov w1, w0
2553b0: add x0, x19, #0x1c0
2553b4: bl #0x23d928
2553b8: str x0, [x19, #0x2a8]
2553bc: adrp x1, #0x6d2000
2553c0: add x1, x1, #0x1a9
2553c4: mov x0, x22
2553c8: mov w2, #0xf
2553cc: bl #0x23cbf0
2553d0: mov w1, w0
2553d4: add x0, x19, #0x1c0
2553d8: bl #0x23d928
2553dc: str x0, [x19, #0x2b0]
2553e0: adrp x1, #0x6ac000
2553e4: add x1, x1, #0x80
2553e8: mov x0, x22
2553ec: mov w2, #0x12
2553f0: bl #0x23cbf0
2553f4: mov w1, w0
2553f8: add x0, x19, #0x1c0
2553fc: bl #0x23d928
255400: str x0, [x19, #0x2b8]
255404: adrp x1, #0x69c000
255408: add x1, x1, #0x6bb
25540c: mov x0, x22
255410: mov w2, #0x17
255414: bl #0x23cbf0
255418: mov w1, w0
25541c: add x0, x19, #0x1c0
255420: bl #0x23d928
255424: str x0, [x19, #0x2c0]
255428: adrp x1, #0x6de000
25542c: add x1, x1, #0x3b2
255430: mov x0, x22
255434: mov w2, #0x12
255438: bl #0x23cbf0
25543c: mov w1, w0
255440: add x0, x19, #0x1c0
255444: bl #0x23d928
255448: str x0, [x19, #0x2c8]
25544c: adrp x1, #0x6f9000
255450: add x1, x1, #0x484
255454: mov x0, x22
255458: mov w2, #0x16
25545c: bl #0x23cbf0
255460: mov w1, w0
255464: add x0, x19, #0x1c0
255468: bl #0x23d928
25546c: str x0, [x19, #0x2d0]
255470: adrp x1, #0x6ac000
255474: add x1, x1, #0x93
255478: mov x0, x22
25547c: mov w2, #0x19
255480: bl #0x23cbf0
255484: mov w1, w0
255488: add x0, x19, #0x1c0
25548c: bl #0x23d928
255490: mov x20, x0
255494: adrp x1, #0x6da000
255498: add x1, x1, #0x3e5
25549c: mov x0, x22
2554a0: mov w2, #0x19
2554a4: bl #0x23cbf0
2554a8: mov w1, w0
2554ac: add x0, x19, #0x1c0
2554b0: bl #0x23d928
2554b4: mov x24, x0
2554b8: adrp x1, #0x6a7000
2554bc: add x1, x1, #0xbd7
2554c0: mov x0, x22
2554c4: mov w2, #0x19
2554c8: bl #0x23cbf0
2554cc: mov w1, w0
2554d0: add x0, x19, #0x1c0
2554d4: bl #0x23d928
2554d8: mov x25, x0
2554dc: adrp x1, #0x693000
2554e0: add x1, x1, #0x62d
2554e4: mov x0, x22
2554e8: mov w2, #0x1a
2554ec: bl #0x23cbf0
2554f0: mov w1, w0
2554f4: add x0, x19, #0x1c0
2554f8: bl #0x23d928
2554fc: mov x26, x0
255500: adrp x1, #0x687000
255504: add x1, x1, #0xc30
255508: mov x0, x22
25550c: mov w2, #0x1a
255510: bl #0x23cbf0
255514: mov w1, w0
255518: add x0, x19, #0x1c0
25551c: bl #0x23d928
255520: mov x27, x0
255524: adrp x1, #0x6af000
255528: add x1, x1, #0xf10
25552c: mov x0, x22
255530: mov w2, #0x1a
255534: bl #0x23cbf0
255538: mov w1, w0
25553c: add x0, x19, #0x1c0
255540: bl #0x23d928
255544: mov x28, x0
255548: adrp x1, #0x6bc000
25554c: add x1, x1, #0x2c
255550: mov x0, x22
255554: mov w2, #0x16
255558: bl #0x23cbf0
25555c: mov w1, w0
255560: add x0, x19, #0x1c0
255564: bl #0x23d928
255568: mov x21, x0
25556c: adrp x1, #0x6f5000
255570: add x1, x1, #0x835
255574: mov x0, x22
255578: mov w2, #0x16
25557c: bl #0x23cbf0
255580: mov w1, w0
255584: add x0, x19, #0x1c0
255588: bl #0x23d928
25558c: mov x23, x0
255590: adrp x1, #0x6f5000
255594: add x1, x1, #0x84c
255598: mov x0, x22
25559c: mov w2, #0x16
2555a0: bl #0x23cbf0
2555a4: mov w1, w0
2555a8: add x0, x19, #0x1c0
2555ac: bl #0x23d928
2555b0: str x0, [x19, #0x11f0]
2555b4: adrp x0, #0x6d6000
2555b8: add x0, x0, #0x60b
2555bc: mov w1, #0xb
2555c0: str x20, [x19, #0x11b0]
2555c4: str x24, [x19, #0x11b8]
2555c8: str x25, [x19, #0x11c0]
2555cc: str x26, [x19, #0x11c8]
2555d0: str x27, [x19, #0x11d0]
2555d4: str x28, [x19, #0x11d8]
2555d8: str x21, [x19, #0x11e0]
2555dc: str x23, [x19, #0x11e8]
2555e0: bl #0x23d184
2555e4: str x0, [sp]
2555e8: adrp x0, #0x6fc000
2555ec: add x0, x0, #0xf76
2555f0: mov w1, #0xb
2555f4: bl #0x23d184
2555f8: mov x21, x0
2555fc: adrp x0, #0x700000
255600: add x0, x0, #0xb39
255604: mov w1, #0xb
255608: bl #0x23d184
25560c: mov x24, x0
255610: adrp x0, #0x687000
255614: add x0, x0, #0xa6e
255618: mov w1, #0xb
25561c: bl #0x23d184
255620: mov x25, x0
255624: adrp x0, #0x6a0000
255628: add x0, x0, #0x37c
25562c: mov w1, #0xb
255630: bl #0x23d184
255634: mov x26, x0
255638: adrp x0, #0x6c7000
25563c: add x0, x0, #0x8d2
255640: mov w1, #0xb
255644: bl #0x23d184
255648: mov x27, x0
25564c: adrp x0, #0x6da000
255650: add x0, x0, #0x242
255654: mov w1, #0xb
255658: bl #0x23d184
25565c: mov x28, x0
255660: adrp x0, #0x6e9000
255664: add x0, x0, #0xc8c
255668: mov w1, #0xb
25566c: bl #0x23d184
255670: mov x23, x0
255674: adrp x0, #0x6da000
255678: add x0, x0, #0x24e
25567c: mov w1, #0xb
255680: bl #0x23d184
255684: mov x20, x0
255688: adrp x0, #0x687000
25568c: add x0, x0, #0xa7a
255690: mov w1, #0xb
255694: bl #0x23d184
255698: ldr x8, [sp]
25569c: str x0, [x19, #0x1240]
2556a0: adrp x0, #0x6d6000
2556a4: add x0, x0, #0x719
2556a8: mov w1, #0x10
2556ac: mov w2, wzr
2556b0: str x8, [x19, #0x11f8]
2556b4: str x21, [x19, #0x1200]
2556b8: str x24, [x19, #0x1208]
2556bc: str x25, [x19, #0x1210]
2556c0: str x26, [x19, #0x1218]
2556c4: str x27, [x19, #0x1220]
2556c8: str x28, [x19, #0x1228]
2556cc: str x23, [x19, #0x1230]
2556d0: str x20, [x19, #0x1238]
2556d4: bl #0x23d338
2556d8: movi v1.2d, #0xffffffffffffffff
2556dc: mov w8, #-1
2556e0: adrp x1, #0x6c3000
2556e4: add x1, x1, #0x6ee
2556e8: mov x0, x22
2556ec: mov w2, #0x16
2556f0: str s0, [x19, #0x1254]
2556f4: str w8, [x19, #0x1250]
2556f8: str d1, [x19, #0x1248]
2556fc: bl #0x23cbf0
255700: mov w1, w0
255704: add x0, x19, #0x1c0
255708: bl #0x23d928
25570c: str x0, [x19, #0x1258]
255710: adrp x1, #0x6bc000
255714: add x1, x1, #0x43
255718: mov x0, x22
25571c: mov w2, #8
255720: bl #0x23cbf0
255724: mov w1, w0
255728: add x0, x19, #0x1c0
25572c: bl #0x23d928
255730: ldr x2, [x19, #0x1f0]
255734: mov x8, x0
255738: mov w0, wzr
25573c: str x8, [x19, #0x1278]
255740: cbz x2, #0x255ff4
255744: ldr x8, [x19, #0x200]
255748: cbz x8, #0x255ff4
25574c: ldr x8, [x19, #0x208]
255750: ldr x20, [sp, #0x20]
255754: ldur x28, [x29, #-0x18]
255758: cbz x8, #0x255ff8
25575c: add x1, x19, #8
255760: mov x0, x28
255764: bl #0x23dc40
255768: ldr x1, [x19, #0x1278]
25576c: mov x0, x28
255770: bl #0x28ce90
255774: adrp x0, #0x69c000
255778: add x0, x0, #0x52f
25577c: mov w1, #0xa
255780: bl #0x23d184
255784: mov x20, x0
255788: adrp x0, #0x6d6000
25578c: add x0, x0, #0x64f
255790: mov w1, #0xa
255794: bl #0x23d184
255798: mov x21, x0
25579c: adrp x0, #0x6e5000
2557a0: add x0, x0, #0xd6d
2557a4: mov w1, #0xa
2557a8: bl #0x23d184
2557ac: mov x22, x0
2557b0: adrp x0, #0x68f000
2557b4: add x0, x0, #0x6d7
2557b8: mov w1, #0xa
2557bc: bl #0x23d184
2557c0: mov x23, x0
2557c4: adrp x0, #0x687000
2557c8: add x0, x0, #0xacb
2557cc: mov w1, #0xa
2557d0: bl #0x23d184
2557d4: str x0, [x19, #0x5f8]
2557d8: adrp x0, #0x6a0000
2557dc: add x0, x0, #0x388
2557e0: mov w1, #0x14
2557e4: str x20, [x19, #0x5d8]
2557e8: add x25, x19, #0x5d8
2557ec: str x21, [x19, #0x5e0]
2557f0: str x22, [x19, #0x5e8]
2557f4: str x23, [x19, #0x5f0]
2557f8: bl #0x23d184
2557fc: mov x20, x0
255800: adrp x0, #0x6e2000
255804: add x0, x0, #0x339
255808: mov w1, #0x15
25580c: bl #0x23d184
255810: mov x21, x0
255814: adrp x0, #0x6cb000
255818: add x0, x0, #0xb9
25581c: mov w1, #0x12
255820: bl #0x23d184
255824: mov x22, x0
255828: adrp x0, #0x6b3000
25582c: add x0, x0, #0xd9d
255830: mov w1, #0x11
255834: bl #0x23d184
255838: mov x23, x0
25583c: adrp x0, #0x6fc000
255840: add x0, x0, #0xf93
255844: mov w1, #0x12
255848: bl #0x23d184
25584c: mov x26, xzr
255850: mov x27, xzr
255854: str x22, [x19, #0x610]
255858: str x23, [x19, #0x618]
25585c: adrp x22, #0x6fe000
255860: add x22, x22, #0xc6b
255864: adrp x23, #0x68f000
255868: add x23, x23, #0x8b3
25586c: str x20, [x19, #0x600]
255870: str x21, [x19, #0x608]
255874: str x0, [x19, #0x620]
255878: ldr x8, [x19, #0x208]
25587c: add x20, x25, x26
255880: ldr w1, [x19, #0x1e0]
255884: sub x24, x20, #0x300
255888: mov x0, x28
25588c: mov x4, xzr
255890: ldp x9, x8, [x8, #0x10]
255894: mov x3, x24
255898: mov x5, xzr
25589c: mov w6, #1
2558a0: mov w7, wzr
2558a4: cmp x9, #0
2558a8: csel x2, xzr, x8, eq
2558ac: bl #0x22bf2c
2558b0: tbz w0, #0, #0x255fe8
2558b4: ldr w1, [x19, #0x1e0]
2558b8: mov x0, x24
2558bc: bl #0x23d928
2558c0: sub x21, x20, #0x2e0
2558c4: ldr w1, [x19, #0x1e4]
2558c8: str x0, [x21]
2558cc: mov x0, x24
2558d0: bl #0x23d928
2558d4: sub x28, x20, #0x2d8
2558d8: ldr w1, [x19, #0x1e8]
2558dc: str x0, [x28]
2558e0: mov x0, x24
2558e4: bl #0x23d928
2558e8: sub x8, x20, #0x2d0
2558ec: mov x1, x23
2558f0: mov w2, #0x22
2558f4: str x0, [x8]
2558f8: mov x0, x22
2558fc: bl #0x23cbf0
255900: mov w1, w0
255904: mov x0, x24
255908: bl #0x23d928
25590c: movi d0, #0000000000000000
255910: sub x8, x20, #0x2c0
255914: ldr x1, [x21]
255918: str x0, [x8]
25591c: ldur x0, [x29, #-0x18]
255920: bl #0x22cf38
255924: ldr x1, [x21]
255928: ldur x0, [x29, #-0x18]
25592c: mov w2, #1
255930: bl #0x22ce80
255934: ldr x1, [x28]
255938: ldur x28, [x29, #-0x18]
25593c: ldr x2, [x25, x27]
255940: mov x0, x28
255944: bl #0x22d40c
255948: add x27, x27, #8
25594c: add x26, x26, #0x80
255950: cmp x27, #0x28
255954: b.ne #0x255878
255958: ldr q0, [x19, #0x210]
25595c: ldr x8, [x19, #0x220]
255960: adrp x0, #0x6fe000
255964: add x0, x0, #0xc6b
255968: ldr x9, [sp, #8]
25596c: adrp x1, #0x6f9000
255970: add x1, x1, #0x49b
255974: mov w2, #0x1b
255978: str x8, [x19, #0x590]
25597c: str q0, [x9]
255980: bl #0x23cbf0
255984: mov w1, w0
255988: add x0, x19, #0x1c0
25598c: bl #0x23d928
255990: ldr x1, [x19, #0x210]
255994: str x0, [x19, #0x598]
255998: cbz x1, #0x2559e8
25599c: movi d0, #0000000000000000
2559a0: mov x0, x28
2559a4: bl #0x22cf38
2559a8: ldr x1, [x19, #0x210]
2559ac: mov x0, x28
2559b0: mov w2, #1
2559b4: bl #0x22ce80
2559b8: ldr x8, [x19, #0x210]
2559bc: ldp x9, x8, [x8, #0x10]
2559c0: cmp x9, #0
2559c4: csel x22, xzr, x8, eq
2559c8: mov x0, x22
2559cc: bl #0x198128
2559d0: tbz w0, #0, #0x2559e8
2559d4: cbz x22, #0x2559e8
2559d8: ldr x8, [x28, #0xd0]
2559dc: mov x0, x22
2559e0: mov x1, xzr
2559e4: blr x8
2559e8: adrp x8, #0x683000
2559ec: str wzr, [x19, #0x334]
2559f0: adrp x22, #0x6fe000
2559f4: add x22, x22, #0xc6b
2559f8: ldr d0, [x8, #0xdd8]
2559fc: add x8, x19, #0x334
255a00: str wzr, [x19, #0x3b4]
255a04: adrp x1, #0x6a4000
255a08: add x1, x1, #0x273
255a0c: str d0, [x19, #0x338]
255a10: mov x0, x22
255a14: mov w2, #0x1b
255a18: ldr x8, [x8]
255a1c: str d0, [x19, #0x3b8]
255a20: ldr w9, [x19, #0x33c]
255a24: ldr w10, [x19, #0x3bc]
255a28: str d0, [x19, #0x438]
255a2c: str x8, [x19, #0x328]
255a30: str x8, [x19, #0x340]
255a34: add x8, x19, #0x3b4
255a38: ldr x8, [x8]
255a3c: str w9, [x19, #0x330]
255a40: str w9, [x19, #0x348]
255a44: add x9, x19, #0x434
255a48: str wzr, [x19, #0x434]
255a4c: str w10, [x19, #0x3b0]
255a50: str x8, [x19, #0x3a8]
255a54: str w10, [x19, #0x3c8]
255a58: ldr w10, [x19, #0x43c]
255a5c: str x8, [x19, #0x3c0]
255a60: ldr x8, [x9]
255a64: add x9, x19, #0x4b4
255a68: str d0, [x19, #0x4b8]
255a6c: str wzr, [x19, #0x4b4]
255a70: str w10, [x19, #0x430]
255a74: str x8, [x19, #0x428]
255a78: str w10, [x19, #0x448]
255a7c: ldr w10, [x19, #0x4bc]
255a80: str x8, [x19, #0x440]
255a84: ldr x8, [x9]
255a88: add x9, x19, #0x534
255a8c: str d0, [x19, #0x538]
255a90: str wzr, [x19, #0x534]
255a94: str w10, [x19, #0x4b0]
255a98: str x8, [x19, #0x4a8]
255a9c: str w10, [x19, #0x4c8]
255aa0: ldr w10, [x19, #0x53c]
255aa4: str x8, [x19, #0x4c0]
255aa8: ldr x8, [x9]
255aac: add x9, x19, #0x5b4
255ab0: str d0, [x19, #0x5b8]
255ab4: str wzr, [x19, #0x5b4]
255ab8: str w10, [x19, #0x530]
255abc: str x8, [x19, #0x528]
255ac0: str w10, [x19, #0x548]
255ac4: ldr w10, [x19, #0x5bc]
255ac8: str x8, [x19, #0x540]
255acc: ldr x8, [x9]
255ad0: str w10, [x19, #0x5b0]
255ad4: str x8, [x19, #0x5a8]
255ad8: str w10, [x19, #0x5c8]
255adc: str x8, [x19, #0x5c0]
255ae0: bl #0x23cbf0
255ae4: mov w23, w0
255ae8: ldr x0, [sp, #0x10]
255aec: mov w1, w23
255af0: bl #0x23d928
255af4: mov x1, x0
255af8: mov x0, x28
255afc: mov w2, #1
255b00: bl #0x246b10
255b04: str w0, [x19, #0x320]
255b08: add x0, x19, #0x358
255b0c: mov w1, w23
255b10: bl #0x23d928
255b14: mov x1, x0
255b18: mov x0, x28
255b1c: mov w2, #1
255b20: bl #0x246b10
255b24: str w0, [x19, #0x3a0]
255b28: add x0, x19, #0x3d8
255b2c: mov w1, w23
255b30: bl #0x23d928
255b34: mov x1, x0
255b38: mov x0, x28
255b3c: mov w2, #1
255b40: bl #0x246b10
255b44: str w0, [x19, #0x420]
255b48: add x0, x19, #0x458
255b4c: mov w1, w23
255b50: bl #0x23d928
255b54: mov x1, x0
255b58: mov x0, x28
255b5c: mov w2, #1
255b60: bl #0x246b10
255b64: str w0, [x19, #0x4a0]
255b68: add x0, x19, #0x4d8
255b6c: mov w1, w23
255b70: bl #0x23d928
255b74: mov x1, x0
255b78: mov x0, x28
255b7c: mov w2, #1
255b80: bl #0x246b10
255b84: str w0, [x19, #0x520]
255b88: adrp x1, #0x68f000
255b8c: add x1, x1, #0x8d6
255b90: mov x0, x22
255b94: mov w2, #0x16
255b98: bl #0x23cbf0
255b9c: mov w1, w0
255ba0: add x0, x19, #0x1c0
255ba4: bl #0x23d928
255ba8: mov x1, x0
255bac: mov x0, x28
255bb0: mov w2, #1
255bb4: bl #0x246b10
255bb8: str w0, [x19, #0x5a0]
255bbc: adrp x1, #0x6af000
255bc0: add x1, x1, #0xf2b
255bc4: mov x0, x22
255bc8: mov w2, #0xc
255bcc: bl #0x23cbf0
255bd0: mov w1, w0
255bd4: add x0, x19, #0x1c0
255bd8: bl #0x23d928
255bdc: mov x1, x0
255be0: mov x0, x28
255be4: mov w2, #2
255be8: bl #0x246b10
255bec: ldr x1, [x19, #0x208]
255bf0: mov x0, x28
255bf4: mov w2, wzr
255bf8: bl #0x22b5e4
255bfc: adrp x0, #0x6f5000
255c00: add x0, x0, #0x74a
255c04: mov w1, #9
255c08: bl #0x23d184
255c0c: str x0, [x19, #0x628]
255c10: adrp x0, #0x6bb000
255c14: add x0, x0, #0xeac
255c18: mov w1, #0x10
255c1c: bl #0x23d184
255c20: adrp x20, #0x6ce000
255c24: add x20, x20, #0x830
255c28: str x0, [x19, #0x630]
255c2c: mov x0, x20
255c30: mov w1, #0x19
255c34: bl #0x23d184
255c38: adrp x22, #0x6a7000
255c3c: add x22, x22, #0x9a0
255c40: mov x21, x0
255c44: mov x0, x22
255c48: mov w1, #0x1e
255c4c: bl #0x23d184
255c50: adrp x24, #0x6bb000
255c54: add x24, x24, #0xe97
255c58: mov x23, x0
255c5c: mov x0, x24
255c60: mov w1, #0x14
255c64: bl #0x23d184
255c68: adrp x26, #0x6a7000
255c6c: add x26, x26, #0x96f
255c70: mov x25, x0
255c74: mov x0, x26
255c78: mov w1, #0x1b
255c7c: bl #0x23d184
255c80: adrp x28, #0x6a7000
255c84: add x28, x28, #0x98b
255c88: mov x27, x0
255c8c: mov x0, x28
255c90: mov w1, #0x14
255c94: bl #0x23d184
255c98: str x0, [x19, #0x680]
255c9c: adrp x0, #0x6f9000
255ca0: add x0, x0, #0x38e
255ca4: mov w1, #0xa
255ca8: str x20, [x19, #0x638]
255cac: str x21, [x19, #0x640]
255cb0: str x22, [x19, #0x648]
255cb4: str x23, [x19, #0x650]
255cb8: str x24, [x19, #0x658]
255cbc: str x25, [x19, #0x660]
255cc0: str x26, [x19, #0x668]
255cc4: str x27, [x19, #0x670]
255cc8: str x28, [x19, #0x678]
255ccc: bl #0x23d5c0
255cd0: adrp x0, #0x6e2000
255cd4: add x0, x0, #0x3fd
255cd8: mov w1, #0xb
255cdc: str s0, [x19, #0x688]
255ce0: str s1, [x19, #0x68c]
255ce4: str s2, [x19, #0x690]
255ce8: str s3, [x19, #0x694]
255cec: bl #0x23d5c0
255cf0: adrp x0, #0x6a0000
255cf4: add x0, x0, #0x478
255cf8: mov w1, #0x14
255cfc: mov w2, wzr
255d00: str s0, [x19, #0x698]
255d04: str s1, [x19, #0x69c]
255d08: str s2, [x19, #0x6a0]
255d0c: str s3, [x19, #0x6a4]
255d10: bl #0x23d338
255d14: adrp x1, #0x6a4000
255d18: add x1, x1, #0x107
255d1c: adrp x2, #0x6c7000
255d20: add x2, x2, #0x9a7
255d24: adrp x4, #0x687000
255d28: add x4, x4, #0xc4b
255d2c: add x0, x19, #0x6dc
255d30: mov w3, wzr
255d34: mov w5, wzr
255d38: str s0, [x19, #0x6a8]
255d3c: bl #0x252ad4
255d40: adrp x1, #0x6a0000
255d44: add x1, x1, #0x437
255d48: adrp x2, #0x6b7000
255d4c: add x2, x2, #0xd15
255d50: adrp x4, #0x693000
255d54: add x4, x4, #0x648
255d58: add x0, x19, #0x7e4
255d5c: mov w3, wzr
255d60: mov w5, #3
255d64: bl #0x252ad4
255d68: adrp x1, #0x700000
255d6c: add x1, x1, #0xbd3
255d70: adrp x2, #0x6bc000
255d74: add x2, x2, #0x4c
255d78: adrp x4, #0x6b7000
255d7c: add x4, x4, #0xd26
255d80: add x0, x19, #0x8ec
255d84: mov w3, wzr
255d88: mov w5, #3
255d8c: bl #0x252ad4
255d90: adrp x1, #0x69c000
255d94: add x1, x1, #0x578
255d98: adrp x2, #0x6a7000
255d9c: add x2, x2, #0xbf1
255da0: adrp x4, #0x6e5000
255da4: add x4, x4, #0xec9
255da8: add x0, x19, #0x9f4
255dac: mov w3, #4
255db0: mov w5, #4
255db4: bl #0x252ad4
255db8: adrp x1, #0x6e5000
255dbc: add x1, x1, #0xdca
255dc0: adrp x2, #0x6de000
255dc4: add x2, x2, #0x3c5
255dc8: adrp x4, #0x68f000
255dcc: add x4, x4, #0x8ed
255dd0: add x0, x19, #0xafc
255dd4: mov w3, #4
255dd8: mov w5, #4
255ddc: bl #0x252ad4
255de0: adrp x1, #0x6bf000
255de4: add x1, x1, #0x8af
255de8: adrp x2, #0x68f000
255dec: add x2, x2, #0x901
255df0: adrp x4, #0x6ac000
255df4: add x4, x4, #0xad
255df8: add x0, x19, #0xc04
255dfc: mov w3, #4
255e00: mov w5, #4
255e04: bl #0x252ad4
255e08: adrp x1, #0x6d2000
255e0c: add x1, x1, #0x5c
255e10: adrp x2, #0x6e2000
255e14: add x2, x2, #0x499
255e18: adrp x4, #0x6bc000
255e1c: add x4, x4, #0x5a
255e20: add x0, x19, #0xd0c
255e24: mov w3, #4
255e28: mov w5, #4
255e2c: bl #0x252ad4
255e30: adrp x1, #0x6d2000
255e34: add x1, x1, #0x9d
255e38: adrp x2, #0x6ed000
255e3c: add x2, x2, #0xb2e
255e40: adrp x4, #0x6d2000
255e44: add x4, x4, #0x1b9
255e48: add x0, x19, #0xe14
255e4c: mov w3, #2
255e50: mov w5, wzr
255e54: bl #0x252ad4
255e58: adrp x1, #0x6da000
255e5c: add x1, x1, #0x2ec
255e60: adrp x2, #0x6af000
255e64: add x2, x2, #0xf38
255e68: adrp x4, #0x700000
255e6c: add x4, x4, #0xcf3
255e70: add x0, x19, #0xf1c
255e74: mov w3, #4
255e78: mov w5, wzr
255e7c: bl #0x252ad4
255e80: mov w8, #0x1024
255e84: adrp x1, #0x68b000
255e88: add x1, x1, #0xa30
255e8c: adrp x2, #0x698000
255e90: add x2, x2, #0x521
255e94: adrp x4, #0x6e5000
255e98: add x4, x4, #0xed8
255e9c: add x0, x19, x8
255ea0: mov w3, #5
255ea4: mov w5, #5
255ea8: bl #0x252ad4
255eac: movi d0, #0000000000000000
255eb0: movi d1, #0000000000000000
255eb4: ldr x8, [x19, #0x258]
255eb8: cbz x8, #0x255ec0
255ebc: ldur d1, [x8, #0xdc]
255ec0: ldp x22, x20, [sp, #0x18]
255ec4: ldr x1, [x19, #0x260]
255ec8: str d1, [x22]
255ecc: cbz x1, #0x255ed4
255ed0: ldur d0, [x1, #0xdc]
255ed4: movi d1, #0000000000000000
255ed8: movi d2, #0000000000000000
255edc: ldr x8, [x19, #0x278]
255ee0: ldur x21, [x29, #-0x18]
255ee4: str d0, [x22, #8]
255ee8: cbz x8, #0x255ef0
255eec: ldur d2, [x8, #0xdc]
255ef0: ldr x8, [x19, #0x2b0]
255ef4: str d2, [x22, #0x10]
255ef8: cbz x8, #0x255f00
255efc: ldur d1, [x8, #0xdc]
255f00: movi d0, #0000000000000000
255f04: movi d2, #0000000000000000
255f08: ldr x8, [x19, #0x2d0]
255f0c: str d1, [x22, #0x18]
255f10: cbz x8, #0x255f18
255f14: ldur d2, [x8, #0xdc]
255f18: ldr x8, [x19, #0x290]
255f1c: str d2, [x22, #0x20]
255f20: cbz x8, #0x255f28
255f24: ldur d0, [x8, #0xdc]
255f28: movi d1, #0000000000000000
255f2c: movi d2, #0000000000000000
255f30: ldr x8, [x19, #0x250]
255f34: str d0, [x22, #0x28]
255f38: cbz x8, #0x255f40
255f3c: ldur d2, [x8, #0xdc]
255f40: ldr x8, [x19, #0x2a8]
255f44: str d2, [x19, #0x1260]
255f48: cbz x8, #0x255f50
255f4c: ldur d1, [x8, #0xdc]
255f50: ldr x8, [x19, #0x1f8]
255f54: str d1, [x19, #0x1268]
255f58: cbz x8, #0x255f7c
255f5c: movi d0, #0000000000000000
255f60: movi d1, #0000000000000000
255f64: ldr s3, [x19, #0x6a8]
255f68: movi d2, #0000000000000000
255f6c: mov x0, x21
255f70: mov x1, x8
255f74: bl #0x22d238
255f78: ldr x1, [x19, #0x260]
255f7c: movi d0, #0000000000000000
255f80: mov x0, x21
255f84: bl #0x22cf38
255f88: movi v0.2d, #0xffffffffffffffff
255f8c: adrp x8, #0x683000
255f90: mov x9, #-0x100000001
255f94: ldr d1, [x8, #0x260]
255f98: mov w8, #0x1184
255f9c: mov w0, #1
255fa0: str x9, [x19, x8]
255fa4: mov w8, #-0x3d380000
255fa8: mov w9, #-1
255fac: str d1, [x19, #0x1170]
255fb0: str q0, [x19, #0x1160]
255fb4: str q0, [x19, #0x1150]
255fb8: fmov v0.4s, #1.00000000
255fbc: str xzr, [x19, #0x1178]
255fc0: strh wzr, [x22, #0xae8]
255fc4: strb wzr, [x22, #0xae0]
255fc8: str q0, [x22, #0xaf0]
255fcc: dup v0.4s, w8
255fd0: str wzr, [x19, #0x1190]
255fd4: str w9, [x19, #0x1198]
255fd8: str q0, [x22, #0xa80]
255fdc: str q0, [x22, #0xa90]
255fe0: str w8, [x19, #0x114c]
255fe4: b #0x255ff8
255fe8: ldr x20, [sp, #0x20]
255fec: mov w0, wzr
255ff0: b #0x255ff8
255ff4: ldr x20, [sp, #0x20]
255ff8: ldr x8, [x20, #0x28]
255ffc: ldur x9, [x29, #-8]
256000: cmp x8, x9
256004: b.ne #0x256028
256008: ldp x20, x19, [sp, #0x90]
25600c: ldp x22, x21, [sp, #0x80]
256010: ldp x24, x23, [sp, #0x70]
256014: ldp x26, x25, [sp, #0x60]
256018: ldp x28, x27, [sp, #0x50]
25601c: ldp x29, x30, [sp, #0x40]
256020: add sp, sp, #0xa0
256024: ret 
256028: bl #0x67f680

FUNCTION 0x25602c
25602c: sub sp, sp, #0x170
256030: stp d15, d14, [sp, #0xd0]
256034: stp d13, d12, [sp, #0xe0]
256038: stp d11, d10, [sp, #0xf0]
25603c: stp d9, d8, [sp, #0x100]
256040: stp x29, x30, [sp, #0x110]
256044: stp x28, x27, [sp, #0x120]
256048: stp x26, x25, [sp, #0x130]
25604c: stp x24, x23, [sp, #0x140]
256050: stp x22, x21, [sp, #0x150]
256054: stp x20, x19, [sp, #0x160]
256058: add x29, sp, #0x110
25605c: mrs x24, tpidr_el0
256060: mov x9, x0
256064: mov x20, x0
256068: ldr x8, [x24, #0x28]
25606c: fmov s9, s1
256070: fmov s8, s0
256074: mov x19, x1
256078: stur x8, [x29, #-0x50]
25607c: ldr x8, [x9, #0xf0]!
256080: str x9, [sp, #0x88]
256084: ldr x9, [x9, #8]
256088: cmp x8, #0
25608c: csel x22, xzr, x9, eq
256090: mov x0, x22
256094: bl #0x198128
256098: tbz w0, #0, #0x2560a0
25609c: cbnz x22, #0x2561d0
2560a0: ldr s0, [x20, #0x1b8]
2560a4: fcmp s0, s8
2560a8: b.gt #0x2561d0
2560ac: mov x0, x19
2560b0: bl #0x22e288
2560b4: tbz w0, #0, #0x2561d0
2560b8: fmov s0, #1.00000000
2560bc: ldr x1, [sp, #0x88]
2560c0: mov x0, x19
2560c4: fadd s0, s8, s0
2560c8: str s0, [x20, #0x1b8]
2560cc: bl #0x22f5c4
2560d0: ldr x1, [x20, #0xe8]
2560d4: cbnz x1, #0x2560ec
2560d8: adrp x0, #0x6c5000
2560dc: add x0, x0, #0xa7
2560e0: bl #0x22dfb8
2560e4: mov x1, x0
2560e8: str x0, [x20, #0xe8]
2560ec: mov x0, x19
2560f0: mov x2, xzr
2560f4: bl #0x22e050
2560f8: cbz x0, #0x2561d0
2560fc: ldp x8, x9, [x20, #0xf0]
256100: cmp x8, #0
256104: csel x8, xzr, x9, eq
256108: cmp x8, x0
25610c: b.eq #0x256148
256110: mov x22, x0
256114: bl #0x439970
256118: mov x23, x0
25611c: cbz x0, #0x2561d0
256120: ldr x8, [x20, #0xf0]
256124: mov x0, x22
256128: str xzr, [x20, #0xf8]
25612c: cbz x8, #0x256144
256130: ldr x9, [sp, #0x88]
256134: mov x0, x8
256138: str xzr, [x9]
25613c: bl #0x439c54
256140: mov x0, x22
256144: stp x23, x0, [x20, #0xf0]
256148: bl #0x197da4
25614c: ldp x23, x8, [x20, #0x100]
256150: cmp x23, #0
256154: csel x9, xzr, x8, eq
256158: cmp x9, x0
25615c: b.eq #0x256180
256160: mov x22, x0
256164: cbz x0, #0x256188
256168: mov x0, x22
25616c: bl #0x439970
256170: cbz x0, #0x2561d0
256174: mov x23, x0
256178: ldr x0, [x20, #0x100]
25617c: b #0x256190
256180: mov x22, x8
256184: b #0x2561a4
256188: mov x0, x23
25618c: mov x23, xzr
256190: str xzr, [x20, #0x108]
256194: cbz x0, #0x2561a0
256198: str xzr, [x20, #0x100]
25619c: bl #0x439c54
2561a0: stp x23, x22, [x20, #0x100]
2561a4: cmp x23, #0
2561a8: adrp x1, #0x6fe000
2561ac: add x1, x1, #0x978
2561b0: csel x0, xzr, x22, eq
2561b4: bl #0x197c20
2561b8: cbz x0, #0x2561d0
2561bc: ldr x1, [sp, #0x88]
2561c0: mov x2, x0
2561c4: mov x0, x19
2561c8: mov w3, wzr
2561cc: bl #0x22ef70
2561d0: fsub s0, s8, s9
2561d4: fadd s1, s8, s8
2561d8: fadd s0, s0, s0
2561dc: fcvtzs w8, s1
2561e0: fcvtzs w9, s0
2561e4: cmp w8, w9
2561e8: b.eq #0x2561f8
2561ec: ldr x1, [sp, #0x88]
2561f0: mov x0, x19
2561f4: bl #0x22f40c
2561f8: ldr w9, [x20, #0x1198]
2561fc: ldr w8, [x19, #0x514]
256200: cmp w9, w8
256204: b.eq #0x256220
256208: str w8, [x20, #0x1198]
25620c: bl #0x23e358
256210: str s0, [x20, #0x119c]
256214: str s1, [x20, #0x11a0]
256218: str s2, [x20, #0x11a4]
25621c: str s3, [x20, #0x11a8]
256220: movi d0, #0000000000000000
256224: ldrb w21, [x19, #0x51c]
256228: fmov s1, #1.00000000
25622c: ldr x1, [x20, #0x200]
256230: ldr x8, [sp, #0x88]
256234: mov x0, x19
256238: cmp w21, #0
25623c: add x22, x8, #0xf10
256240: fcsel s0, s0, s1, eq
256244: bl #0x22cf38
256248: ldrb w9, [x19, #0x506]
25624c: cbz w21, #0x256778
256250: ldr s0, [x20, #0x1190]
256254: str w9, [sp, #0x6c]
256258: str x24, [sp, #0x70]
25625c: fcmp s0, s8
256260: str x22, [sp, #0x80]
256264: b.gt #0x2565c4
256268: fmov s0, #1.00000000
25626c: ldrb w8, [x22, #0x18c]
256270: fadd s0, s8, s0
256274: str s0, [x20, #0x1190]
256278: cbz w8, #0x256284
25627c: bl #0x24fd88
256280: tbnz w0, #0, #0x2565c4
256284: fmov s0, #1.00000000
256288: fmov s1, #1.00000000
25628c: bl #0x24f2f0
256290: ldr x8, [x20, #0x280]
256294: ldr x24, [x20, #0x228]
256298: mov w21, w0
25629c: ldr x26, [x20, #0x230]
2562a0: ldr x27, [x20, #0x238]
2562a4: adrp x0, #0x6fe000
2562a8: add x0, x0, #0xc6b
2562ac: str x8, [sp, #0x10]
2562b0: ldr x8, [x20, #0x290]
2562b4: ldr x23, [x20, #0x240]
2562b8: ldr x25, [x20, #0x258]
2562bc: adrp x1, #0x6de000
2562c0: add x1, x1, #0x3d9
2562c4: str x8, [sp, #0x20]
2562c8: ldr x8, [x20, #0x298]
2562cc: ldr x22, [x20, #0x270]
2562d0: ldr x28, [x20, #0x2d0]
2562d4: mov w2, #0x11
2562d8: str x8, [sp, #0x30]
2562dc: ldr x8, [x20, #0x2b0]
2562e0: str x8, [sp, #0x40]
2562e4: ldr x8, [x20, #0x2c0]
2562e8: str x8, [sp, #0x50]
2562ec: ldr x8, [x20, #0x2c8]
2562f0: stur x8, [x29, #-0x80]
2562f4: bl #0x23cbf0
2562f8: mov w1, w0
2562fc: add x0, x20, #0x1c0
256300: bl #0x23d928
256304: str x0, [sp, #0x78]
256308: mov x0, x19
25630c: mov x1, x24
256310: mov w2, #1
256314: bl #0x24f5a4
256318: str w0, [sp, #0x4c]
25631c: mov x0, x19
256320: mov x1, x26
256324: mov w2, #1
256328: bl #0x24f5a4
25632c: str w0, [sp, #0x3c]
256330: mov x0, x19
256334: mov x1, x27
256338: mov w2, #1
25633c: bl #0x24f5a4
256340: str w0, [sp, #0x2c]
256344: mov x0, x19
256348: mov x1, x23
25634c: mov w2, #1
256350: bl #0x24f5a4
256354: str w0, [sp, #0x1c]
256358: mov x0, x19
25635c: mov x1, x25
256360: mov w2, #1
256364: bl #0x24f5a4
256368: str w0, [sp, #0x18]
25636c: mov x0, x19
256370: mov x1, x22
256374: mov w2, #1
256378: bl #0x24f5a4
25637c: ldr x1, [sp, #0x10]
256380: str w0, [sp, #0xc]
256384: mov x0, x19
256388: mov w2, #1
25638c: bl #0x24f5a4
256390: ldr x1, [sp, #0x20]
256394: str w0, [sp, #0x10]
256398: mov x0, x19
25639c: mov w2, #1
2563a0: bl #0x24f5a4
2563a4: ldr x1, [sp, #0x30]
2563a8: mov w25, w0
2563ac: mov x0, x19
2563b0: mov w2, #1
2563b4: bl #0x24f5a4
2563b8: ldr x1, [sp, #0x40]
2563bc: mov w23, w0
2563c0: mov x0, x19
2563c4: mov w2, #1
2563c8: bl #0x24f5a4
2563cc: ldr x1, [sp, #0x50]
2563d0: mov w24, w0
2563d4: mov x0, x19
2563d8: mov w2, #1
2563dc: bl #0x24f5a4
2563e0: ldur x1, [x29, #-0x80]
2563e4: mov w26, w0
2563e8: mov x0, x19
2563ec: mov w2, #1
2563f0: bl #0x24f5a4
2563f4: mov w27, w0
2563f8: mov x0, x19
2563fc: mov x1, x28
256400: mov w2, #1
256404: bl #0x24f5a4
256408: ldr x1, [sp, #0x78]
25640c: mov w22, w0
256410: mov x0, x19
256414: mov w2, #1
256418: bl #0x24f5a4
25641c: ldr w8, [sp, #0x4c]
256420: ldr w9, [sp, #0x3c]
256424: mov w2, #1
256428: ldr w10, [sp, #0x1c]
25642c: ldr x1, [x20, #0x11b0]
256430: and w8, w9, w8
256434: ldr w9, [sp, #0x2c]
256438: and w8, w8, w21
25643c: and w9, w10, w9
256440: ldp w10, w11, [sp, #0xc]
256444: and w10, w11, w10
256448: ldr w11, [sp, #0x18]
25644c: and w10, w25, w10
256450: and w9, w11, w9
256454: and w11, w23, w24
256458: and w8, w9, w8
25645c: and w9, w27, w26
256460: and w9, w9, w11
256464: and w11, w0, w22
256468: mov x0, x19
25646c: and w21, w10, w8
256470: and w23, w11, w9
256474: bl #0x24f5a4
256478: ldr x1, [x20, #0x11b8]
25647c: mov w22, w0
256480: mov x0, x19
256484: mov w2, #1
256488: bl #0x24f5a4
25648c: ldr x1, [x20, #0x11c0]
256490: and w22, w22, w0
256494: mov x0, x19
256498: mov w2, #1
25649c: bl #0x24f5a4
2564a0: ldr x1, [x20, #0x11c8]
2564a4: and w8, w22, w0
2564a8: mov x0, x19
2564ac: mov w2, #1
2564b0: and w25, w23, w8
2564b4: bl #0x24f5a4
2564b8: ldr x1, [x20, #0x11d0]
2564bc: mov w22, w0
2564c0: mov x0, x19
2564c4: mov w2, #1
2564c8: bl #0x24f5a4
2564cc: ldr x1, [x20, #0x11d8]
2564d0: and w27, w22, w0
2564d4: mov x0, x19
2564d8: mov w2, #1
2564dc: bl #0x24f5a4
2564e0: ldr x1, [x20, #0x11e0]
2564e4: mov w22, w0
2564e8: mov x0, x19
2564ec: mov w2, #1
2564f0: bl #0x24f5a4
2564f4: ldr x1, [x20, #0x11e8]
2564f8: mov w23, w0
2564fc: mov x0, x19
256500: mov w2, #1
256504: bl #0x24f5a4
256508: ldr x1, [x20, #0x11f0]
25650c: mov w24, w0
256510: mov x0, x19
256514: mov w2, #1
256518: bl #0x24f5a4
25651c: and w8, w22, w23
256520: and w9, w24, w0
256524: mov x26, xzr
256528: and w8, w27, w8
25652c: and w8, w8, w9
256530: and w8, w8, w25
256534: and w21, w8, w21
256538: add x27, x20, x26
25653c: mov x0, x19
256540: mov w2, wzr
256544: ldr x1, [x27, #0x300]
256548: ldr x22, [x27, #0x308]
25654c: ldr x23, [x27, #0x310]
256550: ldr x24, [x27, #0x318]
256554: bl #0x24f5a4
256558: mov w25, w0
25655c: mov x0, x19
256560: mov x1, x22
256564: mov w2, wzr
256568: bl #0x24f5a4
25656c: and w25, w25, w0
256570: mov x0, x19
256574: mov x1, x23
256578: mov w2, wzr
25657c: bl #0x24f5a4
256580: mov w22, w0
256584: mov x0, x19
256588: mov x1, x24
25658c: mov w2, wzr
256590: bl #0x24f5a4
256594: and w8, w0, w22
256598: add x26, x26, #0x80
25659c: str wzr, [x27, #0x324]
2565a0: and w8, w8, w25
2565a4: cmp x26, #0x300
2565a8: and w21, w8, w21
2565ac: b.ne #0x256538
2565b0: ldr x22, [sp, #0x80]
2565b4: and w8, w21, #1
2565b8: mov w9, #-2
2565bc: str w9, [x20, #0x1188]
2565c0: strb w8, [x22, #0x18c]
2565c4: ldr w28, [x19, #0x5ec]
2565c8: ldr w21, [x19, #0x5f0]
2565cc: mov w10, #1
2565d0: ldrb w9, [x22, #0x194]
2565d4: ldr w23, [x19, #0x5e8]
2565d8: ldrb w8, [x22, #0x195]
2565dc: strh w10, [x22, #0x194]
2565e0: cbz w9, #0x2567e8
2565e4: cbnz w8, #0x2567e8
2565e8: ldr w8, [x20, #0x1178]
2565ec: cmp w23, w8
2565f0: b.eq #0x256b4c
2565f4: movi d0, #0000000000000000
2565f8: mov w8, #-0x3dd80000
2565fc: cmp w23, #5
256600: fmov s1, w8
256604: sub w26, w23, #1
256608: mov w8, #0x3c
25660c: adrp x9, #0x2a50000
256610: add x9, x9, #0x37c
256614: umaddl x8, w26, w8, x9
256618: str w21, [sp, #0x78]
25661c: sxtw x21, w23
256620: mov x25, xzr
256624: fcsel s9, s0, s1, gt
256628: mov x27, xzr
25662c: stur x23, [x29, #-0x80]
256630: add x23, x8, #4
256634: b #0x256684
256638: ldr x8, [x22]
25663c: ldr w10, [x22, #8]
256640: add x9, x20, x25
256644: str x8, [x9, #0x340]
256648: str w10, [x9, #0x348]
25664c: add x8, x20, x25
256650: str s12, [x22]
256654: ldr x9, [x8, #0x340]
256658: ldr w10, [x8, #0x348]
25665c: str s10, [x8, #0x338]
256660: str s11, [x8, #0x33c]
256664: str x9, [x8, #0x328]
256668: str w10, [x8, #0x330]
25666c: str s8, [x24, #0x34c]
256670: add x25, x25, #0x80
256674: add x27, x27, #1
256678: add x23, x23, #0xc
25667c: cmp x25, #0x300
256680: b.eq #0x256a34
256684: movi d12, #0000000000000000
256688: movi d11, #0000000000000000
25668c: cmp x25, #0x280
256690: fmov s10, s9
256694: b.eq #0x2566bc
256698: mov w8, #-0x3dd80000
25669c: cmp w26, #4
2566a0: fmov s10, w8
2566a4: b.hi #0x2566bc
2566a8: cmp x27, x21
2566ac: b.ge #0x2566bc
2566b0: ldp s0, s11, [x23]
2566b4: ldur s12, [x23, #-4]
2566b8: fneg s10, s0
2566bc: add x24, x20, x25
2566c0: ldr s0, [x24, #0x334]
2566c4: fcmp s0, s12
2566c8: b.ne #0x2566e8
2566cc: ldr s0, [x24, #0x338]
2566d0: fcmp s0, s10
2566d4: b.ne #0x2566e8
2566d8: add x8, x20, x25
2566dc: ldr s0, [x8, #0x33c]
2566e0: fcmp s0, s11
2566e4: b.eq #0x256670
2566e8: ldr s0, [x24, #0x34c]
2566ec: add x22, x24, #0x334
2566f0: fsub s0, s8, s0
2566f4: fcmp s0, #0.0
2566f8: b.mi #0x256638
2566fc: ldr s1, [x20, #0x6dc]
256700: fcmp s1, #0.0
256704: b.le #0x256638
256708: ldr s2, [x20, #0x6e0]
25670c: fsub s2, s0, s2
256710: movi d0, #0000000000000000
256714: fcmp s2, #0.0
256718: b.mi #0x256740
25671c: fdiv s0, s2, s1
256720: ldr w8, [x20, #0x6e8]
256724: cmp w8, #1
256728: b.lt #0x256738
25672c: scvtf s1, w8
256730: fcmp s0, s1
256734: b.ge #0x256638
256738: frintm s1, s0
25673c: fsub s0, s0, s1
256740: ldr w0, [x20, #0x6e4]
256744: bl #0x254534
256748: add x8, x20, x25
25674c: ldr d1, [x22]
256750: ldr d2, [x8, #0x328]
256754: ldr s3, [x8, #0x330]
256758: ldr s4, [x8, #0x33c]
25675c: fsub v1.2s, v1.2s, v2.2s
256760: fsub s4, s4, s3
256764: fmla v2.2s, v1.2s, v0.s[0]
256768: fmadd s0, s4, s0, s3
25676c: str d2, [x8, #0x340]
256770: str s0, [x8, #0x348]
256774: b #0x25664c
256778: mov x8, #-1
25677c: cmp w9, #0
256780: str wzr, [x20, #0x117c]
256784: str x8, [x20, #0x1150]
256788: str x8, [x20, #0x1158]
25678c: mov w8, #1
256790: cset w20, ne
256794: strb w8, [x22, #0x195]
256798: bl #0x28dd44
25679c: ldr x8, [x24, #0x28]
2567a0: ldur x9, [x29, #-0x50]
2567a4: cmp x8, x9
2567a8: b.ne #0x259184
2567ac: mov x0, x19
2567b0: fmov s0, s8
2567b4: mov w1, w20
2567b8: ldp x20, x19, [sp, #0x160]
2567bc: ldp x22, x21, [sp, #0x150]
2567c0: ldp x24, x23, [sp, #0x140]
2567c4: ldp x26, x25, [sp, #0x130]
2567c8: ldp x28, x27, [sp, #0x120]
2567cc: ldp x29, x30, [sp, #0x110]
2567d0: ldp d9, d8, [sp, #0x100]
2567d4: ldp d11, d10, [sp, #0xf0]
2567d8: ldp d13, d12, [sp, #0xe0]
2567dc: ldp d15, d14, [sp, #0xd0]
2567e0: add sp, sp, #0x170
2567e4: b #0x28dfb8
2567e8: movi d1, #0000000000000000
2567ec: mov w8, #-0x3dd80000
2567f0: cmp w23, #5
2567f4: fmov s2, w8
2567f8: movi d3, #0000000000000000
2567fc: movi d4, #0000000000000000
256800: sub w8, w23, #1
256804: adrp x9, #0x2a50000
256808: add x9, x9, #0x37c
25680c: fcsel s0, s1, s2, gt
256810: cmp w8, #4
256814: b.hi #0x25682c
256818: mov w10, #0x3c
25681c: umaddl x10, w8, w10, x9
256820: ldp s3, s2, [x10]
256824: ldr s4, [x10, #8]
256828: fneg s2, s2
25682c: str s3, [x20, #0x334]
256830: add x10, x20, #0x334
256834: sub w12, w23, #2
256838: str s2, [x20, #0x338]
25683c: cmp w12, #3
256840: str s4, [x20, #0x33c]
256844: ldr x10, [x10]
256848: ldr w11, [x20, #0x33c]
25684c: str x10, [x20, #0x328]
256850: str x10, [x20, #0x340]
256854: mov w10, #-0x3d380000
256858: str w11, [x20, #0x330]
25685c: str w11, [x20, #0x348]
256860: str w10, [x20, #0x34c]
256864: b.hi #0x256880
256868: mov w11, #0x3c
25686c: umaddl x11, w8, w11, x9
256870: ldp s1, s2, [x11, #0xc]
256874: fneg s3, s2
256878: ldr s2, [x11, #0x14]
25687c: b #0x25688c
256880: mov w11, #-0x3dd80000
256884: movi d2, #0000000000000000
256888: fmov s3, w11
25688c: str s1, [x20, #0x3b4]
256890: add x11, x20, #0x3b4
256894: movi d1, #0000000000000000
256898: str s3, [x20, #0x3b8]
25689c: ldr x11, [x11]
2568a0: str s2, [x20, #0x3bc]
2568a4: ldr w12, [x20, #0x3bc]
2568a8: str w10, [x20, #0x3cc]
2568ac: str x11, [x20, #0x3a8]
2568b0: str x11, [x20, #0x3c0]
2568b4: sub w11, w23, #3
2568b8: cmp w11, #2
2568bc: str w12, [x20, #0x3b0]
2568c0: str w12, [x20, #0x3c8]
2568c4: b.hi #0x2568e0
2568c8: mov w10, #0x3c
2568cc: umaddl x10, w8, w10, x9
2568d0: ldp s2, s3, [x10, #0x18]
2568d4: fneg s4, s3
2568d8: ldr s3, [x10, #0x20]
2568dc: b #0x2568f0
2568e0: mov w10, #-0x3dd80000
2568e4: movi d2, #0000000000000000
2568e8: movi d3, #0000000000000000
2568ec: fmov s4, w10
2568f0: str s2, [x20, #0x434]
2568f4: add x10, x20, #0x434
2568f8: and w12, w23, #0xfffffffe
2568fc: str s4, [x20, #0x438]
256900: cmp w12, #4
256904: str s3, [x20, #0x43c]
256908: ldr x10, [x10]
25690c: ldr w11, [x20, #0x43c]
256910: str x10, [x20, #0x428]
256914: str x10, [x20, #0x440]
256918: mov w10, #-0x3d380000
25691c: str w11, [x20, #0x430]
256920: str w11, [x20, #0x448]
256924: str w10, [x20, #0x44c]
256928: b.ne #0x256944
25692c: mov w11, #0x3c
256930: umaddl x11, w8, w11, x9
256934: ldp s1, s2, [x11, #0x24]
256938: fneg s3, s2
25693c: ldr s2, [x11, #0x2c]
256940: b #0x256950
256944: mov w11, #-0x3dd80000
256948: movi d2, #0000000000000000
25694c: fmov s3, w11
256950: str s1, [x20, #0x4b4]
256954: add x11, x20, #0x4b4
256958: cmp w23, #5
25695c: str s3, [x20, #0x4b8]
256960: str s2, [x20, #0x4bc]
256964: ldr x11, [x11]
256968: ldr w12, [x20, #0x4bc]
25696c: str w10, [x20, #0x4cc]
256970: str x11, [x20, #0x4a8]
256974: str w12, [x20, #0x4b0]
256978: str x11, [x20, #0x4c0]
25697c: str w12, [x20, #0x4c8]
256980: b.ne #0x25699c
256984: mov w10, #0x3c
256988: movi v3.2s, #0x80, lsl #24
25698c: umaddl x8, w8, w10, x9
256990: ldr s1, [x8, #0x30]
256994: ldr s2, [x8, #0x38]
256998: b #0x2569ac
25699c: mov w8, #-0x3dd80000
2569a0: movi d1, #0000000000000000
2569a4: movi d2, #0000000000000000
2569a8: fmov s3, w8
2569ac: str s2, [x20, #0x53c]
2569b0: add x8, x20, #0x534
2569b4: ldr w9, [x20, #0x53c]
2569b8: str s1, [x20, #0x534]
2569bc: str s3, [x20, #0x538]
2569c0: str w9, [x20, #0x530]
2569c4: ldr x8, [x8]
2569c8: str w9, [x20, #0x548]
2569cc: add x9, x20, #0x5b4
2569d0: str s0, [x20, #0x5b8]
2569d4: str xzr, [x20, #0x5b0]
2569d8: ldr x9, [x9]
2569dc: str x8, [x20, #0x528]
2569e0: str x8, [x20, #0x540]
2569e4: mov w8, #-0x3d380000
2569e8: str x9, [x20, #0x5a8]
2569ec: str x9, [x20, #0x5c0]
2569f0: mov w9, #-1
2569f4: str w8, [x20, #0x54c]
2569f8: str wzr, [x20, #0x5bc]
2569fc: str wzr, [x20, #0x5c8]
256a00: str w8, [x20, #0x5cc]
256a04: str w9, [x20, #0x1184]
256a08: str w8, [x20, #0x1130]
256a0c: str w8, [x20, #0x112c]
256a10: bl #0x28dd44
256a14: str w23, [x20, #0x1178]
256a18: str wzr, [x20, #0x117c]
256a1c: cmp w23, #1
256a20: b.lt #0x256c50
256a24: cmp w28, #0
256a28: b.le #0x256ac0
256a2c: ldr w8, [x19, #0x5f4]
256a30: b #0x256ac4
256a34: ldr w8, [x20, #0x1178]
256a38: ldur x23, [x29, #-0x80]
256a3c: cmp w23, w8
256a40: b.le #0x256b3c
256a44: cmp w23, #5
256a48: mov w8, #5
256a4c: str s8, [x20, #0x1130]
256a50: csel w8, w8, w26, gt
256a54: str s8, [x20, #0x112c]
256a58: ldr w21, [sp, #0x78]
256a5c: str w8, [x20, #0x1184]
256a60: ldrb w8, [x19, #0x506]
256a64: cbz w8, #0x256aa4
256a68: cmp w28, w23
256a6c: fmov s4, s8
256a70: mov w9, #4
256a74: csel w8, wzr, w21, lt
256a78: mov w10, #3
256a7c: ldr s0, [x20, #0x119c]
256a80: cmp w8, #3
256a84: ldr s1, [x20, #0x11a0]
256a88: ldr s2, [x20, #0x11a4]
256a8c: csinc w9, w9, wzr, eq
256a90: cmp w8, #2
256a94: ldr s3, [x20, #0x11a8]
256a98: csel w1, w10, w9, eq
256a9c: mov w0, w23
256aa0: bl #0x28d8e0
256aa4: and w8, w21, #0xfffffffe
256aa8: str s8, [x20, #0x1180]
256aac: cmp w8, #2
256ab0: ccmp w28, w23, #8, eq
256ab4: csel w8, wzr, w23, ge
256ab8: str w8, [x20, #0x117c]
256abc: b #0x256b48
256ac0: mov w8, wzr
256ac4: ldr w9, [x20, #0x350]
256ac8: add x21, x20, #0x600
256acc: cmp w9, w8
256ad0: b.eq #0x256ae8
256ad4: str w8, [x20, #0x350]
256ad8: ldr x1, [x20, #0x308]
256adc: mov x0, x19
256ae0: ldr x2, [x21, w8, sxtw #3]
256ae4: bl #0x22d40c
256ae8: cmp w23, #1
256aec: b.eq #0x256c50
256af0: cmp w28, #2
256af4: b.lt #0x256b00
256af8: ldr w8, [x19, #0x5f8]
256afc: b #0x256b04
256b00: mov w8, wzr
256b04: ldr w9, [x20, #0x3d0]
256b08: cmp w9, w8
256b0c: b.eq #0x256b24
256b10: str w8, [x20, #0x3d0]
256b14: ldr x1, [x20, #0x388]
256b18: mov x0, x19
256b1c: ldr x2, [x21, w8, sxtw #3]
256b20: bl #0x22d40c
256b24: cmp w23, #2
256b28: b.eq #0x256c50
256b2c: cmp w28, #3
256b30: b.lt #0x256bb4
256b34: ldr w8, [x19, #0x5fc]
256b38: b #0x256bb8
256b3c: ldr w21, [sp, #0x78]
256b40: b.ge #0x256b48
256b44: bl #0x28dd44
256b48: str w23, [x20, #0x1178]
256b4c: ldrb w8, [x19, #0x506]
256b50: cbz w8, #0x256a18
256b54: ldr w8, [x20, #0x117c]
256b58: cmp w23, w8
256b5c: b.lt #0x256a18
256b60: cbz w8, #0x256b90
256b64: cmp w28, w8
256b68: b.lt #0x256b90
256b6c: and w9, w21, #0xfffffffe
256b70: cmp w9, #2
256b74: b.ne #0x256b90
256b78: cmp w21, #2
256b7c: mov w8, #3
256b80: ldr s0, [x20, #0x1180]
256b84: cinc w0, w8, ne
256b88: bl #0x28deb8
256b8c: b #0x256a18
256b90: cbz w8, #0x256a1c
256b94: ldr s0, [x20, #0x1180]
256b98: mov w8, #0x999a
256b9c: movk w8, #0x3e19, lsl #16
256ba0: fsub s0, s8, s0
256ba4: fmov s1, w8
256ba8: fcmp s0, s1
256bac: b.ge #0x256a18
256bb0: b #0x256a1c
256bb4: mov w8, wzr
256bb8: ldr w9, [x20, #0x450]
256bbc: cmp w9, w8
256bc0: b.eq #0x256bd8
256bc4: str w8, [x20, #0x450]
256bc8: ldr x1, [x20, #0x408]
256bcc: mov x0, x19
256bd0: ldr x2, [x21, w8, sxtw #3]
256bd4: bl #0x22d40c
256bd8: cmp w23, #3
256bdc: b.eq #0x256c50
256be0: cmp w28, #4
256be4: b.lt #0x256bf0
256be8: ldr w8, [x19, #0x600]
256bec: b #0x256bf4
256bf0: mov w8, wzr
256bf4: ldr w9, [x20, #0x4d0]
256bf8: cmp w9, w8
256bfc: b.eq #0x256c14
256c00: str w8, [x20, #0x4d0]
256c04: ldr x1, [x20, #0x488]
256c08: mov x0, x19
256c0c: ldr x2, [x21, w8, sxtw #3]
256c10: bl #0x22d40c
256c14: cmp w23, #4
256c18: b.eq #0x256c50
256c1c: cmp w28, #5
256c20: b.lt #0x256c2c
256c24: ldr w8, [x19, #0x604]
256c28: b #0x256c30
256c2c: mov w8, wzr
256c30: ldr w9, [x20, #0x550]
256c34: cmp w9, w8
256c38: b.eq #0x256c50
256c3c: str w8, [x20, #0x550]
256c40: ldr x1, [x20, #0x508]
256c44: mov x0, x19
256c48: ldr x2, [x21, w8, sxtw #3]
256c4c: bl #0x22d40c
256c50: ldr w8, [x20, #0x1178]
256c54: cmp w8, #5
256c58: b.le #0x256ca4
256c5c: cmp w8, #0x63
256c60: mov w9, #0x63
256c64: ldr w10, [x20, #0x1174]
256c68: csel w0, w8, w9, lo
256c6c: cmp w10, w0
256c70: b.eq #0x256ca4
256c74: ldr x22, [x20, #0x220]
256c78: sub x8, x29, #0x68
256c7c: str w0, [x20, #0x1174]
256c80: bl #0x63b560
256c84: sub x2, x29, #0x68
256c88: mov x0, x19
256c8c: mov x1, x22
256c90: bl #0x22cfc0
256c94: ldurb w8, [x29, #-0x68]
256c98: tbz w8, #0, #0x256ca4
256c9c: ldur x0, [x29, #-0x58]
256ca0: bl #0x6790c8
256ca4: fmov s12, #1.00000000
256ca8: fmov s13, #1.00000000
256cac: ldr w8, [x20, #0x1184]
256cb0: tbnz w8, #0x1f, #0x256dd4
256cb4: mov w8, #-0x3db80000
256cb8: ldr s0, [x20, #0x1130]
256cbc: fmov s1, w8
256cc0: fcmp s0, s1
256cc4: b.le #0x256dd4
256cc8: fsub s1, s8, s0
256ccc: fcmp s1, #0.0
256cd0: b.mi #0x256dd4
256cd4: ldr s0, [x20, #0x7e4]
256cd8: fcmp s0, #0.0
256cdc: b.le #0x256dd4
256ce0: ldr s2, [x20, #0x7e8]
256ce4: fsub s2, s1, s2
256ce8: movi d1, #0000000000000000
256cec: fcmp s2, #0.0
256cf0: b.mi #0x256d18
256cf4: fdiv s0, s2, s0
256cf8: ldr w8, [x20, #0x7f0]
256cfc: cmp w8, #1
256d00: b.lt #0x256d10
256d04: scvtf s1, w8
256d08: fcmp s0, s1
256d0c: b.ge #0x256dd4
256d10: frintm s1, s0
256d14: fsub s1, s0, s1
256d18: ldr w9, [x20, #0x7f8]
256d1c: cbz w9, #0x256dd4
256d20: cmp w9, #1
256d24: b.lt #0x256d7c
256d28: cmp w9, #1
256d2c: add x8, x20, #0x8c4
256d30: b.eq #0x256d84
256d34: add x12, x20, #0x89c
256d38: ldr s0, [x12]
256d3c: fcmp s0, s1
256d40: b.ge #0x256d84
256d44: mov x11, xzr
256d48: add x10, x20, #0x8c8
256d4c: sub x13, x9, #1
256d50: mov x14, #0x100000000
256d54: ldur s0, [x10, #-0x28]
256d58: fcmp s0, s1
256d5c: b.pl #0x256d8c
256d60: subs x13, x13, #1
256d64: add x11, x11, x14
256d68: add x10, x10, #4
256d6c: b.ne #0x256d54
256d70: add x8, x8, x9, lsl #2
256d74: ldur s13, [x8, #-4]
256d78: b #0x256dd4
256d7c: movi d13, #0000000000000000
256d80: b #0x256dd4
256d84: ldr s13, [x8]
256d88: b #0x256dd4
256d8c: asr x9, x11, #0x1e
256d90: ldr s2, [x12, x9]
256d94: mov w9, #0x37bd
256d98: movk w9, #0x3586, lsl #16
256d9c: fsub s3, s0, s2
256da0: fmov s0, w9
256da4: asr x9, x11, #0x20
256da8: fcmp s3, s0
256dac: fmov s0, #1.00000000
256db0: b.le #0x256dbc
256db4: fsub s0, s1, s2
256db8: fdiv s0, s0, s3
256dbc: ldr s9, [x8, x9, lsl #2]
256dc0: ldr s1, [x10]
256dc4: ldr w0, [x20, #0x7ec]
256dc8: fsub s10, s1, s9
256dcc: bl #0x254534
256dd0: fmadd s13, s10, s0, s9
256dd4: movi d14, #0000000000000000
256dd8: fmov v15.2s, #1.00000000
256ddc: mov w27, #0xfa35
256de0: mov w26, #0x3333
256de4: mov x22, xzr
256de8: mov x23, xzr
256dec: add x24, x20, #0x2d8
256df0: mov w25, #-0x3dd80000
256df4: movk w27, #0x3c8e, lsl #16
256df8: movk w26, #0x3f33, lsl #16
256dfc: b #0x256e58
256e00: fmov s1, w8
256e04: mov x28, x1
256e08: fdiv s0, s0, s1
256e0c: bl #0x254a74
256e10: mov x1, x28
256e14: mov w8, #0xcccd
256e18: movk w8, #0x3e4c, lsl #16
256e1c: fmov s1, w8
256e20: fmul s0, s0, s1
256e24: mov x0, x19
256e28: bl #0x22cf38
256e2c: fmov s1, s11
256e30: fmov s2, s9
256e34: ldr x1, [x21, #0x318]
256e38: fmov s3, s10
256e3c: mov x0, x19
256e40: ldur q0, [x29, #-0x80]
256e44: bl #0x22d238
256e48: add x22, x22, #0x80
256e4c: add x23, x23, #1
256e50: cmp x22, #0x300
256e54: b.eq #0x2570e4
256e58: add x8, x20, x22
256e5c: ldr s0, [x8, #0x34c]
256e60: fsub s0, s8, s0
256e64: fcmp s0, #0.0
256e68: b.mi #0x256ea8
256e6c: ldr s1, [x20, #0x6dc]
256e70: fcmp s1, #0.0
256e74: b.le #0x256ea8
256e78: ldr s2, [x20, #0x6e0]
256e7c: fsub s2, s0, s2
256e80: movi d0, #0000000000000000
256e84: fcmp s2, #0.0
256e88: b.mi #0x256f0c
256e8c: fdiv s0, s2, s1
256e90: ldr w9, [x20, #0x6e8]
256e94: cmp w9, #1
256e98: b.lt #0x256f04
256e9c: scvtf s1, w9
256ea0: fcmp s0, s1
256ea4: b.lt #0x256f04
256ea8: ldr s0, [x8, #0x334]
256eac: add x9, x8, #0x334
256eb0: ldr w10, [x8, #0x33c]
256eb4: ldr x9, [x9]
256eb8: fcmp s0, #0.0
256ebc: str w10, [x8, #0x348]
256ec0: str x9, [x8, #0x340]
256ec4: b.ne #0x256f44
256ec8: add x8, x20, x22
256ecc: fmov s1, w25
256ed0: ldr s0, [x8, #0x338]
256ed4: fcmp s0, s1
256ed8: b.ne #0x256f44
256edc: ldr s0, [x8, #0x33c]
256ee0: ldr x1, [x8, #0x2f8]
256ee4: fcmp s0, #0.0
256ee8: b.eq #0x256ef4
256eec: add x28, x8, #0x2f8
256ef0: b #0x256f54
256ef4: movi d0, #0000000000000000
256ef8: mov x0, x19
256efc: bl #0x22cf38
256f00: b #0x256e48
256f04: frintm s1, s0
256f08: fsub s0, s0, s1
256f0c: ldr w0, [x20, #0x6e4]
256f10: bl #0x254534
256f14: add x8, x20, x22
256f18: add x9, x8, #0x334
256f1c: ldr d1, [x8, #0x328]
256f20: ldr s3, [x8, #0x330]
256f24: ldr d2, [x9]
256f28: ldr s4, [x8, #0x33c]
256f2c: fsub v2.2s, v2.2s, v1.2s
256f30: fsub s4, s4, s3
256f34: fmla v1.2s, v2.2s, v0.s[0]
256f38: fmadd s0, s4, s0, s3
256f3c: str d1, [x8, #0x340]
256f40: str s0, [x8, #0x348]
256f44: add x8, x24, x23, lsl #7
256f48: add x9, x20, x22
256f4c: ldr x1, [x9, #0x2f8]
256f50: add x28, x8, #0x20
256f54: fmov s0, #1.00000000
256f58: mov x0, x19
256f5c: bl #0x22cf38
256f60: add x21, x20, x22
256f64: fmov s1, w27
256f68: sub x0, x29, #0x6c
256f6c: ldr s0, [x21, #0x348]
256f70: sub x1, x29, #0x70
256f74: fmul s0, s0, s1
256f78: bl #0x67f8c0
256f7c: ldp s5, s0, [x29, #-0x70]
256f80: mov x0, x19
256f84: ldr s1, [x21, #0x340]
256f88: ldr s2, [x21, #0x344]
256f8c: ldr x1, [x28]
256f90: fmul s3, s0, s2
256f94: fnmul s4, s1, s0
256f98: fmadd s0, s1, s5, s3
256f9c: fmadd s1, s2, s5, s4
256fa0: bl #0x22d590
256fa4: ldr s0, [x21, #0x348]
256fa8: ldr x1, [x28]
256fac: mov x0, x19
256fb0: fneg s0, s0
256fb4: bl #0x22d908
256fb8: ldp x8, x9, [sp, #0x80]
256fbc: mov w10, #0x10ac
256fc0: ldr s9, [x20, #0x11a4]
256fc4: ldrb w8, [x8, #0x18c]
256fc8: ldr d0, [x9, x10]
256fcc: cbnz w8, #0x256ff0
256fd0: ldr w8, [x20, #0x1184]
256fd4: cmp x23, x8
256fd8: fcsel s1, s13, s12, eq
256fdc: fmaxnm s2, s1, s14
256fe0: fmul v1.2s, v0.2s, v2.s[0]
256fe4: fmul s2, s9, s2
256fe8: fminnm v0.2s, v1.2s, v15.2s
256fec: fminnm s9, s2, s12
256ff0: mov s11, v0.s[1]
256ff4: ldr s10, [x20, #0x11a8]
256ff8: fmov s2, s9
256ffc: ldr x1, [x21, #0x300]
257000: mov x0, x19
257004: stur q0, [x29, #-0x80]
257008: fmov s3, s10
25700c: fmov s1, s11
257010: bl #0x22d238
257014: fmov s1, s11
257018: fmov s2, s9
25701c: ldr x1, [x21, #0x308]
257020: fmov s3, s10
257024: mov x0, x19
257028: ldur q0, [x29, #-0x80]
25702c: bl #0x22d238
257030: fmov s1, s11
257034: fmov s2, s9
257038: ldr x1, [x21, #0x310]
25703c: fmov s3, s10
257040: mov x0, x19
257044: ldur q0, [x29, #-0x80]
257048: bl #0x22d238
25704c: movi d0, #0000000000000000
257050: ldr w8, [x20, #0x1184]
257054: ldr x1, [x21, #0x318]
257058: cmp x23, x8
25705c: b.ne #0x256e24
257060: ldr s1, [x20, #0x1130]
257064: fsub s1, s8, s1
257068: fcmp s1, #0.0
25706c: b.mi #0x256e24
257070: fmov s2, w26
257074: fcmp s1, s2
257078: b.ge #0x256e24
25707c: fmov s0, w26
257080: mov w8, #0xd70a
257084: movk w8, #0x3c23, lsl #16
257088: fdiv s0, s1, s0
25708c: fmov s1, w8
257090: fcmp s0, s1
257094: b.mi #0x256e00
257098: mov w8, #0x999a
25709c: movk w8, #0x3e99, lsl #16
2570a0: fmov s1, w8
2570a4: fcmp s0, s1
2570a8: b.ls #0x2570d4
2570ac: mov w8, #0x999a
2570b0: mov x28, x1
2570b4: movk w8, #0xbe99, lsl #16
2570b8: fmov s1, w8
2570bc: fadd s0, s0, s1
2570c0: fmov s1, w26
2570c4: fdiv s0, s0, s1
2570c8: bl #0x254a74
2570cc: fsub s0, s12, s0
2570d0: b #0x256e10
2570d4: mov w8, #0xcccd
2570d8: movk w8, #0x3e4c, lsl #16
2570dc: fmov s0, w8
2570e0: b #0x256e24
2570e4: ldr w8, [sp, #0x6c]
2570e8: fmov s0, s8
2570ec: mov x0, x19
2570f0: cmp w8, #0
2570f4: cset w1, ne
2570f8: bl #0x28dfb8
2570fc: mov w8, #-0x3db80000
257100: ldr s0, [x20, #0x112c]
257104: fmov s12, #1.00000000
257108: fmov s1, w8
25710c: ldr x27, [sp, #0x70]
257110: ldr x23, [sp, #0x80]
257114: fcmp s0, s1
257118: fmov s1, #1.00000000
25711c: b.le #0x257230
257120: fsub s2, s8, s0
257124: fcmp s2, #0.0
257128: b.mi #0x257230
25712c: ldr s0, [x20, #0x8ec]
257130: fcmp s0, #0.0
257134: b.le #0x257230
257138: ldr s3, [x20, #0x8f0]
25713c: fsub s3, s2, s3
257140: movi d2, #0000000000000000
257144: fcmp s3, #0.0
257148: b.mi #0x257170
25714c: fdiv s0, s3, s0
257150: ldr w8, [x20, #0x8f8]
257154: cmp w8, #1
257158: b.lt #0x257168
25715c: scvtf s2, w8
257160: fcmp s0, s2
257164: b.ge #0x257230
257168: frintm s2, s0
25716c: fsub s2, s0, s2
257170: ldr w9, [x20, #0x900]
257174: cbz w9, #0x257230
257178: cmp w9, #1
25717c: b.lt #0x2571d4
257180: cmp w9, #1
257184: add x8, x20, #0x9cc
257188: b.eq #0x2571dc
25718c: add x12, x20, #0x9a4
257190: ldr s0, [x12]
257194: fcmp s0, s2
257198: b.ge #0x2571dc
25719c: mov x11, xzr
2571a0: add x10, x20, #0x9d0
2571a4: sub x13, x9, #1
2571a8: mov x14, #0x100000000
2571ac: ldur s0, [x10, #-0x28]
2571b0: fcmp s0, s2
2571b4: b.pl #0x2571e4
2571b8: subs x13, x13, #1
2571bc: add x11, x11, x14
2571c0: add x10, x10, #4
2571c4: b.ne #0x2571ac
2571c8: add x8, x8, x9, lsl #2
2571cc: ldur s12, [x8, #-4]
2571d0: b #0x257230
2571d4: movi d12, #0000000000000000
2571d8: b #0x257230
2571dc: ldr s12, [x8]
2571e0: b #0x257230
2571e4: asr x9, x11, #0x1e
2571e8: ldr s1, [x12, x9]
2571ec: mov w9, #0x37bd
2571f0: movk w9, #0x3586, lsl #16
2571f4: fsub s3, s0, s1
2571f8: fmov s0, w9
2571fc: asr x9, x11, #0x20
257200: fcmp s3, s0
257204: fmov s0, #1.00000000
257208: b.le #0x257214
25720c: fsub s0, s2, s1
257210: fdiv s0, s0, s3
257214: ldr s9, [x8, x9, lsl #2]
257218: ldr s1, [x10]
25721c: ldr w0, [x20, #0x8f4]
257220: fsub s10, s1, s9
257224: bl #0x254534
257228: fmadd s12, s10, s0, s9
25722c: fmov s1, #1.00000000
257230: mov w8, #-0x3db80000
257234: ldr s0, [x20, #0x1130]
257238: fmov s2, w8
25723c: fcmp s0, s2
257240: b.le #0x257350
257244: fsub s2, s8, s0
257248: fcmp s2, #0.0
25724c: b.mi #0x257350
257250: ldr s0, [x20, #0x7e4]
257254: fcmp s0, #0.0
257258: b.le #0x257350
25725c: ldr s3, [x20, #0x7e8]
257260: fsub s3, s2, s3
257264: movi d2, #0000000000000000
257268: fcmp s3, #0.0
25726c: b.mi #0x257294
257270: fdiv s0, s3, s0
257274: ldr w8, [x20, #0x7f0]
257278: cmp w8, #1
25727c: b.lt #0x25728c
257280: scvtf s2, w8
257284: fcmp s0, s2
257288: b.ge #0x257350
25728c: frintm s2, s0
257290: fsub s2, s0, s2
257294: ldr w9, [x20, #0x7f8]
257298: cbz w9, #0x257350
25729c: cmp w9, #1
2572a0: b.lt #0x2572f8
2572a4: cmp w9, #1
2572a8: add x8, x20, #0x8c4
2572ac: b.eq #0x257300
2572b0: add x12, x20, #0x89c
2572b4: ldr s0, [x12]
2572b8: fcmp s0, s2
2572bc: b.ge #0x257300
2572c0: mov x11, xzr
2572c4: add x10, x20, #0x8c8
2572c8: sub x13, x9, #1
2572cc: mov x14, #0x100000000
2572d0: ldur s0, [x10, #-0x28]
2572d4: fcmp s0, s2
2572d8: b.pl #0x257308
2572dc: subs x13, x13, #1
2572e0: add x11, x11, x14
2572e4: add x10, x10, #4
2572e8: b.ne #0x2572d0
2572ec: add x8, x8, x9, lsl #2
2572f0: ldur s1, [x8, #-4]
2572f4: b #0x257350
2572f8: movi d1, #0000000000000000
2572fc: b #0x257350
257300: ldr s1, [x8]
257304: b #0x257350
257308: asr x9, x11, #0x1e
25730c: ldr s1, [x12, x9]
257310: mov w9, #0x37bd
257314: movk w9, #0x3586, lsl #16
257318: fsub s3, s0, s1
25731c: fmov s0, w9
257320: asr x9, x11, #0x20
257324: fcmp s3, s0
257328: fmov s0, #1.00000000
25732c: b.le #0x257338
257330: fsub s0, s2, s1
257334: fdiv s0, s0, s3
257338: ldr s9, [x8, x9, lsl #2]
25733c: ldr s1, [x10]
257340: ldr w0, [x20, #0x7ec]
257344: fsub s10, s1, s9
257348: bl #0x254534
25734c: fmadd s1, s10, s0, s9
257350: ldrb w8, [x23, #0x18c]
257354: cbz w8, #0x257390
257358: fmov s0, s12
25735c: bl #0x24f2f0
257360: ldr w9, [x20, #0x1188]
257364: ldr w8, [x20, #0x1184]
257368: cmp w9, w8
25736c: b.ne #0x25762c
257370: ldr x23, [sp, #0x80]
257374: ldrb w8, [x23, #0x18c]
257378: cbz w8, #0x257390
25737c: ldr x8, [sp, #0x88]
257380: mov w9, #0x10ac
257384: ldr s9, [x20, #0x11a4]
257388: ldr d0, [x8, x9]
25738c: b #0x2573bc
257390: movi d0, #0000000000000000
257394: ldr x8, [sp, #0x88]
257398: mov w9, #0x10ac
25739c: ldr s1, [x20, #0x11a4]
2573a0: ldr d2, [x8, x9]
2573a4: fmaxnm s0, s12, s0
2573a8: fmul v2.2s, v2.2s, v0.s[0]
2573ac: fmul s3, s0, s1
2573b0: fmov s1, #1.00000000
2573b4: fminnm v0.2s, v2.2s, v15.2s
2573b8: fminnm s9, s3, s1
2573bc: mov s11, v0.s[1]
2573c0: ldr s10, [x20, #0x11a8]
2573c4: fmov s2, s9
2573c8: ldr x1, [x20, #0x228]
2573cc: mov x0, x19
2573d0: stur q0, [x29, #-0x80]
2573d4: fmov s3, s10
2573d8: fmov s1, s11
2573dc: bl #0x22d238
2573e0: fmov s1, s11
2573e4: fmov s2, s9
2573e8: ldr x1, [x20, #0x230]
2573ec: fmov s3, s10
2573f0: mov x0, x19
2573f4: ldur q0, [x29, #-0x80]
2573f8: str s10, [sp, #0x88]
2573fc: bl #0x22d238
257400: ldr w8, [x19, #0x518]
257404: ldr x1, [x20, #0x238]
257408: add x9, x20, #0x240
25740c: mov w10, #1
257410: mov x0, x19
257414: cmp w8, #2
257418: add x8, x20, #0x238
25741c: cset w2, eq
257420: cinc w21, w10, eq
257424: csel x22, x8, x9, eq
257428: bl #0x22ce80
25742c: ldr w8, [x19, #0x518]
257430: ldr x1, [x20, #0x240]
257434: mov x0, x19
257438: cmp w8, #1
25743c: cset w2, eq
257440: bl #0x22ce80
257444: ldr x22, [x22]
257448: mov w0, w21
25744c: bl #0x23e9cc
257450: ldrb w8, [x23, #0x18c]
257454: fmov s4, #1.00000000
257458: movi d5, #0000000000000000
25745c: mov x0, x19
257460: mov x1, x22
257464: cmp w8, #0
257468: fcsel s6, s12, s4, eq
25746c: fmaxnm s5, s6, s5
257470: fmul s0, s0, s5
257474: fmul s1, s1, s5
257478: fmul s2, s2, s5
25747c: fminnm s0, s0, s4
257480: fminnm s1, s1, s4
257484: fminnm s2, s2, s4
257488: bl #0x22d238
25748c: ldr w9, [x19, #0x520]
257490: ldr w8, [x20, #0x1150]
257494: bic w21, w9, w9, asr #31
257498: tbnz w8, #0x1f, #0x2574b0
25749c: cmp w21, w8
2574a0: b.ge #0x2574b0
2574a4: str s8, [x20, #0x1134]
2574a8: str s8, [x20, #0x1138]
2574ac: str s8, [x20, #0x1140]
2574b0: ldr w8, [x20, #0x1160]
2574b4: str w21, [x20, #0x1150]
2574b8: cmp w8, w21
2574bc: b.eq #0x2574f4
2574c0: ldr x22, [x20, #0x258]
2574c4: sub x8, x29, #0x68
2574c8: mov w0, w21
2574cc: str w21, [x20, #0x1160]
2574d0: bl #0x63b560
2574d4: sub x2, x29, #0x68
2574d8: mov x0, x19
2574dc: mov x1, x22
2574e0: bl #0x22cfc0
2574e4: ldurb w8, [x29, #-0x68]
2574e8: tbz w8, #0, #0x2574f4
2574ec: ldur x0, [x29, #-0x58]
2574f0: bl #0x6790c8
2574f4: cmp w21, #0x15
2574f8: ldr x1, [x20, #0x250]
2574fc: mov x0, x19
257500: cset w2, lo
257504: str s11, [sp, #0x6c]
257508: bl #0x22ce80
25750c: mov w8, #-0x3db80000
257510: ldr s0, [x20, #0x1138]
257514: movi d11, #0000000000000000
257518: fmov s1, w8
25751c: fcmp s0, s1
257520: b.le #0x25757c
257524: fsub s0, s8, s0
257528: ldur q3, [x29, #-0x80]
25752c: fcmp s0, #0.0
257530: b.mi #0x257580
257534: ldr s1, [x20, #0xafc]
257538: fcmp s1, #0.0
25753c: b.le #0x257580
257540: ldr s2, [x20, #0xb00]
257544: fsub s0, s0, s2
257548: fcmp s0, #0.0
25754c: b.mi #0x257574
257550: fdiv s0, s0, s1
257554: ldr w8, [x20, #0xb08]
257558: cmp w8, #1
25755c: b.lt #0x25756c
257560: scvtf s1, w8
257564: fcmp s0, s1
257568: b.ge #0x257580
25756c: frintm s1, s0
257570: fsub s11, s0, s1
257574: mov w22, #1
257578: b #0x257584
25757c: ldur q3, [x29, #-0x80]
257580: mov w22, wzr
257584: fmov s10, s9
257588: fmov d13, d3
25758c: cmp w21, #0x14
257590: str s9, [sp, #0x80]
257594: b.hi #0x2575b8
257598: fmov v0.2s, #1.75000000
25759c: fmov s1, #1.75000000
2575a0: ldr s2, [sp, #0x80]
2575a4: fmul s1, s2, s1
2575a8: fmov s2, #1.00000000
2575ac: fmul v0.2s, v3.2s, v0.2s
2575b0: fminnm s10, s1, s2
2575b4: fminnm v13.2s, v0.2s, v15.2s
2575b8: fmov s12, #1.00000000
2575bc: fmov s0, #1.00000000
2575c0: ldr x1, [x20, #0x258]
2575c4: cbz w22, #0x257728
2575c8: ldr w9, [x20, #0xb10]
2575cc: cbz w9, #0x257728
2575d0: cmp w9, #1
2575d4: b.lt #0x2576c8
2575d8: cmp w9, #1
2575dc: add x8, x20, #0xbdc
2575e0: b.eq #0x2576d0
2575e4: add x12, x20, #0xbb4
2575e8: ldr s0, [x12]
2575ec: fcmp s0, s11
2575f0: b.ge #0x2576d0
2575f4: mov x11, xzr
2575f8: add x10, x20, #0xbe0
2575fc: sub x13, x9, #1
257600: mov x14, #0x100000000
257604: ldur s0, [x10, #-0x28]
257608: fcmp s0, s11
25760c: b.pl #0x2576d8
257610: subs x13, x13, #1
257614: add x11, x11, x14
257618: add x10, x10, #4
25761c: b.ne #0x257604
257620: add x8, x8, x9, lsl #2
257624: ldur s0, [x8, #-4]
257628: b #0x257728
25762c: mov x21, xzr
257630: add x26, x20, #0x324
257634: str w8, [x20, #0x1188]
257638: b #0x257658
25763c: ldur w0, [x26, #-4]
257640: mov w1, w22
257644: bl #0x248648
257648: add x21, x21, #1
25764c: add x26, x26, #0x80
257650: cmp x21, #6
257654: b.eq #0x257370
257658: ldr w8, [x20, #0x1184]
25765c: cmp x21, x8
257660: cset w8, eq
257664: lsl w22, w8, #1
257668: ldr w8, [x26]
25766c: cmp w22, w8
257670: b.eq #0x25763c
257674: ldur x1, [x26, #-0x24]
257678: ldur x23, [x26, #-0x1c]
25767c: mov x0, x19
257680: ldur x24, [x26, #-0x14]
257684: ldur x25, [x26, #-0xc]
257688: mov w2, w22
25768c: bl #0x24f5a4
257690: mov x0, x19
257694: mov x1, x23
257698: mov w2, w22
25769c: bl #0x24f5a4
2576a0: mov x0, x19
2576a4: mov x1, x24
2576a8: mov w2, w22
2576ac: bl #0x24f5a4
2576b0: mov x0, x19
2576b4: mov x1, x25
2576b8: mov w2, w22
2576bc: bl #0x24f5a4
2576c0: str w22, [x26]
2576c4: b #0x25763c
2576c8: movi d0, #0000000000000000
2576cc: b #0x257728
2576d0: ldr s0, [x8]
2576d4: b #0x257728
2576d8: asr x9, x11, #0x1e
2576dc: mov x23, x1
2576e0: ldr s1, [x12, x9]
2576e4: mov w9, #0x37bd
2576e8: movk w9, #0x3586, lsl #16
2576ec: fsub s2, s0, s1
2576f0: fmov s0, w9
2576f4: asr x9, x11, #0x20
2576f8: fcmp s2, s0
2576fc: fmov s0, #1.00000000
257700: b.le #0x25770c
257704: fsub s0, s11, s1
257708: fdiv s0, s0, s2
25770c: ldr s9, [x8, x9, lsl #2]
257710: ldr s1, [x10]
257714: ldr w0, [x20, #0xb04]
257718: fsub s14, s1, s9
25771c: bl #0x254534
257720: fmadd s0, s14, s0, s9
257724: mov x1, x23
257728: movi d9, #0000000000000000
25772c: ldr s3, [sp, #0x88]
257730: mov x0, x19
257734: fmaxnm s1, s0, s9
257738: fmul v0.2s, v13.2s, v1.s[0]
25773c: fmul s1, s10, s1
257740: fminnm v0.2s, v0.2s, v15.2s
257744: fminnm s2, s1, s12
257748: mov s1, v0.s[1]
25774c: bl #0x22d238
257750: movi d10, #0000000000000000
257754: cbz w22, #0x25799c
257758: ldr w8, [x20, #0xb0c]
25775c: cbz w8, #0x2577c0
257760: cmp w8, #1
257764: b.lt #0x2577c8
257768: add x22, x20, #0xb14
25776c: add x9, x20, #0xb8c
257770: b.eq #0x2577d0
257774: ldr s0, [x22]
257778: fcmp s0, s11
25777c: b.ge #0x2577d0
257780: mov x11, xzr
257784: add x10, x20, #0xb90
257788: sub x12, x8, #1
25778c: mov x13, #0x100000000
257790: ldur s0, [x10, #-0x78]
257794: fcmp s0, s11
257798: b.pl #0x2577d8
25779c: subs x12, x12, #1
2577a0: add x11, x11, x13
2577a4: add x10, x10, #4
2577a8: b.ne #0x257790
2577ac: add x9, x9, x8, lsl #2
2577b0: ldur s12, [x9, #-4]
2577b4: cmp w8, #1
2577b8: b.ge #0x25782c
2577bc: b #0x257938
2577c0: fmov s12, #1.00000000
2577c4: b #0x257988
2577c8: movi d12, #0000000000000000
2577cc: b #0x257988
2577d0: ldr s12, [x9]
2577d4: b #0x25782c
2577d8: asr x8, x11, #0x1e
2577dc: ldr s1, [x22, x8]
2577e0: mov w8, #0x37bd
2577e4: movk w8, #0x3586, lsl #16
2577e8: fsub s2, s0, s1
2577ec: fmov s0, w8
2577f0: asr x8, x11, #0x20
2577f4: fcmp s2, s0
2577f8: fmov s0, #1.00000000
2577fc: b.le #0x257808
257800: fsub s0, s11, s1
257804: fdiv s0, s0, s2
257808: ldr s10, [x9, x8, lsl #2]
25780c: ldr s1, [x10]
257810: ldr w0, [x20, #0xb04]
257814: fsub s12, s1, s10
257818: bl #0x254534
25781c: ldr w8, [x20, #0xb0c]
257820: fmadd s12, s12, s0, s10
257824: cmp w8, #1
257828: b.lt #0x257938
25782c: cmp w8, #1
257830: add x9, x20, #0xb3c
257834: b.eq #0x257880
257838: ldr s0, [x20, #0xb14]
25783c: fcmp s0, s11
257840: b.ge #0x257880
257844: mov w12, w8
257848: mov x11, xzr
25784c: add x10, x20, #0xb40
257850: sub x13, x12, #1
257854: mov x14, #0x100000000
257858: ldur s0, [x10, #-0x28]
25785c: fcmp s0, s11
257860: b.pl #0x257888
257864: subs x13, x13, #1
257868: add x11, x11, x14
25786c: add x10, x10, #4
257870: b.ne #0x257858
257874: add x9, x9, x12, lsl #2
257878: ldur s10, [x9, #-4]
25787c: b #0x2578d4
257880: ldr s10, [x9]
257884: b #0x2578dc
257888: asr x8, x11, #0x1e
25788c: ldr s1, [x22, x8]
257890: mov w8, #0x37bd
257894: movk w8, #0x3586, lsl #16
257898: fsub s2, s0, s1
25789c: fmov s0, w8
2578a0: asr x8, x11, #0x20
2578a4: fcmp s2, s0
2578a8: fmov s0, #1.00000000
2578ac: b.le #0x2578b8
2578b0: fsub s0, s11, s1
2578b4: fdiv s0, s0, s2
2578b8: ldr s10, [x9, x8, lsl #2]
2578bc: ldr s1, [x10]
2578c0: ldr w0, [x20, #0xb04]
2578c4: fsub s13, s1, s10
2578c8: bl #0x254534
2578cc: ldr w8, [x20, #0xb0c]
2578d0: fmadd s10, s13, s0, s10
2578d4: cmp w8, #1
2578d8: b.lt #0x257988
2578dc: cmp w8, #1
2578e0: add x9, x20, #0xb64
2578e4: b.eq #0x257930
2578e8: ldr s0, [x20, #0xb14]
2578ec: fcmp s0, s11
2578f0: b.ge #0x257930
2578f4: mov w11, w8
2578f8: mov x10, xzr
2578fc: add x8, x20, #0xb68
257900: sub x12, x11, #1
257904: mov x13, #0x100000000
257908: ldur s0, [x8, #-0x50]
25790c: fcmp s0, s11
257910: b.pl #0x257940
257914: subs x12, x12, #1
257918: add x10, x10, x13
25791c: add x8, x8, #4
257920: b.ne #0x257908
257924: add x8, x9, x11, lsl #2
257928: ldur s9, [x8, #-4]
25792c: b #0x257988
257930: ldr s9, [x9]
257934: b #0x257988
257938: movi d10, #0000000000000000
25793c: b #0x257988
257940: asr x11, x10, #0x1e
257944: asr x10, x10, #0x20
257948: ldr s1, [x22, x11]
25794c: mov w11, #0x37bd
257950: movk w11, #0x3586, lsl #16
257954: fsub s2, s0, s1
257958: fmov s0, w11
25795c: fcmp s2, s0
257960: fmov s0, #1.00000000
257964: b.le #0x257970
257968: fsub s0, s11, s1
25796c: fdiv s0, s0, s2
257970: ldr s9, [x9, x10, lsl #2]
257974: ldr s1, [x8]
257978: ldr w0, [x20, #0xb04]
25797c: fsub s11, s1, s9
257980: bl #0x254534
257984: fmadd s9, s11, s0, s9
257988: fmov s0, #-1.00000000
25798c: mov w8, #-0x3dac0000
257990: fmov s1, w8
257994: fadd s0, s12, s0
257998: fmadd s9, s0, s1, s9
25799c: ldr s0, [x20, #0x6ac]
2579a0: ldr s1, [x20, #0x6b0]
2579a4: mov x0, x19
2579a8: ldr x1, [x20, #0x258]
2579ac: fadd s0, s10, s0
2579b0: fadd s1, s9, s1
2579b4: bl #0x22d590
2579b8: fmov s0, s12
2579bc: fmov s1, s12
2579c0: ldr x1, [x20, #0x258]
2579c4: mov x0, x19
2579c8: bl #0x22d830
2579cc: cmp w21, #0x14
2579d0: b.hi #0x257a18
2579d4: mov x0, x20
2579d8: mov x1, x19
2579dc: mov w2, wzr
2579e0: mov w3, w21
2579e4: bl #0x2592e4
2579e8: ldr s0, [x20, #0x1260]
2579ec: ldr s1, [x20, #0x1264]
2579f0: mov x0, x19
2579f4: ldr x1, [x20, #0x250]
2579f8: fadd s0, s10, s0
2579fc: fadd s1, s9, s1
257a00: bl #0x22d590
257a04: fmov s0, s12
257a08: fmov s1, s12
257a0c: ldr x1, [x20, #0x250]
257a10: mov x0, x19
257a14: bl #0x22d830
257a18: mov w8, #-0x3db80000
257a1c: ldr s0, [x20, #0x1134]
257a20: str d15, [sp, #0x78]
257a24: fmov s1, w8
257a28: fcmp s0, s1
257a2c: b.le #0x257a78
257a30: fsub s1, s8, s0
257a34: fcmp s1, #0.0
257a38: b.mi #0x257a78
257a3c: ldr s0, [x20, #0x9f4]
257a40: fcmp s0, #0.0
257a44: b.le #0x257a78
257a48: ldr s2, [x20, #0x9f8]
257a4c: fsub s1, s1, s2
257a50: movi d2, #0000000000000000
257a54: fcmp s1, #0.0
257a58: b.mi #0x257b7c
257a5c: fdiv s0, s1, s0
257a60: ldr w8, [x20, #0xa00]
257a64: cmp w8, #1
257a68: b.lt #0x257b74
257a6c: scvtf s1, w8
257a70: fcmp s0, s1
257a74: b.lt #0x257b74
257a78: movi d0, #0000000000000000
257a7c: ldr x1, [x20, #0x260]
257a80: mov x0, x19
257a84: bl #0x22cf38
257a88: ldr s10, [sp, #0x80]
257a8c: mov w8, #-0x3db80000
257a90: ldr s1, [x20, #0x1140]
257a94: movi d13, #0000000000000000
257a98: fmov s0, w8
257a9c: movi d15, #0000000000000000
257aa0: fmov s11, #1.00000000
257aa4: fmov s12, #1.00000000
257aa8: fmov s9, #1.00000000
257aac: fcmp s1, s0
257ab0: movi d0, #0000000000000000
257ab4: b.le #0x2581fc
257ab8: fsub s1, s8, s1
257abc: fcmp s1, #0.0
257ac0: b.mi #0x2581fc
257ac4: ldr s2, [x20, #0xd0c]
257ac8: fcmp s2, #0.0
257acc: b.le #0x2581fc
257ad0: ldr s0, [x20, #0xd10]
257ad4: movi d14, #0000000000000000
257ad8: movi d10, #0000000000000000
257adc: fsub s0, s1, s0
257ae0: fcmp s0, #0.0
257ae4: b.mi #0x257b14
257ae8: fdiv s1, s0, s2
257aec: ldr w8, [x20, #0xd18]
257af0: ldr s10, [sp, #0x80]
257af4: cmp w8, #1
257af8: b.lt #0x257b0c
257afc: scvtf s0, w8
257b00: fcmp s1, s0
257b04: movi d0, #0000000000000000
257b08: b.ge #0x2581fc
257b0c: frintm s0, s1
257b10: fsub s10, s1, s0
257b14: ldr w8, [x20, #0xd1c]
257b18: cbz w8, #0x258128
257b1c: cmp w8, #1
257b20: b.lt #0x257c40
257b24: add x9, x20, #0xd9c
257b28: b.eq #0x257c50
257b2c: add x12, x20, #0xd24
257b30: ldr s0, [x12]
257b34: fcmp s0, s10
257b38: b.ge #0x257c50
257b3c: mov x11, xzr
257b40: add x10, x20, #0xda0
257b44: sub x13, x8, #1
257b48: mov x14, #0x100000000
257b4c: ldur s0, [x10, #-0x78]
257b50: fcmp s0, s10
257b54: b.pl #0x257c60
257b58: subs x13, x13, #1
257b5c: add x11, x11, x14
257b60: add x10, x10, #4
257b64: b.ne #0x257b4c
257b68: add x9, x9, x8, lsl #2
257b6c: ldur s12, [x9, #-4]
257b70: b #0x257cac
257b74: frintm s1, s0
257b78: fsub s2, s0, s1
257b7c: ldr w8, [x20, #0x1164]
257b80: str s2, [sp, #0x50]
257b84: cmp w8, w21
257b88: b.eq #0x257bc0
257b8c: ldr x22, [x20, #0x270]
257b90: sub x8, x29, #0x68
257b94: mov w0, w21
257b98: str w21, [x20, #0x1164]
257b9c: bl #0x63b560
257ba0: sub x2, x29, #0x68
257ba4: mov x0, x19
257ba8: mov x1, x22
257bac: bl #0x22cfc0
257bb0: ldurb w8, [x29, #-0x68]
257bb4: tbz w8, #0, #0x257bc0
257bb8: ldur x0, [x29, #-0x58]
257bbc: bl #0x6790c8
257bc0: fmov s11, #1.00000000
257bc4: fmov s0, #1.00000000
257bc8: ldr x1, [x20, #0x270]
257bcc: ldr w9, [x20, #0xa08]
257bd0: ldr d14, [x20, #0x698]
257bd4: ldr s2, [x20, #0x6a0]
257bd8: ldr s3, [x20, #0x6a4]
257bdc: cbz w9, #0x257d80
257be0: cmp w9, #1
257be4: b.lt #0x257c48
257be8: ldr s4, [sp, #0x50]
257bec: cmp w9, #1
257bf0: add x8, x20, #0xad4
257bf4: b.eq #0x257c58
257bf8: add x12, x20, #0xaac
257bfc: ldr s0, [x12]
257c00: fcmp s0, s4
257c04: b.ge #0x257c58
257c08: mov x11, xzr
257c0c: add x10, x20, #0xad8
257c10: sub x13, x9, #1
257c14: mov x14, #0x100000000
257c18: ldur s0, [x10, #-0x28]
257c1c: fcmp s0, s4
257c20: b.pl #0x257d14
257c24: subs x13, x13, #1
257c28: add x11, x11, x14
257c2c: add x10, x10, #4
257c30: b.ne #0x257c18
257c34: add x8, x8, x9, lsl #2
257c38: ldur s0, [x8, #-4]
257c3c: b #0x257d80
257c40: movi d12, #0000000000000000
257c44: b #0x258128
257c48: movi d0, #0000000000000000
257c4c: b #0x257d80
257c50: ldr s12, [x9]
257c54: b #0x257cb4
257c58: ldr s0, [x8]
257c5c: b #0x257d80
257c60: asr x8, x11, #0x1e
257c64: ldr s1, [x12, x8]
257c68: mov w8, #0x37bd
257c6c: movk w8, #0x3586, lsl #16
257c70: fsub s2, s0, s1
257c74: fmov s0, w8
257c78: asr x8, x11, #0x20
257c7c: fcmp s2, s0
257c80: fmov s0, #1.00000000
257c84: b.le #0x257c90
257c88: fsub s0, s10, s1
257c8c: fdiv s0, s0, s2
257c90: ldr s12, [x9, x8, lsl #2]
257c94: ldr s1, [x10]
257c98: ldr w0, [x20, #0xd14]
257c9c: fsub s14, s1, s12
257ca0: bl #0x254534
257ca4: ldr w8, [x20, #0xd1c]
257ca8: fmadd s12, s14, s0, s12
257cac: cmp w8, #1
257cb0: b.lt #0x2580d0
257cb4: cmp w8, #1
257cb8: add x22, x20, #0xd24
257cbc: add x9, x20, #0xd4c
257cc0: b.eq #0x257d0c
257cc4: ldr s0, [x20, #0xd24]
257cc8: fcmp s0, s10
257ccc: b.ge #0x257d0c
257cd0: mov w12, w8
257cd4: mov x11, xzr
257cd8: add x10, x20, #0xd50
257cdc: sub x13, x12, #1
257ce0: mov x14, #0x100000000
257ce4: ldur s0, [x10, #-0x28]
257ce8: fcmp s0, s10
257cec: b.pl #0x258018
257cf0: subs x13, x13, #1
257cf4: add x11, x11, x14
257cf8: add x10, x10, #4
257cfc: b.ne #0x257ce4
257d00: add x9, x9, x12, lsl #2
257d04: ldur s14, [x9, #-4]
257d08: b #0x25806c
257d0c: ldr s14, [x9]
257d10: b #0x258074
257d14: asr x9, x11, #0x1e
257d18: fmov s13, s2
257d1c: mov x22, x1
257d20: str s3, [sp, #0x4c]
257d24: ldr s1, [x12, x9]
257d28: mov w9, #0x37bd
257d2c: movk w9, #0x3586, lsl #16
257d30: fsub s2, s0, s1
257d34: fmov s0, w9
257d38: asr x9, x11, #0x20
257d3c: fcmp s2, s0
257d40: fmov s0, #1.00000000
257d44: b.le #0x257d50
257d48: fsub s0, s4, s1
257d4c: fdiv s0, s0, s2
257d50: ldr s15, [x8, x9, lsl #2]
257d54: ldr s1, [x10]
257d58: ldr w0, [x20, #0x9fc]
257d5c: fsub s1, s1, s15
257d60: str s1, [sp, #0x40]
257d64: bl #0x254534
257d68: ldr s1, [sp, #0x40]
257d6c: ldr s3, [sp, #0x4c]
257d70: mov x1, x22
257d74: fmov s2, s13
257d78: fmadd s0, s1, s0, s15
257d7c: ldr d15, [sp, #0x78]
257d80: movi d13, #0000000000000000
257d84: mov x0, x19
257d88: fmaxnm s1, s0, s13
257d8c: fmul v0.2s, v14.2s, v1.s[0]
257d90: fmul s1, s2, s1
257d94: fminnm v0.2s, v0.2s, v15.2s
257d98: fminnm s2, s1, s11
257d9c: mov s1, v0.s[1]
257da0: bl #0x22d238
257da4: mov x0, x20
257da8: mov x1, x19
257dac: mov w2, #1
257db0: mov w3, w21
257db4: bl #0x2592e4
257db8: mov w8, #0xcccd
257dbc: ldr s1, [sp, #0x50]
257dc0: ldr s14, [x20, #0x698]
257dc4: movk w8, #0xbdcc, lsl #16
257dc8: ldr s15, [x20, #0x69c]
257dcc: ldr x1, [x20, #0x11c8]
257dd0: fmov s0, w8
257dd4: mov x0, x19
257dd8: fdiv s0, s1, s0
257ddc: fadd s0, s0, s11
257de0: fcmp s0, s11
257de4: fcsel s1, s11, s0, gt
257de8: fcmp s0, #0.0
257dec: ldr s11, [x20, #0x6a0]
257df0: fmov s2, s11
257df4: fcsel s0, s13, s1, mi
257df8: ldr s1, [x20, #0x6a4]
257dfc: fmul s13, s0, s1
257e00: fmov s0, s14
257e04: fmov s1, s15
257e08: fmov s3, s13
257e0c: bl #0x22d238
257e10: fmov s0, s14
257e14: fmov s1, s15
257e18: ldr x1, [x20, #0x11d0]
257e1c: fmov s2, s11
257e20: fmov s3, s13
257e24: mov x0, x19
257e28: bl #0x22d238
257e2c: fmov s0, s14
257e30: fmov s1, s15
257e34: ldr x1, [x20, #0x11d8]
257e38: fmov s2, s11
257e3c: fmov s3, s13
257e40: mov x0, x19
257e44: bl #0x22d238
257e48: ldr s3, [sp, #0x50]
257e4c: movi d2, #0000000000000000
257e50: fcmp s3, #0.0
257e54: b.ls #0x257edc
257e58: mov w8, #0xcccd
257e5c: movk w8, #0x3dcc, lsl #16
257e60: fmov s0, w8
257e64: fcmp s3, s0
257e68: b.le #0x257e84
257e6c: fmov s0, #1.00000000
257e70: fmov s2, #-0.25000000
257e74: fcmp s3, s0
257e78: b.gt #0x257edc
257e7c: mov w8, #2
257e80: b #0x257e88
257e84: mov w8, #1
257e88: sub w9, w8, #1
257e8c: adrp x10, #0x2a50000
257e90: add x10, x10, #0x364
257e94: ldr s1, [x10, w9, uxtw #2]
257e98: mov w10, #0x37bd
257e9c: movk w10, #0x3586, lsl #16
257ea0: fsub s2, s0, s1
257ea4: fmov s0, w10
257ea8: fcmp s2, s0
257eac: fmov s0, #1.00000000
257eb0: b.le #0x257ebc
257eb4: fsub s0, s3, s1
257eb8: fdiv s0, s0, s2
257ebc: adrp x10, #0x2a50000
257ec0: add x10, x10, #0x370
257ec4: ldr w0, [x20, #0x9fc]
257ec8: ldr s11, [x10, x9, lsl #2]
257ecc: ldr s1, [x10, x8, lsl #2]
257ed0: fsub s13, s1, s11
257ed4: bl #0x254534
257ed8: fmadd s2, s13, s0, s11
257edc: mov w8, #0x42540000
257ee0: ldr s0, [x20, #0x6b8]
257ee4: ldr x1, [x20, #0x260]
257ee8: fmov s1, w8
257eec: mov x0, x19
257ef0: fmul s1, s2, s1
257ef4: fadd s2, s9, s0
257ef8: ldr s0, [x20, #0x6b4]
257efc: fadd s0, s10, s0
257f00: fadd s1, s1, s2
257f04: bl #0x22d590
257f08: fmov s0, s12
257f0c: fmov s1, s12
257f10: ldr x1, [x20, #0x260]
257f14: mov x0, x19
257f18: bl #0x22d830
257f1c: fmov s9, #1.00000000
257f20: fmov s0, #1.00000000
257f24: ldr w9, [x20, #0xa04]
257f28: ldr x1, [x20, #0x260]
257f2c: ldr s10, [sp, #0x80]
257f30: cbz w9, #0x257ff8
257f34: cmp w9, #1
257f38: b.lt #0x257f94
257f3c: ldr s3, [sp, #0x50]
257f40: cmp w9, #1
257f44: add x8, x20, #0xa34
257f48: b.eq #0x257f9c
257f4c: add x12, x20, #0xa0c
257f50: ldr s0, [x12]
257f54: fcmp s0, s3
257f58: b.ge #0x257f9c
257f5c: mov x11, xzr
257f60: add x10, x20, #0xa38
257f64: sub x13, x9, #1
257f68: mov x14, #0x100000000
257f6c: ldur s0, [x10, #-0x28]
257f70: fcmp s0, s3
257f74: b.pl #0x257fa4
257f78: subs x13, x13, #1
257f7c: add x11, x11, x14
257f80: add x10, x10, #4
257f84: b.ne #0x257f6c
257f88: add x8, x8, x9, lsl #2
257f8c: ldur s0, [x8, #-4]
257f90: b #0x257ff8
257f94: movi d0, #0000000000000000
257f98: b #0x257ff8
257f9c: ldr s0, [x8]
257fa0: b #0x257ff8
257fa4: asr x9, x11, #0x1e
257fa8: mov x22, x1
257fac: ldr s1, [x12, x9]
257fb0: mov w9, #0x37bd
257fb4: movk w9, #0x3586, lsl #16
257fb8: fsub s2, s0, s1
257fbc: fmov s0, w9
257fc0: asr x9, x11, #0x20
257fc4: fcmp s2, s0
257fc8: fmov s0, #1.00000000
257fcc: b.le #0x257fd8
257fd0: fsub s0, s3, s1
257fd4: fdiv s0, s0, s2
257fd8: ldr s10, [x8, x9, lsl #2]
257fdc: ldr s1, [x10]
257fe0: ldr w0, [x20, #0x9fc]
257fe4: fsub s11, s1, s10
257fe8: bl #0x254534
257fec: fmadd s0, s11, s0, s10
257ff0: ldr s10, [sp, #0x80]
257ff4: mov x1, x22
257ff8: fcmp s0, s9
257ffc: movi d2, #0000000000000000
258000: mov x0, x19
258004: fcsel s1, s9, s0, gt
258008: fcmp s0, #0.0
25800c: fcsel s0, s2, s1, mi
258010: bl #0x22cf38
258014: b #0x257a8c
258018: asr x8, x11, #0x1e
25801c: ldr s1, [x22, x8]
258020: mov w8, #0x37bd
258024: movk w8, #0x3586, lsl #16
258028: fsub s2, s0, s1
25802c: fmov s0, w8
258030: asr x8, x11, #0x20
258034: fcmp s2, s0
258038: fmov s0, #1.00000000
25803c: b.le #0x258048
258040: fsub s0, s10, s1
258044: fdiv s0, s0, s2
258048: ldr s14, [x9, x8, lsl #2]
25804c: ldr s1, [x10]
258050: ldr w0, [x20, #0xd14]
258054: fsub s1, s1, s14
258058: str s1, [sp, #0x50]
25805c: bl #0x254534
258060: ldr s1, [sp, #0x50]
258064: ldr w8, [x20, #0xd1c]
258068: fmadd s14, s1, s0, s14
25806c: cmp w8, #1
258070: b.lt #0x258128
258074: cmp w8, #1
258078: add x9, x20, #0xd74
25807c: b.eq #0x2580c8
258080: ldr s0, [x20, #0xd24]
258084: fcmp s0, s10
258088: b.ge #0x2580c8
25808c: mov w11, w8
258090: mov x10, xzr
258094: add x8, x20, #0xd78
258098: sub x12, x11, #1
25809c: mov x13, #0x100000000
2580a0: ldur s0, [x8, #-0x50]
2580a4: fcmp s0, s10
2580a8: b.pl #0x2580d8
2580ac: subs x12, x12, #1
2580b0: add x10, x10, x13
2580b4: add x8, x8, #4
2580b8: b.ne #0x2580a0
2580bc: add x8, x9, x11, lsl #2
2580c0: ldur s15, [x8, #-4]
2580c4: b #0x258128
2580c8: ldr s15, [x9]
2580cc: b #0x258128
2580d0: movi d14, #0000000000000000
2580d4: b #0x258128
2580d8: asr x11, x10, #0x1e
2580dc: asr x10, x10, #0x20
2580e0: ldr s1, [x22, x11]
2580e4: mov w11, #0x37bd
2580e8: movk w11, #0x3586, lsl #16
2580ec: fsub s2, s0, s1
2580f0: fmov s0, w11
2580f4: fcmp s2, s0
2580f8: fmov s0, #1.00000000
2580fc: b.le #0x258108
258100: fsub s0, s10, s1
258104: fdiv s0, s0, s2
258108: ldr s15, [x9, x10, lsl #2]
25810c: ldr s1, [x8]
258110: ldr w0, [x20, #0xd14]
258114: fsub s1, s1, s15
258118: str s1, [sp, #0x50]
25811c: bl #0x254534
258120: ldr s1, [sp, #0x50]
258124: fmadd s15, s1, s0, s15
258128: fmov s0, #-1.00000000
25812c: fmov s1, #-8.00000000
258130: ldr w9, [x20, #0xd20]
258134: fadd s0, s12, s0
258138: fmadd s15, s0, s1, s15
25813c: cbz w9, #0x2581f4
258140: cmp w9, #1
258144: b.lt #0x25819c
258148: cmp w9, #1
25814c: add x8, x20, #0xdec
258150: b.eq #0x2581a4
258154: add x12, x20, #0xdc4
258158: ldr s0, [x12]
25815c: fcmp s0, s10
258160: b.ge #0x2581a4
258164: mov x11, xzr
258168: add x10, x20, #0xdf0
25816c: sub x13, x9, #1
258170: mov x14, #0x100000000
258174: ldur s0, [x10, #-0x28]
258178: fcmp s0, s10
25817c: b.pl #0x2581ac
258180: subs x13, x13, #1
258184: add x11, x11, x14
258188: add x10, x10, #4
25818c: b.ne #0x258174
258190: add x8, x8, x9, lsl #2
258194: ldur s9, [x8, #-4]
258198: b #0x2581f4
25819c: movi d9, #0000000000000000
2581a0: b #0x2581f4
2581a4: ldr s9, [x8]
2581a8: b #0x2581f4
2581ac: asr x9, x11, #0x1e
2581b0: ldr s1, [x12, x9]
2581b4: mov w9, #0x37bd
2581b8: movk w9, #0x3586, lsl #16
2581bc: fsub s2, s0, s1
2581c0: fmov s0, w9
2581c4: asr x9, x11, #0x20
2581c8: fcmp s2, s0
2581cc: fmov s0, #1.00000000
2581d0: b.le #0x2581dc
2581d4: fsub s0, s10, s1
2581d8: fdiv s0, s0, s2
2581dc: ldr s9, [x8, x9, lsl #2]
2581e0: ldr s1, [x10]
2581e4: ldr w0, [x20, #0xd14]
2581e8: fsub s10, s1, s9
2581ec: bl #0x254534
2581f0: fmadd s9, s10, s0, s9
2581f4: fmov s0, s14
2581f8: ldr s10, [sp, #0x80]
2581fc: ldr s1, [x20, #0x6bc]
258200: ldr s2, [x20, #0x6c0]
258204: mov x0, x19
258208: ldr x1, [x20, #0x278]
25820c: fadd s0, s0, s1
258210: fadd s1, s15, s2
258214: bl #0x22d590
258218: fmov s0, s12
25821c: fmov s1, s12
258220: ldr x1, [x20, #0x278]
258224: mov x0, x19
258228: bl #0x22d830
25822c: scvtf s0, w21
258230: mov w8, #0x42c80000
258234: ldr x1, [x20, #0x280]
258238: fmov s1, w8
25823c: mov x0, x19
258240: fdiv s0, s0, s1
258244: fcmp s0, s11
258248: fcsel s1, s11, s0, gt
25824c: fcmp s0, #0.0
258250: fcsel s0, s13, s1, mi
258254: bl #0x22d48c
258258: fmaxnm s1, s9, s13
25825c: ldur q0, [x29, #-0x80]
258260: ldr d15, [sp, #0x78]
258264: ldr x1, [x20, #0x280]
258268: ldr s3, [sp, #0x88]
25826c: mov x0, x19
258270: fmul v0.2s, v0.2s, v1.s[0]
258274: fmul s1, s10, s1
258278: fminnm v0.2s, v0.2s, v15.2s
25827c: fminnm s2, s1, s11
258280: mov s1, v0.s[1]
258284: bl #0x22d238
258288: ldr w21, [x19, #0x524]
25828c: ldr w9, [x20, #0x1154]
258290: bic w8, w21, w21, asr #31
258294: tbnz w9, #0x1f, #0x2582a4
258298: cmp w8, w9
25829c: b.le #0x2582a4
2582a0: str s8, [x20, #0x114c]
2582a4: cmp w21, #0
2582a8: ldr x1, [x20, #0x288]
2582ac: mov x0, x19
2582b0: cset w2, gt
2582b4: str w8, [x20, #0x1154]
2582b8: bl #0x22ce80
2582bc: cmp w21, #1
2582c0: b.lt #0x2586d0
2582c4: ldrb w8, [x19, #0x528]
2582c8: ldr x9, [x20, #0x630]
2582cc: movi d0, #0000000000000000
2582d0: ldr x11, [x20, #0x628]
2582d4: fmov s1, #3.00000000
2582d8: ldr x1, [x20, #0x290]
2582dc: cmp w8, #0
2582e0: mov x0, x19
2582e4: cset w8, ne
2582e8: cmp x9, #0
2582ec: cset w10, ne
2582f0: tst w8, w10
2582f4: mov w8, #0x42280000
2582f8: csel x2, x9, x11, ne
2582fc: mov w9, #0x42380000
258300: fmov s2, w8
258304: fmov s3, w9
258308: fcsel s9, s1, s0, ne
25830c: fcsel s11, s3, s2, ne
258310: bl #0x22d40c
258314: fmov s0, s11
258318: fmov s1, s11
25831c: ldr x1, [x20, #0x290]
258320: mov x0, x19
258324: bl #0x22d77c
258328: ldr s0, [x20, #0x6d8]
25832c: ldr x1, [x20, #0x290]
258330: mov x0, x19
258334: fadd s1, s9, s0
258338: ldr s0, [x20, #0x6d4]
25833c: bl #0x22d590
258340: ldr w8, [x20, #0x1168]
258344: cmp w8, w21
258348: b.eq #0x258380
25834c: ldr x22, [x20, #0x298]
258350: sub x8, x29, #0x68
258354: mov w0, w21
258358: str w21, [x20, #0x1168]
25835c: bl #0x63b560
258360: sub x2, x29, #0x68
258364: mov x0, x19
258368: mov x1, x22
25836c: bl #0x22cfc0
258370: ldurb w8, [x29, #-0x68]
258374: tbz w8, #0, #0x258380
258378: ldur x0, [x29, #-0x58]
25837c: bl #0x6790c8
258380: mov w8, #-0x3db80000
258384: ldr s0, [x20, #0x114c]
258388: fmov s9, #1.00000000
25838c: fmov s1, w8
258390: fmov s12, #1.00000000
258394: fmov s14, #1.00000000
258398: fmov s11, #1.00000000
25839c: fcmp s0, s1
2583a0: b.le #0x258658
2583a4: fsub s0, s8, s0
2583a8: fcmp s0, #0.0
2583ac: b.mi #0x258658
2583b0: ldr s1, [x20, #0x1024]
2583b4: fcmp s1, #0.0
2583b8: b.le #0x258658
2583bc: ldr s2, [x20, #0x1028]
2583c0: movi d10, #0000000000000000
2583c4: fsub s0, s0, s2
2583c8: fcmp s0, #0.0
2583cc: b.mi #0x2583f8
2583d0: fdiv s0, s0, s1
2583d4: ldr w8, [x20, #0x1030]
2583d8: ldr s10, [sp, #0x80]
2583dc: cmp w8, #1
2583e0: b.lt #0x2583f0
2583e4: scvtf s1, w8
2583e8: fcmp s0, s1
2583ec: b.ge #0x258658
2583f0: frintm s1, s0
2583f4: fsub s10, s0, s1
2583f8: ldr w8, [x20, #0x1034]
2583fc: cbz w8, #0x25858c
258400: movi d12, #0000000000000000
258404: cmp w8, #1
258408: b.lt #0x258468
25840c: mov w9, #0x1064
258410: add x9, x20, x9
258414: b.eq #0x258470
258418: mov w10, #0x103c
25841c: add x11, x20, x10
258420: ldr s0, [x11]
258424: fcmp s0, s10
258428: b.ge #0x258470
25842c: mov w10, #0x1068
258430: mov x12, xzr
258434: sub x13, x8, #1
258438: add x10, x20, x10
25843c: mov x14, #0x100000000
258440: ldur s0, [x10, #-0x28]
258444: fcmp s0, s10
258448: b.pl #0x258478
25844c: subs x13, x13, #1
258450: add x12, x12, x14
258454: add x10, x10, #4
258458: b.ne #0x258440
25845c: add x9, x9, x8, lsl #2
258460: ldur s14, [x9, #-4]
258464: b #0x2584c4
258468: movi d14, #0000000000000000
25846c: b #0x25858c
258470: ldr s14, [x9]
258474: b #0x2584d0
258478: asr x8, x12, #0x1e
25847c: ldr s1, [x11, x8]
258480: mov w8, #0x37bd
258484: movk w8, #0x3586, lsl #16
258488: fsub s2, s0, s1
25848c: fmov s0, w8
258490: asr x8, x12, #0x20
258494: fcmp s2, s0
258498: fmov s0, #1.00000000
25849c: b.le #0x2584a8
2584a0: fsub s0, s10, s1
2584a4: fdiv s0, s0, s2
2584a8: ldr s13, [x9, x8, lsl #2]
2584ac: ldr s1, [x10]
2584b0: ldr w0, [x20, #0x102c]
2584b4: fsub s14, s1, s13
2584b8: bl #0x254534
2584bc: ldr w8, [x20, #0x1034]
2584c0: fmadd s14, s14, s0, s13
2584c4: cbz w8, #0x25853c
2584c8: cmp w8, #1
2584cc: b.lt #0x25858c
2584d0: mov w9, #0x108c
2584d4: cmp w8, #1
2584d8: add x9, x20, x9
2584dc: b.eq #0x258534
2584e0: ldr s0, [x20, #0x103c]
2584e4: fcmp s0, s10
2584e8: b.ge #0x258534
2584ec: mov w12, #0x103c
2584f0: mov w11, w8
2584f4: mov w8, #0x1090
2584f8: mov x10, xzr
2584fc: add x12, x20, x12
258500: add x8, x20, x8
258504: sub x13, x11, #1
258508: mov x14, #0x100000000
25850c: ldur s0, [x8, #-0x50]
258510: fcmp s0, s10
258514: b.pl #0x258544
258518: subs x13, x13, #1
25851c: add x10, x10, x14
258520: add x8, x8, #4
258524: b.ne #0x25850c
258528: add x8, x9, x11, lsl #2
25852c: ldur s12, [x8, #-4]
258530: b #0x25858c
258534: ldr s12, [x9]
258538: b #0x25858c
25853c: fmov s12, #1.00000000
258540: b #0x25858c
258544: asr x11, x10, #0x1e
258548: asr x10, x10, #0x20
25854c: ldr s1, [x12, x11]
258550: mov w11, #0x37bd
258554: movk w11, #0x3586, lsl #16
258558: fsub s2, s0, s1
25855c: fmov s0, w11
258560: fcmp s2, s0
258564: fmov s0, #1.00000000
258568: b.le #0x258574
25856c: fsub s0, s10, s1
258570: fdiv s0, s0, s2
258574: ldr s12, [x9, x10, lsl #2]
258578: ldr s1, [x8]
25857c: ldr w0, [x20, #0x102c]
258580: fsub s13, s1, s12
258584: bl #0x254534
258588: fmadd s12, s13, s0, s12
25858c: ldr w9, [x20, #0x1038]
258590: cbz w9, #0x258654
258594: cmp w9, #1
258598: b.lt #0x2585fc
25859c: mov w8, #0x1104
2585a0: cmp w9, #1
2585a4: add x8, x20, x8
2585a8: b.eq #0x258604
2585ac: mov w10, #0x10dc
2585b0: add x11, x20, x10
2585b4: ldr s0, [x11]
2585b8: fcmp s0, s10
2585bc: b.ge #0x258604
2585c0: mov w10, #0x1108
2585c4: mov x12, xzr
2585c8: sub x13, x9, #1
2585cc: add x10, x20, x10
2585d0: mov x14, #0x100000000
2585d4: ldur s0, [x10, #-0x28]
2585d8: fcmp s0, s10
2585dc: b.pl #0x25860c
2585e0: subs x13, x13, #1
2585e4: add x12, x12, x14
2585e8: add x10, x10, #4
2585ec: b.ne #0x2585d4
2585f0: add x8, x8, x9, lsl #2
2585f4: ldur s11, [x8, #-4]
2585f8: b #0x258654
2585fc: movi d11, #0000000000000000
258600: b #0x258654
258604: ldr s11, [x8]
258608: b #0x258654
25860c: asr x9, x12, #0x1e
258610: ldr s1, [x11, x9]
258614: mov w9, #0x37bd
258618: movk w9, #0x3586, lsl #16
25861c: fsub s2, s0, s1
258620: fmov s0, w9
258624: asr x9, x12, #0x20
258628: fcmp s2, s0
25862c: fmov s0, #1.00000000
258630: b.le #0x25863c
258634: fsub s0, s10, s1
258638: fdiv s0, s0, s2
25863c: ldr s10, [x8, x9, lsl #2]
258640: ldr s1, [x10]
258644: ldr w0, [x20, #0x102c]
258648: fsub s11, s1, s10
25864c: bl #0x254534
258650: fmadd s11, s11, s0, s10
258654: ldr s10, [sp, #0x80]
258658: movi d0, #0000000000000000
25865c: ldur q1, [x29, #-0x80]
258660: ldr x1, [x20, #0x290]
258664: mov x0, x19
258668: fmaxnm s0, s11, s0
25866c: fmul v1.2s, v1.2s, v0.s[0]
258670: fmul s0, s10, s0
258674: fminnm v1.2s, v1.2s, v15.2s
258678: fminnm s11, s0, s9
25867c: ldr s0, [sp, #0x88]
258680: fmul s14, s0, s14
258684: mov s13, v1.s[1]
258688: str q1, [sp, #0x50]
25868c: fmov s0, s1
258690: fmov s2, s11
258694: fmov s3, s14
258698: fmov s1, s13
25869c: bl #0x22d238
2586a0: fmov s1, s13
2586a4: fmov s2, s11
2586a8: ldr x1, [x20, #0x298]
2586ac: fmov s3, s14
2586b0: mov x0, x19
2586b4: ldr q0, [sp, #0x50]
2586b8: bl #0x22d238
2586bc: fmov s0, s12
2586c0: fmov s1, s12
2586c4: ldr x1, [x20, #0x288]
2586c8: mov x0, x19
2586cc: bl #0x22d830
2586d0: ldr w8, [x19, #0x53c]
2586d4: sub w8, w8, #1
2586d8: cmp w8, #2
2586dc: b.hs #0x258728
2586e0: ldr w21, [x19, #0x52c]
2586e4: ldr x1, [x20, #0x2a0]
2586e8: mov x0, x19
2586ec: mvn w8, w21
2586f0: lsr w2, w8, #0x1f
2586f4: bl #0x22ce80
2586f8: tbnz w21, #0x1f, #0x258738
2586fc: ldr w8, [x19, #0x538]
258700: ldr w9, [x20, #0x115c]
258704: cmp w8, w9
258708: b.ne #0x258744
25870c: ldr w10, [x20, #0x1158]
258710: ldr w9, [x19, #0x52c]
258714: tbnz w10, #0x1f, #0x258878
258718: cmp w9, w10
25871c: b.ge #0x258790
258720: str s8, [x20, #0x113c]
258724: b #0x258878
258728: ldr x1, [x20, #0x2a0]
25872c: mov x0, x19
258730: mov w2, wzr
258734: bl #0x22ce80
258738: movi v0.2d, #0xffffffffffffffff
25873c: str d0, [x20, #0x1158]
258740: b #0x258ffc
258744: sub w9, w8, #0x2a
258748: ldr x21, [x20, #0x2d0]
25874c: str s8, [x20, #0x1144]
258750: cmp w9, #0x17
258754: b.hi #0x2587b0
258758: mov w10, #1
25875c: mov w11, #0xd
258760: lsl w10, w10, w9
258764: tst w10, w11
258768: b.ne #0x258784
25876c: mov w11, #0xb00000
258770: tst w10, w11
258774: b.eq #0x25879c
258778: adrp x22, #0x6a7000
25877c: add x22, x22, #0x9a0
258780: b #0x2587cc
258784: adrp x22, #0x6a7000
258788: add x22, x22, #0x96f
25878c: b #0x2587cc
258790: b.le #0x258878
258794: str s8, [x20, #0x1148]
258798: b #0x258878
25879c: cmp w9, #0x16
2587a0: b.ne #0x2587b0
2587a4: adrp x22, #0x6bb000
2587a8: add x22, x22, #0xe97
2587ac: b #0x2587cc
2587b0: cmp w8, #0x23
2587b4: b.ne #0x2587c4
2587b8: adrp x22, #0x6a7000
2587bc: add x22, x22, #0x98b
2587c0: b #0x2587cc
2587c4: adrp x22, #0x6ce000
2587c8: add x22, x22, #0x830
2587cc: ldr x0, [x20, #0x638]
2587d0: cbz x0, #0x2587e0
2587d4: mov x1, x22
2587d8: bl #0x67f990
2587dc: cbz w0, #0x258838
2587e0: ldr x0, [x20, #0x648]
2587e4: cbz x0, #0x2587f4
2587e8: mov x1, x22
2587ec: bl #0x67f990
2587f0: cbz w0, #0x258840
2587f4: ldr x0, [x20, #0x658]
2587f8: cbz x0, #0x258808
2587fc: mov x1, x22
258800: bl #0x67f990
258804: cbz w0, #0x258848
258808: ldr x0, [x20, #0x668]
25880c: cbz x0, #0x25881c
258810: mov x1, x22
258814: bl #0x67f990
258818: cbz w0, #0x258850
25881c: ldr x0, [x20, #0x678]
258820: cbz x0, #0x258830
258824: mov x1, x22
258828: bl #0x67f990
25882c: cbz w0, #0x258858
258830: add x8, x20, #0x640
258834: b #0x258860
258838: add x8, x20, #0x638
25883c: b #0x25885c
258840: add x8, x20, #0x648
258844: b #0x25885c
258848: add x8, x20, #0x658
25884c: b #0x25885c
258850: add x8, x20, #0x668
258854: b #0x25885c
258858: add x8, x20, #0x678
25885c: add x8, x8, #8
258860: ldr x2, [x8]
258864: mov x0, x19
258868: mov x1, x21
25886c: bl #0x22d40c
258870: ldr w8, [x19, #0x538]
258874: ldr w9, [x19, #0x52c]
258878: mov w10, #-0x3db80000
25887c: ldr s1, [x20, #0x1144]
258880: str w8, [x20, #0x115c]
258884: fmov s0, w10
258888: str w9, [x20, #0x1158]
25888c: fcmp s1, s0
258890: fmov s0, #1.00000000
258894: b.le #0x2589a8
258898: fsub s1, s8, s1
25889c: fcmp s1, #0.0
2588a0: b.mi #0x2589a8
2588a4: ldr s2, [x20, #0xe14]
2588a8: fcmp s2, #0.0
2588ac: b.le #0x2589a8
2588b0: ldr s3, [x20, #0xe18]
2588b4: fsub s3, s1, s3
2588b8: movi d1, #0000000000000000
2588bc: fcmp s3, #0.0
2588c0: b.mi #0x2588e8
2588c4: fdiv s1, s3, s2
2588c8: ldr w8, [x20, #0xe20]
2588cc: cmp w8, #1
2588d0: b.lt #0x2588e0
2588d4: scvtf s2, w8
2588d8: fcmp s1, s2
2588dc: b.ge #0x2589a8
2588e0: frintm s2, s1
2588e4: fsub s1, s1, s2
2588e8: ldr w9, [x20, #0xe24]
2588ec: cbz w9, #0x2589a8
2588f0: cmp w9, #1
2588f4: b.lt #0x25894c
2588f8: cmp w9, #1
2588fc: add x8, x20, #0xe54
258900: b.eq #0x258954
258904: add x12, x20, #0xe2c
258908: ldr s0, [x12]
25890c: fcmp s0, s1
258910: b.ge #0x258954
258914: mov x11, xzr
258918: add x10, x20, #0xe58
25891c: sub x13, x9, #1
258920: mov x14, #0x100000000
258924: ldur s0, [x10, #-0x28]
258928: fcmp s0, s1
25892c: b.pl #0x25895c
258930: subs x13, x13, #1
258934: add x11, x11, x14
258938: add x10, x10, #4
25893c: b.ne #0x258924
258940: add x8, x8, x9, lsl #2
258944: ldur s0, [x8, #-4]
258948: b #0x2589a8
25894c: movi d0, #0000000000000000
258950: b #0x2589a8
258954: ldr s0, [x8]
258958: b #0x2589a8
25895c: asr x9, x11, #0x1e
258960: ldr s2, [x12, x9]
258964: mov w9, #0x37bd
258968: movk w9, #0x3586, lsl #16
25896c: fsub s3, s0, s2
258970: fmov s0, w9
258974: asr x9, x11, #0x20
258978: fcmp s3, s0
25897c: fmov s0, #1.00000000
258980: b.le #0x25898c
258984: fsub s0, s1, s2
258988: fdiv s0, s0, s3
25898c: ldr s9, [x8, x9, lsl #2]
258990: ldr s1, [x10]
258994: ldr w0, [x20, #0xe1c]
258998: fsub s10, s1, s9
25899c: bl #0x254534
2589a0: fmadd s0, s10, s0, s9
2589a4: ldr s10, [sp, #0x80]
2589a8: fmov s1, s0
2589ac: ldr x1, [x20, #0x2a0]
2589b0: mov x0, x19
2589b4: bl #0x22d830
2589b8: ldr w0, [x19, #0x52c]
2589bc: mov w21, wzr
2589c0: tbnz w0, #0x1f, #0x2589f0
2589c4: ldr w8, [x19, #0x530]
2589c8: cmp w8, #1
2589cc: b.lt #0x2589f0
2589d0: scvtf s0, w8
2589d4: mov w8, #0xcccd
2589d8: scvtf s2, w0
2589dc: movk w8, #0x3e4c, lsl #16
2589e0: fmov s1, w8
2589e4: fmul s0, s0, s1
2589e8: fcmp s0, s2
2589ec: cset w21, ge
2589f0: ldr w8, [x20, #0x116c]
2589f4: cmp w8, w0
2589f8: b.eq #0x258a2c
2589fc: ldr x22, [x20, #0x2b0]
258a00: sub x8, x29, #0x68
258a04: str w0, [x20, #0x116c]
258a08: bl #0x63b560
258a0c: sub x2, x29, #0x68
258a10: mov x0, x19
258a14: mov x1, x22
258a18: bl #0x22cfc0
258a1c: ldurb w8, [x29, #-0x68]
258a20: tbz w8, #0, #0x258a2c
258a24: ldur x0, [x29, #-0x58]
258a28: bl #0x6790c8
258a2c: ldr x1, [x20, #0x2a8]
258a30: mov x0, x19
258a34: mov w2, w21
258a38: bl #0x22ce80
258a3c: mov w8, #-0x3db80000
258a40: ldr s0, [x20, #0x113c]
258a44: ldur q3, [x29, #-0x80]
258a48: fmov s1, w8
258a4c: fcmp s0, s1
258a50: b.le #0x258a9c
258a54: fsub s1, s8, s0
258a58: fcmp s1, #0.0
258a5c: b.mi #0x258a9c
258a60: ldr s0, [x20, #0xc04]
258a64: fcmp s0, #0.0
258a68: b.le #0x258a9c
258a6c: ldr s2, [x20, #0xc08]
258a70: movi d9, #0000000000000000
258a74: fsub s1, s1, s2
258a78: fcmp s1, #0.0
258a7c: b.mi #0x258d6c
258a80: fdiv s0, s1, s0
258a84: ldr w8, [x20, #0xc10]
258a88: cmp w8, #1
258a8c: b.lt #0x258d64
258a90: scvtf s1, w8
258a94: fcmp s0, s1
258a98: b.lt #0x258d64
258a9c: fminnm v0.2s, v3.2s, v15.2s
258aa0: fmov s12, #1.00000000
258aa4: ldr x1, [x20, #0x2b0]
258aa8: ldr s3, [sp, #0x88]
258aac: mov x0, x19
258ab0: fminnm s2, s10, s12
258ab4: mov s1, v0.s[1]
258ab8: bl #0x22d238
258abc: movi d11, #0000000000000000
258ac0: movi d10, #0000000000000000
258ac4: ldr s0, [x20, #0x6c4]
258ac8: ldr s1, [x20, #0x6c8]
258acc: mov x0, x19
258ad0: ldr x1, [x20, #0x2b0]
258ad4: fadd s0, s11, s0
258ad8: fadd s1, s10, s1
258adc: bl #0x22d590
258ae0: fmov s0, s12
258ae4: fmov s1, s12
258ae8: ldr x1, [x20, #0x2b0]
258aec: mov x0, x19
258af0: bl #0x22d830
258af4: cbz w21, #0x258b4c
258af8: ldr w3, [x19, #0x52c]
258afc: mov x0, x20
258b00: mov x1, x19
258b04: mov w2, #2
258b08: bl #0x2592e4
258b0c: ldr s0, [x20, #0x1268]
258b10: ldr s1, [x20, #0x126c]
258b14: mov x0, x19
258b18: ldr x1, [x20, #0x2a8]
258b1c: fadd s0, s11, s0
258b20: fadd s1, s10, s1
258b24: bl #0x22d590
258b28: fmov s0, s12
258b2c: fmov s1, s12
258b30: ldr x1, [x20, #0x2a8]
258b34: mov x0, x19
258b38: bl #0x22d830
258b3c: ldr w8, [x19, #0x530]
258b40: cmp w8, #0
258b44: cset w2, gt
258b48: b #0x258b50
258b4c: mov w2, wzr
258b50: ldr x1, [x20, #0x1258]
258b54: ldr s9, [sp, #0x80]
258b58: mov x0, x19
258b5c: ldr s11, [sp, #0x6c]
258b60: bl #0x22ce80
258b64: ldr w8, [x19, #0x530]
258b68: ldr x1, [x20, #0x2b8]
258b6c: mov x0, x19
258b70: cmp w8, #0
258b74: cset w2, gt
258b78: bl #0x22ce80
258b7c: ldr w8, [x19, #0x530]
258b80: cmp w8, #1
258b84: b.lt #0x258bbc
258b88: ldr s0, [x19, #0x52c]
258b8c: scvtf s1, w8
258b90: movi d2, #0000000000000000
258b94: ldr x1, [x20, #0x2c0]
258b98: mov x0, x19
258b9c: scvtf s0, s0
258ba0: fdiv s0, s0, s1
258ba4: fmov s1, #1.00000000
258ba8: fcmp s0, s1
258bac: fcsel s1, s1, s0, gt
258bb0: fcmp s0, #0.0
258bb4: fcsel s0, s2, s1, mi
258bb8: bl #0x22d48c
258bbc: dup v0.2s, w21
258bc0: ldr d1, [x20, #0x688]
258bc4: ldur q2, [x29, #-0x80]
258bc8: cmp w21, #0
258bcc: ldr s3, [x20, #0x694]
258bd0: ldr x1, [x20, #0x2c0]
258bd4: mov x0, x19
258bd8: shl v0.2s, v0.2s, #0x1f
258bdc: cmlt v0.2s, v0.2s, #0
258be0: bsl v0.8b, v1.8b, v2.8b
258be4: ldr s1, [x20, #0x690]
258be8: fcsel s2, s1, s9, ne
258bec: ldr s1, [sp, #0x88]
258bf0: fcsel s3, s3, s1, ne
258bf4: mov s1, v0.s[1]
258bf8: bl #0x22d238
258bfc: ldr w0, [x19, #0x534]
258c00: ldr w8, [x20, #0x1170]
258c04: cmp w0, w8
258c08: b.eq #0x258c4c
258c0c: ldr x21, [x20, #0x2c8]
258c10: str w0, [x20, #0x1170]
258c14: tbnz w0, #0x1f, #0x258c24
258c18: sub x8, x29, #0x68
258c1c: bl #0x63b560
258c20: b #0x258c2c
258c24: stp xzr, xzr, [x29, #-0x68]
258c28: stur xzr, [x29, #-0x58]
258c2c: sub x2, x29, #0x68
258c30: mov x0, x19
258c34: mov x1, x21
258c38: bl #0x22cfc0
258c3c: ldurb w8, [x29, #-0x68]
258c40: tbz w8, #0, #0x258c4c
258c44: ldur x0, [x29, #-0x58]
258c48: bl #0x6790c8
258c4c: ldr s10, [sp, #0x88]
258c50: fmov s1, s11
258c54: fmov s2, s9
258c58: ldr x1, [x20, #0x2c8]
258c5c: mov x0, x19
258c60: ldur q0, [x29, #-0x80]
258c64: fmov s3, s10
258c68: bl #0x22d238
258c6c: fmov s1, s11
258c70: fmov s2, s9
258c74: ldr x1, [x20, #0x2d0]
258c78: fmov s3, s10
258c7c: mov x0, x19
258c80: ldur q0, [x29, #-0x80]
258c84: bl #0x22d238
258c88: mov w8, #-0x3db80000
258c8c: ldr s1, [x20, #0x1148]
258c90: movi d0, #0000000000000000
258c94: fmov s2, w8
258c98: fcmp s1, s2
258c9c: b.le #0x258fe4
258ca0: fsub s1, s8, s1
258ca4: fcmp s1, #0.0
258ca8: b.mi #0x258fe4
258cac: ldr s2, [x20, #0xf1c]
258cb0: fcmp s2, #0.0
258cb4: b.le #0x258fe4
258cb8: ldr s0, [x20, #0xf20]
258cbc: fsub s0, s1, s0
258cc0: movi d1, #0000000000000000
258cc4: fcmp s0, #0.0
258cc8: b.mi #0x258cf4
258ccc: fdiv s1, s0, s2
258cd0: ldr w8, [x20, #0xf28]
258cd4: cmp w8, #1
258cd8: b.lt #0x258cec
258cdc: scvtf s2, w8
258ce0: movi d0, #0000000000000000
258ce4: fcmp s1, s2
258ce8: b.ge #0x258fe4
258cec: frintm s0, s1
258cf0: fsub s1, s1, s0
258cf4: ldr w9, [x20, #0xf2c]
258cf8: cbz w9, #0x258d5c
258cfc: movi d0, #0000000000000000
258d00: cmp w9, #1
258d04: b.lt #0x258fe4
258d08: cmp w9, #1
258d0c: add x8, x20, #0xf5c
258d10: b.eq #0x258dec
258d14: add x12, x20, #0xf34
258d18: ldr s0, [x12]
258d1c: fcmp s0, s1
258d20: b.ge #0x258dec
258d24: mov x11, xzr
258d28: add x10, x20, #0xf60
258d2c: sub x13, x9, #1
258d30: mov x14, #0x100000000
258d34: ldur s0, [x10, #-0x28]
258d38: fcmp s0, s1
258d3c: b.pl #0x258f9c
258d40: subs x13, x13, #1
258d44: add x11, x11, x14
258d48: add x10, x10, #4
258d4c: b.ne #0x258d34
258d50: add x8, x8, x9, lsl #2
258d54: ldur s0, [x8, #-4]
258d58: b #0x258fe4
258d5c: movi d0, #0000000000000000
258d60: b #0x258fe4
258d64: frintm s1, s0
258d68: fsub s9, s0, s1
258d6c: fmov s12, #1.00000000
258d70: fmov s0, #1.00000000
258d74: ldr w9, [x20, #0xc18]
258d78: ldr x1, [x20, #0x2b0]
258d7c: cbz w9, #0x258e4c
258d80: cmp w9, #1
258d84: b.lt #0x258ddc
258d88: cmp w9, #1
258d8c: add x8, x20, #0xce4
258d90: b.eq #0x258de4
258d94: add x12, x20, #0xcbc
258d98: ldr s0, [x12]
258d9c: fcmp s0, s9
258da0: b.ge #0x258de4
258da4: mov x11, xzr
258da8: add x10, x20, #0xce8
258dac: sub x13, x9, #1
258db0: mov x14, #0x100000000
258db4: ldur s0, [x10, #-0x28]
258db8: fcmp s0, s9
258dbc: b.pl #0x258df4
258dc0: subs x13, x13, #1
258dc4: add x11, x11, x14
258dc8: add x10, x10, #4
258dcc: b.ne #0x258db4
258dd0: add x8, x8, x9, lsl #2
258dd4: ldur s0, [x8, #-4]
258dd8: b #0x258e4c
258ddc: movi d0, #0000000000000000
258de0: b #0x258e4c
258de4: ldr s0, [x8]
258de8: b #0x258e4c
258dec: ldr s0, [x8]
258df0: b #0x258fe4
258df4: asr x9, x11, #0x1e
258df8: mov x22, x1
258dfc: ldr s1, [x12, x9]
258e00: mov w9, #0x37bd
258e04: movk w9, #0x3586, lsl #16
258e08: fsub s2, s0, s1
258e0c: fmov s0, w9
258e10: asr x9, x11, #0x20
258e14: fcmp s2, s0
258e18: fmov s0, #1.00000000
258e1c: b.le #0x258e28
258e20: fsub s0, s9, s1
258e24: fdiv s0, s0, s2
258e28: ldr s10, [x8, x9, lsl #2]
258e2c: ldr s1, [x10]
258e30: ldr w0, [x20, #0xc0c]
258e34: fsub s11, s1, s10
258e38: bl #0x254534
258e3c: fmadd s0, s11, s0, s10
258e40: ldr s10, [sp, #0x80]
258e44: ldur q3, [x29, #-0x80]
258e48: mov x1, x22
258e4c: movi d11, #0000000000000000
258e50: mov x0, x19
258e54: fmaxnm s1, s0, s11
258e58: fmul v0.2s, v3.2s, v1.s[0]
258e5c: fmul s1, s10, s1
258e60: ldr s3, [sp, #0x88]
258e64: fminnm v0.2s, v0.2s, v15.2s
258e68: fminnm s2, s1, s12
258e6c: mov s1, v0.s[1]
258e70: bl #0x22d238
258e74: movi d10, #0000000000000000
258e78: ldr w8, [x20, #0xc14]
258e7c: cbz w8, #0x258ac4
258e80: cmp w8, #1
258e84: b.lt #0x258ed8
258e88: add x9, x20, #0xc94
258e8c: b.eq #0x258ee0
258e90: add x12, x20, #0xc1c
258e94: ldr s0, [x12]
258e98: fcmp s0, s9
258e9c: b.ge #0x258ee0
258ea0: mov x11, xzr
258ea4: add x10, x20, #0xc98
258ea8: sub x13, x8, #1
258eac: mov x14, #0x100000000
258eb0: ldur s0, [x10, #-0x78]
258eb4: fcmp s0, s9
258eb8: b.pl #0x258ee8
258ebc: subs x13, x13, #1
258ec0: add x11, x11, x14
258ec4: add x10, x10, #4
258ec8: b.ne #0x258eb0
258ecc: add x9, x9, x8, lsl #2
258ed0: ldur s12, [x9, #-4]
258ed4: b #0x258f34
258ed8: movi d12, #0000000000000000
258edc: b #0x258ac4
258ee0: ldr s12, [x9]
258ee4: b #0x258f3c
258ee8: asr x8, x11, #0x1e
258eec: ldr s1, [x12, x8]
258ef0: mov w8, #0x37bd
258ef4: movk w8, #0x3586, lsl #16
258ef8: fsub s2, s0, s1
258efc: fmov s0, w8
258f00: asr x8, x11, #0x20
258f04: fcmp s2, s0
258f08: fmov s0, #1.00000000
258f0c: b.le #0x258f18
258f10: fsub s0, s9, s1
258f14: fdiv s0, s0, s2
258f18: ldr s11, [x9, x8, lsl #2]
258f1c: ldr s1, [x10]
258f20: ldr w0, [x20, #0xc0c]
258f24: fsub s12, s1, s11
258f28: bl #0x254534
258f2c: ldr w8, [x20, #0xc14]
258f30: fmadd s12, s12, s0, s11
258f34: cmp w8, #1
258f38: b.lt #0x2590ec
258f3c: cmp w8, #1
258f40: add x22, x20, #0xc1c
258f44: add x9, x20, #0xc44
258f48: b.eq #0x258f94
258f4c: ldr s0, [x20, #0xc1c]
258f50: fcmp s0, s9
258f54: b.ge #0x258f94
258f58: mov w12, w8
258f5c: mov x11, xzr
258f60: add x10, x20, #0xc48
258f64: sub x13, x12, #1
258f68: mov x14, #0x100000000
258f6c: ldur s0, [x10, #-0x28]
258f70: fcmp s0, s9
258f74: b.pl #0x25903c
258f78: subs x13, x13, #1
258f7c: add x11, x11, x14
258f80: add x10, x10, #4
258f84: b.ne #0x258f6c
258f88: add x9, x9, x12, lsl #2
258f8c: ldur s11, [x9, #-4]
258f90: b #0x259088
258f94: ldr s11, [x9]
258f98: b #0x259090
258f9c: asr x9, x11, #0x1e
258fa0: ldr s2, [x12, x9]
258fa4: mov w9, #0x37bd
258fa8: movk w9, #0x3586, lsl #16
258fac: fsub s3, s0, s2
258fb0: fmov s0, w9
258fb4: asr x9, x11, #0x20
258fb8: fcmp s3, s0
258fbc: fmov s0, #1.00000000
258fc0: b.le #0x258fcc
258fc4: fsub s0, s1, s2
258fc8: fdiv s0, s0, s3
258fcc: ldr s8, [x8, x9, lsl #2]
258fd0: ldr s1, [x10]
258fd4: ldr w0, [x20, #0xf24]
258fd8: fsub s9, s1, s8
258fdc: bl #0x254534
258fe0: fmadd s0, s9, s0, s8
258fe4: ldr s1, [x20, #0x6d0]
258fe8: ldr x1, [x20, #0x2d0]
258fec: mov x0, x19
258ff0: fadd s1, s0, s1
258ff4: ldr s0, [x20, #0x6cc]
258ff8: bl #0x22d590
258ffc: ldr x8, [x27, #0x28]
259000: ldur x9, [x29, #-0x50]
259004: cmp x8, x9
259008: b.ne #0x259184
25900c: ldp x20, x19, [sp, #0x160]
259010: ldp x22, x21, [sp, #0x150]
259014: ldp x24, x23, [sp, #0x140]
259018: ldp x26, x25, [sp, #0x130]
25901c: ldp x28, x27, [sp, #0x120]
259020: ldp x29, x30, [sp, #0x110]
259024: ldp d9, d8, [sp, #0x100]
259028: ldp d11, d10, [sp, #0xf0]
25902c: ldp d13, d12, [sp, #0xe0]
259030: ldp d15, d14, [sp, #0xd0]
259034: add sp, sp, #0x170
259038: ret 
25903c: asr x8, x11, #0x1e
259040: ldr s1, [x22, x8]
259044: mov w8, #0x37bd
259048: movk w8, #0x3586, lsl #16
25904c: fsub s2, s0, s1
259050: fmov s0, w8
259054: asr x8, x11, #0x20
259058: fcmp s2, s0
25905c: fmov s0, #1.00000000
259060: b.le #0x25906c
259064: fsub s0, s9, s1
259068: fdiv s0, s0, s2
25906c: ldr s11, [x9, x8, lsl #2]
259070: ldr s1, [x10]
259074: ldr w0, [x20, #0xc0c]
259078: fsub s13, s1, s11
25907c: bl #0x254534
259080: ldr w8, [x20, #0xc14]
259084: fmadd s11, s13, s0, s11
259088: cmp w8, #1
25908c: b.lt #0x258ac4
259090: cmp w8, #1
259094: add x9, x20, #0xc6c
259098: b.eq #0x2590e4
25909c: ldr s0, [x20, #0xc1c]
2590a0: fcmp s0, s9
2590a4: b.ge #0x2590e4
2590a8: mov w11, w8
2590ac: mov x10, xzr
2590b0: add x8, x20, #0xc70
2590b4: sub x12, x11, #1
2590b8: mov x13, #0x100000000
2590bc: ldur s0, [x8, #-0x50]
2590c0: fcmp s0, s9
2590c4: b.pl #0x2590f4
2590c8: subs x12, x12, #1
2590cc: add x10, x10, x13
2590d0: add x8, x8, #4
2590d4: b.ne #0x2590bc
2590d8: add x8, x9, x11, lsl #2
2590dc: ldur s10, [x8, #-4]
2590e0: b #0x258ac4
2590e4: ldr s10, [x9]
2590e8: b #0x258ac4
2590ec: movi d11, #0000000000000000
2590f0: b #0x258ac4
2590f4: asr x11, x10, #0x1e
2590f8: asr x10, x10, #0x20
2590fc: ldr s1, [x22, x11]
259100: mov w11, #0x37bd
259104: movk w11, #0x3586, lsl #16
259108: fsub s2, s0, s1
25910c: fmov s0, w11
259110: fcmp s2, s0
259114: fmov s0, #1.00000000
259118: b.le #0x259124
25911c: fsub s0, s9, s1
259120: fdiv s0, s0, s2
259124: ldr s9, [x9, x10, lsl #2]
259128: ldr s1, [x8]
25912c: ldr w0, [x20, #0xc0c]
259130: fsub s10, s1, s9
259134: bl #0x254534
259138: fmadd s10, s10, s0, s9
25913c: b #0x258ac4
259140: b #0x259154
259144: b #0x259154
259148: b #0x259154
25914c: b #0x259154
259150: b #0x259154
259154: ldurb w8, [x29, #-0x68]
259158: mov x19, x0
25915c: tbz w8, #0, #0x259168
259160: ldur x0, [x29, #-0x58]
259164: bl #0x6790c8
259168: ldr x8, [sp, #0x70]
25916c: ldr x8, [x8, #0x28]
259170: ldur x9, [x29, #-0x50]
259174: cmp x8, x9
259178: b.ne #0x259184
25917c: mov x0, x19
259180: bl #0x67b74c
259184: bl #0x67f680

FUNCTION 0x259188
259188: stp x29, x30, [sp, #-0x50]!
25918c: stp x26, x25, [sp, #0x10]
259190: stp x24, x23, [sp, #0x20]
259194: stp x22, x21, [sp, #0x30]
259198: stp x20, x19, [sp, #0x40]
25919c: mov x29, sp
2591a0: mov x8, x1
2591a4: mov x19, x0
2591a8: add x1, x0, #0xf0
2591ac: mov x0, x8
2591b0: bl #0x22f5c4
2591b4: mov x23, #-0x10000
2591b8: add x24, x19, #0x2d8
2591bc: mov w21, #0x2d8
2591c0: mov w22, #-1
2591c4: movk x23, #0xc2c8, lsl #16
2591c8: b #0x259204
2591cc: str x26, [x24, #0x10]
2591d0: bl #0x6790c8
2591d4: movi v0.2d, #0000000000000000
2591d8: movi v1.2d, #0xffffffffffffffff
2591dc: add x21, x21, #0x80
2591e0: str wzr, [x24, #0x70]
2591e4: cmp x21, #0x5d8
2591e8: stur x23, [x24, #0x74]
2591ec: str d1, [x24, #0x48]
2591f0: stp q0, q0, [x24, #0x50]
2591f4: add x24, x19, x21
2591f8: stp q0, q0, [x25]
2591fc: stp q0, q0, [x25, #0x20]
259200: b.eq #0x259240
259204: mov x25, x24
259208: str w22, [x24]
25920c: ldr x26, [x25, #8]!
259210: cbz x26, #0x2591d4
259214: ldr x20, [x24, #0x10]
259218: mov x0, x26
25921c: cmp x20, x26
259220: b.eq #0x2591cc
259224: sub x20, x20, #0x120
259228: mov x0, x20
25922c: bl #0x215c38
259230: cmp x20, x26
259234: b.ne #0x259224
259238: ldr x0, [x25]
25923c: b #0x2591cc
259240: bl #0x28d784
259244: movi v0.2d, #0000000000000000
259248: str xzr, [x19, #0x1258]
25924c: str xzr, [x19, #0x1278]
259250: str xzr, [x19, #0x11f0]
259254: str q0, [x19, #0x11b0]
259258: str q0, [x19, #0x11c0]
25925c: str q0, [x19, #0x11d0]
259260: str q0, [x19, #0x11e0]
259264: stp q0, q0, [x19, #0x1f0]
259268: stp q0, q0, [x19, #0x210]
25926c: stp q0, q0, [x19, #0x230]
259270: stp q0, q0, [x19, #0x250]
259274: stp q0, q0, [x19, #0x270]
259278: stp q0, q0, [x19, #0x290]
25927c: stp q0, q0, [x19, #0x2b0]
259280: str xzr, [x19, #0x2d0]
259284: ldp x20, x19, [sp, #0x40]
259288: ldp x22, x21, [sp, #0x30]
25928c: ldp x24, x23, [sp, #0x20]
259290: ldp x26, x25, [sp, #0x10]
259294: ldp x29, x30, [sp], #0x50
259298: ret 

FUNCTION 0x23e3e0
23e3e0: sub sp, sp, #0xf0
23e3e4: stp x29, x30, [sp, #0x90]
23e3e8: str x27, [sp, #0xa0]
23e3ec: stp x26, x25, [sp, #0xb0]
23e3f0: stp x24, x23, [sp, #0xc0]
23e3f4: stp x22, x21, [sp, #0xd0]
23e3f8: stp x20, x19, [sp, #0xe0]
23e3fc: add x29, sp, #0x90
23e400: mrs x22, tpidr_el0
23e404: adrp x23, #0x6a5e000
23e408: ldr x8, [x22, #0x28]
23e40c: stur x8, [x29, #-8]
23e410: ldrb w8, [x23, #0x534]
23e414: cbnz w8, #0x23e958
23e418: adrp x0, #0x6c5000
23e41c: add x0, x0, #0x3df
23e420: mov w1, #8
23e424: bl #0x23d394
23e428: adrp x8, #0x682000
23e42c: ldr q0, [x8, #0x900]
23e430: cbz x0, #0x23e468
23e434: ldr w8, [x0, #8]
23e438: cmp w8, #3
23e43c: b.lt #0x23e468
23e440: ldur d0, [x0, #0xc]
23e444: ldr s1, [x0, #0x14]
23e448: cmp w8, #3
23e44c: mov v0.s[2], v1.s[0]
23e450: b.ne #0x23e460
23e454: fmov s1, #1.00000000
23e458: mov v0.s[3], v1.s[0]
23e45c: b #0x23e468
23e460: add x8, x0, #0x18
23e464: ld1 {v0.s}[3], [x8]
23e468: adrp x8, #0x6a5e000
23e46c: add x8, x8, #0x538
23e470: adrp x0, #0x6c1000
23e474: add x0, x0, #0x5f3
23e478: mov w1, #7
23e47c: str q0, [x8]
23e480: bl #0x23d394
23e484: adrp x19, #0x682000
23e488: ldr q0, [x19, #0xbd0]
23e48c: cbz x0, #0x23e4c4
23e490: ldr w8, [x0, #8]
23e494: cmp w8, #3
23e498: b.lt #0x23e4c4
23e49c: ldur d0, [x0, #0xc]
23e4a0: ldr s1, [x0, #0x14]
23e4a4: cmp w8, #3
23e4a8: mov v0.s[2], v1.s[0]
23e4ac: b.ne #0x23e4bc
23e4b0: fmov s1, #1.00000000
23e4b4: mov v0.s[3], v1.s[0]
23e4b8: b #0x23e4c4
23e4bc: add x8, x0, #0x18
23e4c0: ld1 {v0.s}[3], [x8]
23e4c4: adrp x8, #0x6a5e000
23e4c8: add x8, x8, #0x548
23e4cc: adrp x0, #0x6f3000
23e4d0: add x0, x0, #0x39f
23e4d4: mov w1, #0xd
23e4d8: str q0, [x8]
23e4dc: bl #0x23d394
23e4e0: adrp x8, #0x681000
23e4e4: ldr q0, [x8, #0xb00]
23e4e8: cbz x0, #0x23e520
23e4ec: ldr w8, [x0, #8]
23e4f0: cmp w8, #3
23e4f4: b.lt #0x23e520
23e4f8: ldur d0, [x0, #0xc]
23e4fc: ldr s1, [x0, #0x14]
23e500: cmp w8, #3
23e504: mov v0.s[2], v1.s[0]
23e508: b.ne #0x23e518
23e50c: fmov s1, #1.00000000
23e510: mov v0.s[3], v1.s[0]
23e514: b #0x23e520
23e518: add x8, x0, #0x18
23e51c: ld1 {v0.s}[3], [x8]
23e520: adrp x8, #0x6a5e000
23e524: add x8, x8, #0x558
23e528: adrp x0, #0x689000
23e52c: add x0, x0, #0x9f5
23e530: mov w1, #0xc
23e534: str q0, [x8]
23e538: bl #0x23d394
23e53c: adrp x8, #0x681000
23e540: ldr q0, [x8, #0xf0]
23e544: cbz x0, #0x23e57c
23e548: ldr w8, [x0, #8]
23e54c: cmp w8, #3
23e550: b.lt #0x23e57c
23e554: ldur d0, [x0, #0xc]
23e558: ldr s1, [x0, #0x14]
23e55c: cmp w8, #3
23e560: mov v0.s[2], v1.s[0]
23e564: b.ne #0x23e574
23e568: fmov s1, #1.00000000
23e56c: mov v0.s[3], v1.s[0]
23e570: b #0x23e57c
23e574: add x8, x0, #0x18
23e578: ld1 {v0.s}[3], [x8]
23e57c: adrp x8, #0x6a5e000
23e580: add x8, x8, #0x568
23e584: adrp x0, #0x6d0000
23e588: add x0, x0, #0x201
23e58c: mov w1, #0xc
23e590: str q0, [x8]
23e594: bl #0x23d394
23e598: adrp x8, #0x682000
23e59c: ldr q0, [x8, #0xa60]
23e5a0: cbz x0, #0x23e5d8
23e5a4: ldr w8, [x0, #8]
23e5a8: cmp w8, #3
23e5ac: b.lt #0x23e5d8
23e5b0: ldur d0, [x0, #0xc]
23e5b4: ldr s1, [x0, #0x14]
23e5b8: cmp w8, #3
23e5bc: mov v0.s[2], v1.s[0]
23e5c0: b.ne #0x23e5d0
23e5c4: fmov s1, #1.00000000
23e5c8: mov v0.s[3], v1.s[0]
23e5cc: b #0x23e5d8
23e5d0: add x8, x0, #0x18
23e5d4: ld1 {v0.s}[3], [x8]
23e5d8: adrp x8, #0x6a5e000
23e5dc: add x8, x8, #0x578
23e5e0: adrp x0, #0x6a9000
23e5e4: add x0, x0, #0xa78
23e5e8: mov w1, #0xb
23e5ec: str q0, [x8]
23e5f0: bl #0x23d394
23e5f4: ldr q0, [x19, #0xbd0]
23e5f8: cbz x0, #0x23e630
23e5fc: ldr w8, [x0, #8]
23e600: cmp w8, #3
23e604: b.lt #0x23e630
23e608: ldur d0, [x0, #0xc]
23e60c: ldr s1, [x0, #0x14]
23e610: cmp w8, #3
23e614: mov v0.s[2], v1.s[0]
23e618: b.ne #0x23e628
23e61c: fmov s1, #1.00000000
23e620: mov v0.s[3], v1.s[0]
23e624: b #0x23e630
23e628: add x8, x0, #0x18
23e62c: ld1 {v0.s}[3], [x8]
23e630: adrp x8, #0x6a5e000
23e634: add x8, x8, #0x588
23e638: adrp x0, #0x6a5000
23e63c: add x0, x0, #0xce6
23e640: mov w1, #0xd
23e644: str q0, [x8]
23e648: bl #0x23d394
23e64c: adrp x8, #0x683000
23e650: ldr q0, [x8]
23e654: cbz x0, #0x23e68c
23e658: ldr w8, [x0, #8]
23e65c: cmp w8, #3
23e660: b.lt #0x23e68c
23e664: ldur d0, [x0, #0xc]
23e668: ldr s1, [x0, #0x14]
23e66c: cmp w8, #3
23e670: mov v0.s[2], v1.s[0]
23e674: b.ne #0x23e684
23e678: fmov s1, #1.00000000
23e67c: mov v0.s[3], v1.s[0]
23e680: b #0x23e68c
23e684: add x8, x0, #0x18
23e688: ld1 {v0.s}[3], [x8]
23e68c: adrp x8, #0x6a5e000
23e690: add x8, x8, #0x598
23e694: adrp x0, #0x685000
23e698: add x0, x0, #0x31e
23e69c: mov w1, #0xd
23e6a0: str q0, [x8]
23e6a4: bl #0x23d394
23e6a8: adrp x8, #0x683000
23e6ac: ldr q0, [x8, #0x10]
23e6b0: cbz x0, #0x23e6e8
23e6b4: ldr w8, [x0, #8]
23e6b8: cmp w8, #3
23e6bc: b.lt #0x23e6e8
23e6c0: ldur d0, [x0, #0xc]
23e6c4: ldr s1, [x0, #0x14]
23e6c8: cmp w8, #3
23e6cc: mov v0.s[2], v1.s[0]
23e6d0: b.ne #0x23e6e0
23e6d4: fmov s1, #1.00000000
23e6d8: mov v0.s[3], v1.s[0]
23e6dc: b #0x23e6e8
23e6e0: add x8, x0, #0x18
23e6e4: ld1 {v0.s}[3], [x8]
23e6e8: adrp x8, #0x6a5e000
23e6ec: add x8, x8, #0x5a8
23e6f0: adrp x0, #0x6f3000
23e6f4: add x0, x0, #0x3ad
23e6f8: mov w1, #0xc
23e6fc: str q0, [x8]
23e700: bl #0x23d394
23e704: adrp x8, #0x682000
23e708: ldr q0, [x8, #0x620]
23e70c: cbz x0, #0x23e744
23e710: ldr w8, [x0, #8]
23e714: cmp w8, #3
23e718: b.lt #0x23e744
23e71c: ldur d0, [x0, #0xc]
23e720: ldr s1, [x0, #0x14]
23e724: cmp w8, #3
23e728: mov v0.s[2], v1.s[0]
23e72c: b.ne #0x23e73c
23e730: fmov s1, #1.00000000
23e734: mov v0.s[3], v1.s[0]
23e738: b #0x23e744
23e73c: add x8, x0, #0x18
23e740: ld1 {v0.s}[3], [x8]
23e744: adrp x8, #0x6a5e000
23e748: add x8, x8, #0x5b8
23e74c: mov w9, #0x437f0000
23e750: str q0, [x8]
23e754: dup v0.4s, w9
23e758: add x8, sp, #0x30
23e75c: mov x21, xzr
23e760: adrp x19, #0x6cc000
23e764: add x19, x19, #0x9e3
23e768: adrp x25, #0x2980000
23e76c: add x25, x25, #0x550
23e770: orr x26, x8, #1
23e774: adrp x24, #0x6a5e000
23e778: add x24, x24, #0x534
23e77c: str q0, [sp]
23e780: b #0x23e790
23e784: add x21, x21, #1
23e788: cmp x21, #0xb
23e78c: b.eq #0x23e854
23e790: add x8, sp, #0x30
23e794: add w1, w21, #1
23e798: mov x0, x19
23e79c: bl #0x23d78c
23e7a0: ldrb w8, [sp, #0x30]
23e7a4: ldr x10, [sp, #0x40]
23e7a8: add x9, x25, x21, lsl #2
23e7ac: tst w8, #1
23e7b0: ldr w27, [x9, #4]
23e7b4: csel x20, x26, x10, eq
23e7b8: mov x0, x20
23e7bc: bl #0x67f6f0
23e7c0: mov x1, x0
23e7c4: mov x0, x20
23e7c8: bl #0x23d394
23e7cc: fmov s0, w27
23e7d0: lsr w8, w27, #0x10
23e7d4: movi v2.2d, #0x0000ff000000ff
23e7d8: ushr v1.4s, v0.4s, #0x18
23e7dc: mov v0.s[1], w8
23e7e0: lsr w8, w27, #8
23e7e4: mov v0.s[2], w8
23e7e8: mov v0.s[3], w27
23e7ec: and v0.16b, v0.16b, v2.16b
23e7f0: mov v0.s[0], v1.s[0]
23e7f4: ldr q1, [sp]
23e7f8: ucvtf v0.4s, v0.4s
23e7fc: fdiv v0.4s, v0.4s, v1.4s
23e800: cbz x0, #0x23e838
23e804: ldr w8, [x0, #8]
23e808: cmp w8, #3
23e80c: b.lt #0x23e838
23e810: ldur d0, [x0, #0xc]
23e814: ldr s1, [x0, #0x14]
23e818: cmp w8, #3
23e81c: mov v0.s[2], v1.s[0]
23e820: b.ne #0x23e830
23e824: fmov s1, #1.00000000
23e828: mov v0.s[3], v1.s[0]
23e82c: b #0x23e838
23e830: add x8, x0, #0x18
23e834: ld1 {v0.s}[3], [x8]
23e838: add x8, x24, x21, lsl #4
23e83c: ldrb w9, [sp, #0x30]
23e840: stur q0, [x8, #0xa4]
23e844: tbz w9, #0, #0x23e784
23e848: ldr x0, [sp, #0x40]
23e84c: bl #0x6790c8
23e850: b #0x23e784
23e854: adrp x8, #0x681000
23e858: adrp x9, #0x680000
23e85c: mov x19, xzr
23e860: ldr q0, [x8, #0xcb0]
23e864: adrp x8, #0x681000
23e868: ldr q1, [x9, #0x7f0]
23e86c: adrp x9, #0x681000
23e870: ldr q2, [x8, #0x850]
23e874: adrp x8, #0x682000
23e878: stp q0, q1, [sp, #0x30]
23e87c: ldr q0, [x9, #0x630]
23e880: ldr q1, [x8, #0xed0]
23e884: add x8, sp, #0x18
23e888: adrp x20, #0x6d8000
23e88c: add x20, x20, #0x1ff
23e890: orr x25, x8, #1
23e894: add x26, sp, #0x30
23e898: stp q2, q0, [sp, #0x50]
23e89c: str q1, [sp, #0x70]
23e8a0: b #0x23e8b0
23e8a4: add x19, x19, #1
23e8a8: cmp x19, #5
23e8ac: b.eq #0x23e950
23e8b0: add x8, sp, #0x18
23e8b4: mov x0, x20
23e8b8: mov w1, w19
23e8bc: bl #0x23d78c
23e8c0: ldrb w8, [sp, #0x18]
23e8c4: ldr x9, [sp, #0x28]
23e8c8: ldr q0, [x26, x19, lsl #4]
23e8cc: tst w8, #1
23e8d0: str q0, [sp]
23e8d4: csel x21, x25, x9, eq
23e8d8: mov x0, x21
23e8dc: bl #0x67f6f0
23e8e0: mov x1, x0
23e8e4: mov x0, x21
23e8e8: bl #0x23d394
23e8ec: cbz x0, #0x23e920
23e8f0: ldr w8, [x0, #8]
23e8f4: ldr q1, [sp]
23e8f8: cmp w8, #3
23e8fc: b.lt #0x23e930
23e900: ldur d1, [x0, #0xc]
23e904: ldr s0, [x0, #0x14]
23e908: cmp w8, #3
23e90c: mov v1.s[2], v0.s[0]
23e910: b.ne #0x23e928
23e914: fmov s0, #1.00000000
23e918: mov v1.s[3], v0.s[0]
23e91c: b #0x23e930
23e920: ldr q1, [sp]
23e924: b #0x23e930
23e928: add x8, x0, #0x18
23e92c: ld1 {v1.s}[3], [x8]
23e930: add x8, x24, x19, lsl #4
23e934: ldrb w9, [sp, #0x18]
23e938: add x8, x8, #0x154
23e93c: str q1, [x8]
23e940: tbz w9, #0, #0x23e8a4
23e944: ldr x0, [sp, #0x28]
23e948: bl #0x6790c8
23e94c: b #0x23e8a4
23e950: mov w8, #1
23e954: strb w8, [x23, #0x534]
23e958: ldr x8, [x22, #0x28]
23e95c: ldur x9, [x29, #-8]
23e960: cmp x8, x9
23e964: b.ne #0x23e9c8
23e968: ldp x20, x19, [sp, #0xe0]
23e96c: ldr x27, [sp, #0xa0]
23e970: ldp x22, x21, [sp, #0xd0]
23e974: ldp x24, x23, [sp, #0xc0]
23e978: ldp x26, x25, [sp, #0xb0]
23e97c: ldp x29, x30, [sp, #0x90]
23e980: add sp, sp, #0xf0
23e984: ret 
23e988: ldrb w8, [sp, #0x18]
23e98c: mov x19, x0
23e990: tbz w8, #0, #0x23e9b0
23e994: ldr x0, [sp, #0x28]
23e998: b #0x23e9ac
23e99c: ldrb w8, [sp, #0x30]
23e9a0: mov x19, x0
23e9a4: tbz w8, #0, #0x23e9b0
23e9a8: ldr x0, [sp, #0x40]
23e9ac: bl #0x6790c8
23e9b0: ldr x8, [x22, #0x28]
23e9b4: ldur x9, [x29, #-8]
23e9b8: cmp x8, x9
23e9bc: b.ne #0x23e9c8
23e9c0: mov x0, x19
23e9c4: bl #0x67b74c
23e9c8: bl #0x67f680
