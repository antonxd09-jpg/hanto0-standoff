typedef struct st_23e358_0 {
    char padding_0[1288];
    unsigned int field_508;
    char padding_50c[12];
    unsigned int field_518;
} st_23e358_0;

double sub_23e358(void)
{
    st_23e358_0 *v2;  // x0
    unsigned long v3;  // x19
    uint128_t *v4;  // x8
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    v2 = sub_236d98();
    v3 = v2->field_508;
    if (10 >= (unsigned int)v3 - 1)
    {
        sub_23e3e0();
        return (long long)*(int128_t *)(111535412 + v3 * 16 + 148);
    }
    sub_23e3e0();
    if (v2->field_518 == 1)
    {
        v4 = 0x6a5e548;
    }
    else if (v2->field_518 == 2)
    {
        v4 = 0x6a5e538;
    }
    else
    {
        return 0x3f8000003f800000;
    }
    return (unsigned long long)*v4;
}
