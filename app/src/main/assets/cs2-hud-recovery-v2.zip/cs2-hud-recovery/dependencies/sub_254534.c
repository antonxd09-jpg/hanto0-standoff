float sub_254534(int a0, float a1)
{
    float v0;  // s1
    unsigned long long v1;  // 4130
    float v10;  // s21
    float v11;  // s20
    float v12;  // s16
    float v13;  // s19
    float v14;  // s16
    float v15;  // s17
    float v16;  // s18
    unsigned long long v18;  // 4271
    float v19;  // s16
    float v2;  // s1
    unsigned long long v20;  // 4225
    unsigned long long v21;  // 4176
    unsigned long v22;  // cc_dep1
    unsigned long long v23;  // 4112
    unsigned long long v24;  // 4112
    unsigned long long v25;  // 4112
    unsigned long long v26;  // 4108
    unsigned long long v27;  // 4112
    unsigned long long v28;  // 4108
    float v29;  // s2
    unsigned long long v3;  // 4129
    float v30;  // s6
    unsigned int v31;  // w8
    unsigned int v32;  // w8
    float v33;  // s16
    float v34;  // s17
    float v35;  // s21
    unsigned long long v37;  // 4271
    unsigned long long v38;  // 4110
    unsigned long v39;  // cc_dep1
    unsigned long long v4;  // 4130
    unsigned long long v40;  // 4129
    unsigned long long v41;  // 4106
    unsigned long long v42;  // 4106
    float v43;  // s1
    float v44;  // s2
    unsigned long long v45;  // 4130
    unsigned long long v46;  // 4126
    unsigned long long v47;  // 4125
    unsigned int v48;  // w8
    float v49;  // s0
    unsigned long long v5;  // 4126
    unsigned int v50;  // w8
    float v51;  // s21
    float v52;  // s19
    float v53;  // s16
    float v54;  // s20
    float v55;  // s16
    float v56;  // s17
    float v57;  // s18
    unsigned long long v59;  // 4258
    unsigned long long v6;  // 4125
    float v60;  // s16
    unsigned long long v61;  // 4225
    unsigned long long v62;  // 4176
    unsigned long v63;  // cc_dep1
    unsigned long long v64;  // 4112
    unsigned long long v65;  // 4112
    unsigned long long v66;  // 4112
    unsigned long long v67;  // 4108
    unsigned long long v68;  // 4112
    unsigned long long v69;  // 4108
    unsigned int v7;  // w8
    float v70;  // s2
    float v71;  // s6
    unsigned int v72;  // w8
    unsigned int v73;  // w8
    float v74;  // s16
    float v75;  // s17
    float v76;  // s20
    unsigned long long v78;  // 4258
    unsigned long long v79;  // 4110
    float v8;  // s0
    unsigned long v80;  // cc_dep1
    unsigned long long v81;  // 4129
    unsigned long long v82;  // 4106
    unsigned long long v83;  // 4106
    float v84;  // s1
    float v85;  // s2
    unsigned int v9;  // w8

    v0 = 1.0f;
    v1 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(a1), 1.0f)) >> 5 & 3 | a1 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(a1)) * 0x10000000, 0, 0);
    if (!(v1 & 1))
        v0 = a1;
    v2 = v0;
    v3 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(a1), 0.0f)) >> 5 & 3 | a1 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(a1)) * 0x10000000, 0, 0);
    if (v3 & 1)
        v2 = 0;
    if (a0 > 2)
    {
        if (a0 == 3)
        {
            sub_254a74();
            return v2;
        }
        else if (a0 != 4)
        {
            if (a0 == 5)
            {
                v4 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v2), 0.0f)) >> 5 & 3 | v2 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
                if (v4 & 1)
                    v2 = 0;
                v5 = arm64g_calculate_condition(144, (((((char)(CmpF(__float_as_int(v2), 0.0f)) >> 5 & 3 | v2 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
                if (v5 & 1)
                    return 0;
                v6 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v2), 0x3f800000)) >> 5 & 3 | v2 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
                if (v6 & 1)
                    return 1.0;
                v7 = 7;
                v8 = v2;
                while (1)
                {
                    v9 = v7;
                    v10 = 1.0f - v8;
                    v11 = v8 * v8;
                    v12 = v10 * 3.0f;
                    v13 = v10 * v12;
                    v14 = v8 * v8 * v12;
                    v15 = v8 * v13;
                    v16 = v11 * v8 + v15 * 0.8999999761581421f + v14 * 0.10000000149011612f;
                    v18 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v16 - v2)), 9.999999747378752e-06f)) >> 5 & 3 | fabsf(v16 - v2) < 9.999999747378752e-06f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v16 - v2))) * 0x10000000, 0, 0);
                    if (v18 & 1)
                        break;
                    v19 = v8 * v8 * 3.0f * 0.8999999761581421f + v13 * 0.8999999761581421f + v8 * v10 * 6.0f * -0.7999999523162842f;
                    v20 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v19)), 9.999999974752427e-07f)) >> 5 & 3 | fabsf(v19) < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v19))) * 0x10000000, 0, 0);
                    if (v20 & 1)
                    {
LABEL_25465c:
                        v29 = 0;
                        v30 = 1.0f;
                        v31 = 40;
                        v8 = v2;
                        while (1)
                        {
                            v32 = v31;
                            v33 = 1.0f - v8;
                            v34 = v33 * 3.0f;
                            v14 = v8 * v8 * v34;
                            v15 = v8 * v33 * v34;
                            v11 = v8 * v8;
                            v35 = v11 * v8 + v15 * 0.8999999761581421f + v14 * 0.10000000149011612f;
                            v37 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v35 - v2)), 9.999999747378752e-06f)) >> 5 & 3 | fabsf(v35 - v2) < 9.999999747378752e-06f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v35 - v2))) * 0x10000000, 0, 0);
                            if (v37 & 1)
                                break;
                            v38 = (isunordered(v35, v2) ? 2 : v35 == v2 ? 2 : 0) | v35 < v2;
                            v39 = (((v38 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v35, v2)) * 0x10000000;
                            v40 = arm64g_calculate_condition(64, (((v38 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v35, v2)) * 0x10000000, 0, 0);
                            if (v40 & 1)
                            {
                                v29 = v8;
                                v41 = arm64g_calculate_condition(64, v39, 0, 0);
                                if (!(v41 & 1))
                                    goto LABEL_2546da;
                                goto LABEL_2546d9;
                            }
                            else
                            {
                                v29 = v29;
                                v42 = arm64g_calculate_condition(64, v39, 0, 0);
                                if (v42 & 1)
                                {
LABEL_2546d9:
                                    goto LABEL_2546dc;
                                }
                                else
                                {
LABEL_2546da:
                                    v30 = v8;
LABEL_2546dc:
                                    v31 = v32 - 1;
                                    v8 = (v29 + v30) * 0.5f;
                                    if (v32 == 1)
                                    {
                                        v11 = v8 * v8;
                                        v43 = 1.0f - v8;
                                        v44 = v43 * 3.0f;
                                        v15 = v8 * v43 * v44;
                                        v14 = v8 * v8 * v44;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    v8 -= (v16 - v2) / v19;
                    v21 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v8), 0.0f)) >> 5 & 3 | v8 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v8)) * 0x10000000, 0, 0);
                    if (v21 & 1)
                    {
                        v22 = (((((isnan(v8) ? 2 : v8 == 1.0f ? 2 : 0) | v8 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v8)) * 0x10000000;
                        v23 = arm64g_calculate_condition(208, v22, 0, 0);
                        if (!(v23 & 1))
                            goto LABEL_254652;
                        goto LABEL_254651;
                    }
                    else
                    {
                        v22 = 0;
                        v24 = arm64g_calculate_condition(208, 0, 0, 0);
                        if (v24 & 1)
                        {
LABEL_254651:
                            v25 = arm64g_calculate_condition(208, v22, 0, 0);
                            v7 = v9 - 1;
                            v26 = arm64g_calculate_condition(19, (v25 & 1 ? v9 : 0x40000000), 0, 0);
                            if (v26 & 1)
                                continue;
                            goto LABEL_25465c;
                        }
                        else
                        {
LABEL_254652:
                            v27 = arm64g_calculate_condition(208, v22, 0, 0);
                            v7 = v9 - 1;
                            v28 = arm64g_calculate_condition(16, (v27 & 1 ? v9 : 0x40000000), 0, 0);
                            if (!(v28 & 1))
                                goto LABEL_25465c;
                        }
                    }
                }
                return v11 * v8 + v15 * 0.009999999776482582f + v14;
            }
            else
            {
                return v2;
            }
        }
    }
    else
    {
        if (a0 != 1)
        {
            if (a0 != 2)
                return v2;
            v45 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v2), 0.0f)) >> 5 & 3 | v2 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
            if (v45 & 1)
                v2 = 0;
            v46 = arm64g_calculate_condition(144, (((((char)(CmpF(__float_as_int(v2), 0.0f)) >> 5 & 3 | v2 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
            if (v46 & 1)
                return 0;
            v47 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v2), 0x3f800000)) >> 5 & 3 | v2 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
            if (v47 & 1)
                return 1.0;
            v48 = 7;
            v49 = v2;
            while (1)
            {
                v50 = v48;
                v51 = 1.0f - v49;
                v52 = v49 * v49;
                v53 = v51 * 3.0f;
                v54 = v51 * v53;
                v55 = v49 * v54;
                v56 = v49 * v49 * v53;
                v57 = v52 * v49 + v55 * 0.41999998688697815f + v56;
                v59 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v57 - v2)), 9.999999747378752e-06f)) >> 5 & 3 | fabsf(v57 - v2) < 9.999999747378752e-06f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v57 - v2))) * 0x10000000, 0, 0);
                if (v59 & 1)
                    break;
                v60 = v49 * v49 * 3.0f * 0.0f + v54 * 0.41999998688697815f + v49 * v51 * 6.0f * 0.5800000429153442f;
                v61 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v60)), 9.999999974752427e-07f)) >> 5 & 3 | fabsf(v60) < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v60))) * 0x10000000, 0, 0);
                if (v61 & 1)
                {
LABEL_25481c:
                    v70 = 0;
                    v71 = 1.0f;
                    v72 = 40;
                    v49 = v2;
                    while (1)
                    {
                        v73 = v72;
                        v74 = 1.0f - v49;
                        v52 = v49 * v49;
                        v75 = v74 * 3.0f;
                        v55 = v49 * v74 * v75;
                        v56 = v49 * v49 * v75;
                        v76 = v52 * v49 + v55 * 0.41999998688697815f + v56;
                        v78 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v76 - v2)), 9.999999747378752e-06f)) >> 5 & 3 | fabsf(v76 - v2) < 9.999999747378752e-06f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v76 - v2))) * 0x10000000, 0, 0);
                        if (v78 & 1)
                            break;
                        v79 = (isunordered(v76, v2) ? 2 : v76 == v2 ? 2 : 0) | v76 < v2;
                        v80 = (((v79 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v76, v2)) * 0x10000000;
                        v81 = arm64g_calculate_condition(64, (((v79 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v76, v2)) * 0x10000000, 0, 0);
                        if (v81 & 1)
                        {
                            v70 = v49;
                            v82 = arm64g_calculate_condition(64, v80, 0, 0);
                            if (!(v82 & 1))
                                goto LABEL_25488a;
                            goto LABEL_254889;
                        }
                        else
                        {
                            v70 = v70;
                            v83 = arm64g_calculate_condition(64, v80, 0, 0);
                            if (v83 & 1)
                            {
LABEL_254889:
                                goto LABEL_25488c;
                            }
                            else
                            {
LABEL_25488a:
                                v71 = v49;
LABEL_25488c:
                                v72 = v73 - 1;
                                v49 = (v70 + v71) * 0.5f;
                                if (v73 == 1)
                                {
                                    v52 = v49 * v49;
                                    v84 = 1.0f - v49;
                                    v85 = v84 * 3.0f;
                                    v55 = v49 * v84 * v85;
                                    v56 = v49 * v49 * v85;
                                    break;
                                }
                            }
                        }
                    }
                }
                v49 -= (v57 - v2) / v60;
                v62 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v49), 0.0f)) >> 5 & 3 | v49 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v49)) * 0x10000000, 0, 0);
                if (v62 & 1)
                {
                    v63 = (((((isnan(v49) ? 2 : v49 == 1.0f ? 2 : 0) | v49 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v49)) * 0x10000000;
                    v64 = arm64g_calculate_condition(208, v63, 0, 0);
                    if (!(v64 & 1))
                        goto LABEL_254812;
                    goto LABEL_254811;
                }
                else
                {
                    v63 = 0;
                    v65 = arm64g_calculate_condition(208, 0, 0, 0);
                    if (v65 & 1)
                    {
LABEL_254811:
                        v66 = arm64g_calculate_condition(208, v63, 0, 0);
                        v48 = v50 - 1;
                        v67 = arm64g_calculate_condition(19, (v66 & 1 ? v50 : 0x40000000), 0, 0);
                        if (v67 & 1)
                            continue;
                        goto LABEL_25481c;
                    }
                    else
                    {
LABEL_254812:
                        v68 = arm64g_calculate_condition(208, v63, 0, 0);
                        v48 = v50 - 1;
                        v69 = arm64g_calculate_condition(16, (v68 & 1 ? v50 : 0x40000000), 0, 0);
                        if (!(v69 & 1))
                            goto LABEL_25481c;
                    }
                }
            }
            return v52 * v49 + v55 * 0.0f + v56;
        }
    }
}
