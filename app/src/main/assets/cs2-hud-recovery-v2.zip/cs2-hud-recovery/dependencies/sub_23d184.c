typedef struct st_22ab5c_0 {
    char padding_0[120];
    unsigned long long field_78;
} st_22ab5c_0;

typedef struct st_23d184_1 {
    unsigned long long field_0;
    long long field_8;
} st_23d184_1;

typedef struct st_23d184_0 {
    char padding_0[8];
    struct st_22ab5c_0 *field_8;
    char padding_10[1080];
    unsigned long long field_448;
    unsigned long long field_450;
} st_23d184_0;

long long sub_23d184(long long a0, long long a1)
{
    st_23d184_0 *v2;  // x21
    st_22ab5c_0 *v3;  // x0
    unsigned long long v4;  // x0
    long long v5;  // x9
    st_23d184_1 *v6;  // x8
    long long v7;  // x8
    char *v0;  // [bp-0x30]
    char v1;  // [bp+0x0]

    v0 = &v1;
    v2 = sub_236d98();
    v3 = v2->field_8;
    if (!v3)
        return v3;
    v4 = sub_22ab5c(v3, a0, a1);
    if (!(v4 >> 31 & 1))
    {
        v5 = v4 & 0xffffffff;
        if ((long long)(v2->field_450 - v2->field_448) >> 4 > (unsigned long long)v5)
        {
            v6 = v2->field_448 + v5 * 16;
            v7 = v6->field_8;
            if (!v6->field_0)
                v7 = 0;
            if (!(sub_198128(v7) & 1))
                v7 = 0;
            return v7;
        }
    }
    else
    {
        sub_23cef8(6905786, 6, a0, a1);
    }
    return 0;
}
