typedef struct st_22f5c4_0 {
    long long field_0;
    unsigned long long field_8;
    long long field_10;
    unsigned long long field_18;
    long long field_20;
    long long field_28;
    long long field_30;
    unsigned long long field_38;
    long long field_40;
    unsigned long long field_48;
    long long field_50;
    long long field_58;
    long long field_60;
    unsigned long long field_68;
    char *field_70;
    struct st_22f5c4_1 *field_78;
    char padding_80[48];
    unsigned long long field_b0;
    unsigned long long field_b8;
} st_22f5c4_0;

typedef struct st_22f5c4_2 {
    char padding_0[344];
    struct st_22f5c4_3 *field_158;
} st_22f5c4_2;

typedef struct st_22f5c4_1 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
    long long *field_20;
    long long *field_28;
} st_22f5c4_1;

typedef struct st_22f5c4_3 {
    unsigned long long field_0;
} st_22f5c4_3;

unsigned long long sub_22f5c4(st_22f5c4_2 *a0, st_22f5c4_0 *a1)
{
    char *iter;  // x22
    char *v3;  // x23
    long long v12;  // x0
    long long v13;  // x20
    long long v14;  // x0
    long long v15;  // x0
    long long v16;  // x0
    long long v17;  // x0
    long long v18;  // x0
    long long v19;  // x0
    unsigned long long v20;  // x0
    long long v4;  // x21
    unsigned long long v5;  // x0
    long long *node;  // x24
    long long v7;  // x21
    char *j;  // x20
    long long v9;  // x8
    long long v10;  // x9
    long long v11;  // x20
    char *v0;  // [bp-0x50]
    char v1;  // [bp+0x0]

    v0 = &v1;
    iter = a1->field_70;
    v3 = &a1->field_78->padding_0[0];
    if (iter != v3)
    {
        do
        {
            if (!*(long long *)&iter[16])
                v4 = 0;
            else
                v4 = *(long long *)&iter[24];
            if (sub_198128(v4) & 1 && v4)
                sub_198eac(v4);
            v5 = *(long long *)&iter[16];
            *(long long *)&iter[24] = 0;
            if (v5)
            {
                *(unsigned long long *)&iter[16] = 0;
                sub_439c54(v5);
            }
            for (node = *(long long *)&iter[32]; node != *(long long *)&iter[40]; node += 2)
            {
                if (!*node)
                    v7 = 0;
                else
                    v7 = node[1];
                if (sub_198128(v7) & 1 && v7)
                    a0->field_158();
            }
            iter += 56;
        } while (iter != v3);
        iter = a1->field_70;
        j = &a1->field_78->padding_0[0];
        if (a1->field_78 != iter)
        {
            do
            {
                j -= 56;
                sub_215afc(j);
            } while (j != iter);
        }
    }
    v9 = a1->field_20;
    v10 = a1->field_28;
    a1->field_78 = iter;
    if (!v9)
        v11 = 0;
    else
        v11 = v10;
    if (sub_198128(v11) & 1 && v11)
        sub_198eac(v11);
    v12 = a1->field_20;
    a1->field_28 = 0;
    if (v12)
    {
        a1->field_20 = 0;
        sub_439c54(v12);
    }
    if (!a1->field_50)
        v13 = 0;
    else
        v13 = a1->field_58;
    if (sub_198128(v13) & 1 && v13)
        sub_198eac(v13);
    v14 = a1->field_50;
    a1->field_58 = 0;
    if (v14)
    {
        a1->field_50 = 0;
        sub_439c54(v14);
    }
    v15 = a1->field_30;
    a1->field_38 = 0;
    if (v15)
    {
        a1->field_30 = 0;
        sub_439c54(v15);
    }
    v16 = a1->field_40;
    a1->field_48 = 0;
    if (v16)
    {
        a1->field_40 = 0;
        sub_439c54(v16);
    }
    v17 = a1->field_60;
    a1->field_68 = 0;
    if (v17)
    {
        a1->field_60 = 0;
        sub_439c54(v17);
    }
    v18 = a1->field_10;
    a1->field_18 = 0;
    if (v18)
    {
        a1->field_10 = 0;
        sub_439c54(v18);
    }
    v19 = a1->field_0;
    a1->field_8 = 0;
    if (v19)
    {
        a1->field_0 = 0;
        sub_439c54(v19);
    }
    v20 = a1->field_b0;
    a1->field_b8 = 0;
    if (!v20)
        return 0;
    a1->field_b0 = 0;
    return sub_439c54();
}
