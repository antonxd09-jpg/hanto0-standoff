typedef struct st_22a7d8_0 {
    unsigned int field_0;
    char padding_4[4];
    unsigned long long field_8;
    unsigned long long field_10;
} st_22a7d8_0;

unsigned long long * sub_22a7d8(st_22a7d8_0 *a0, unsigned long a1)
{
    unsigned long v0;  // x9
    unsigned long long v1;  // x9
    unsigned int v2;  // w10
    unsigned long v3;  // cc_dep1
    unsigned long v4;  // cc_dep2
    unsigned long long *v5;  // x8
    unsigned long long v6;  // 4110
    unsigned long long v7;  // 4104
    unsigned long long v8;  // 4110
    unsigned long long v9;  // 4104

    v0 = a0->field_0;
    if (v0 >> 31 & 1)
        return NULL;
    v1 = a1 - v0;
    if (v1 >> 31 & 1)
        return NULL;
    v2 = 954437177 * (unsigned int)(a0->field_10 - a0->field_8 >> 5);
    v3 = v1 & 0xffffffff;
    v4 = v2;
    if ((int)v2 <= (int)v1)
        return NULL;
    v5 = a0->field_8 + (unsigned int)v1 * 288;
    if (v5[1])
    {
        v6 = arm64g_calculate_condition(19, v3, v4, 0);
        v7 = arm64g_calculate_condition(4, (v6 & 1 ? *v5 : 0x40000000), 0, 0);
        if (!(v7 & 1))
            return v5;
    }
    else
    {
        v8 = arm64g_calculate_condition(19, v3, v4, 0);
        v9 = arm64g_calculate_condition(0, (v8 & 1 ? *v5 : 0x40000000), 0, 0);
        if (!(v9 & 1))
            return v5;
    }
    return NULL;
}
