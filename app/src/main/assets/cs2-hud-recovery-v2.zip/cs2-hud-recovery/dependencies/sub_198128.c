long long sub_198128(long long a0)
{
    char *v0;  // [bp-0x30]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (!a0)
        return a0;
    /* unsupported instruction */;
    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
    {
        sub_1269d0(123377504);
        6813216();
        sub_65eed8(123388920);
    }
    if (!(sub_139354(123377576, a0, 24) & 1))
        return 0;
    /* unsupported instruction */;
    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
    {
        sub_1269d0(123377504);
        6813216();
        sub_65eed8(123388920);
    }
    if (sub_139354(123377576, *(short *)0x75aa1d8 + a0, 8) & 1)
        return *(long long *)(*(short *)0x75aa1d8 + a0) != 0;
    return 0;
}
