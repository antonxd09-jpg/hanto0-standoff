typedef struct st_22d40c_0 {
    char padding_0[32];
    unsigned long long field_20;
    long long field_28;
    char padding_30[152];
    unsigned long long field_c8;
    char padding_d0[8];
    char field_d8;
} st_22d40c_0;

typedef struct st_22d40c_1 {
    char padding_0[384];
    struct st_22d40c_2 *field_180;
} st_22d40c_1;

typedef struct st_22d40c_2 {
    unsigned long long field_0;
} st_22d40c_2;

void sub_22d40c(st_22d40c_1 *a0, st_22d40c_0 *a1, unsigned long a2)
{
    unsigned long long v7;  // x30
    unsigned long long v8;  // x22
    unsigned long long v9;  // x21
    unsigned long long v10;  // x20
    unsigned long long v11;  // x19
    long long v12;  // x9
    char *v0;  // [bp-0x30]
    unsigned long long v1;  // [bp-0x28]
    unsigned long long v2;  // [bp-0x20]
    unsigned long long v3;  // [bp-0x18]
    unsigned long long v4;  // [bp-0x10]
    unsigned long long v5;  // [bp-0x8]
    char v6;  // [bp+0x0]

    if (!a1)
        return;
    v0 = &v6;
    v1 = v7;
    v2 = v8;
    v3 = v9;
    v4 = v10;
    v5 = v11;
    if (!a1->field_d8 || a1->field_c8 != a2)
    {
        v12 = a1->field_28;
        if (!a1->field_20)
            v12 = 0;
        if (sub_198128(v12) & 1 && v12)
            a0->field_180();
    }
    return;
}
