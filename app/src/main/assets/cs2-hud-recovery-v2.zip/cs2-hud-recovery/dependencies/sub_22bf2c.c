typedef struct st_22bf2c_2 {
    long long field_0;
    unsigned int field_8;
    unsigned int field_c;
    char padding_10[72];
    int field_58;
    int field_5c;
    int field_60;
    unsigned int field_64;
    int field_68;
    int field_6c;
    int field_70;
    unsigned int field_74;
    int field_78;
    char field_7c;
} st_22bf2c_2;

typedef struct st_22bf2c_7 {
    char padding_0[112];
    long long field_70;
    unsigned long long field_78;
} st_22bf2c_7;

typedef struct st_215c38_0 {
    long long field_0;
    unsigned long long field_8;
    long long field_10;
    unsigned long long field_18;
    long long field_20;
    unsigned long long field_28;
    long long field_30;
    unsigned long long field_38;
    long long field_40;
    unsigned long long field_48;
    long long field_50;
    unsigned long long field_58;
    long long field_60;
    unsigned long long field_68;
    long long field_70;
    unsigned long long field_78;
    char padding_80[8];
    char field_88;
    char padding_89[15];
    long long field_98;
} st_215c38_0;

typedef struct st_22bf2c_1 {
    unsigned int field_0;
    char padding_4[4];
    struct st_215c38_0 *field_8;
    struct st_215c38_0 *field_10;
} st_22bf2c_1;

typedef struct st_22bf2c_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_22bf2c_0;

typedef struct st_22bf2c_5 {
    unsigned long long field_0;
} st_22bf2c_5;

typedef struct st_22bf2c_3 {
    char padding_0[8];
    struct st_22bf2c_4 *field_8;
    char padding_10[8];
    unsigned long long field_18;
    char padding_20[8];
    struct st_22bf2c_5 *field_28;
    struct st_22bf2c_4 *field_30;
    char padding_38[24];
    struct st_22bf2c_4 *field_50;
} st_22bf2c_3;

typedef struct st_22bf2c_6 {
    char padding_0[8];
    struct st_22bf2c_3 *field_8;
    long long field_10;
    long long field_18;
    long long field_20;
    char padding_28[24];
    long long field_40;
    long long field_48;
    long long field_50;
    char padding_58[16];
    long long field_68;
    char padding_70[32];
    long long field_90;
    char padding_98[16];
    struct st_22bf2c_5 *field_a8;
    char padding_b0[56];
    struct st_22bf2c_5 *field_e8;
    char padding_f0[104];
    struct st_22bf2c_5 *field_158;
    char padding_160[24];
    struct st_22bf2c_5 *field_178;
    char padding_180[256];
    long long field_280;
    struct st_22bf2c_5 *field_288;
    char padding_290[32];
    struct st_22bf2c_5 *field_2b0;
    char padding_2b8[8];
    struct st_22bf2c_5 *field_2c0;
    char padding_2c8[48];
    struct st_22bf2c_5 *field_2f8;
    char padding_300[56];
    struct st_22bf2c_5 *field_338;
    char padding_340[8];
    struct st_22bf2c_5 *field_348;
    char padding_350[24];
    struct st_22bf2c_5 *field_368;
    struct st_22bf2c_5 *field_370;
} st_22bf2c_6;

typedef struct st_22bf2c_4 {
    char field_0;
} st_22bf2c_4;

unsigned int sub_22bf2c(st_22bf2c_6 *a0, int a1, unsigned long long a2, st_22bf2c_1 *a3, unsigned long a4, unsigned long a5, unsigned int a6, unsigned int a7)
{
    st_22bf2c_0 *v14;  // tpidr_el0
    unsigned long i;  // x23
    int v24;  // w23
    unsigned long long v25;  // x0
    unsigned long v26;  // x8
    unsigned long long v27;  // x10
    st_22bf2c_2 *v28;  // x19
    st_215c38_0 *v29;  // x11
    unsigned long v30;  // x9
    unsigned long long v31;  // x9
    st_215c38_0 *v32;  // x12
    unsigned long long *v33;  // x10
    st_22bf2c_3 *v16;  // x19
    unsigned long long v34;  // x9
    unsigned long long *v35;  // x25
    unsigned long long v36;  // x10
    st_22bf2c_2 *v37;  // x22
    unsigned long v38;  // x8
    long long v39;  // x26
    long long *v40;  // x24
    unsigned long long *v41;  // x27
    unsigned long long *v42;  // x27
    long long v43;  // x8
    st_215c38_0 *j;  // x22
    unsigned long long v44;  // x0
    long long v45;  // x0
    long long v46;  // x26
    long long *v47;  // x24
    unsigned long long *v48;  // x27
    unsigned long long *v49;  // x27
    long long v50;  // x8
    unsigned long long v51;  // x0
    long long v52;  // x0
    st_22bf2c_2 *v53;  // x22
    unsigned long long v18;  // x10
    long long v54;  // x26
    long long *v55;  // x24
    unsigned long long *v56;  // x27
    unsigned long long *v57;  // x27
    long long v58;  // x8
    unsigned long long v59;  // x0
    long long v60;  // x0
    unsigned long v61;  // x8
    unsigned long long v62;  // x26
    char *v63;  // x24
    unsigned long long v19;  // x8
    long long v65;  // x26
    unsigned long long v66;  // x0
    long long v67;  // x25
    long long *v68;  // x27
    unsigned long long *v69;  // x28
    unsigned long long *v70;  // x28
    long long v71;  // x8
    unsigned long long v72;  // x0
    long long v73;  // x0
    unsigned long long v20;  // 4102
    long long v74;  // x25
    long long *v75;  // x27
    unsigned long long *v76;  // x28
    unsigned long long *v77;  // x28
    long long v78;  // x8
    unsigned long long v79;  // x0
    long long v80;  // x0
    unsigned long long v81;  // x0
    st_22bf2c_7 *v82;  // x24
    unsigned long long *v83;  // x26
    unsigned long v21;  // x19
    unsigned long long *v84;  // x26
    unsigned long long v85;  // x8
    unsigned long long v86;  // x22
    long long v87;  // x8
    unsigned long v89;  // x19
    unsigned long v90;  // x23
    unsigned long long v91;  // x24
    unsigned long v92;  // x8
    unsigned long long v93;  // x27
    int v22;  // w22
    st_215c38_0 *v94;  // x28
    unsigned long long *v95;  // x8
    unsigned long v23;  // x8
    unsigned long long v0;  // [bp-0x130]
    unsigned long long *v1;  // [bp-0x120]
    unsigned long v2;  // [bp-0x118]
    unsigned long long v3;  // [bp-0x110]
    unsigned long long v4;  // [bp-0x108]
    unsigned long long v5;  // [bp-0xf8]
    unsigned long long v6;  // [bp-0xf0]
    st_215c38_0 *v7;  // [bp-0xe8]
    st_22bf2c_3 *v8;  // [bp-0xe0]
    long long v9;  // [bp-0xd0], Other Possible Types: unsigned long long
    unsigned long long v10;  // [bp-0xc8], Other Possible Types: long long
    unsigned long v11;  // [bp-0x80]
    char *v12;  // [bp-0x60]
    char v13;  // [bp+0x0]

    v12 = &v13;
    v0 = a2;
    v11 = v14->field_28;
    sub_67b3a0(1, 123935948);
    i = a3->field_10;
    v16 = a0->field_8;
    j = a3->field_8;
    v1 = &a3->field_8;
    a3->field_0 = a1;
    if (i != j)
    {
        do
        {
            i -= 288;
            sub_215c38(i);
        } while (i != j);
        i = *v1;
    }
    a3->field_10 = j;
    v18 = 10248191152060862009 * ((char *)j - i >> 5);
    v19 = *(int *)&v16->field_8[12 + 128 * a1] - a1;
    if (v19 > v18)
    {
        sub_23183c(v1);
    }
    else
    {
        v20 = arm64g_calculate_condition(36, v19, v18, 0);
        if (!(v20 & 1))
        {
            v21 = i + 288 * v19;
            if (j != v21)
            {
                do
                {
                    j = (char *)j - 288;
                    sub_215c38(j);
                } while (j != v21);
            }
            a3->field_10 = v21;
        }
    }
    v22 = a1;
    v23 = *(int *)&v16->field_8[12 + 128 * a1];
    if ((int)v23 > v22)
    {
        v8 = v16;
        v3 = a4 + a5 * 4;
        v4 = (long long)(a5 * 4) >> 63 & 0xc000000000000000 | a5 & 0x3fffffffffffffff;
        v24 = v22;
        do
        {
            v25 = 0x67f820();
            v26 = v24;
            if (!v25)
                v27 = v3;
            else
                v27 = v25;
            v28 = &v16->field_8[128 * v26];
            if (v27 != v3)
            {
                v24 = v28->field_c - 1;
                continue;
            }
            v29 = *v1;
            v7 = *v1;
            if (v24 == v22)
            {
LABEL_22c0f8:
                v34 = v26 - a1;
                v35 = (char *)v29 + 288 * v34;
                v6 = v34;
                if (!(sub_22b63c(a0, v28->field_0) & 1))
                {
                    sub_67b3a0(0xffffffff, 123935948);
                    if (v14->field_28 == v11)
                        return 0;
                    6813312();
                }
                v36 = v35[1];
                v37 = v28;
                if (!*v35)
                    v36 = 0;
                v38 = *(long long *)((char *)v7 + 288 * v6 + 24);
                v5 = v36;
                if (!*(long long *)((char *)v29 + 288 * v6 + 16))
                    v38 = 0;
                v2 = v38;
                if (v37->field_58 >= 0)
                {
                    v39 = sub_199d38(v5, a0->field_10);
                    if (v39)
                    {
                        v40 = (char *)v7 + 288 * v6;
                        v41 = v40 + 4;
                        v42 = v41 + 1;
                        if (!v40[4])
                            v43 = 0;
                        else
                            v43 = v41[1];
                        if (v43 != v39)
                        {
                            v44 = sub_439970(v39);
                            if (v44)
                            {
                                v45 = *v41;
                                *v42 = 0;
                                if (v45)
                                {
                                    *v41 = 0;
                                    sub_439c54(v45);
                                }
                                *v41 = v44;
                                *v42 = v39;
                            }
                            else
                            {
                                sub_67b3a0(0xffffffff, 123935948);
                                if (v14->field_28 == v11)
                                    return 0;
                                6813312();
                            }
                        }
                        sub_22bd8c(a0, v39, v8->field_18 + v37->field_58 * 52, v35);
                    }
                    else
                    {
                        sub_67b3a0(0xffffffff, 123935948);
                        if (v14->field_28 == v11)
                            return 0;
                        6813312();
                    }
                }
                if (v28->field_5c >= 0)
                {
                    v46 = sub_199d38(v5, a0->field_18);
                    if (v46)
                    {
                        v47 = (char *)v7 + 288 * v6;
                        v48 = v47 + 6;
                        v49 = v48 + 1;
                        if (!v47[6])
                            v50 = 0;
                        else
                            v50 = v48[1];
                        if (v50 != v46)
                        {
                            v51 = sub_439970(v46);
                            if (v51)
                            {
                                v52 = *v48;
                                *v49 = 0;
                                if (v52)
                                {
                                    *v48 = 0;
                                    sub_439c54(v52);
                                }
                                *v48 = v51;
                                *v49 = v46;
                            }
                            else
                            {
                                sub_67b3a0(0xffffffff, 123935948);
                                if (v14->field_28 == v11)
                                    return 0;
                                6813312();
                            }
                        }
                        a0->field_178();
                    }
                    else
                    {
                        sub_67b3a0(0xffffffff, 123935948);
                        if (v14->field_28 == v11)
                            return 0;
                        6813312();
                    }
                }
                v53 = v28;
                if (v53->field_60 >= 0)
                {
                    v54 = sub_199d38(v5, a0->field_20);
                    if (v54)
                    {
                        v55 = (char *)v7 + 288 * v6;
                        v56 = v55 + 8;
                        v57 = v56 + 1;
                        if (!v55[8])
                            v58 = 0;
                        else
                            v58 = v56[1];
                        if (v58 != v54)
                        {
                            v59 = sub_439970(v54);
                            if (v59)
                            {
                                v60 = *v56;
                                *v57 = 0;
                                if (v60)
                                {
                                    *v56 = 0;
                                    sub_439c54(v60);
                                }
                                *v56 = v59;
                                *v57 = v54;
                            }
                            else
                            {
                                sub_67b3a0(0xffffffff, 123935948);
                                if (v14->field_28 == v11)
                                    return 0;
                                6813312();
                            }
                        }
                        v8->field_28();
                    }
                    else
                    {
                        sub_67b3a0(0xffffffff, 123935948);
                        if (v14->field_28 == v11)
                            return 0;
                        6813312();
                    }
                }
                v61 = v28->field_74;
                if (!(v61 >> 31 & 1))
                {
                    v62 = v61 * 3;
                    v63 = v8->field_50;
                    if (sub_199d38())
                    {
                        if (!v63[v62])
                        {
                            a0->field_368();
                        }
                        else if (!v63[2 + v62])
                        {
                            a0->field_158();
                        }
                    }
                }
                if (v28->field_78 >= 0 && v53->field_60 < 0 && sub_199d38(v5, a0->field_68))
                    a0->field_370();
                if (!(v28->field_64 >> 31 & 1) && sub_199d38())
                {
                    v9 = 0;
                    v10 = 0;
                    /* unsupported instruction */;
                    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
                    {
                        sub_1269d0(123377504);
                        6813216();
                        sub_65eed8(123388920);
                    }
                    v65 = sub_43cd6c(123377512, a0->field_90);
                    if (!v65)
                        a0->field_2c0();
                    if (!v9)
                        v10 = 0;
                    if (v10 != v65)
                    {
                        v66 = sub_439970(v65);
                        if (!v66)
                            a0->field_2c0();
                        v10 = 0;
                        if (v9)
                        {
                            v9 = 0;
                            sub_439c54(v9);
                        }
                        v9 = v66;
                        v10 = v65;
                    }
                    a0->field_2b0();
                }
                if (v28->field_68 >= 0 && (v67 = sub_199d38(v5, a0->field_40), v67))
                {
                    v68 = (char *)v7 + 288 * v6;
                    v69 = v68 + 12;
                    v70 = v69 + 1;
                    if (!v68[12])
                        v71 = 0;
                    else
                        v71 = v69[1];
                    if (v71 != v67)
                    {
                        v72 = sub_439970(v67);
                        if (!v72)
                            goto LABEL_22c7a4;
                        v73 = *v69;
                        *v70 = 0;
                        if (v73)
                        {
                            *v69 = 0;
                            sub_439c54(v73);
                        }
                        *v69 = v72;
                        *v70 = v67;
                    }
                    a0->field_2f8();
                }
                else
                {
LABEL_22c7a4:
                    if (v28->field_6c >= 0 && sub_199d38(v5, a0->field_48))
                        a0->field_338();
                    if (v28->field_70 >= 0 && (v74 = sub_199d38(v5, a0->field_50), v74))
                    {
                        v75 = (char *)v7 + 288 * v6;
                        v76 = v75 + 10;
                        v77 = v76 + 1;
                        if (!v75[10])
                            v78 = 0;
                        else
                            v78 = v76[1];
                        if (v78 != v74)
                        {
                            v79 = sub_439970(v74);
                            if (!v79)
                                goto LABEL_22c920;
                            v80 = *v76;
                            *v77 = 0;
                            if (v80)
                            {
                                *v76 = 0;
                                sub_439c54(v80);
                            }
                            *v76 = v79;
                            *v77 = v74;
                        }
                        a0->field_348();
                    }
                    else
                    {
LABEL_22c920:
                        if (a7 & 1 && v28->field_7c)
                        {
                            v81 = sub_199d38(v5, a0->field_280);
                            if (v81)
                            {
                                v82 = (char *)v7 + 288 * v6;
                                v83 = &v82->field_70;
                                v84 = v83 + 1;
                                if (!v82->field_70)
                                    v85 = 0;
                                else
                                    v85 = v83[1];
                                if (v85 != v81)
                                {
                                    v86 = sub_439970();
                                    if (!v86)
                                        a0->field_e8();
                                    v87 = *v83;
                                    *v84 = 0;
                                    if (v87)
                                    {
                                        *v83 = 0;
                                        sub_439c54(v87);
                                    }
                                    *v83 = v86;
                                    *v84 = v81;
                                }
                                a0->field_288();
                            }
                        }
                        a0->field_e8();
                    }
                }
            }
            else
            {
                v30 = a3->field_0;
                if (!(v30 >> 31 & 1) && (v31 = v28->field_8 - v30, !(v31 >> 31 & 1) && (v32 = v7, (int)((unsigned int)(a3->field_10 - v32 >> 5) * 954437177) > (int)v31 && (v33 = (char *)v32 + (unsigned int)v31 * 288, *v33 && v33[1]))))
                {
                    v29 = v7;
                    goto LABEL_22c0f8;
                }
            }
        } while ((v16 = v8, v24 += 1, v23 = *(int *)&v16->field_8[12 + 128 * a1], (int)v23 > v24));
    }
    if ((int)v23 > v22)
    {
        v8 = v16;
        v89 = (int)v23;
        v90 = (unsigned int)v23 - 1;
        v91 = ((long long)(v23 * 0x100000000) >> 63 & 0xffffff8000000000 | __ROL__(v23, 7) & 0x7fffffff80 & 0x7fffffffff) - 112;
        do
        {
            v92 = a3->field_0;
            if (!(v92 >> 31 & 1))
            {
                v93 = v90 - v92;
                if (!(v93 >> 31 & 1))
                {
                    v94 = a3->field_8;
                    if ((int)((unsigned int)(a3->field_10 - v94 >> 5) * 954437177) > (int)v93)
                    {
                        v95 = (char *)v94 + (unsigned int)v93 * 288;
                        if (*v95 && v95[1])
                        {
                            if (a1 + 1 != v89)
                            {
                                if (!*(char *)&v8->field_8[v91])
                                    a0->field_a8();
                            }
                            else
                            {
                                if (!(a6 & 1) && !*(char *)&v8->field_8[16 + 128 * a1])
                                    a0->field_a8();
                            }
                            *(unsigned int *)((char *)v94 + (unsigned int)v93 * 288 + 192) = 1;
                        }
                    }
                }
            }
        } while ((v89 -= 1, v90 = (unsigned int)v90 - 1, v91 -= 128, (long long)v89 > a1));
    }
    sub_67b3a0(0xffffffff, 123935948);
    if (v14->field_28 == v11)
        return 1;
    6813312();
}
