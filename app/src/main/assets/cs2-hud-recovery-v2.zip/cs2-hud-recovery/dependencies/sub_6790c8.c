long long sub_6790c8(unsigned long a0)
{
}
