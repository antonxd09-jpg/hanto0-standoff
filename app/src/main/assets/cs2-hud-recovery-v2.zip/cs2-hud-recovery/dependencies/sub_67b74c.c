typedef struct st_67b74c_0 {
    char padding_0[16];
    unsigned long long field_10;
} st_67b74c_0;

void sub_67b74c(st_67b74c_0 *a0)
{
    unsigned long long v7;  // x30
    unsigned long long v8;  // x28
    unsigned long long v9;  // x19
    char v0;  // [bp-0x4a0]
    char v1;  // [bp-0x230]
    char *v2;  // [bp-0x20]
    unsigned long long v3;  // [bp-0x18]
    unsigned long long v4;  // [bp-0x10]
    unsigned long long v5;  // [bp-0x8]
    char v6;  // [bp+0x0]

    v2 = &v6;
    v3 = v7;
    v4 = v8;
    v5 = v9;
    sub_67f53c(&v1);
    if (!a0->field_10)
        sub_67b618(&v1, &v0, a0);
    else
        sub_67b7d0(&v1, &v0, a0);
    0x67ffe0();
    6816560();
    6816944();
}
