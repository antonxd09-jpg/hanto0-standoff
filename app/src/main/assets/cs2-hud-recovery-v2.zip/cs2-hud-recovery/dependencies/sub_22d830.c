typedef struct st_22d830_1 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
    char padding_20[208];
    float field_f0;
    float field_f4;
    char padding_f8[1];
    char field_f9;
} st_22d830_1;

typedef struct st_22d830_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_22d830_0;

void sub_22d830(unsigned long a0, st_22d830_1 *a1, float a2, float a3)
{
    st_22d830_0 *v6;  // tpidr_el0
    float v7;  // s0
    unsigned long long v8;  // 4152
    float v9;  // s0
    unsigned long long v10;  // 4145
    long long v11;  // x20
    float v0;  // [bp-0x54]
    float v1;  // [bp-0x50]
    unsigned int v2;  // [bp-0x4c]
    unsigned long v3;  // [bp-0x48]
    char *v4;  // [bp-0x30]
    char v5;  // [bp+0x0]

    v4 = &v5;
    v3 = v6->field_28;
    if (a1 && (!a1->field_f9 || (v7 = fabsf(a1->field_f0 - a2), v8 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v7), 0.0005000000237487257f)) >> 5 & 3 | v7 < 0.0005000000237487257f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v7)) * 0x10000000, 0, 0), v8 & 1 || (v9 = fabsf(a1->field_f4 - a3), v10 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v9), 0.0005000000237487257f)) >> 5 & 3 | v9 < 0.0005000000237487257f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v9)) * 0x10000000, 0, 0), !(v10 & 1)))))
    {
        if (!a1->field_10)
            v11 = 0;
        else
            v11 = a1->field_18;
        if (sub_198128(v11) & 1 && v11)
        {
            v0 = a2;
            v1 = a3;
            v2 = 0x3f800000;
            sub_1979a4(v11, &v0);
            a1->field_f0 = a2;
            a1->field_f4 = a3;
            a1->field_f9 = 1;
        }
    }
    if (v6->field_28 == v3)
        return;
    6813312();
}
