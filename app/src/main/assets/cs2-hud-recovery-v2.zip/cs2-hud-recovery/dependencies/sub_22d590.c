typedef struct st_22d590_0 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
    char padding_20[188];
    float field_dc;
    float field_e0;
    char field_e4;
} st_22d590_0;

typedef struct st_22d590_1 {
    char padding_0[248];
    struct st_22d590_2 *field_f8;
} st_22d590_1;

typedef struct st_22d590_2 {
    unsigned long long field_0;
} st_22d590_2;

void sub_22d590(st_22d590_1 *a0, st_22d590_0 *a1, float a2, float a3)
{
    unsigned long long v6;  // x30
    unsigned long long v7;  // x21
    unsigned long long v8;  // x20
    unsigned long long v9;  // x19
    float v10;  // s0
    unsigned long long v11;  // 4152
    float v12;  // s0
    unsigned long long v13;  // 4145
    long long v14;  // x9
    char *v0;  // [bp-0x30]
    unsigned long long v1;  // [bp-0x28]
    unsigned long long v2;  // [bp-0x20]
    unsigned long long v3;  // [bp-0x10]
    unsigned long long v4;  // [bp-0x8]
    char v5;  // [bp+0x0]

    if (!a1)
        return;
    v0 = &v5;
    v1 = v6;
    v2 = v7;
    v3 = v8;
    v4 = v9;
    if (!a1->field_e4 || (v10 = fabsf(a1->field_dc - a2), v11 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v10), 0.009999999776482582f)) >> 5 & 3 | v10 < 0.009999999776482582f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v10)) * 0x10000000, 0, 0), v11 & 1 || (v12 = fabsf(a1->field_e0 - a3), v13 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v12), 0.009999999776482582f)) >> 5 & 3 | v12 < 0.009999999776482582f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v12)) * 0x10000000, 0, 0), !(v13 & 1))))
    {
        v14 = a1->field_18;
        if (!a1->field_10)
            v14 = 0;
        if (sub_198128(v14) & 1 && v14)
            a0->field_f8();
    }
    return;
}
