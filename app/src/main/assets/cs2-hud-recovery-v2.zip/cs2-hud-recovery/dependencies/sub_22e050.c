typedef struct st_22e050_1 {
    char padding_0[184];
    struct st_22e050_2 *field_b8;
} st_22e050_1;

typedef struct st_22e050_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_22e050_0;

typedef struct st_22e050_2 {
    unsigned long long field_0;
} st_22e050_2;

unsigned long long sub_22e050(st_22e050_1 *a0, long long a1, unsigned long long a2)
{
    st_22e050_0 *v8;  // tpidr_el0
    unsigned long long v9;  // x0
    unsigned long long *iter;  // x21
    unsigned long long v11;  // x22
    unsigned long v13;  // x28
    unsigned long long v14;  // x8
    unsigned long long v16;  // x23
    char v0;  // [bp-0x98]
    unsigned long long v1;  // [bp-0x90]
    long long v2;  // [bp-0x88]
    unsigned long long *v3;  // [bp-0x80]
    unsigned long long *v4;  // [bp-0x78]
    unsigned long v5;  // [bp-0x68]
    char *v6;  // [bp-0x60]
    char v7;  // [bp+0x0]

    v6 = &v7;
    v5 = v8->field_28;
    if (!a1)
    {
        v9 = 0;
    }
    else if (!a2 && !(a1 = a1, !(sub_1989a0() & 1)))
    {
        v9 = sub_198a4c(a1, 0);
        if (!v9)
        {
            if (v8->field_28 == v5)
                return sub_198a4c();
            6813312();
        }
    }
    else
    {
        sub_198538(a1, 1, 16);
        iter = v3;
        if (iter != v4)
        {
            v9 = 0;
            do
            {
                v11 = *iter;
                if (!(sub_198128(v11) & 1))
                    continue;
                if (a2)
                {
                    sub_198468(sub_1997d4(v11));
                    v13 = v0;
                    v14 = v1;
                    if (!(v13 & 1))
                        v14 = v13 >> 1;
                    if (v14 == 6813424())
                    {
                        v16 = !6813376();
                        if (!(v13 & 1))
                            goto LABEL_22e1b0;
                    }
                    else
                    {
                        v16 = 0;
                        if (!(v13 & 1))
                        {
LABEL_22e1b0:
                            if (!(v16 & 1))
                                continue;
                            goto LABEL_22e1b4;
                        }
                    }
                    sub_6790c8(v2); /* do not return */
                }
                else
                {
LABEL_22e1b4:
                    if (sub_198128(v11) & 1 && sub_1997d4(v11))
                        a0->field_b8();
                    if (!v9)
                        v9 = v11;
                }
            } while ((iter += 1, iter != v4));
            iter = v3;
            if (iter)
            {
                v4 = iter;
                sub_6790c8(iter); /* do not return */
            }
        }
        else
        {
            v9 = 0;
            if (iter)
            {
                v4 = iter;
                sub_6790c8(iter); /* do not return */
            }
        }
    }
    if (v8->field_28 == v5)
        return v9;
    6813312();
}
