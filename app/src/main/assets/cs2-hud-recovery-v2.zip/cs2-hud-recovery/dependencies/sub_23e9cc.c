float sub_23e9cc(unsigned int a0)
{
    float *v2;  // x8
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    sub_23e3e0();
    if (a0 == 1)
    {
        v2 = 0x6a5e548;
    }
    else if (a0 == 2)
    {
        v2 = 0x6a5e538;
    }
    else
    {
        return 1.0f;
    }
    return *v2;
}
