typedef struct st_246b10_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_246b10_0;

void sub_246b10(unsigned long a0, unsigned long a1, char a2)
{
    st_246b10_0 *v12;  // tpidr_el0
    unsigned short v0;  // [bp-0x5c]
    unsigned int v1;  // [bp-0x58]
    char v2;  // [bp-0x54]
    uint128_t v3;  // [bp-0x50]
    unsigned short v4;  // [bp-0x40]
    unsigned int v5;  // [bp-0x3c]
    char v6;  // [bp-0x38]
    unsigned int v7;  // [bp-0x34]
    unsigned long long v8;  // [bp-0x30]
    unsigned long v9;  // [bp-0x28]
    char *v10;  // [bp-0x20]
    char v11;  // [bp+0x0]

    v10 = &v11;
    v9 = v12->field_28;
    v4 = 1;
    v0 = 0;
    v1 = 0;
    v2 = 0;
    v3 = CONCAT(0x3f8000003f800000, 0x3f8000003f800000);
    v5 = 0;
    v6 = 0;
    v8 = 0;
    v7 = 0;
    if (12 >= a2)
    {
        goto *((void *)(sub_246b80 + *(char *)(a2 + 43517502) * 4));
    }
    else
    {
        sub_246d14();
        if (v12->field_28 == v9)
            return;
        6813312();
    }
}
