float sub_254a74(float a0)
{
    float v0;  // s2
    unsigned long long v1;  // 4131
    float v10;  // s20
    float v11;  // s16
    float v12;  // s21
    float v13;  // s16
    float v14;  // s17
    float v15;  // s18
    unsigned long long v17;  // 4271
    float v18;  // s16
    unsigned long long v19;  // 4225
    float v2;  // s3
    unsigned long long v20;  // 4176
    unsigned long v21;  // cc_dep1
    unsigned long long v22;  // 4112
    unsigned long long v23;  // 4112
    unsigned long long v24;  // 4112
    unsigned long long v25;  // 4108
    unsigned long long v26;  // 4112
    unsigned long long v27;  // 4108
    float v28;  // s4
    float v29;  // s7
    unsigned long long v3;  // 4130
    unsigned int v30;  // w8
    unsigned int v31;  // w8
    float v32;  // s16
    float v33;  // s17
    float v34;  // s21
    unsigned long long v36;  // 4271
    unsigned long long v37;  // 4110
    unsigned long v38;  // cc_dep1
    unsigned long long v39;  // 4129
    unsigned long long v4;  // 4125
    unsigned long long v40;  // 4106
    unsigned long long v41;  // 4106
    float v42;  // s1
    float v43;  // s2
    unsigned long long v5;  // 4125
    unsigned int v6;  // w8
    float v7;  // s0
    unsigned int v8;  // w8
    float v9;  // s19

    v0 = 1.0f;
    v1 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(a0), 1.0f)) >> 5 & 3 | a0 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(a0)) * 0x10000000, 0, 0);
    if (!(v1 & 1))
        v0 = a0;
    v2 = v0;
    v3 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(a0), 0.0f)) >> 5 & 3 | a0 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(a0)) * 0x10000000, 0, 0);
    if (v3 & 1)
        v2 = 0;
    v4 = arm64g_calculate_condition(144, (((((char)(CmpF(__float_as_int(v2), 0.0f)) >> 5 & 3 | v2 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
    if (v4 & 1)
        return 0;
    v5 = arm64g_calculate_condition(160, (((((char)(CmpF(__float_as_int(v2), 1.0f)) >> 5 & 3 | v2 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
    if (v5 & 1)
        return 1.0;
    v6 = 7;
    v7 = v2;
    while (1)
    {
        v8 = v6;
        v9 = 1.0f - v7;
        v10 = v7 * v7;
        v11 = v9 * 3.0f;
        v12 = v9 * v11;
        v13 = v7 * v7 * v11;
        v14 = v7 * v12;
        v15 = v10 * v7 + v14 * 0.0f + v13 * 0.5799999833106995f;
        v17 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v15 - v2)), 9.999999747378752e-06f)) >> 5 & 3 | fabsf(v15 - v2) < 9.999999747378752e-06f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v15 - v2))) * 0x10000000, 0, 0);
        if (v17 & 1)
            break;
        v18 = v7 * v7 * 3.0f * 0.42000001668930054f + v12 * 0.0f + v7 * v9 * 6.0f * 0.5799999833106995f;
        v19 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v18)), 9.999999974752427e-07f)) >> 5 & 3 | fabsf(v18) < 9.999999974752427e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v18))) * 0x10000000, 0, 0);
        if (v19 & 1)
        {
LABEL_254b64:
            v28 = 0;
            v29 = 1.0f;
            v30 = 40;
            v7 = v2;
            while (1)
            {
                v31 = v30;
                v32 = 1.0f - v7;
                v33 = v32 * 3.0f;
                v13 = v7 * v7 * v33;
                v14 = v7 * v32 * v33;
                v10 = v7 * v7;
                v34 = v10 * v7 + v14 * 0.0f + v13 * 0.5799999833106995f;
                v36 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(fabsf(v34 - v2)), 9.999999747378752e-06f)) >> 5 & 3 | fabsf(v34 - v2) < 9.999999747378752e-06f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(fabsf(v34 - v2))) * 0x10000000, 0, 0);
                if (v36 & 1)
                    break;
                v37 = (isunordered(v34, v2) ? 2 : v34 == v2 ? 2 : 0) | v34 < v2;
                v38 = (((v37 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v34, v2)) * 0x10000000;
                v39 = arm64g_calculate_condition(64, (((v37 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v34, v2)) * 0x10000000, 0, 0);
                if (v39 & 1)
                {
                    v28 = v7;
                    v40 = arm64g_calculate_condition(64, v38, 0, 0);
                    if (!(v40 & 1))
                        goto LABEL_254bda;
                    goto LABEL_254bd9;
                }
                else
                {
                    v28 = v28;
                    v41 = arm64g_calculate_condition(64, v38, 0, 0);
                    if (v41 & 1)
                    {
LABEL_254bd9:
                        goto LABEL_254bdc;
                    }
                    else
                    {
LABEL_254bda:
                        v29 = v7;
LABEL_254bdc:
                        v30 = v31 - 1;
                        v7 = (v28 + v29) * 0.5f;
                        if (v31 == 1)
                        {
                            v10 = v7 * v7;
                            v42 = 1.0f - v7;
                            v43 = v42 * 3.0f;
                            v14 = v7 * v42 * v43;
                            v13 = v7 * v7 * v43;
                            break;
                        }
                    }
                }
            }
        }
        v7 -= (v15 - v2) / v18;
        v20 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v7), 0.0f)) >> 5 & 3 | v7 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v7)) * 0x10000000, 0, 0);
        if (v20 & 1)
        {
            v21 = (((((isnan(v7) ? 2 : v7 == 1.0f ? 2 : 0) | v7 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v7)) * 0x10000000;
            v22 = arm64g_calculate_condition(208, v21, 0, 0);
            if (!(v22 & 1))
                goto LABEL_254b5a;
            goto LABEL_254b59;
        }
        else
        {
            v21 = 0;
            v23 = arm64g_calculate_condition(208, 0, 0, 0);
            if (v23 & 1)
            {
LABEL_254b59:
                v24 = arm64g_calculate_condition(208, v21, 0, 0);
                v6 = v8 - 1;
                v25 = arm64g_calculate_condition(19, (v24 & 1 ? v8 : 0x40000000), 0, 0);
                if (v25 & 1)
                    continue;
                goto LABEL_254b64;
            }
            else
            {
LABEL_254b5a:
                v26 = arm64g_calculate_condition(208, v21, 0, 0);
                v6 = v8 - 1;
                v27 = arm64g_calculate_condition(16, (v26 & 1 ? v8 : 0x40000000), 0, 0);
                if (!(v27 & 1))
                    goto LABEL_254b64;
            }
        }
    }
    return v10 * v7 + v14 * 0.0f + v13;
}
