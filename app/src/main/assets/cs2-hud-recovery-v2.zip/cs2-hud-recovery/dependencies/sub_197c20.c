extern unsigned long long g_75e0718;

unsigned long long sub_197c20(long long a0, char *a1)
{
    unsigned long long v2;  // x0
    long long v3;  // x0
    unsigned int v4;  // w0
    char *v0;  // [bp-0x30]
    char v1;  // [bp+0x0]

    v0 = &v1;
    /* unsupported instruction */;
    if (!(*0x75e0720 & 1) && sub_65eda8(123602720))
    {
        v2 = sub_18de28();
        if (v2)
        {
            v3 = sub_126488();
            v2 = sub_43d5e4(v3 + 8, sub_18de28(v3), 7015766, 1);
        }
        g_75e0718 = v2;
        sub_65eed8(123602720);
    }
    if (!g_75e0718)
        return 0;
    v4 = sub_196900(a0);
    if (!a1)
    {
        return 0;
    }
    else if (!(v4 & 1))
    {
        return 0;
    }
    else if (*a1)
    {
        /* unsupported instruction */;
        if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
        {
            sub_1269d0(123377504);
            6813216();
            sub_65eed8(123388920);
        }
        if (sub_43cd88(123377512, a1))
        {
            g_75e0718();
        }
        else if (sub_196900(0) & 1)
        {
            return 0;
        }
        else
        {
            return 0;
        }
    }
    return 0;
}
