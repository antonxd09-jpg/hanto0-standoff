extern unsigned long long g_7631e28;

int sub_248648(unsigned long long a0, int a1)
{
    unsigned int v2;  // w20
    unsigned long v3;  // x21
    char *v4;  // x8
    unsigned long long v5;  // x9
    int v6;  // w9
    char *v0;  // [bp-0x30]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (!(a0 >> 31 & 1))
    {
        v2 = a0;
        /* unsupported instruction */;
        if (!(*0x7631e30 & 1))
        {
            a0 = sub_65eda8(123936304);
            if ((unsigned int)a0)
            {
                v3 = sub_679020(736);
                6813344();
                sub_24c348(v3);
                g_7631e28 = v3;
                a0 = sub_65eed8(123936304);
            }
        }
        v4 = *(long long *)g_7631e28;
        v5 = v2 & 0xffff;
        if ((*(long long *)(g_7631e28 + 8) - v4 >> 3) * 5887258746928580303 > v5 && v4[(unsigned int)v5 * 376] && *(short *)&v4[2 + (unsigned int)v5 * 376] == v2 >> 16)
        {
            if ((unsigned int)a1 < 2)
                v6 = a1;
            else
                v6 = 2;
            if (a1 < 0)
                v6 = 0;
            *(int *)&v4[52 + (unsigned int)v5 * 376] = v6;
        }
    }
    return a0;
}
