unsigned int sub_22e288(int *a0)
{
    if (!(*0x6a5e530 & 1))
    {
        return 0;
    }
    else if (a0[309] < 1)
    {
        return 1;
    }
    else if (a0[310] < 1)
    {
        return 0;
    }
    else
    {
        a0[310] = a0[310] - 1;
        return 1;
    }
}
