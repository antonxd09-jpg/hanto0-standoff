typedef struct st_2592e4_2 {
    unsigned long long field_0;
    unsigned long long field_8;
    unsigned long long field_10;
    char padding_18[128];
    unsigned int field_98;
    char padding_9c[8];
    unsigned int field_a4;
} st_2592e4_2;

typedef struct st_22d590_0 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
    char padding_20[188];
    float field_dc;
    float field_e0;
    char field_e4;
} st_22d590_0;

typedef struct st_22d590_1 {
    char padding_0[248];
    struct st_22d590_2 *field_f8;
} st_22d590_1;

typedef struct st_2592e4_1 {
    char padding_0[4528];
    struct st_22d590_0 *field_11b0;
    struct st_22d590_0 *field_11b8;
    struct st_22d590_0 *field_11c0;
    char padding_11c8[48];
    char field_11f8;
    char padding_11f9[79];
    unsigned int field_1248;
    char padding_124c[8];
    float field_1254;
} st_2592e4_1;

typedef struct st_2592e4_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_2592e4_0;

typedef struct st_22d590_2 {
    unsigned long long field_0;
} st_22d590_2;

void sub_2592e4(st_2592e4_1 *a0, st_22d590_1 *a1, unsigned int a2, unsigned int a3)
{
    st_2592e4_0 *v5;  // tpidr_el0
    unsigned int *v6;  // x8
    st_2592e4_2 *v15;  // x25
    st_22d590_0 *v16;  // x21
    st_22d590_0 *v17;  // x21
    unsigned long idx;  // x21
    unsigned int v8;  // w0
    unsigned int v9;  // w8
    int v10;  // w23
    unsigned int *v11;  // x24
    st_2592e4_1 *v12;  // x8
    float v13;  // s8
    st_22d590_0 *v14;  // x21
    unsigned long v0;  // [bp-0x68]
    unsigned long long v1;  // [bp-0x60]
    unsigned long v2;  // [bp-0x58]
    char *v3;  // [bp-0x48]
    char v4;  // [bp+0x0]

    v3 = &v4;
    v2 = v5->field_28;
    v6 = &a0->field_1248;
    if (v6[a2] != a3)
    {
        idx = a2;
        v6[idx] = a3;
        v0 = 0;
        v1 = 0;
        v8 = sub_2542d4(&v0);
        if (v8 < 3)
            v9 = v8;
        else
            v9 = 3;
        if ((int)v8 < 0)
            v10 = 0;
        else
            v10 = v9;
        v11 = &a0->field_11f8;
        v12 = &a0->padding_0[(unsigned int)idx * 24];
        v13 = -(float)(v10 - 1);
        v14 = v12->field_11b0;
        v15 = &v12->field_11b0;
        if (v14)
        {
            sub_22ce80(a1, v14, v10 != 0);
            if (v10)
            {
                sub_22d40c(a1, v14, *(long long *)((char *)&v11[2 * v0] - 384));
                sub_22d590(a1, v14, (v13 * 0.5f + 0.0f) * a0->field_1254, 0);
            }
        }
        v16 = v15->field_8;
        if (v16)
        {
            sub_22ce80(a1, v16, (unsigned int)v10 > 1);
            if ((unsigned int)v10 >= 2)
            {
                sub_22d40c(a1, v16, *(long long *)((char *)&v11[2 * *(char *)((void*)&v0 + 1)] - 384));
                sub_22d590(a1, v16, (v13 * 0.5f + 1.0f) * a0->field_1254, 0);
            }
        }
        v17 = v15->field_10;
        if (v17)
        {
            sub_22ce80(a1, v17, v10 == 3);
            if (v10 == 3)
            {
                sub_22d40c(a1, v17, *(long long *)((char *)&v11[2 * *(char *)((void*)&v0 + 2)] - 384));
                sub_22d590(a1, v17, (v13 * 0.5f + 2.0f) * a0->field_1254, 0);
            }
        }
    }
    if (v5->field_28 == v2)
        return;
    6813312();
}
