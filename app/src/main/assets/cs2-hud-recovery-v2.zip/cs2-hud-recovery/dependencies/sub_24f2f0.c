extern unsigned long long g_7632b70;
extern unsigned int g_7632b7c;
extern unsigned long long g_7632cb0;
extern unsigned long long g_7632cb8;
extern char g_7632cc0;

unsigned int sub_24f2f0(float a0, float a1)
{
    long long v2;  // x0
    unsigned long long v3;  // x0
    float v4;  // s0
    unsigned long long v5;  // 4164
    float v6;  // s0
    unsigned long long v7;  // 4164
    float v8;  // s1
    unsigned long long v9;  // 4165
    float v10;  // s0
    unsigned long long v11;  // 4164
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    /* unsupported instruction */;
    if (!(*0x7632b90 & 1) && sub_65eda8(123939728))
    {
        sub_24fe44();
        6813216();
        sub_65eed8(123939728);
    }
    if (!g_7632b70)
    {
        /* unsupported instruction */;
        if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
        {
            sub_1269d0(123377504);
            6813216();
            sub_65eed8(123388920);
        }
        v2 = sub_43d298(123377512, 6935571, 6951890, 7253436);
        if (v2)
            v3 = sub_43d5e4(123377512, v2, 6878898, 2);
        else
            v3 = 0;
        if (sub_43bc24(123377512) + 120482580 != v3)
            return 0;
        g_7632b70 = v3;
        /* unsupported instruction */;
        if (!(*0x7632cc8 & 1) && sub_65eda8(123940040))
        {
            g_7632cb0 = 0;
            g_7632cb8 = 0;
            g_7632cc0 = 0;
            sub_126978(43517941, &g_7632cb0, 0x11, 6979537903417071971);
            sub_65eed8(123940040);
        }
        g_7632b7c = sub_19e714(&g_7632cb0);
    }
    v4 = (a0 - *(int *)0x7632b80) * (a0 - *(int *)0x7632b80);
    v5 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v4), 9.999999439624929e-11f)) >> 5 & 3 | (a0 - *(int *)0x7632b80) * (a0 - *(int *)0x7632b80) < 9.999999439624929e-11f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((a0 - *(int *)0x7632b80) * (a0 - *(int *)0x7632b80))) * 0x10000000, 0, 0);
    if (!(v5 & 1))
    {
        v6 = (a1 - *(int *)0x7632b84) * (a1 - *(int *)0x7632b84);
        v7 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v6), 9.999999439624929e-11f)) >> 5 & 3 | (a1 - *(int *)0x7632b84) * (a1 - *(int *)0x7632b84) < 9.999999439624929e-11f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((a1 - *(int *)0x7632b84) * (a1 - *(int *)0x7632b84))) * 0x10000000, 0, 0);
        if (!(v7 & 1))
        {
            v8 = (0.0f - *(int *)0x7632b88) * (0.0f - *(int *)0x7632b88);
            v9 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v8), 9.999999439624929e-11f)) >> 5 & 3 | (0.0f - *(int *)0x7632b88) * (0.0f - *(int *)0x7632b88) < 9.999999439624929e-11f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((0.0f - *(int *)0x7632b88) * (0.0f - *(int *)0x7632b88))) * 0x10000000, 0, 0);
            if (!(v9 & 1))
            {
                v10 = (0.0f - *(int *)0x7632b8c) * (0.0f - *(int *)0x7632b8c);
                v11 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int(v10), 9.999999439624929e-11f)) >> 5 & 3 | (0.0f - *(int *)0x7632b8c) * (0.0f - *(int *)0x7632b8c) < 9.999999439624929e-11f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((0.0f - *(int *)0x7632b8c) * (0.0f - *(int *)0x7632b8c))) * 0x10000000, 0, 0);
                if (!(v11 & 1))
                    return 1;
            }
        }
    }
    g_7632b70();
}
