unsigned long long sub_24fd88(void)
{
    long long v2;  // x19
    long long v3;  // x19
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    /* unsupported instruction */;
    if (!(*0x7632b90 & 1) && sub_65eda8(123939728))
    {
        sub_24fe44();
        6813216();
        sub_65eed8(123939728);
    }
    if (!*(long long *)0x76320b8)
        v2 = 0;
    else
        v2 = *0x76320c0;
    if (!(sub_198128(v2) & 1))
    {
        return 0;
    }
    else if (v2)
    {
        if (!*(long long *)0x7632118)
            v3 = 0;
        else
            v3 = *0x7632120;
        return (int)sub_198128(v3) & v3 != 0;
    }
    else
    {
        return 0;
    }
}
