typedef struct st_63b560_0 {
    long long field_0;
    struct st_63b560_1 *field_8;
    struct st_63b560_1 *field_10;
} st_63b560_0;

typedef struct st_63b560_1 {
    char field_0;
} st_63b560_1;

char * sub_63b560(unsigned int a0)
{
    unsigned long v4;  // x1
    char *v5;  // x0
    char *iter;  // x19
    unsigned long long v14;  // x22
    st_63b560_0 *v15;  // x8
    char *v6;  // x20
    char *v7;  // x8
    unsigned int v8;  // w9
    unsigned int v9;  // w9
    unsigned int v10;  // w9
    char *v11;  // x21
    unsigned long long v12;  // 4113
    char v0;  // [bp-0x3c]
    char v1;  // [bp-0x31]
    char *v2;  // [bp-0x30]
    char v3;  // [bp+0x0]

    v2 = &v3;
    v4 = a0;
    v5 = &v0;
    v6 = &v1;
    if (!(v4 >> 31 & 1))
    {
        v7 = 0xb;
        if (0)
            goto LABEL_63b5b8;
    }
    else
    {
        v5 = &v0 | 1;
        v4 = -(unsigned int)v4;
        v0 = 45;
        v7 = &v1 - v5;
        if (0x9 >= v7)
        {
LABEL_63b5b8:
            v8 = (unsigned int)v4 | 1;
            if (!(v8 * 0x100000000))
                v9 = 32;
            else
                v9 = Clz(v8 * 0x100000000);
            v10 = 1233 * (unsigned int)(32 - v9) >> 12;
            if (v7 < v10 - ((unsigned int)*(int *)(4 * v10 + 104719216) > (unsigned int)v4) + 1)
                goto LABEL_63b600;
        }
    }
    v5 = sub_63be04(v5, v4);
    v6 = v5;
LABEL_63b600:
    v11 = v6 - &v0;
    v12 = arm64g_calculate_condition(0x22, v11, 16, 0);
    if (!(v12 & 1))
    {
        if (0x16 >= v11)
        {
            *(char *)&v15->field_0 = (char)v11 * 2;
            iter = (char *)&v15->field_0 + 1;
            if (&v0 != v6)
                goto LABEL_63b658;
        }
        else
        {
            v14 = v11 | 15;
            v5 = sub_679020(v14 + 1);
            v15->field_8 = v11;
            v15->field_10 = v5;
            v15->field_0 = v14 + 2;
            iter = v5;
            if (&v0 != v6)
            {
LABEL_63b658:
                v5 = 6813280();
                iter += v11;
            }
        }
        *iter = 0;
        return v5;
    }
    sub_13a8e8(v15);
}
