typedef struct st_22b5e4_0 {
    unsigned long long field_0;
    long long field_8;
} st_22b5e4_0;

unsigned int sub_22b5e4(unsigned long a0, st_22b5e4_0 *a1, unsigned long a2)
{
    unsigned long long v6;  // x30
    unsigned long long v7;  // x21
    unsigned long long v8;  // x20
    unsigned long long v9;  // x19
    long long v10;  // x21
    char *v0;  // [bp-0x30]
    unsigned long long v1;  // [bp-0x28]
    unsigned long long v2;  // [bp-0x20]
    unsigned long long v3;  // [bp-0x10]
    unsigned long long v4;  // [bp-0x8]
    char v5;  // [bp+0x0]

    if (!a1)
        return 0;
    v0 = &v5;
    v1 = v6;
    v2 = v7;
    v3 = v8;
    v4 = v9;
    if (!a1->field_0)
        v10 = 0;
    else
        v10 = a1->field_8;
}
