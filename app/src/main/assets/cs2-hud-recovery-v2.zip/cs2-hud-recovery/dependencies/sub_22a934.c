typedef struct st_22a934_1 {
    char padding_0[8];
    unsigned long long field_8;
} st_22a934_1;

typedef struct st_22a934_0 {
    char padding_0[8];
    unsigned int field_8;
    unsigned int field_c;
} st_22a934_0;

unsigned int sub_22a934(st_22a934_1 *a0, unsigned long long a1, unsigned long long a2, unsigned long long a3)
{
    unsigned int v2;  // w21
    unsigned long long v3;  // x0
    unsigned long long v4;  // x9
    unsigned long v5;  // x22
    unsigned long long v6;  // x23
    st_22a934_0 *v7;  // x28
    unsigned long long v8;  // 4106
    unsigned long long v9;  // 4107
    unsigned long long v10;  // x8
    char *v0;  // [bp-0x60]
    char v1;  // [bp+0x0]

    v0 = &v1;
    v2 = a1;
    if (a1 >> 31 & 1 || !a3)
        return a1;
    while (1)
    {
        v3 = 6813408();
        v4 = v3 - a2;
        if (!v3)
            v4 = 0xffffffffffffffff;
        v5 = v2 + 1;
        if (a3 < v4)
            v6 = a3;
        else
            v6 = v4;
        while (1)
        {
            if (*(int *)(a0->field_8 + v2 * 128 + 12) > (int)v5)
            {
                v7 = a0->field_8 + (int)v5 * 128;
                if (v7->field_8 != v2 || v6 != 6813424() || 6813376())
                {
                    v5 = v7->field_c;
                }
                else
                {
                    v8 = arm64g_calculate_condition(18, v4, 1, 0);
                    if (!(v8 & 1))
                        return v5;
                    goto LABEL_22aa04;
                }
            }
            else
            {
                v5 = 0xffffffff;
                v9 = arm64g_calculate_condition(2, v4, 1, 0);
                if (v9 & 1)
                    return 0xffffffff;
LABEL_22aa04:
                if (a3 <= v4)
                    sub_125954(7068293);
                if (v5 >> 31 & 1 || !(v10 = v4 + 1, v2 = v5, a3 -= v10, a2 += v10, a3))
                    return v5;
                break;
            }
        }
    }
    return a1;
}
