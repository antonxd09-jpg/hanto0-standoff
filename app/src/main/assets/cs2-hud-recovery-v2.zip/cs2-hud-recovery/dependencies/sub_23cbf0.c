typedef struct st_23cbf0_2 {
    char padding_0[40];
    unsigned int field_28;
} st_23cbf0_2;

typedef struct st_23cbf0_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_23cbf0_0;

typedef struct st_23cbf0_1 {
    unsigned long long field_0[2];
    char field_8;
} st_23cbf0_1;

extern uint128_t g_7631d20;
extern st_23cbf0_1 g_7631d30;
extern unsigned int g_7631d40;

unsigned long long sub_23cbf0(long long a0, unsigned long long a1, unsigned long long a2)
{
    st_23cbf0_0 *v7;  // tpidr_el0
    void* v8;  // x0
    long long v17;  // x0
    unsigned long long v18;  // x1
    unsigned int v19;  // w8
    unsigned long v20;  // cc_dep1
    unsigned long long v21;  // 4105
    unsigned long long v22;  // 4105
    long long v23;  // x0
    void* v9;  // x22
    unsigned long long v10;  // x0
    unsigned long long v11;  // 4106
    unsigned long long v12;  // x23
    unsigned long long v13;  // x24
    unsigned long long v14;  // x26
    st_23cbf0_2 *v15;  // x0
    unsigned long long v16;  // x0
    unsigned int v0;  // [bp-0x74]
    char v1;  // [bp-0x70], Other Possible Types: unsigned long long
    unsigned long long v2;  // [bp-0x68]
    unsigned long long v3;  // [bp-0x60]
    unsigned long v4;  // [bp-0x58]
    char *v5;  // [bp-0x50]
    char v6;  // [bp+0x0]

    v5 = &v6;
    v4 = v7->field_28;
    /* unsupported instruction */;
    if (!(*0x7631d48 & 1) && sub_65eda8(123936072))
    {
        g_7631d40 = 0x3f800000;
        g_7631d20 = 0;
        *(uint128_t *)g_7631d30.field_0 = 0;
        6813216();
        sub_65eed8(123936072);
    }
    v8 = sub_236d98();
    if (a0 && !(v9 = v8, !(long long)v8[8]))
    {
        v10 = 6813424();
        v11 = arm64g_calculate_condition(0x22, v10, 16, 0);
        if (!(v11 & 1))
        {
            v12 = v10;
            if (23 > v10)
            {
                v13 = &v1 | 1;
                v1 = _INSERT(CONCAT(v1, 0), 0, (char)v12 * 2);
                if (!v12)
                    goto LABEL_23ccb0;
            }
            else
            {
                v14 = v12 | 15;
                v13 = sub_679020(v14 + 1);
                v2 = v12;
                v3 = v13;
                v1 = v14 + 2;
            }
            6813280();
LABEL_23ccb0:
            *(char *)(v13 + v12) = 0;
            sub_63aac0(&v1, 10);
            sub_63a938(&v1, a1, a2);
            v15 = sub_242d7c(&g_7631d20, &v1);
            if (v15)
            {
                v16 = v15->field_28;
            }
            else
            {
                v17 = 6813424();
                v18 = sub_22aa58((long long)v9[8], a0, a0, v17) & 0xffffffff;
                if (!(v18 >> 31 & 1))
                {
                    v16 = sub_22a934((long long)v9[8], v18, a1, a2);
                    v0 = v16;
                    if (!(v16 >> 31 & 1))
                        goto LABEL_23cd74;
                }
                else
                {
                    v16 = 0xffffffff;
                    v0 = 0xffffffff;
                }
                v19 = (char)v1;
                v20 = v19 & 1;
                if (!(v19 & 1))
                {
                    v21 = arm64g_calculate_condition(9, v20, 0, 0);
                    if (!(v21 & 1))
                        goto LABEL_23cd56;
LABEL_23cd55:
                }
                else
                {
                    v22 = arm64g_calculate_condition(9, v20, 0, 0);
                    if (v22 & 1)
                        goto LABEL_23cd55;
LABEL_23cd56:
                }
                sub_23cef8();
                v16 &= 0xffffffff;
LABEL_23cd74:
                if (0xfff >= g_7631d30.field_0[1])
                {
                    sub_242f38(&g_7631d20, &v1, &v1, &v0);
                    v16 = v0;
                }
            }
            if ((char)v1 & 1)
                sub_6790c8(v3); /* do not return */
LABEL_23cdbc:
            if (v7->field_28 == v4)
                return v16;
        }
        else if (v7->field_28 == v4)
        {
            v23 = sub_13a8e8(&v1);
            if (v1 & 1)
            {
                sub_6790c8(v3); /* do not return */
            }
            else if (v7->field_28 == v4)
            {
                sub_67b74c(v23); /* do not return */
            }
        }
        6813312();
    }
    else
    {
        v16 = 0xffffffff;
        goto LABEL_23cdbc;
    }
}
