typedef struct st_252ad4_1 {
    unsigned int field_0;
    unsigned int field_4;
    unsigned int field_8;
    unsigned int field_c;
    int field_10;
    int field_14;
    unsigned int field_18;
    char padding_1c[36];
    unsigned int field_40;
    char padding_44[36];
    unsigned int field_68;
    char field_6c;
    char padding_6d[35];
    unsigned int field_90;
    char padding_94[36];
    unsigned int field_b8;
    char padding_bc[36];
    unsigned int field_e0;
} st_252ad4_1;

typedef struct st_252ad4_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_252ad4_0;

float sub_252ad4(st_252ad4_1 *a0, unsigned int a1, long long a2, int a3, long long a4, int a5)
{
    st_252ad4_0 *v6;  // tpidr_el0
    unsigned int *iter;  // x24
    unsigned long long v17;  // x23
    unsigned long v18;  // x8
    unsigned long v19;  // cc_dep1
    unsigned long long v20;  // x0
    unsigned long long v21;  // 4105
    unsigned long long v22;  // 4105
    unsigned long long v23;  // x1
    unsigned long v24;  // x8
    unsigned long v25;  // cc_dep1
    float v8;  // s0
    unsigned long long v26;  // x0
    unsigned long long v27;  // 4105
    unsigned long long v28;  // 4105
    unsigned long long v29;  // x1
    unsigned long v30;  // x8
    unsigned long v31;  // cc_dep1
    unsigned long long v32;  // x0
    unsigned long long v33;  // 4105
    unsigned long long v34;  // 4105
    unsigned long long v35;  // x1
    unsigned long v36;  // x8
    unsigned long v37;  // cc_dep1
    unsigned long long v38;  // x0
    unsigned long long v39;  // 4105
    unsigned long long v40;  // 4105
    unsigned long long v41;  // x1
    unsigned long j;  // x21
    unsigned long long v43;  // x22
    unsigned long v44;  // x8
    unsigned long v45;  // cc_dep1
    unsigned long long v46;  // x0
    unsigned long long v47;  // 4105
    unsigned long long v48;  // 4105
    unsigned long long v49;  // x1
    unsigned long v50;  // x8
    st_252ad4_1 *v51;  // x23
    unsigned long long v52;  // x0
    unsigned long long v53;  // 4109
    unsigned long long v54;  // x1
    float v11;  // x0
    unsigned int v12;  // w9
    int v13;  // w10
    int v14;  // w8
    unsigned long i;  // x22
    char v0;  // [bp-0x70]
    unsigned long long v1;  // [bp-0x68]
    unsigned long long v2;  // [bp-0x60]
    unsigned long v3;  // [bp-0x58]
    char *v4;  // [bp-0x50]
    char v5;  // [bp+0x0]

    v4 = &v5;
    v3 = v6->field_28;
    sub_23d338(a1, 6813424(), 0);
    *(float *)&a0->field_0 = v8;
    sub_23d338(a1, 6813424(), 1);
    *(float *)&a0->field_4 = v8;
    sub_23d338(a1, 6813424(), 2);
    a0->field_8 = (long long)v8;
    v11 = sub_23d338(a1, 6813424(), 3);
    v12 = (long long)v8;
    if (1 >= v12)
        v12 = 1;
    if ((unsigned int)a3 < 10)
        v13 = a3;
    else
        v13 = 10;
    if (a3 < 0)
        v13 = 0;
    if ((unsigned int)a5 < 10)
        v14 = a5;
    else
        v14 = 10;
    a0->field_c = v12;
    a0->field_10 = v13;
    if (a5 < 0)
        v14 = 0;
    a0->field_14 = v14;
    if (v13)
    {
        i = 0;
        iter = &a0->field_68;
        v17 = &v0 | 1;
        do
        {
            sub_23d78c(a2, i & 0xffffffff);
            v18 = v0;
            v19 = (unsigned int)v18 & 1;
            if (!(v18 & 1))
            {
                v20 = v17;
                v21 = arm64g_calculate_condition(9, v19, 0, 0);
                if (!(v21 & 1))
                    goto LABEL_252c0e;
                goto LABEL_252c0d;
            }
            else
            {
                v20 = v2;
                v22 = arm64g_calculate_condition(9, v19, 0, 0);
                if (v22 & 1)
                {
LABEL_252c0d:
                    v23 = v18 >> 1;
                    goto LABEL_252c10;
                }
                else
                {
LABEL_252c0e:
                    v23 = v1;
LABEL_252c10:
                    sub_23d338(v20, v23, 0);
                    v24 = v0;
                    *(float *)((char *)iter - 80) = v8;
                    v25 = (unsigned int)v24 & 1;
                    if (!(v24 & 1))
                    {
                        v26 = v17;
                        v27 = arm64g_calculate_condition(9, v25, 0, 0);
                        if (!(v27 & 1))
                            goto LABEL_252c32;
                        goto LABEL_252c31;
                    }
                    else
                    {
                        v26 = v2;
                        v28 = arm64g_calculate_condition(9, v25, 0, 0);
                        if (v28 & 1)
                        {
LABEL_252c31:
                            v29 = v24 >> 1;
                            goto LABEL_252c34;
                        }
                        else
                        {
LABEL_252c32:
                            v29 = v1;
LABEL_252c34:
                            sub_23d338(v26, v29, 1);
                            v30 = v0;
                            *(float *)((char *)iter - 40) = v8;
                            v31 = (unsigned int)v30 & 1;
                            if (!(v30 & 1))
                            {
                                v32 = v17;
                                v33 = arm64g_calculate_condition(9, v31, 0, 0);
                                if (!(v33 & 1))
                                    goto LABEL_252c56;
                                goto LABEL_252c55;
                            }
                            else
                            {
                                v32 = v2;
                                v34 = arm64g_calculate_condition(9, v31, 0, 0);
                                if (v34 & 1)
                                {
LABEL_252c55:
                                    v35 = v30 >> 1;
                                    goto LABEL_252c58;
                                }
                                else
                                {
LABEL_252c56:
                                    v35 = v1;
LABEL_252c58:
                                    sub_23d338(v32, v35, 2);
                                    v36 = v0;
                                    *(float *)iter = v8;
                                    v37 = (unsigned int)v36 & 1;
                                    if (!(v36 & 1))
                                    {
                                        v38 = v17;
                                        v39 = arm64g_calculate_condition(9, v37, 0, 0);
                                        if (!(v39 & 1))
                                            goto LABEL_252c7a;
                                        goto LABEL_252c79;
                                    }
                                    else
                                    {
                                        v38 = v2;
                                        v40 = arm64g_calculate_condition(9, v37, 0, 0);
                                        if (v40 & 1)
                                        {
LABEL_252c79:
                                            v41 = v36 >> 1;
                                            continue;
                                        }
                                        else
                                        {
LABEL_252c7a:
                                            v41 = v1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            v11 = sub_23d338(v38, v41, 3);
            *(float *)&iter[10] = v8;
            if (v0 & 1)
                sub_6790c8(v2); /* do not return */
            i += 1;
            iter += 1;
        } while (a0->field_10 > (long long)i);
        v14 = a0->field_14;
    }
    if (v14 >= 1)
    {
        j = 0;
        v43 = &v0 | 1;
        do
        {
            sub_23d78c(a4, j & 0xffffffff);
            v44 = v0;
            v45 = (unsigned int)v44 & 1;
            if (!(v44 & 1))
            {
                v46 = v43;
                v47 = arm64g_calculate_condition(9, v45, 0, 0);
                if (!(v47 & 1))
                    goto LABEL_252cee;
                goto LABEL_252ced;
            }
            else
            {
                v46 = v2;
                v48 = arm64g_calculate_condition(9, v45, 0, 0);
                if (v48 & 1)
                {
LABEL_252ced:
                    v49 = v44 >> 1;
                    continue;
                }
                else
                {
LABEL_252cee:
                    v49 = v1;
                }
            }
            sub_23d338(v46, v49, 0);
            v50 = v0;
            v51 = &(&a0->field_0)[j];
            if (!(v50 & 1))
                v52 = v43;
            else
                v52 = v2;
            *(float *)&v51->field_b8 = v8;
            v53 = arm64g_calculate_condition(9, (unsigned int)v50 & 1, 0, 0);
            if (v53 & 1)
                v54 = v50 >> 1;
            else
                v54 = v1;
            v11 = sub_23d338(v52, v54, 1);
            *(float *)&v51->field_e0 = v8;
            if (v0 & 1)
                sub_6790c8(v2); /* do not return */
            j += 1;
        } while (a0->field_14 > (long long)j);
    }
    if (v6->field_28 == v3)
        return v11;
    6813312();
}
