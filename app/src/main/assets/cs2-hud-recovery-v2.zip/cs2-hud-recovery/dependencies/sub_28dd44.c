typedef struct st_28dd44_0 {
    uint128_t field_0;
    uint128_t field_10;
    uint128_t field_20;
    uint128_t field_30;
    uint128_t field_40;
    uint128_t field_50;
    uint128_t field_60;
    uint128_t field_70;
    uint128_t field_80;
    uint128_t field_90;
    uint128_t field_a0;
    uint128_t field_b0;
    uint128_t field_c0;
    uint128_t field_d0;
    uint128_t field_e0;
    uint128_t field_f0;
    uint128_t field_100;
    uint128_t field_110;
    uint128_t field_120;
    uint128_t field_130;
    uint128_t field_140;
    uint128_t field_150;
    uint128_t field_160;
    uint128_t field_170;
    uint128_t field_180;
    uint128_t field_190;
    unsigned int field_198;
    unsigned long long field_19c;
    unsigned long long field_1a0;
    char field_1a4;
} st_28dd44_0;

extern unsigned long long g_7650668;

int sub_28dd44(void)
{
    unsigned int v2;  // w0
    st_28dd44_0 *v3;  // x0
    st_28dd44_0 *v4;  // x0
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    /* unsupported instruction */;
    if (!(*0x7650670 & 1))
    {
        v2 = sub_65eda8(124061296);
        if (v2)
        {
            v3 = sub_679020(424);
            *(unsigned long long *)&v3->field_198 = 0;
            *(char *)&(&v3->field_198)[1] = 0;
            g_7650668 = v3;
            v3->field_0 = 0;
            v3->field_10 = 0;
            v3->field_20 = 0;
            v3->field_30 = 0;
            v3->field_40 = 0;
            v3->field_50 = 0;
            v3->field_60 = 0;
            v3->field_70 = 0;
            v3->field_80 = 0;
            v3->field_90 = 0;
            v3->field_a0 = 0;
            v3->field_b0 = 0;
            v3->field_c0 = 0;
            v3->field_d0 = 0;
            v3->field_e0 = 0;
            v3->field_f0 = 0;
            v3->field_100 = 0;
            v3->field_110 = 0;
            v3->field_120 = 0;
            v3->field_130 = 0;
            v3->field_140 = 0;
            v3->field_150 = 0;
            v3->field_160 = 0;
            v3->field_170 = 0;
            v3->field_180 = 0;
            v3->field_190 = 0;
            *(unsigned int *)((char *)&v3->field_190 + 8) = 3463342888;
            *(unsigned long long *)((char *)&v3->field_190 + 12) = 0;
            v2 = sub_65eed8(124061296);
        }
    }
    if (!*(long long *)g_7650668)
        return v2;
    /* unsupported instruction */;
    if (*0x7650670 & 1 || !sub_65eda8(124061296))
        return sub_282e5c();
    v4 = sub_679020(424);
    *(unsigned long long *)&v4->field_198 = 0;
    *(char *)&(&v4->field_198)[1] = 0;
    g_7650668 = v4;
    v4->field_0 = 0;
    v4->field_10 = 0;
    v4->field_20 = 0;
    v4->field_30 = 0;
    v4->field_40 = 0;
    v4->field_50 = 0;
    v4->field_60 = 0;
    v4->field_70 = 0;
    v4->field_80 = 0;
    v4->field_90 = 0;
    v4->field_a0 = 0;
    v4->field_b0 = 0;
    v4->field_c0 = 0;
    v4->field_d0 = 0;
    v4->field_e0 = 0;
    v4->field_f0 = 0;
    v4->field_100 = 0;
    v4->field_110 = 0;
    v4->field_120 = 0;
    v4->field_130 = 0;
    v4->field_140 = 0;
    v4->field_150 = 0;
    v4->field_160 = 0;
    v4->field_170 = 0;
    v4->field_180 = 0;
    v4->field_190 = 0;
    *(unsigned int *)((char *)&v4->field_190 + 8) = 3463342888;
    *(unsigned long long *)((char *)&v4->field_190 + 12) = 0;
    sub_65eed8(124061296);
    return sub_282e5c();
}
