typedef struct st_23dc40_2 {
    char padding_0[312];
    struct st_23dc40_3 *field_138;
} st_23dc40_2;

typedef struct st_23dc40_0 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
} st_23dc40_0;

typedef struct st_23dc40_1 {
    char padding_0[48];
    unsigned long long field_30;
    long long field_38;
} st_23dc40_1;

typedef struct st_23dc40_3 {
    unsigned long long field_0;
} st_23dc40_3;

long long sub_23dc40(st_23dc40_2 *a0, st_23dc40_1 *a1, st_23dc40_0 *a2)
{
    long long v2;  // x22
    long long v3;  // x23
    char *v0;  // [bp-0x48]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (a2)
    {
        if (!a2->field_10)
            v2 = 0;
        else
            v2 = a2->field_18;
        if (!(sub_198128(v2) & 1))
            v2 = 0;
    }
    else
    {
        v2 = 0;
    }
    if (!a1->field_30)
        v3 = 0;
    else
        v3 = a1->field_38;
    if (!(sub_198128(v3) & 1))
        v3 = 0;
    if (!v2)
    {
        return v3;
    }
    else if (v3)
    {
        a0->field_138();
    }
    else
    {
        return v3;
    }
}
