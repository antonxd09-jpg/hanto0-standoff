typedef struct st_23d5c0_0 {
    char padding_0[8];
    int field_8;
    float field_c;
} st_23d5c0_0;

float sub_23d5c0(void)
{
    st_23d5c0_0 *v2;  // x0
    char *v0;  // [bp-0x10]
    char v1;  // [bp+0x0]

    v0 = &v1;
    v2 = sub_23d394();
    if (!v2)
    {
        return 1.0f;
    }
    else if (3 > v2->field_8)
    {
        return 1.0f;
    }
    else
    {
        return v2->field_c;
    }
}
