typedef struct st_24f5a4_5 {
    char padding_0[152];
    unsigned long long field_98;
    long long field_a0;
} st_24f5a4_5;

typedef struct st_24f5a4_2 {
    char padding_0[200];
    unsigned long long field_c8;
    unsigned long long field_d0;
    unsigned long long field_d8;
    long long field_e0;
    unsigned int field_e8;
} st_24f5a4_2;

typedef struct st_24f5a4_3 {
    char padding_0[16];
    unsigned long long field_10;
    unsigned long long field_18;
    unsigned int field_20;
} st_24f5a4_3;

typedef struct st_24f5a4_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_24f5a4_0;

typedef struct st_24f5a4_4 {
    char padding_0[520];
    struct st_24f5a4_1 *field_208;
} st_24f5a4_4;

typedef struct st_24f5a4_1 {
    unsigned long long field_0;
} st_24f5a4_1;

extern unsigned long long g_7632b60;
extern unsigned long long g_7632b68;
extern unsigned int g_7632b78;
extern uint128_t g_7632cd0;
extern uint128_t g_7632ce0;
extern uint128_t g_7632cf0;
extern uint128_t g_7632cfb;
extern uint128_t g_7632d18;
extern uint128_t g_7632d28;
extern uint128_t g_7632d38;
extern unsigned long long g_7632d46;

long long sub_24f5a4(st_24f5a4_4 *a0, unsigned long long *a1, int a2)
{
    st_24f5a4_0 *v12;  // tpidr_el0
    int v13;  // w8
    st_24f5a4_3 *v22;  // x21
    st_24f5a4_2 *v23;  // x20
    unsigned long long *v24;  // x8
    long long v25;  // x23
    long long v26;  // x21
    long long v27;  // x22
    st_24f5a4_3 *v29;  // x20
    long long v30;  // x23
    long long v31;  // x0
    unsigned int v14;  // w26
    unsigned long long *v32;  // x21
    long long v34;  // x21
    long long v35;  // x20
    unsigned long long v36;  // x0
    long long v37;  // x20
    st_24f5a4_5 *v38;  // x22
    long long v39;  // x21
    long long v40;  // x23
    long long v15;  // x19
    unsigned long long v16;  // x0
    long long v17;  // x20
    long long v18;  // x22
    unsigned long long v19;  // x8
    unsigned long long *v20;  // x9
    unsigned long long i;  // x25
    long long v0;  // [bp-0xa8]
    unsigned long v1;  // [bp-0x98], Other Possible Types: unsigned long long
    unsigned long long v2;  // [bp-0x90]
    unsigned long long v3;  // [bp-0x88]
    unsigned long v4;  // [bp-0x88]
    unsigned long long v5;  // [bp-0x80]
    float v6;  // [bp-0x78]
    unsigned long long v7;  // [bp-0x74]
    unsigned int v8;  // [bp-0x6c]
    unsigned long v9;  // [bp-0x68]
    char *v10;  // [bp-0x60]
    char v11;  // [bp+0x0]

    v10 = &v11;
    v9 = v12->field_28;
    if (a1)
    {
        /* unsupported instruction */;
        if (!(*0x7632b90 & 1) && sub_65eda8(123939728))
        {
            sub_24fe44();
            6813216();
            sub_65eed8(123939728);
        }
        v13 = (a2 < 2 ? a2 : 2);
        v14 = v13 & ~(v13 >> 31);
        if (!g_7632b78)
            g_7632b78 = sub_19e714(7217954);
        v7 = 0;
        v8 = 0;
        v15 = (!a1[8] ? 0 : a1[9]);
        v6 = (float)(int)v14;
        if (sub_198128(v15) & 1 && v15)
        {
            if (!g_7632b68)
            {
                /* unsupported instruction */;
                if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
                {
                    sub_1269d0(123377504);
                    6813216();
                    sub_65eed8(123388920);
                }
                v16 = sub_43d298(123377512, 6883018, 6866867, 6866873);
                if (v16)
                    v16 = sub_43d5e4(123377512, v16, 6866882, 0);
                g_7632b68 = v16;
            }
            /* unsupported instruction */;
            if (!(*0x7632d10 & 1) && sub_65eda8(123940112))
            {
                g_7632cfb = 0;
                g_7632ce0 = 0;
                g_7632cf0 = 0;
                g_7632cd0 = 0;
                sub_126978(43517958, &g_7632cd0, 59, -0x6075d0bed9c84030);
                sub_65eed8(123940112);
            }
            v17 = sub_24ee54(&g_7632cd0);
            if (g_7632b68)
                g_7632b68();
            v18 = 0;
            if (v17 && sub_198128(0) & 1)
            {
                v19 = 0;
                while (1)
                {
                    v20 = 123936920 + v19;
                    if (!v20[27])
                        break;
                    v19 += 40;
                    if (v19 == 0xa00)
                        goto LABEL_24f8cc;
                }
                v18 = (!v20[25] ? 0 : v20[26]);
                if (!(sub_198128(v18) & 1))
                    goto LABEL_24f964;
LABEL_24f8cc:
                if (v18)
                {
                    i = 0;
                    v22 = NULL;
                    v0 = v17;
                    do
                    {
                        v23 = 123936920 + i;
                        if ((!v23->field_c8 ? 0 : v23->field_d0) == v18 && v23->field_e8 == v14)
                        {
                            v24 = 123936920 + i;
                            v25 = (!v24[27] ? 0 : v24[28]);
                            if (sub_198128(v25) & 1 && v25)
                            {
                                v32 = 123936920 + i;
                                if (sub_19cbdc((!v32[27] ? 0 : v32[28])) != v0)
                                {
                                    sub_19cca8((!v32[27] ? 0 : v32[28]));
                                    sub_19d5a8((!v32[27] ? 0 : v32[28]), g_7632b78, &v6);
                                }
                                a0->field_208();
                            }
                        }
                        if (!v22)
                        {
                            v26 = (!v23->field_c8 ? 0 : v23->field_d0);
                            v22 = ((int)sub_198128(v26) & v26 != 0 ? NULL : (struct st_24f5a4_2 *)&v23->field_c8);
                        }
                        i += 40;
                    } while (i != 0xa00);
                    v4 = 0;
                    v5 = 0;
                    v1 = 0;
                    v2 = 0;
                    if (v22)
                    {
                        if (sub_2035ac(&v4, v18) & 1)
                        {
                            v27 = sub_19b1d0(v18);
                            if (v27)
                            {
                                if (sub_2035ac(&v1, v27) & 1)
                                {
                                    sub_19cca8(v27, v0);
                                    sub_19d5a8(v27, g_7632b78, &v6);
                                    sub_199704(v27, sub_198de0(v27) | 32);
                                    v29 = v22;
                                    v30 = (!v29->field_10 ? 0 : v29->field_18);
                                    if (v30 && !~(sub_198128(v30) & 1))
                                        sub_198eac(v30);
                                    sub_24fd28(v22, &v4);
                                    sub_24fd28(&v29->field_10, &v1);
                                    v22->field_20 = v14;
                                    a0->field_208();
                                }
                                else
                                {
                                    sub_198eac(v27);
                                }
                            }
                        }
                        v2 = 0;
                        if (v1)
                        {
                            v1 = 0;
                            sub_439c54(v1);
                        }
                    }
                    v5 = 0;
                    if (!v4)
                    {
                        if (v12->field_28 == v9)
                            return 0;
                        6813312();
                    }
                    else
                    {
                        v3 = 0;
                        sub_439c54(v4);
                        if (v12->field_28 == v9)
                            return 0;
                        6813312();
                    }
                }
            }
LABEL_24f964:
            v31 = 0;
        }
        else
        {
            v34 = (!a1[4] ? 0 : a1[5]);
            if (sub_198128(v34) & 1 && v34 || (v35 = (!a1[6] ? 0 : a1[7]), v31 = 1, sub_198128(v35) & 1 && v35))
            {
                if (!g_7632b60)
                {
                    /* unsupported instruction */;
                    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
                    {
                        sub_1269d0(123377504);
                        6813216();
                        sub_65eed8(123388920);
                    }
                    v36 = sub_43d298(123377512, 7032924, 7032924, 7064710);
                    if (v36)
                        v36 = sub_43d5e4(123377512, v36, 6837108, 1);
                    g_7632b60 = v36;
                }
                /* unsupported instruction */;
                if (!(*0x7632d50 & 1) && sub_65eda8(123940176))
                {
                    g_7632d46 = 0;
                    g_7632d28 = 0;
                    g_7632d38 = 0;
                    g_7632d18 = 0;
                    sub_126978(43518017, &g_7632d18, 54, 2822589417472955843);
                    sub_65eed8(123940176);
                }
                v37 = sub_24ee54(&g_7632d18);
                v31 = 0;
                if (v37 && g_7632b60)
                {
                    v38 = 123936920 + v14 * 16;
                    v39 = v38->field_a0;
                    v40 = (!v38->field_98 ? 0 : v38->field_a0);
                    if (!(sub_198128(v40) & 1) || !v40)
                    {
                        v31 = sub_19ca80(v37);
                        if (v31)
                        {
                            v39 = v31;
                            if (sub_2035ac(&v38->field_98, v39) & 1)
                            {
                                sub_199704(v39, sub_198de0(v39) | 32);
                                sub_19d5a8(v39, g_7632b78, &v6);
                                goto LABEL_24f824;
                            }
                            else
                            {
                                sub_198eac(v39);
                                v31 = 0;
                            }
                        }
                    }
                    else
                    {
LABEL_24f824:
                        if (sub_19cbdc(v39) != v37)
                        {
                            sub_19cca8(v39, v37);
                            sub_19d5a8(v39, g_7632b78, &v6);
                        }
                        g_7632b60();
                    }
                }
            }
        }
    }
    else
    {
        v31 = 1;
    }
    if (v12->field_28 == v9)
        return v31;
    6813312();
}
