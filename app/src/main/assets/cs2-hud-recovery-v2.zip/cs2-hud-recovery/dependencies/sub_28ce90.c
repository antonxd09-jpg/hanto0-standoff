typedef struct st_28ce90_2 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
} st_28ce90_2;

typedef struct st_28ce90_1 {
    uint128_t field_0;
    uint128_t field_10;
    uint128_t field_20;
    uint128_t field_30;
    uint128_t field_40;
    uint128_t field_50;
    uint128_t field_60;
    uint128_t field_70;
    uint128_t field_80;
    uint128_t field_90;
    uint128_t field_a0;
    uint128_t field_b0;
    uint128_t field_c0;
    uint128_t field_d0;
    uint128_t field_e0;
    uint128_t field_f0;
    uint128_t field_100;
    uint128_t field_110;
    uint128_t field_120;
    uint128_t field_130;
    uint128_t field_140;
    uint128_t field_150;
    uint128_t field_160;
    uint128_t field_170;
    uint128_t field_180;
    uint128_t field_190;
    unsigned int field_198;
    unsigned long long field_19c;
    unsigned long long field_1a0;
    char field_1a4;
} st_28ce90_1;

typedef struct st_28ce90_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_28ce90_0;

typedef struct st_28ce90_4 {
    unsigned long long field_0;
} st_28ce90_4;

typedef struct st_28ce90_3 {
    char padding_0[24];
    unsigned long long field_18;
    char padding_20[200];
    struct st_28ce90_4 *field_e8;
    char padding_f0[832];
    char field_430;
} st_28ce90_3;

extern unsigned long long g_7650668;
extern unsigned long long g_7650678;
extern unsigned long long g_7650680;
extern unsigned long long g_7650688;
extern unsigned long long g_7650690;
extern unsigned long long g_7650698;
extern unsigned long long g_76506e0;
extern unsigned long long g_76506e8;
extern char g_76506f0;
extern char g_76506f1;

unsigned int sub_28ce90(st_28ce90_3 *a0, st_28ce90_2 *a1)
{
    st_28ce90_0 *v8;  // tpidr_el0
    st_28ce90_1 *v9;  // x0
    long long v10;  // x20
    long long v11;  // x22
    long long v12;  // x25
    long long v13;  // x24
    long long v14;  // x23
    char v15;  // x8
    unsigned long long v16;  // x0
    unsigned long long v17;  // x0
    unsigned long v0;  // [bp-0x88], Other Possible Types: unsigned long long
    unsigned long long v1;  // [bp-0x80]
    unsigned long long v2;  // [bp-0x78]
    unsigned long v3;  // [bp-0x78]
    unsigned long long v4;  // [bp-0x70]
    unsigned long v5;  // [bp-0x68]
    char *v6;  // [bp-0x60]
    char v7;  // [bp+0x0]

    v6 = &v7;
    v5 = v8->field_28;
    sub_28d784();
    /* unsupported instruction */;
    if (!(*0x7650670 & 1) && sub_65eda8(124061296))
    {
        v9 = sub_679020(424);
        *(unsigned long long *)&v9->field_198 = 0;
        *(char *)&(&v9->field_198)[1] = 0;
        g_7650668 = v9;
        v9->field_0 = 0;
        v9->field_10 = 0;
        v9->field_20 = 0;
        v9->field_30 = 0;
        v9->field_40 = 0;
        v9->field_50 = 0;
        v9->field_60 = 0;
        v9->field_70 = 0;
        v9->field_80 = 0;
        v9->field_90 = 0;
        v9->field_a0 = 0;
        v9->field_b0 = 0;
        v9->field_c0 = 0;
        v9->field_d0 = 0;
        v9->field_e0 = 0;
        v9->field_f0 = 0;
        v9->field_100 = 0;
        v9->field_110 = 0;
        v9->field_120 = 0;
        v9->field_130 = 0;
        v9->field_140 = 0;
        v9->field_150 = 0;
        v9->field_160 = 0;
        v9->field_170 = 0;
        v9->field_180 = 0;
        v9->field_190 = 0;
        *(unsigned int *)((char *)&v9->field_190 + 8) = 3463342888;
        *(unsigned long long *)((char *)&v9->field_190 + 12) = 0;
        sub_65eed8(124061296);
    }
    if (a1)
    {
        if (!a1->field_10)
            v10 = 0;
        else
            v10 = a1->field_18;
        if (!(sub_198128(v10) & 1))
            v10 = 0;
        if (v10 && a0->field_430)
        {
            if (!a0->field_18)
                goto LABEL_28d274;
            if (g_76506f0)
            {
LABEL_28cf24:
                *(unsigned int *)(g_7650668 + 388) = 0;
                *(unsigned int *)(g_7650668 + 412) = 0;
                v3 = 0;
                v4 = 0;
                v0 = 0;
                v1 = 0;
                if (sub_22b63c(a0, 6847779, v10, &v3, &v0) & 1)
                    a0->field_e8();
                v1 = 0;
                if (v0)
                {
                    v0 = 0;
                    sub_439c54(v0);
                }
                v4 = 0;
                if (v3)
                {
                    v2 = 0;
                    sub_439c54(v3);
                }
            }
            else
            {
                if (g_76506f1)
                    goto LABEL_28d274;
                /* unsupported instruction */;
                if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
                {
                    sub_1269d0(123377504);
                    6813216();
                    sub_65eed8(123388920);
                }
                g_7650678 = sub_43d298(123377512, 6935571, 6951890, 7280676);
                g_7650680 = sub_43d298(123377512, 6935571, 6951890, 7061822);
                g_7650688 = sub_18deb4(g_7650680, 6935571, 6951890, 7061822);
                g_7650690 = sub_43d298(123377512, 7032507, 6935594, 7138039);
                if (!g_7650690)
                    g_7650690 = sub_43cab8(123377512, 6935594, 7138039);
                v11 = sub_43d298(123377512, 7331494, 6951890, 7083487);
                v12 = sub_43d298(123377512, 7032924, 7032924, 7064710);
                v13 = sub_43d298(123377512, 6935571, 6951890, 7268774);
                v14 = sub_18e1b4(v13, 6935571, 6951890, 7268774);
                if (v12)
                {
                    /* unsupported instruction */;
                    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
                    {
                        sub_1269d0(123377504);
                        6813216();
                        sub_65eed8(123388920);
                    }
                    g_7650698 = sub_43d5e4(123377512, v12, 7019487, 0);
                    if (g_7650698 && sub_28f694(124061344, v12, 6837108) & 1 && sub_28f694(124061352, v11, 6964049) & 1 && sub_28f764(v11) & 1 && sub_28f82c(124061368, v13, 7335248) & 1 && sub_28f82c(124061376, v13, 6837095) & 1 && sub_28f8fc(v14) & 1 && sub_28f9c4(v14) & 1)
                    {
                        v15 = 0;
                        if (sub_28fa8c(v14) & 1 && g_7650678 && g_7650680 && g_7650688)
                            v15 = g_7650690 != 0;
                    }
                    else
                    {
                        v15 = 0;
                    }
                }
                else
                {
                    v15 = 0;
                    g_7650698 = 0;
                }
                g_76506f0 = v15;
                if (v14)
                    v16 = sub_43d5e4(123377512, v14, 6915698, 0);
                else
                    v16 = 0;
                g_76506e0 = v16;
                if (v11)
                    v17 = sub_43d5e4(123377512, v11, 7129628, 0);
                else
                    v17 = 0;
                g_76506e8 = v17;
                if (g_76506f0)
                    goto LABEL_28cf24;
                g_76506f1 = 1;
            }
        }
    }
    else
    {
LABEL_28d274:
    }
    if (v8->field_28 == v5)
        return 0;
    6813312();
}
