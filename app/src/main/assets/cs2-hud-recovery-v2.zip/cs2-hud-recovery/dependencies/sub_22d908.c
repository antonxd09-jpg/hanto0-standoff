typedef struct st_22d908_1 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
    char padding_20[220];
    float field_fc;
    char field_100;
} st_22d908_1;

typedef struct st_22d908_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_22d908_0;

long long sub_22d908(long long a0, st_22d908_1 *a1, float a2)
{
    st_22d908_0 *v8;  // tpidr_el0
    float v9;  // s0
    unsigned long long v10;  // 4152
    long long v11;  // x20
    unsigned int v0;  // [bp-0x50]
    unsigned int v1;  // [bp-0x4c]
    unsigned long v2;  // [bp-0x48]
    unsigned int v3;  // [bp-0x40]
    unsigned int v4;  // [bp-0x3c]
    unsigned long v5;  // [bp-0x38]
    char *v6;  // [bp-0x28]
    char v7;  // [bp+0x0]

    v6 = &v7;
    v5 = v8->field_28;
    if (a1 && (!a1->field_100 || (v9 = fabsf(a1->field_fc - a2), v10 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v9), 0.009999999776482582f)) >> 5 & 3 | v9 < 0.009999999776482582f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v9)) * 0x10000000, 0, 0), !(v10 & 1))))
    {
        if (!a1->field_10)
            v11 = 0;
        else
            v11 = a1->field_18;
        a0 = sub_198128(v11);
        if (a0 & 1 && v11)
        {
            v2 = 0;
            0x67f8c0();
            v3 = v1;
            v4 = v0;
            a0 = sub_197738(v11, &v2);
            a1->field_fc = a2;
            a1->field_100 = 1;
        }
    }
    if (v8->field_28 == v5)
        return a0;
    6813312();
}
