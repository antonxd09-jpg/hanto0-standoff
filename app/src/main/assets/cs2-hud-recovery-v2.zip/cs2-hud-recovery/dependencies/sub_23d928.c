typedef struct st_22a7d8_0 {
    unsigned int field_0;
    char padding_4[4];
    unsigned long long field_8;
    unsigned long long field_10;
} st_22a7d8_0;

unsigned long long * sub_23d928(st_22a7d8_0 *a0, unsigned long long a1)
{
    if (a1 >> 31 & 1)
        return NULL;
    return sub_22a7d8(a0, a1);
}
