typedef struct st_439970_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_439970_0;

unsigned long long sub_439970(unsigned long long a0)
{
    st_439970_0 *v3;  // tpidr_el0
    unsigned long v0;  // [bp-0x48]
    char *v1;  // [bp-0x40]
    char v2;  // [bp+0x0]

    v1 = &v2;
    v0 = v3->field_28;
    if (a0)
    {
        /* unsupported instruction */;
        if (!(*0x77af0d8 & 1) && !(/* unsupported instruction */, *0x77af0d9 & 1))
        {
            /* unsupported instruction */;
            if (!(*0x77af0f8 & 1) && sub_65eda8(125497592))
            {
                sub_439e88();
                sub_65eed8(125497592);
            }
            if (!*(long long *)0x77af0e0)
                goto LABEL_439a60;
            sub_63d380(125497496);
            /* unsupported instruction */;
            if (!(*0x77af0d8 & 1))
            {
                /* unsupported instruction */;
                if (!(*0x77af0d9 & 1))
                    (*(long long *)0x77af0e0)();
            }
            sub_63d3ac(125497496);
            a0 = 0;
        }
        else
        {
LABEL_439a60:
            a0 = 0;
        }
    }
    if (v3->field_28 == v0)
        return a0;
    6813312();
}
