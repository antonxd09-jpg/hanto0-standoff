extern unsigned long long g_75e0728;
extern unsigned long long g_75e0738;

unsigned int sub_197da4(long long a0)
{
    long long v2;  // x0
    unsigned long long v3;  // x0
    char *v0;  // [bp-0x30]
    char v1;  // [bp+0x0]

    v0 = &v1;
    /* unsupported instruction */;
    if (!(*0x75e0730 & 1) && sub_65eda8(123602736))
    {
        g_75e0728 = sub_18ddf0();
        sub_65eed8(123602736);
    }
    /* unsupported instruction */;
    if (!(*0x75e0740 & 1) && sub_65eda8(123602752))
    {
        if (g_75e0728)
        {
            v2 = sub_126488();
            v3 = sub_43d5e4(v2 + 8, g_75e0728, 7000114, 0);
        }
        else
        {
            v3 = 0;
        }
        g_75e0738 = v3;
        sub_65eed8(123602752);
    }
    if (!g_75e0738)
    {
        return 0;
    }
    else if (sub_196900(a0) & 1)
    {
        goto *((void *)(g_75e0738));
    }
    else
    {
        return 0;
    }
}
