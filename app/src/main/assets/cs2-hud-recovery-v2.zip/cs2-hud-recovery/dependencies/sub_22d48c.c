typedef struct st_22d48c_0 {
    char padding_0[32];
    unsigned long long field_20;
    long long field_28;
    char padding_30[140];
    float field_bc;
} st_22d48c_0;

typedef struct st_22d48c_1 {
    char padding_0[440];
    struct st_22d48c_2 *field_1b8;
} st_22d48c_1;

typedef struct st_22d48c_2 {
    unsigned long long field_0;
} st_22d48c_2;

st_22d48c_1 * sub_22d48c(st_22d48c_1 *a0, st_22d48c_0 *a1, float a2)
{
    unsigned long long v6;  // x30
    unsigned long long v7;  // x21
    unsigned long long v8;  // x20
    unsigned long long v9;  // x19
    float v10;  // s0
    unsigned long long v11;  // 4184
    st_22d48c_1 *v12;  // x0
    long long v13;  // x9
    char *v0;  // [bp-0x28]
    unsigned long long v1;  // [bp-0x20]
    unsigned long long v2;  // [bp-0x18]
    unsigned long long v3;  // [bp-0x10]
    unsigned long long v4;  // [bp-0x8]
    char v5;  // [bp+0x0]

    if (!a1)
        return a0;
    v0 = &v5;
    v1 = v6;
    v2 = v7;
    v3 = v8;
    v4 = v9;
    v10 = fabsf(a1->field_bc - a2);
    v11 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v10), 0.0005000000237487257f)) >> 5 & 3 | v10 < 0.0005000000237487257f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v10)) * 0x10000000, 0, 0);
    v12 = a0;
    if (!(v11 & 1))
    {
        v13 = a1->field_28;
        if (!a1->field_20)
            v13 = 0;
        v12 = sub_198128(v13);
        if (v12 & 0x1 && v13)
            a0->field_1b8();
    }
    return v12;
}
