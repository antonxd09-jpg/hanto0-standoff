typedef struct st_22cfc0_0 {
    char padding_0[64];
    unsigned long long field_40;
    long long field_48;
    char padding_50[56];
    char field_88;
    char field_89;
    char field_8a;
    char padding_8b[5];
    unsigned long long field_90;
    char padding_98[8];
    char field_a0;
} st_22cfc0_0;

typedef struct st_22cfc0_1 {
    char field_0;
    char field_1;
    char padding_2[6];
    unsigned long long field_8;
    struct st_22cfc0_2 *field_10;
} st_22cfc0_1;

typedef struct st_22cfc0_3 {
    char padding_0[504];
    struct st_22cfc0_4 *field_1f8;
} st_22cfc0_3;

typedef struct st_22cfc0_4 {
    unsigned long long field_0;
} st_22cfc0_4;

typedef struct st_22cfc0_2 {
    char field_0;
} st_22cfc0_2;

st_22cfc0_3 * sub_22cfc0(st_22cfc0_3 *a0, st_22cfc0_0 *a1, st_22cfc0_1 *a2)
{
    unsigned long v2;  // x9
    unsigned long v3;  // x10
    long long v12;  // x9
    st_22cfc0_3 *v13;  // x0
    st_22cfc0_3 *v14;  // x0
    unsigned long long v4;  // x11
    unsigned long long v5;  // x8
    unsigned long long v6;  // x12
    unsigned long long v7;  // x13
    char *v8;  // x11
    char *v9;  // x9
    unsigned long long v10;  // x8
    st_22cfc0_3 *v11;  // x0
    char *v0;  // [bp-0x40]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (!a1)
        return a0;
    if (a1->field_a0)
    {
        v2 = a1->field_88;
        v3 = a2->field_0;
        v4 = a2->field_8;
        v5 = v2 >> 1;
        v6 = v3 >> 1;
        if (!(v2 & 1))
            v7 = v5;
        else
            v7 = a1->field_90;
        if (!(v3 & 1))
            v4 = v6;
        if (v7 == v4)
        {
            v8 = a2->field_10;
            if (!(v3 & 1))
                v8 = &a2->field_1;
            if (v2 & 1)
            {
                v11 = 6813376();
                if (!(unsigned int)v11)
                    return v11;
            }
            else if ((unsigned int)v2 >= 2)
            {
                v9 = &a1->field_89;
                while (1)
                {
                    v10 = v5;
                    if (*v9 != *v8)
                        break;
                    v5 = v10 - 1;
                    v9 += 1;
                    v8 += 1;
                    if (v10 == 1)
                        return a0;
                }
            }
            else
            {
                return a0;
            }
        }
    }
    v12 = a1->field_48;
    if (!a1->field_40)
        v12 = 0;
    v13 = sub_198128(v12);
    if (!(v13 & 0x1))
    {
        return v13;
    }
    else if (v12)
    {
        /* unsupported instruction */;
        if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
        {
            sub_1269d0(123377504);
            6813216();
            sub_65eed8(123388920);
        }
        v14 = sub_43cd88();
        if (!v14)
            return v14;
        a0->field_1f8();
    }
    else
    {
        return v13;
    }
}
