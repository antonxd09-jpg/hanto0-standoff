typedef struct st_22d238_0 {
    char padding_0[32];
    unsigned long long field_20;
    long long field_28;
    unsigned long long field_30;
    long long field_38;
    unsigned long long field_40;
    long long field_48;
    char padding_50[84];
    float field_a4;
    float field_a8;
    float field_ac;
    float field_b0;
    char field_b4;
    char padding_b5[104];
    char field_11d;
} st_22d238_0;

typedef struct st_22d238_2 {
    unsigned long long field_0;
} st_22d238_2;

typedef struct st_22d238_1 {
    char padding_0[360];
    char field_168;
    char padding_169[263];
    struct st_22d238_2 *field_270;
    char padding_278[384];
    struct st_22d238_2 *field_3f8;
    unsigned long long field_400;
    char padding_408[194];
    char field_4ca;
} st_22d238_1;

st_22d238_1 * sub_22d238(st_22d238_1 *a0, st_22d238_0 *a1, float a2, float a3, float a4, float a5)
{
    unsigned long long v7;  // x30
    unsigned long long v8;  // x22
    unsigned long long v17;  // 4157
    float v18;  // s0
    float v19;  // s0
    unsigned long long v20;  // 4157
    float v21;  // s0
    float v22;  // s0
    unsigned long long v23;  // 4157
    st_22d238_1 *v24;  // x0
    long long v25;  // x21
    unsigned long long v9;  // x21
    long long v27;  // x9
    long long v28;  // x21
    unsigned long long v10;  // x20
    unsigned long long v11;  // x19
    float v12;  // s0
    float v13;  // s0
    unsigned long long v14;  // 4164
    float v15;  // s0
    float v16;  // s0
    char *v0;  // [bp-0x30]
    unsigned long long v1;  // [bp-0x28]
    unsigned long long v2;  // [bp-0x20]
    unsigned long long v3;  // [bp-0x18]
    unsigned long long v4;  // [bp-0x10]
    unsigned long long v5;  // [bp-0x8]
    char v6;  // [bp+0x0]

    if (!a1)
        return a0;
    v0 = &v6;
    v1 = v7;
    v2 = v8;
    v3 = v9;
    v4 = v10;
    v5 = v11;
    if (!a1->field_b4 || !(v12 = a1->field_a4, v13 = (a1->field_a4 - a2) * (a1->field_a4 - a2), v14 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int((a1->field_a4 - a2) * (a1->field_a4 - a2)), 2.500000277905201e-07f)) >> 5 & 3 | (v12 - a2) * (v12 - a2) < 2.500000277905201e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((v12 - a2) * (v12 - a2))) * 0x10000000, 0, 0), !(v14 & 1) && (v15 = a1->field_a8, v16 = (a1->field_a8 - a3) * (a1->field_a8 - a3), v17 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int((a1->field_a8 - a3) * (a1->field_a8 - a3)), 2.500000277905201e-07f)) >> 5 & 3 | (v15 - a3) * (v15 - a3) < 2.500000277905201e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((v15 - a3) * (v15 - a3))) * 0x10000000, 0, 0), !(v17 & 1) && (v18 = a1->field_ac, v19 = (a1->field_ac - a4) * (a1->field_ac - a4), v20 = arm64g_calculate_condition(80, (((((char)(CmpF(__float_as_int((a1->field_ac - a4) * (a1->field_ac - a4)), 2.500000277905201e-07f)) >> 5 & 3 | (v18 - a4) * (v18 - a4) < 2.500000277905201e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((v18 - a4) * (v18 - a4))) * 0x10000000, 0, 0), !(v20 & 1) && (v21 = a1->field_b0, v22 = (a1->field_b0 - a5) * (a1->field_b0 - a5), v23 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int((a1->field_b0 - a5) * (a1->field_b0 - a5)), 2.500000277905201e-07f)) >> 5 & 3 | (v21 - a5) * (v21 - a5) < 2.500000277905201e-07f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan((v21 - a5) * (v21 - a5))) * 0x10000000, 0, 0), v24 = a0, v23 & 1)))))
    {
        if (!a1->field_40)
            v25 = 0;
        else
            v25 = a1->field_48;
        if (sub_198128(v25) & 1 && v25)
        {
            if (a0->field_4ca && a1->field_11d && a0->field_3f8 && a0->field_400)
                a0->field_3f8();
            a0->field_270();
        }
        v27 = a1->field_28;
        if (!a1->field_20)
            v27 = 0;
        v24 = sub_198128(v27);
        if (!(v24 & 0x1) || !v27)
        {
            v28 = a1->field_38;
            if (!a1->field_30)
                v28 = 0;
            v24 = sub_198128(v28);
            if (v24 & 1)
                goto LABEL_22d388;
        }
        else if (a1->field_20)
        {
            v28 = a1->field_28;
LABEL_22d388:
            if (v28)
                (*(long long *)&a0->field_168)();
        }
    }
    return v24;
}
