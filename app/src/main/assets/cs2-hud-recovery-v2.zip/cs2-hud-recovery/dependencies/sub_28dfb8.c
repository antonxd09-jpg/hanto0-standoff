typedef struct st_28dfb8_17 {
    unsigned long long field_0;
    unsigned long long field_8;
    char padding_10[136];
    unsigned int field_98;
    unsigned int field_9c;
    unsigned int field_a0;
    unsigned int field_a4;
} st_28dfb8_17;

typedef struct st_28dfb8_7 {
    unsigned short field_0;
    unsigned short field_2;
    unsigned short field_4;
    unsigned short field_6;
    unsigned long long field_8;
    unsigned short field_10;
    unsigned short field_12;
    unsigned short field_14;
    unsigned short field_16;
} st_28dfb8_7;

typedef struct st_28dfb8_4 {
    char padding_0[136];
    unsigned long long field_88;
    unsigned long long field_90;
    char padding_98[96];
    unsigned long long field_f8;
    unsigned long long field_100;
    char padding_108[112];
    char field_178;
    char field_179;
    char padding_17a[2];
    unsigned int field_17c;
} st_28dfb8_4;

typedef struct st_28dfb8_5 {
    char padding_0[152];
    unsigned long long field_98;
    unsigned long long field_a0;
    unsigned long long field_a8;
    unsigned long long field_b0;
    unsigned long long field_b8;
    unsigned long long field_c0;
    unsigned long long field_c8;
    unsigned long long field_d0;
    unsigned long long field_d8;
    unsigned long long field_e0;
    long long field_e8;
    long long field_f0;
    char padding_f8[136];
    unsigned int field_180;
    int field_184;
    unsigned int field_188;
    unsigned int field_18c;
} st_28dfb8_5;

typedef struct st_28dfb8_3 {
    uint128_t field_0;
    uint128_t field_10;
    uint128_t field_20;
    uint128_t field_30;
    uint128_t field_40;
    uint128_t field_50;
    uint128_t field_60;
    uint128_t field_70;
    uint128_t field_80;
    uint128_t field_90;
    uint128_t field_a0;
    uint128_t field_b0;
    uint128_t field_c0;
    uint128_t field_d0;
    uint128_t field_e0;
    uint128_t field_f0;
    uint128_t field_100;
    uint128_t field_110;
    uint128_t field_120;
    uint128_t field_130;
    uint128_t field_140;
    uint128_t field_150;
    uint128_t field_160;
    uint128_t field_170;
    uint128_t field_180;
    uint128_t field_190;
    unsigned int field_198;
    unsigned long long field_19c;
    unsigned long long field_1a0;
    char field_1a4;
} st_28dfb8_3;

typedef struct st_28dfb8_0 {
    char padding_0[336];
    struct st_28dfb8_1 *field_150;
    char padding_158[128];
    struct st_28dfb8_1 *field_1d8;
} st_28dfb8_0;

typedef struct st_28dfb8_2 {
    char padding_0[40];
    unsigned long long field_28;
} st_28dfb8_2;

typedef struct st_28dfb8_1 {
    unsigned long long field_0;
} st_28dfb8_1;

extern unsigned long long g_7650668;
extern unsigned long g_7650678;
extern unsigned long g_7650680;
extern unsigned long g_7650688;
extern unsigned long g_7650690;
extern unsigned long g_76506e0;

int sub_28dfb8(st_28dfb8_0 *a0, unsigned int a1, float a2)
{
    st_28dfb8_2 *v14;  // tpidr_el0
    st_28dfb8_0 *v15;  // x0
    long long v24;  // x21
    float v25;  // s0
    unsigned long long v26;  // 4129
    st_28dfb8_3 *v27;  // x0
    long long *v28;  // x23
    long long v29;  // x21
    st_28dfb8_3 *v30;  // x0
    void* v31;  // x23
    long long v32;  // x21
    st_28dfb8_3 *v33;  // x0
    st_28dfb8_3 *v16;  // x0
    st_28dfb8_5 *v34;  // x21
    st_28dfb8_5 *v35;  // x22
    st_28dfb8_17 *v36;  // x22
    unsigned long v37;  // x23
    long long v38;  // x23
    long long v39;  // x23
    float v40;  // s0
    unsigned long long v41;  // 4129
    unsigned long long v42;  // x23
    long long v43;  // x24
    void* v17;  // x26
    unsigned long long v44;  // x0
    unsigned long long v45;  // x0
    unsigned long long v46;  // x24
    long long v47;  // x23
    unsigned long v48;  // x24
    unsigned int v49;  // w1
    unsigned int v50;  // w22
    long long v51;  // x0
    long long v52;  // x23
    long long v53;  // x0
    char *v18;  // x24
    int v54;  // w8
    unsigned long long v55;  // x0
    unsigned int v56;  // w8
    char *v57;  // x0
    long long v58;  // x0
    long long v59;  // x0
    long long v60;  // x0
    long long v61;  // x0
    long long v62;  // x0
    long long v63;  // x0
    float v19;  // s0
    void* v64;  // x8
    long long v65;  // x0
    long long v66;  // x21
    long long v67;  // x0
    long long v68;  // x0
    unsigned long long i;  // x8
    unsigned short *v70;  // x9
    __m128i v72;  // q1
    uint128_t v73;  // q2
    unsigned long long v20;  // 4129
    unsigned short v74;  // x10
    unsigned short v75;  // x12
    unsigned long long v76;  // d1
    long long v78;  // x0
    long long v79;  // x0
    long long v80;  // x0
    long long v81;  // x0
    long long v82;  // x0
    long long v83;  // x0
    st_28dfb8_3 *v21;  // x0
    long long v84;  // x0
    long long v85;  // x0
    long long v86;  // x21
    long long v87;  // x0
    long long v88;  // x0
    long long v89;  // x22
    int v90;  // w21
    char *v91;  // x20
    st_28dfb8_3 *v92;  // x0
    long long v93;  // x21
    st_28dfb8_4 *v22;  // x20
    long long v94;  // x22
    long long v95;  // x22
    long long v96;  // x22
    char *v97;  // x23
    char *v98;  // x20
    long long v99;  // x22
    long long v100;  // x22
    unsigned long v101;  // x20
    long long v23;  // x21
    unsigned long long v0;  // [bp-0xe8]
    long long v1;  // [bp-0xd8]
    uint128_t v2;  // [bp-0xd0], Other Possible Types: unsigned long
    unsigned long long v3;  // [bp-0xc0]
    unsigned int v4;  // [bp-0xb8]
    unsigned long long v5;  // [bp-0xb0]
    unsigned long v6;  // [bp-0xa8]
    st_28dfb8_7 *v7;  // [bp-0x98]
    unsigned long v8;  // [bp-0x90]
    unsigned long v9;  // [bp-0x88]
    unsigned long v10;  // [bp-0x80]
    unsigned long v11;  // [bp-0x78]
    char *v12;  // [bp-0x60]
    char v13;  // [bp+0x0]

    v12 = &v13;
    v11 = v14->field_28;
    /* unsupported instruction */;
    v15 = a0;
    if (!(*0x7650670 & 1))
    {
        v15 = sub_65eda8(124061296);
        if ((unsigned int)v15)
        {
            v16 = sub_679020(424);
            *(unsigned long long *)&v16->field_198 = 0;
            *(char *)&(&v16->field_198)[1] = 0;
            g_7650668 = v16;
            v16->field_0 = 0;
            v16->field_10 = 0;
            v16->field_20 = 0;
            v16->field_30 = 0;
            v16->field_40 = 0;
            v16->field_50 = 0;
            v16->field_60 = 0;
            v16->field_70 = 0;
            v16->field_80 = 0;
            v16->field_90 = 0;
            v16->field_a0 = 0;
            v16->field_b0 = 0;
            v16->field_c0 = 0;
            v16->field_d0 = 0;
            v16->field_e0 = 0;
            v16->field_f0 = 0;
            v16->field_100 = 0;
            v16->field_110 = 0;
            v16->field_120 = 0;
            v16->field_130 = 0;
            v16->field_140 = 0;
            v16->field_150 = 0;
            v16->field_160 = 0;
            v16->field_170 = 0;
            v16->field_180 = 0;
            v16->field_190 = 0;
            *(unsigned int *)((char *)&v16->field_190 + 8) = 3463342888;
            *(unsigned long long *)((char *)&v16->field_190 + 12) = 0;
            v15 = sub_65eed8(124061296);
        }
    }
    v17 = g_7650668;
    if ((char)v17[104])
    {
        if (a1 & 1)
        {
            v18 = sub_28da38();
            v15 = sub_282ee8(v18);
            if (v15 & 0x1 || (int)v17[400] || !(v19 = __int_as_float((int)v17[412]), v20 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(v19), __float_as_int(a2))) >> 5 & 3 | v19 < a2) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v19, a2)) * 0x10000000, 0, 0), v20 & 1))
            {
                *(float *)&v17[412] = a2 + 1.0f;
                /* unsupported instruction */;
                if (!(*0x7650670 & 1) && sub_65eda8(124061296))
                {
                    v21 = sub_679020(424);
                    *(unsigned long long *)&v21->field_198 = 0;
                    *(char *)&(&v21->field_198)[1] = 0;
                    g_7650668 = v21;
                    v21->field_0 = 0;
                    v21->field_10 = 0;
                    v21->field_20 = 0;
                    v21->field_30 = 0;
                    v21->field_40 = 0;
                    v21->field_50 = 0;
                    v21->field_60 = 0;
                    v21->field_70 = 0;
                    v21->field_80 = 0;
                    v21->field_90 = 0;
                    v21->field_a0 = 0;
                    v21->field_b0 = 0;
                    v21->field_c0 = 0;
                    v21->field_d0 = 0;
                    v21->field_e0 = 0;
                    v21->field_f0 = 0;
                    v21->field_100 = 0;
                    v21->field_110 = 0;
                    v21->field_120 = 0;
                    v21->field_130 = 0;
                    v21->field_140 = 0;
                    v21->field_150 = 0;
                    v21->field_160 = 0;
                    v21->field_170 = 0;
                    v21->field_180 = 0;
                    v21->field_190 = 0;
                    *(unsigned int *)((char *)&v21->field_190 + 8) = 3463342888;
                    *(unsigned long long *)((char *)&v21->field_190 + 12) = 0;
                    sub_65eed8(124061296);
                }
                v22 = g_7650668;
                v23 = (!v22->field_88 ? 0 : v22->field_90);
                if (!(sub_198128(v23) & 1) || !v23 || !(v24 = (!v22->field_f8 ? 0 : v22->field_100), sub_198128(v24) & 1 && v24))
                {
                    v25 = *(float *)&v22->field_17c;
                    v26 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(v25), __float_as_int(a2))) >> 5 & 3 | v25 < a2) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v25, a2)) * 0x10000000, 0, 0);
                    if (!(v26 & 1))
                    {
                        *(float *)&v22->field_17c = a2 + 5.0f;
                        /* unsupported instruction */;
                        if (!(*0x7650670 & 1) && sub_65eda8(124061296))
                        {
                            v27 = sub_679020(424);
                            *(unsigned long long *)&v27->field_198 = 0;
                            *(char *)&(&v27->field_198)[1] = 0;
                            g_7650668 = v27;
                            v27->field_0 = 0;
                            v27->field_10 = 0;
                            v27->field_20 = 0;
                            v27->field_30 = 0;
                            v27->field_40 = 0;
                            v27->field_50 = 0;
                            v27->field_60 = 0;
                            v27->field_70 = 0;
                            v27->field_80 = 0;
                            v27->field_90 = 0;
                            v27->field_a0 = 0;
                            v27->field_b0 = 0;
                            v27->field_c0 = 0;
                            v27->field_d0 = 0;
                            v27->field_e0 = 0;
                            v27->field_f0 = 0;
                            v27->field_100 = 0;
                            v27->field_110 = 0;
                            v27->field_120 = 0;
                            v27->field_130 = 0;
                            v27->field_140 = 0;
                            v27->field_150 = 0;
                            v27->field_160 = 0;
                            v27->field_170 = 0;
                            v27->field_180 = 0;
                            v27->field_190 = 0;
                            *(unsigned int *)((char *)&v27->field_190 + 8) = 3463342888;
                            *(unsigned long long *)((char *)&v27->field_190 + 12) = 0;
                            sub_65eed8(124061296);
                        }
                        v28 = g_7650668;
                        v29 = (!v28[0x11] ? 0 : v28[18]);
                        if (!(sub_198128(v29) & 1) || !v29)
                        {
                            v84 = v28[0x11];
                            v28[18] = 0;
                            if (v84)
                            {
                                v28[0x11] = 0;
                                sub_439c54(v84);
                            }
                            v85 = sub_18b7c0(*0x644ace8, 943645);
                            if (v85)
                            {
                                v86 = v85;
                                if ((!v28[0x11] ? 0 : v28[18]) == v85)
                                    (*(long long *)0x76506b8)();
                                v87 = sub_439970(v86);
                                if (v87)
                                {
                                    v88 = v28[0x11];
                                    v28[18] = 0;
                                    if (v88)
                                    {
                                        v28[0x11] = 0;
                                        sub_439c54(v88);
                                    }
                                    v28[0x11] = v87;
                                    v28[18] = v86;
                                    (*(long long *)0x76506b8)();
                                }
                                else
                                {
                                    sub_198eac(v86);
                                }
                            }
                        }
                        else
                        {
                            /* unsupported instruction */;
                            if (!(*0x7650670 & 1) && sub_65eda8(124061296))
                            {
                                v30 = sub_679020(424);
                                *(unsigned long long *)&v30->field_198 = 0;
                                *(char *)&(&v30->field_198)[1] = 0;
                                g_7650668 = v30;
                                v30->field_0 = 0;
                                v30->field_10 = 0;
                                v30->field_20 = 0;
                                v30->field_30 = 0;
                                v30->field_40 = 0;
                                v30->field_50 = 0;
                                v30->field_60 = 0;
                                v30->field_70 = 0;
                                v30->field_80 = 0;
                                v30->field_90 = 0;
                                v30->field_a0 = 0;
                                v30->field_b0 = 0;
                                v30->field_c0 = 0;
                                v30->field_d0 = 0;
                                v30->field_e0 = 0;
                                v30->field_f0 = 0;
                                v30->field_100 = 0;
                                v30->field_110 = 0;
                                v30->field_120 = 0;
                                v30->field_130 = 0;
                                v30->field_140 = 0;
                                v30->field_150 = 0;
                                v30->field_160 = 0;
                                v30->field_170 = 0;
                                v30->field_180 = 0;
                                v30->field_190 = 0;
                                *(unsigned int *)((char *)&v30->field_190 + 8) = 3463342888;
                                *(unsigned long long *)((char *)&v30->field_190 + 12) = 0;
                                sub_65eed8(124061296);
                            }
                            v31 = g_7650668;
                            v32 = (!(long long)v31[248] ? 0 : (long long)v31[0x100]);
                            if (sub_198128(v32) & 1 && v32 && (long long)v31[264] && (long long)v31[272] && (long long)v31[280] && (long long)v31[288] && (long long)v31[296] && (long long)v31[304] && (long long)v31[312] && (long long)v31[320] && (long long)v31[328] && (long long)v31[336])
                                goto LABEL_28e08c;
                            v58 = (long long)v31[248];
                            *(long long *)&v31[0x100] = 0;
                            if (v58)
                            {
                                *(long long *)&v31[248] = 0;
                                sub_439c54(v58);
                            }
                            v59 = (long long)v31[264];
                            *(unsigned long long *)&v31[272] = 0;
                            if (v59)
                            {
                                *(long long *)&v31[264] = 0;
                                sub_439c54(v59);
                            }
                            v60 = (long long)v31[280];
                            *(unsigned long long *)&v31[288] = 0;
                            if (v60)
                            {
                                *(long long *)&v31[280] = 0;
                                sub_439c54(v60);
                            }
                            v61 = (long long)v31[296];
                            *(unsigned long long *)&v31[304] = 0;
                            if (v61)
                            {
                                *(long long *)&v31[296] = 0;
                                sub_439c54(v61);
                            }
                            v62 = (long long)v31[312];
                            *(unsigned long long *)&v31[320] = 0;
                            if (v62)
                            {
                                *(long long *)&v31[312] = 0;
                                sub_439c54(v62);
                            }
                            v63 = (long long)v31[328];
                            *(unsigned long long *)&v31[336] = 0;
                            if (v63)
                            {
                                *(long long *)&v31[328] = 0;
                                v63 = sub_439c54(v63);
                            }
                            v64 = v31 + 344;
                            *(uint128_t *)v64 = 0;
                            *(uint128_t *)&v64[16] = 0;
                            v65 = sub_367eb4(v63);
                            v2 = 0;
                            v9 = 0;
                            v10 = 0;
                            v7 = NULL;
                            v8 = 0;
                            if (v65)
                            {
                                v66 = v65;
                                if ((!(long long)v31[248] ? 0 : (long long)v31[0x100]) != v65)
                                {
                                    v67 = sub_439970(v66);
                                    if (!v67)
                                        goto LABEL_28e564;
                                    v68 = (long long)v31[248];
                                    *(long long *)&v31[0x100] = 0;
                                    if (v68)
                                    {
                                        *(long long *)&v31[248] = 0;
                                        sub_439c54(v68);
                                    }
                                    *(long long *)&v31[248] = v67;
                                    *(long long *)&v31[0x100] = v66;
                                }
                                if (sub_28fb54(g_7650678, 0x4000, 12, v31 + 264, &v2) && sub_28fb54(g_7650688, 0x4000, 4, v31 + 280, &v10) && sub_28fb54(g_7650680, 0x4000, 8, v31 + 296, &v9) && sub_28fb54(g_7650680, 0x4000, 8, v31 + 312, &v8) && sub_28fb54(g_7650690, 0x6000, 2, v31 + 328, &v7))
                                {
                                    i = 0;
                                    *(unsigned long *)&v31[344] = v2;
                                    *(unsigned long *)&v31[352] = v9;
                                    v70 = &v7->field_10;
                                    *(unsigned long *)&v31[360] = v8;
                                    *(unsigned long *)&v31[368] = v10;
                                    do
                                    {
                                        v72 = __dirty_unsupported_Iop_ZeroHI64ofV128(_mm_slli_epi32(__double_as_longlong(__longlong_as_double(i)), 2));
                                        v73 = __dirty_unsupported_Iop_ZeroHI64ofV128(CatEvenLanesV(CatEvenLanesV(_mm_unpacklo_epi64(v72, v72), _mm_unpacklo_epi64(v72, v72)), CatEvenLanesV(_mm_unpacklo_epi64(v72, v72), _mm_unpacklo_epi64(v72, v72))));
                                        v74 = _mm_cvtsi128_si32(v72);
                                        *(unsigned short *)((char *)v70 - 16) = v74;
                                        v75 = v74 | 6;
                                        v76 = __dirty_unsupported_Iop_ZeroHI64ofV128(v73 | *(unsigned long long *)&*(double *)0x6833c8);
                                        *(unsigned short *)((char *)v70 - 10) = v74;
                                        *(unsigned short *)((char *)v70 - 14) = v74 | 1;
                                        *v70 = v75;
                                        v70[2] = v75;
                                        *(unsigned short *)((char *)v70 - 12) = v76;
                                        *(unsigned long long *)((char *)v70 - 8) = v76;
                                        v70[3] = v74 | 7;
                                        v70[1] = *(unsigned short *)((void*)&v76 + 4);
                                        i += 2;
                                        v70 += 12;
                                    } while (i != 0x1000);
                                    if (!g_76506e0)
                                        a0->field_150();
                                    g_76506e0();
                                }
LABEL_28e564:
                                sub_198eac(v66);
                                goto LABEL_28e56c;
                            }
                            else
                            {
LABEL_28e56c:
                                v78 = (long long)v31[248];
                                *(long long *)&v31[0x100] = 0;
                                if (v78)
                                {
                                    *(long long *)&v31[248] = 0;
                                    sub_439c54(v78);
                                }
                                v79 = (long long)v31[264];
                                *(unsigned long long *)&v31[272] = 0;
                                if (v79)
                                {
                                    *(long long *)&v31[264] = 0;
                                    sub_439c54(v79);
                                }
                                v80 = (long long)v31[280];
                                *(unsigned long long *)&v31[288] = 0;
                                if (v80)
                                {
                                    *(long long *)&v31[280] = 0;
                                    sub_439c54(v80);
                                }
                                v81 = (long long)v31[296];
                                *(unsigned long long *)&v31[304] = 0;
                                if (v81)
                                {
                                    *(long long *)&v31[296] = 0;
                                    sub_439c54(v81);
                                }
                                v82 = (long long)v31[312];
                                *(unsigned long long *)&v31[320] = 0;
                                if (v82)
                                {
                                    *(long long *)&v31[312] = 0;
                                    sub_439c54(v82);
                                }
                                v83 = (long long)v31[328];
                                *(unsigned long long *)&v31[336] = 0;
                                if (v83)
                                {
                                    *(long long *)&v31[328] = 0;
                                    sub_439c54(v83);
                                }
                            }
                        }
                    }
                    if (sub_282ee8(v18) & 1)
                    {
                        sub_282e5c(v18, 0);
                        goto LABEL_28e854;
                    }
                }
LABEL_28e08c:
                /* unsupported instruction */;
                if (!(*0x7650670 & 1) && sub_65eda8(124061296))
                {
                    v33 = sub_679020(424);
                    *(unsigned long long *)&v33->field_198 = 0;
                    *(char *)&(&v33->field_198)[1] = 0;
                    g_7650668 = v33;
                    v33->field_0 = 0;
                    v33->field_10 = 0;
                    v33->field_20 = 0;
                    v33->field_30 = 0;
                    v33->field_40 = 0;
                    v33->field_50 = 0;
                    v33->field_60 = 0;
                    v33->field_70 = 0;
                    v33->field_80 = 0;
                    v33->field_90 = 0;
                    v33->field_a0 = 0;
                    v33->field_b0 = 0;
                    v33->field_c0 = 0;
                    v33->field_d0 = 0;
                    v33->field_e0 = 0;
                    v33->field_f0 = 0;
                    v33->field_100 = 0;
                    v33->field_110 = 0;
                    v33->field_120 = 0;
                    v33->field_130 = 0;
                    v33->field_140 = 0;
                    v33->field_150 = 0;
                    v33->field_160 = 0;
                    v33->field_170 = 0;
                    v33->field_180 = 0;
                    v33->field_190 = 0;
                    *(unsigned int *)((char *)&v33->field_190 + 8) = 3463342888;
                    *(unsigned long long *)((char *)&v33->field_190 + 12) = 0;
                    sub_65eed8(124061296);
                }
                v34 = g_7650668;
                v35 = v34;
                v1 = sub_28da38();
                v36 = &v35->field_e8;
                v37 = (!v35->field_e8 ? 0 : v34->field_f0);
                if (sub_198128(v37) & 1 && v37 && (v38 = (!v34->field_98 ? 0 : v34->field_a0), sub_198128(v38) & 1 && v38 && (v39 = (!v34->field_a8 ? 0 : v34->field_b0), sub_198128(v39) & 1 && v39 && v34->field_b8 && v34->field_c0 && v34->field_c8 && v34->field_d0)))
                {
LABEL_28e6fc:
                    v50 = 1;
                }
                else if (2 < v34->field_184 || (v40 = *(float *)&v34->field_180, v41 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v40), __float_as_int(a2))) >> 5 & 3 | v40 < a2) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isunordered(v40, a2)) * 0x10000000, 0, 0), !(v41 & 1)))
                {
                    v50 = 0;
                }
                else
                {
                    v42 = v34->field_e0;
                    v43 = (!v34->field_d8 ? 0 : v42);
                    if (sub_198128(v43) & 1 && v43)
                    {
LABEL_28e620:
                        v0 = v42;
                        if (sub_28fd5c(a0, &v34->field_98, &v34->field_b8, 180, 200, v1 + 866228) & 1 && sub_28fd5c(a0, &v34->field_a8, &v34->field_c8, 74, 42, v1 + 1010228) & 1)
                        {
                            v47 = v34->field_f0;
                            v48 = (!v34->field_e8 ? 0 : v47);
                            if (sub_198128(v48) & 1 && v48)
                            {
                                v49 = v34->field_188;
                                v34->field_184 = 0;
                                if (!v49)
                                    v34->field_188 = sub_19e714(7061840);
                                v18 = v18;
                                if (!v34->field_18c)
                                    v34->field_18c = sub_19e714(7170121);
                                sub_19d788(v47);
                                sub_19d788(v47, v34->field_18c, (!v34->field_a8 ? 0 : v34->field_b0));
                                goto LABEL_28e6fc;
                            }
                            else
                            {
                                v51 = v34->field_e8;
                                v34->field_f0 = 0;
                                if (v51)
                                {
                                    v36->field_0 = 0;
                                    sub_439c54(v51);
                                }
                                v52 = sub_19ca80(v0);
                                if (sub_198128(v52) & 1 && sub_2035ac(v36, v52) & 1)
                                    a0->field_150();
                                if (v52)
                                    sub_198eac(v52);
                                v53 = v34->field_e8;
                                v34->field_f0 = 0;
                                if (v53)
                                {
                                    v36->field_0 = 0;
                                    sub_439c54(v53);
                                }
                            }
                        }
                        v54 = v34->field_184;
                        goto LABEL_28e7f8;
                    }
                    else
                    {
                        v42 = sub_24ee54(*0x7650620);
                        if (sub_198128(v42) & 1)
                        {
                            v44 = v34->field_d8;
                            if ((!v34->field_d8 ? 0 : v34->field_e0) != v42)
                            {
                                if (v42)
                                {
                                    v45 = sub_439970(v42);
                                    if (!v45)
                                        goto LABEL_28e758;
                                    v46 = v45;
                                    v44 = v34->field_d8;
                                }
                                else
                                {
                                    v46 = 0;
                                }
                                v34->field_e0 = 0;
                                if (v44)
                                {
                                    v34->field_d8 = 0;
                                    sub_439c54();
                                }
                                v34->field_d8 = v46;
                                v34->field_e0 = v42;
                                goto LABEL_28e620;
                            }
                        }
                        else
                        {
LABEL_28e758:
                            v55 = v34->field_d8;
                            v34->field_e0 = 0;
                            if (v55)
                            {
                                v34->field_d8 = 0;
                                sub_439c54(v55);
                            }
                            v54 = v34->field_184;
LABEL_28e7f8:
                            v50 = 0;
                            v56 = v54 + 1;
                            v34->field_184 = v56;
                            *(float *)&v34->field_180 = (float)(int)v56 * 5.0f + a2;
                        }
                    }
                }
                if (!v22->field_179 || v22->field_178 != v50)
                {
                    v57 = sub_28da38();
                    v57[6] = v50;
                    v57[7] = (char)v50 ^ 1;
                    v57[866221] = 1;
                    v22->field_178 = v50;
                    v22->field_179 = 1;
                }
                sub_282ee8(v18);
LABEL_28e854:
                v89 = (!(long long)v17[248] ? 0 : (long long)v17[0x100]);
                v90 = 0;
                if (sub_198128(v89) & 1 && v89)
                {
                    if ((long long)v17[344])
                    {
                        /* unsupported instruction */;
                        v91 = v18;
                        if (!(*0x7650670 & 1) && sub_65eda8(124061296))
                        {
                            v92 = sub_679020(424);
                            *(unsigned long long *)&v92->field_198 = 0;
                            *(char *)&(&v92->field_198)[1] = 0;
                            g_7650668 = v92;
                            v92->field_0 = 0;
                            v92->field_10 = 0;
                            v92->field_20 = 0;
                            v92->field_30 = 0;
                            v92->field_40 = 0;
                            v92->field_50 = 0;
                            v92->field_60 = 0;
                            v92->field_70 = 0;
                            v92->field_80 = 0;
                            v92->field_90 = 0;
                            v92->field_a0 = 0;
                            v92->field_b0 = 0;
                            v92->field_c0 = 0;
                            v92->field_d0 = 0;
                            v92->field_e0 = 0;
                            v92->field_f0 = 0;
                            v92->field_100 = 0;
                            v92->field_110 = 0;
                            v92->field_120 = 0;
                            v92->field_130 = 0;
                            v92->field_140 = 0;
                            v92->field_150 = 0;
                            v92->field_160 = 0;
                            v92->field_170 = 0;
                            v92->field_180 = 0;
                            v92->field_190 = 0;
                            *(unsigned int *)((char *)&v92->field_190 + 8) = 3463342888;
                            *(unsigned long long *)((char *)&v92->field_190 + 12) = 0;
                            sub_65eed8(124061296);
                        }
                        v93 = (!*(long long *)(g_7650668 + 40) ? 0 : *(long long *)(g_7650668 + 48));
                        if (sub_198128(v93) & 1 && v93)
                        {
                            v94 = (!*(long long *)(g_7650668 + 0x88) ? 0 : *(long long *)(g_7650668 + 144));
                            if (sub_198128(v94) & 1 && v94 && v94 != *(long long *)(g_7650668 + 112))
                                a0->field_1d8();
                            if (*(char *)(g_7650668 + 376))
                            {
                                v95 = (!*(long long *)(g_7650668 + 232) ? 0 : *(long long *)(g_7650668 + 240));
                                v96 = ((int)sub_198128(v95) & 1 ? v95 : 0);
                            }
                            else
                            {
                                v96 = 0;
                            }
                            if (!*(char *)(g_7650668 + 128) || v96 != *(long long *)(g_7650668 + 120))
                                (*(long long *)0x76506a0)();
                        }
                        v4 = 0x1000;
                        v2 = (int128_t)v17[344];
                        v97 = v91;
                        v3 = 0;
                        v5 = (!(char)v17[376] ? 0 : (long long)v17[360]);
                        v6 = (long long)v17[368];
                        v90 = sub_282ef8(v91, &v2);
                        if (v91[866222])
                            *(char *)&v17[404] = 1;
                        if ((char)v17[376])
                        {
                            v98 = v97 + 1022692;
                            if (*v98)
                            {
                                v99 = (!(long long)v17[152] ? 0 : (long long)v17[160]);
                                if (sub_198128(v99) & 1 && v99)
                                    sub_18c418((!(long long)v17[152] ? 0 : (long long)v17[160]), (!(long long)v17[184] ? 0 : (long long)v17[192]), v97 + 866228, 36000, 0);
                            }
                            if (v98[1])
                            {
                                v100 = (!(long long)v17[168] ? 0 : (long long)v17[176]);
                                if (sub_198128(v100) & 1 && v100)
                                    sub_18c418((!(long long)v17[168] ? 0 : (long long)v17[176]), (!(long long)v17[200] ? 0 : (long long)v17[208]), v97 + 1010228, 3108, 0);
                            }
                        }
                    }
                    else
                    {
                        v90 = 0;
                    }
                }
                *(int *)&v17[400] = v90;
                v101 = v90 > 0;
                sub_28ee04(a0, v101 & 1);
                v15 = sub_28ef34(v101 & 1);
                if (v90 >= 1)
                {
                    v15 = sub_28f084();
                    if (v15 & 0x1)
                        *(char *)&v17[404] = 1;
                }
            }
        }
        else
        {
            if (*(long long *)v17 && sub_282ee8(*(long long *)v17) & 1)
                sub_282e5c(*(long long *)v17, 0);
            *(int *)&v17[400] = 0;
            *(char *)&v17[404] = 0;
            sub_28ee04(a0, 0);
            v15 = sub_28ef34(0);
            *(float *)&v17[412] = 0;
        }
    }
    if (v14->field_28 == v11)
        return (unsigned int)v15;
    6813312();
}
