typedef struct st_22ef70_2 {
    char padding_0[48];
    unsigned long long field_30;
    long long field_38;
    char padding_40[48];
    char field_70;
    char padding_71[7];
    struct st_22ef70_1 *field_78;
    struct st_22ef70_1 *field_80;
} st_22ef70_2;

typedef struct st_22ef70_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_22ef70_0;

typedef struct st_22ef70_1 {
    unsigned long long field_0;
    unsigned long long field_8;
    unsigned long long *field_10;
    unsigned long long field_18[2];
    unsigned long long field_20;
    unsigned long long field_28;
    unsigned long long field_30;
} st_22ef70_1;

typedef struct st_22ef70_5 {
    unsigned long long field_0;
    unsigned long long field_8;
    unsigned long long *field_10;
    unsigned long long field_18[2];
    char field_20;
    char padding_21[7];
    unsigned long long field_28;
    unsigned long long field_30;
} st_22ef70_5;

typedef struct st_22ef70_4 {
    unsigned long long field_0;
} st_22ef70_4;

typedef struct st_22ef70_3 {
    char padding_0[80];
    long long field_50;
    char padding_58[32];
    long long field_78;
    char padding_80[88];
    struct st_22ef70_4 *field_d8;
    char padding_e0[128];
    struct st_22ef70_4 *field_160;
    char padding_168[480];
    struct st_22ef70_4 *field_348;
} st_22ef70_3;

st_22ef70_3 * sub_22ef70(st_22ef70_3 *a0, st_22ef70_2 *a1, long long a2, int a3)
{
    st_22ef70_0 *v13;  // tpidr_el0
    st_22ef70_3 *v14;  // x0
    unsigned long long *v23;  // x21
    unsigned long long *v24;  // x9
    unsigned long long v25;  // x0
    unsigned long long *v26;  // x0
    unsigned long long *v27;  // x19
    unsigned long long *v28;  // x8
    unsigned long long *v29;  // x0
    unsigned long long *v30;  // x0
    unsigned long long *v31;  // x20
    unsigned long long v32;  // x0
    long long v15;  // x9
    unsigned long long *v33;  // x20
    unsigned long long *v34;  // x0
    st_22ef70_3 *v16;  // x23
    unsigned long long v17;  // x0
    unsigned long v18;  // x0
    long long *v19;  // x24
    st_22ef70_1 *v20;  // x8
    st_22ef70_5 *v21;  // x0
    unsigned long long *v22;  // x8
    long long *v0;  // [bp-0xb8]
    long long *v1;  // [bp-0xb0]
    uint128_t v2;  // [bp-0xa0], Other Possible Types: unsigned long long
    uint128_t v3;  // [bp-0xa0]
    unsigned long long v4;  // [bp-0x98]
    uint256_t v5;  // [bp-0x90], Other Possible Types: unsigned long long
    uint256_t v6;  // [bp-0x90]
    unsigned long long *v7;  // [bp-0x88], Other Possible Types: unsigned long long
    unsigned long long *v8;  // [bp-0x78]
    unsigned long long v9;  // [bp-0x70]
    unsigned long v10;  // [bp-0x68]
    char *v11;  // [bp-0x60]
    char v12;  // [bp+0x0]

    v11 = &v12;
    v10 = v13->field_28;
    v14 = a0;
    if (a2 && (v14 = a0, 6 >= a3))
    {
        v15 = a1->field_38;
        if (!a1->field_30)
            v15 = 0;
        v14 = a0;
        if (v15 != a2 && (v14 = sub_1997d4(a2), v14))
        {
            v16 = v14;
            v9 = 0;
            v6 = 0;
            v3 = 0;
            v17 = sub_439970();
            if (v17)
            {
                v18 = *(unsigned long long *)&v3;
                v4 = 0;
                if (v18)
                    sub_439c54(v18);
                v3 = CONCAT(v16, v17);
            }
            if (sub_19992c(a2, a0->field_50))
            {
                sub_19a824(v16, a0->field_78, 1, 4);
                v19 = v0;
                if (v19 != v1)
                {
                    do
                    {
                        if (sub_1997d4(*v19) == v16)
                            a0->field_160();
                    } while ((v19 += 1, v19 != v1));
                    v19 = v0;
                }
                if (v19)
                {
                    v1 = v19;
                    sub_6790c8(v19); /* do not return */
                }
                v20 = a1->field_78;
                if (a1->field_80 > v20)
                {
                    v2 = _INSERT(v3, 0, 0);
                    v21 = &v20->field_30;
                    v20->field_20 = 0;
                    v20->field_28 = 0;
                    v20->field_0 = *(unsigned long long *)&v3;
                    v3 = _INSERT(v2, 8, 0);
                    v20->field_18[1] = 0;
                    v20->field_8 = *(unsigned long long *)((void*)&v2 + 8);
                    v5 = _INSERT(v6, 0, 0);
                    v20->field_10 = *(unsigned long long *)&v6;
                    v6 = _INSERT(v5, 8, 0);
                    *(uint128_t *)v20->field_18 = *(uint128_t *)((void*)&v5 + 8);
                    v20->field_20 = *(unsigned long long *)((void*)&v6 + 24);
                    v5 = _INSERT(v6, 16, 0);
                    v6 = _INSERT(v5, 24, 0);
                    v20->field_28 = v9;
                    v9 = 0;
                }
                else
                {
                    v21 = sub_231cfc(&a1->field_70, &v3);
                }
                v22 = a0->field_d8;
                a1->field_78 = v21;
                v22();
            }
            v23 = sub_199d38(v16, a0->field_50);
            if (v23)
            {
                v24 = *(unsigned long long *)((void*)&v6 + 8);
                if (!*(unsigned long long *)&v6)
                    v24 = NULL;
                if (v24 != v23)
                {
                    v25 = sub_439970(v23);
                    if (!v25)
                        goto LABEL_22f2d8;
                    v26 = *(unsigned long long *)&v6;
                    v7 = 0;
                    if (v26)
                    {
                        v5 = 0;
                        sub_439c54(v26);
                    }
                    v5 = v25;
                    v7 = v23;
                }
                a0->field_348();
            }
            else
            {
LABEL_22f2d8:
                v27 = *(unsigned long long *)((void*)&v6 + 16);
                if (v27)
                {
                    v28 = *(unsigned long long *)((void*)&v6 + 24);
                    v29 = v27;
                    v30 = v29;
                    if (v28 != v30)
                    {
                        v31 = v28;
                        do
                        {
                            v32 = *(long long *)((char *)v31 - 16);
                            v33 = (char *)v31 - 16;
                            v33[1] = 0;
                            if (v32)
                            {
                                *(unsigned long long *)((char *)v28 - 16) = 0;
                                sub_439c54(v32);
                            }
                        } while ((v31 = v33, v28 = v33, v31 != v29));
                        v30 = *(unsigned long long *)((void*)&v6 + 16);
                    }
                    v8 = v29;
                    sub_6790c8(v30); /* do not return */
                }
                else
                {
                    v34 = *(unsigned long long *)&v6;
                    v7 = 0;
                    if (v34)
                    {
                        v5 = 0;
                        sub_439c54(v34);
                    }
                    v14 = *(unsigned long long *)&v3;
                    v4 = 0;
                    if (v14)
                    {
                        v2 = 0;
                        v14 = sub_439c54(v14);
                    }
                }
            }
        }
    }
    if (v13->field_28 == v10)
        return v14;
    6813312();
}
