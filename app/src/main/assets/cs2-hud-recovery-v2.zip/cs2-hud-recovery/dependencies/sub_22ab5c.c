typedef struct st_22ab5c_0 {
    char padding_0[120];
    unsigned long long field_78;
} st_22ab5c_0;

unsigned int sub_22ab5c(st_22ab5c_0 *a0, unsigned long a1, unsigned long a2)
{
    unsigned long long v2;  // x20
    char *v0;  // [bp-0x40]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (a0->field_78)
    {
        v2 = 0;
        do
        {
            if (a2 == 6813424() && !6813376())
                return v2;
        } while ((v2 += 1, a0->field_78 != v2));
    }
    return 0xffffffff;
}
