typedef struct st_23d338_0 {
    char padding_0[8];
    int field_8;
} st_23d338_0;

float sub_23d338(unsigned long a0, unsigned long a1, int a2)
{
    int v2;  // w19
    st_23d338_0 *v3;  // x0
    int v4;  // w8
    int v5;  // w8
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    v2 = a2;
    v3 = sub_23d394();
    if (!v3)
        return 0;
    v4 = v3->field_8;
    if (v4 < 1)
        return 0;
    if ((unsigned int)v4 >= 4)
        v4 = 4;
    v5 = v4 - 1;
    if (v5 >= v2)
        v5 = v2;
    return *(int *)&v3[1].padding_0[4 * (v2 < 0 ? 0 : v5)];
}
