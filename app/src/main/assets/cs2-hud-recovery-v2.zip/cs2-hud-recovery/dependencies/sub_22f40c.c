typedef struct st_22f40c_0 {
    char padding_0[16];
    unsigned long long field_10;
    long long field_18;
    unsigned long long *field_20;
    unsigned long long *field_28;
} st_22f40c_0;

typedef struct st_22f40c_2 {
    unsigned long long field_0;
} st_22f40c_2;

typedef struct st_22f40c_1 {
    char padding_0[352];
    struct st_22f40c_2 *field_160;
    char padding_168[488];
    struct st_22f40c_2 *field_350;
} st_22f40c_1;

void sub_22f40c(st_22f40c_1 *a0, st_22f40c_0 **a1)
{
    st_22f40c_0 *iter;  // x21
    long long v3;  // x20
    unsigned long long *node;  // x23
    unsigned long long v5;  // x9
    char *v0;  // [bp-0x40]
    char v1;  // [bp+0x0]

    v0 = &v1;
    iter = a1[14];
    if (a1[14] == a1[15])
        return;
    while (1)
    {
        if (!iter->field_10)
            v3 = 0;
        else
            v3 = iter->field_18;
        if (sub_198128(v3) & 1 && v3)
            a0->field_350();
        for (node = iter->field_20; node != iter->field_28; node += 2)
        {
            v5 = node[1];
            if (!*node)
                v5 = 0;
            if (sub_198128(v5) & 1 && v5)
                a0->field_160();
        }
        iter = &iter[1].padding_0[8];
        if (iter == a1[15])
            return;
    }
}
