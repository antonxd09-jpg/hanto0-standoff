typedef struct st_22ce80_0 {
    unsigned long long field_0;
    long long field_8;
} st_22ce80_0;

typedef struct st_22ce80_1 {
    char padding_0[168];
    struct st_22ce80_2 *field_a8;
} st_22ce80_1;

typedef struct st_22ce80_2 {
    unsigned long long field_0;
} st_22ce80_2;

void sub_22ce80(st_22ce80_1 *a0, st_22ce80_0 *a1, unsigned int a2)
{
    long long v2;  // x9
    char *v0;  // [bp-0x40]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (!a1)
    {
        return;
    }
    else if ((int)a1[12].field_0 != (a2 & 1))
    {
        v2 = a1->field_8;
        if (!a1->field_0)
            v2 = 0;
        if (!(sub_198128(v2) & 1))
        {
            return;
        }
        else if (v2)
        {
            sub_67b3a0(1, 123935948);
            a0->field_a8();
        }
        else
        {
            return;
        }
    }
    else
    {
        return;
    }
}
