void sub_22dfb8(unsigned long a0)
{
    unsigned long long v4;  // x30
    unsigned long long v5;  // x19
    char *v0;  // [bp-0x20]
    unsigned long long v1;  // [bp-0x18]
    unsigned long long v2;  // [bp-0x10]
    char v3;  // [bp+0x0]

    v0 = &v3;
    v1 = v4;
    v2 = v5;
    /* unsupported instruction */;
    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
    {
        sub_1269d0(123377504);
        6813216();
        sub_65eed8(123388920);
    }
}
