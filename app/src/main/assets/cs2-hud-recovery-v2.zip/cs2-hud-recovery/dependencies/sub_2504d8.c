unsigned int sub_2504d8(void)
{
    return 105048928;
}
