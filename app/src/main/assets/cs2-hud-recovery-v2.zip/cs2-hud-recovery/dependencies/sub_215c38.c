typedef struct st_215c38_0 {
    long long field_0;
    unsigned long long field_8;
    long long field_10;
    unsigned long long field_18;
    long long field_20;
    unsigned long long field_28;
    long long field_30;
    unsigned long long field_38;
    long long field_40;
    unsigned long long field_48;
    long long field_50;
    unsigned long long field_58;
    long long field_60;
    unsigned long long field_68;
    long long field_70;
    unsigned long long field_78;
    char padding_80[8];
    char field_88;
    char padding_89[15];
    long long field_98;
} st_215c38_0;

void sub_215c38(st_215c38_0 *a0)
{
    long long v2;  // x0
    long long v3;  // x0
    long long v4;  // x0
    long long v5;  // x0
    long long v6;  // x0
    long long v7;  // x0
    long long v8;  // x0
    long long v9;  // x0
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (a0->field_88 & 1)
        sub_6790c8(a0->field_98); /* do not return */
    v2 = a0->field_70;
    a0->field_78 = 0;
    if (v2)
    {
        a0->field_70 = 0;
        sub_439c54(v2);
    }
    v3 = a0->field_60;
    a0->field_68 = 0;
    if (v3)
    {
        a0->field_60 = 0;
        sub_439c54(v3);
    }
    v4 = a0->field_50;
    a0->field_58 = 0;
    if (v4)
    {
        a0->field_50 = 0;
        sub_439c54(v4);
    }
    v5 = a0->field_40;
    a0->field_48 = 0;
    if (v5)
    {
        a0->field_40 = 0;
        sub_439c54(v5);
    }
    v6 = a0->field_30;
    a0->field_38 = 0;
    if (v6)
    {
        a0->field_30 = 0;
        sub_439c54(v6);
    }
    v7 = a0->field_20;
    a0->field_28 = 0;
    if (v7)
    {
        a0->field_20 = 0;
        sub_439c54(v7);
    }
    v8 = a0->field_10;
    a0->field_18 = 0;
    if (v8)
    {
        a0->field_10 = 0;
        sub_439c54(v8);
    }
    v9 = a0->field_0;
    a0->field_8 = 0;
    if (!v9)
        return;
    a0->field_0 = 0;
    sub_439c54(v9);
    return;
}
