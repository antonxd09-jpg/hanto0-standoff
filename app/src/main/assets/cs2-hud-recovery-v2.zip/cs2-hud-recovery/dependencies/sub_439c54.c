typedef struct st_439c54_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_439c54_0;

void sub_439c54(unsigned long a0)
{
    st_439c54_0 *v4;  // tpidr_el0
    unsigned long v0;  // [bp-0x30]
    unsigned long v1;  // [bp-0x28]
    char *v2;  // [bp-0x20]
    char v3;  // [bp+0x0]

    v2 = &v3;
    v1 = v4->field_28;
    if (a0)
    {
        sub_63d380(125497496);
        if (*(long long *)0x77af0d0)
        {
            v0 = a0;
            if (sub_43a480(*0x77af0d0, &v0))
            {
                /* unsupported instruction */;
                if (!(*0x77af0f8 & 1) && sub_65eda8(125497592))
                {
                    sub_439e88();
                    sub_65eed8(125497592);
                }
                if (*(long long *)0x77af0e8)
                    (*(long long *)0x77af0e8)();
            }
        }
        sub_63d3ac(125497496);
    }
    if (v4->field_28 == v1)
        return;
    6813312();
}
