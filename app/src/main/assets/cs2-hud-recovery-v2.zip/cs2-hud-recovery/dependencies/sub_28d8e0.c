typedef struct st_28d8e0_1 {
    uint128_t field_0;
    uint128_t field_10;
    uint128_t field_20;
    uint128_t field_30;
    uint128_t field_40;
    uint128_t field_50;
    uint128_t field_60;
    uint128_t field_70;
    uint128_t field_80;
    uint128_t field_90;
    uint128_t field_a0;
    uint128_t field_b0;
    uint128_t field_c0;
    uint128_t field_d0;
    uint128_t field_e0;
    uint128_t field_f0;
    uint128_t field_100;
    uint128_t field_110;
    uint128_t field_120;
    uint128_t field_130;
    uint128_t field_140;
    uint128_t field_150;
    uint128_t field_160;
    uint128_t field_170;
    uint128_t field_180;
    uint128_t field_190;
    unsigned int field_198;
    unsigned long long field_19c;
    unsigned long long field_1a0;
    char field_1a4;
} st_28d8e0_1;

typedef struct st_28d8e0_0 {
    char padding_0[40];
    unsigned long long field_28;
} st_28d8e0_0;

extern unsigned long long g_7650668;

double sub_28d8e0(unsigned int a0, unsigned int a1, float a2, float a3, float a4, double a5, float a6)
{
    st_28d8e0_0 *v5;  // tpidr_el0
    unsigned long long v6;  // d0
    st_28d8e0_1 *v7;  // x0
    unsigned int v0;  // [bp-0x60]
    unsigned int v1;  // [bp-0x5c]
    unsigned long v2;  // [bp-0x58]
    char *v3;  // [bp-0x30]
    char v4;  // [bp+0x0]

    v3 = &v4;
    v2 = v5->field_28;
    /* unsupported instruction */;
    v6 = a2;
    if (!(*0x7650670 & 1))
    {
        v6 = a2;
        if (sub_65eda8(124061296))
        {
            v7 = sub_679020(424);
            v6 = 0;
            *(unsigned long long *)&v7->field_198 = 0;
            *(char *)&(&v7->field_198)[1] = 0;
            g_7650668 = v7;
            v7->field_0 = 0;
            v7->field_10 = 0;
            v7->field_20 = 0;
            v7->field_30 = 0;
            v7->field_40 = 0;
            v7->field_50 = 0;
            v7->field_60 = 0;
            v7->field_70 = 0;
            v7->field_80 = 0;
            v7->field_90 = 0;
            v7->field_a0 = 0;
            v7->field_b0 = 0;
            v7->field_c0 = 0;
            v7->field_d0 = 0;
            v7->field_e0 = 0;
            v7->field_f0 = 0;
            v7->field_100 = 0;
            v7->field_110 = 0;
            v7->field_120 = 0;
            v7->field_130 = 0;
            v7->field_140 = 0;
            v7->field_150 = 0;
            v7->field_160 = 0;
            v7->field_170 = 0;
            v7->field_180 = 0;
            v7->field_190 = 0;
            *(unsigned int *)((char *)&v7->field_190 + 8) = 3463342888;
            *(unsigned long long *)((char *)&v7->field_190 + 12) = 0;
            sub_65eed8(124061296);
        }
    }
    if (*(char *)(g_7650668 + 104))
    {
        v0 = a3;
        v1 = a4;
        v6 = a6;
        sub_282bbc(sub_28da38(), a0, a1, &(unsigned int)a2);
    }
    if (v5->field_28 == v2)
        return v6;
    6813312();
}
