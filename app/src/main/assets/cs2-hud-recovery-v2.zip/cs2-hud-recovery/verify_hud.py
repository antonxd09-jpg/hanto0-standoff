import ctypes,json,math,pathlib,random,struct,subprocess,sys
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM
from unicorn.arm64_const import *
root=pathlib.Path(__file__).resolve().parent
subprocess.run(['c++','-std=c++17','-O2','-ffp-contract=off','-fPIC','-shared',str(root/'cs2_hud_logic.cpp'),str(root/'bottom_bindings.cpp'),'-o',str(root/'hud.host.so')],check=True)
lib=ctypes.CDLL(str(root/'hud.host.so'));lib.hud_ammo_icon.argtypes=[ctypes.c_int32];lib.hud_ammo_icon.restype=ctypes.c_char_p
lib.hud_animation_curve.argtypes=[ctypes.c_int32,ctypes.c_float];lib.hud_animation_curve.restype=ctypes.c_float
src=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else root.parent/'upload/libzenininternal.captured.so';raw=src.read_bytes()
with src.open('rb') as f:
 e=ELFFile(f);s=e.get_section_by_name('.text');code=s.data();base=s['sh_addr']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(base&~4095,((len(code)+(base&4095)+4095)//4096)*4096);u.mem_write(base,code)
u.mem_map(0x10000000,0x10000);stop=0x1000f000;rng=random.Random(20261104)
counts={'ammo':0,'animation':0};max_error=0.
for ident in list(range(-1000,1001))+[rng.randrange(-2**31,2**31) for _ in range(1000)]:
 u.reg_write(UC_ARM64_REG_X20,0x10000000);u.reg_write(UC_ARM64_REG_X8,ident&0xffffffff)
 u.emu_start(0x258744,0x2587cc,count=300)
 assert u.reg_read(UC_ARM64_REG_PC)==0x2587cc
 a=u.reg_read(UC_ARM64_REG_X22);expected=raw[a:raw.index(b'\0',a)]
 assert lib.hud_ammo_icon(ident)==expected,(ident,expected);counts['ammo']+=1
xs=[-10.,-0.,0.,1e-9,1e-6,.0001,.01,.1,.5,.9,.99,.999999,1.,10.,float('nan'),float('inf'),float('-inf')]+[rng.uniform(-.1,1.1) for _ in range(400)]
for mode in range(-1,8):
 for x in xs:
  bits=struct.unpack('<I',struct.pack('<f',x))[0];u.reg_write(UC_ARM64_REG_W0,mode&0xffffffff);u.reg_write(UC_ARM64_REG_S0,bits);u.reg_write(UC_ARM64_REG_X30,stop)
  u.emu_start(0x254534,stop,count=30000);assert u.reg_read(UC_ARM64_REG_PC)==stop
  original=struct.unpack('<f',struct.pack('<I',u.reg_read(UC_ARM64_REG_S0)))[0];recovered=lib.hud_animation_curve(mode,x)
  if math.isnan(original):assert math.isnan(recovered)
  else:
   error=abs(original-recovered);max_error=max(max_error,error)
   assert error<=2e-6,(mode,x,original,recovered,error)
  counts['animation']+=1
result={'status':'passed','differential_cases':sum(counts.values()),'cases':counts,'maximum_animation_absolute_error':max_error,'animation_tolerance':2e-6,'method':'Compiled C++ compared with original AArch64 code in Unicorn','limits':['No Android UI integration test','No equivalence claim for automatic pseudocode','Bindings and palette extracted statically, not exercised in Unity']}
(root/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
