#include "ui_schema.hpp"
namespace recovered_hud {
std::int32_t find_template(std::string_view name) noexcept {
 for(std::size_t i=0;i<nodes.size();++i)
  if(nodes[i].parent<0&&nodes[i].name==name)return static_cast<std::int32_t>(i);
 return -1;
}
// Semantics reconstructed from 0x22a934. Children occupy depth-first subtrees.
std::int32_t find_path(std::int32_t root,std::string_view path) noexcept {
 if(root<0)return root;
 if(static_cast<std::size_t>(root)>=nodes.size())return -1;
 while(!path.empty()) {
  const auto slash=path.find('/');
  const auto part=path.substr(0,slash);
  const auto end=nodes[root].subtree_end;
  auto child=root+1;
  for(;child<end;) {
   if(nodes[child].parent==root&&nodes[child].name==part)break;
   child=nodes[child].subtree_end;
  }
  if(child>=end)return -1;
  root=child;
  if(slash==std::string_view::npos)return root;
  path.remove_prefix(slash+1);
 }
 return root;
}
// Search in 0x22ab5c uses descriptor order, exact length and byte comparison.
std::int32_t find_sprite(std::string_view name) noexcept {
 for(std::size_t i=0;i<sprites.size();++i)
  if(sprites[i].name==name)return static_cast<std::int32_t>(i);
 return -1;
}
}
extern "C" int hud_find_path(int root,const char* p,std::size_t length) {
 if(!p)return root;
 return recovered_hud::find_path(root,std::string_view(p,length));
}
