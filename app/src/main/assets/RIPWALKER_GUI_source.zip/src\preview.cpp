// RIPWALKER :: previews (3D operator + aim sight)
#include "ui.hpp"
#include "imgui_internal.h"
#include <cmath>

using namespace rw;

namespace {

void DashCircle(ImDrawList* d, ImVec2 c, float r, ImU32 col, float thickness, int dashes, float phase, float fill01) {
    for (int i = 0; i < dashes; ++i) {
        float a0 = phase + (float)i / dashes * 2.f * IM_PI;
        float a1 = a0 + (2.f * IM_PI / dashes) * fill01;
        d->PathArcTo(c, r, a0, a1, 8);
        d->PathStroke(col, 0, thickness);
    }
}

} // namespace

// ---------------------------------------------------------------- ESP panel
void rw::DrawEspPreview(ImDrawList* d, ImRect area, float time) {
    const ImVec2 a = area.Min, b = area.Max;
    const float w = b.x - a.x, h = b.y - a.y;

    d->PushClipRect(a, b, true);
    RRectGrad(d, a, b, 10.f, C(14, 8, 10), C(8, 5, 7));

    const float grid = 32.f;
    for (float x = a.x + grid; x < b.x; x += grid) d->AddLine(ImVec2(x, a.y), ImVec2(x, b.y), C(255, 60, 70, 7));
    for (float y = a.y + grid; y < b.y; y += grid) d->AddLine(ImVec2(a.x, y), ImVec2(b.x, y), C(255, 60, 70, 7));

    // ---- image rect (keeps the render aspect)
    const float padTop = 26.f, padBot = 30.f;
    float availH = h - padTop - padBot;
    float availW = w - 28.f;
    const float aspect = (float)g_hero.w / (float)(g_hero.h ? g_hero.h : 1);
    float ih = availH, iw = ih * aspect;
    if (iw > availW) { iw = availW; ih = iw / aspect; }
    ImVec2 i0(a.x + (w - iw) * 0.5f, a.y + padTop + (availH - ih) * 0.5f);
    ImVec2 i1(i0.x + iw, i0.y + ih);

    // interaction: drag to rotate, wheel to zoom
    {
        ImGui::SetCursorScreenPos(a);
        ImGui::InvisibleButton("##hero_view", ImVec2(w, h));
        bool hov = ImGui::IsItemHovered();
        if (ImGui::IsItemActive()) {
            ImVec2 dd = ImGui::GetIO().MouseDelta;
            st.heroYaw += dd.x * 0.012f;
            st.heroPitch = ImClamp(st.heroPitch + dd.y * 0.010f, -0.6f, 0.6f);
            st.heroSpin = false;
        }
        if (hov && ImGui::GetIO().MouseWheel != 0.f) {
            st.heroZoom = ImClamp(st.heroZoom + ImGui::GetIO().MouseWheel * 0.06f, 0.65f, 1.7f);
        }
    }

    // soft red pool under the model
    Glow(d, ImVec2(i0.x + iw * 0.5f, i0.y + ih * 0.55f), iw * 0.55f, C(120, 10, 20), 0.25f, 14, 2.2f);

    if (g_hero.id) d->AddImage(g_hero.id, i0, i1, ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE);

    // ---- projected joints -> screen
    const size_t nj = g_heroJoints.size();
    std::vector<ImVec2> jp(nj);
    for (size_t i = 0; i < nj; ++i)
        jp[i] = ImVec2(i0.x + g_heroJoints[i].x * iw, i0.y + g_heroJoints[i].y * ih);

    const ImU32 boxCol = IM_COL32((int)(st.boxCol.x * 255), (int)(st.boxCol.y * 255), (int)(st.boxCol.z * 255), 255);
    const ImU32 skelCol = IM_COL32((int)(st.skelCol.x * 255), (int)(st.skelCol.y * 255), (int)(st.skelCol.z * 255), 255);
    const float alpha = st.boxOpacity;

    // box from the actual joints
    ImVec2 boxMin(1e9f, 1e9f), boxMax(-1e9f, -1e9f);
    for (auto& p : jp) { boxMin.x = ImMin(boxMin.x, p.x); boxMin.y = ImMin(boxMin.y, p.y); boxMax.x = ImMax(boxMax.x, p.x); boxMax.y = ImMax(boxMax.y, p.y); }
    if (nj && boxMax.x > boxMin.x) {
        boxMin = ImVec2(boxMin.x - 12.f, boxMin.y - 14.f);
        boxMax = ImVec2(boxMax.x + 12.f, boxMax.y + 10.f);

        if (st.esp.fill) RRectGrad(d, boxMin, boxMax, 2.f, WithA(boxCol, 0.10f * alpha), WithA(boxCol, 0.03f * alpha));

        if (st.esp.box) {
            if (st.esp.boxStyle == 0) {
                const float c = ImMin(14.f, (boxMax.x - boxMin.x) * 0.28f);
                auto corner = [&](ImVec2 p, float dx, float dy) {
                    d->AddLine(p, ImVec2(p.x + dx, p.y), WithA(boxCol, alpha), 1.6f);
                    d->AddLine(p, ImVec2(p.x, p.y + dy), WithA(boxCol, alpha), 1.6f);
                };
                corner(boxMin, c, c);
                corner(ImVec2(boxMax.x, boxMin.y), -c, c);
                corner(ImVec2(boxMin.x, boxMax.y), c, -c);
                corner(boxMax, -c, -c);
            } else {
                d->AddRect(boxMin, boxMax, WithA(boxCol, alpha), 1.f, 0, 1.6f);
            }
        }

        if (st.esp.skeleton && g_heroPairs.size()) {
            for (auto& pr : g_heroPairs) {
                int i0j = pr.first, i1j = pr.second;
                if (i0j < 0 || i1j < 0 || i0j >= (int)nj || i1j >= (int)nj) continue;
                d->AddLine(jp[i0j], jp[i1j], WithA(C(0, 0, 0), 0.55f * alpha), st.skelThick + 3.f);
                d->AddLine(jp[i0j], jp[i1j], WithA(skelCol, alpha), st.skelThick);
            }
            for (auto& p : jp) {
                d->AddCircleFilled(p, st.skelThick + 1.8f, WithA(C(0, 0, 0), 0.5f * alpha), 10);
                d->AddCircleFilled(p, st.skelThick + 0.5f, WithA(skelCol, alpha), 10);
            }
        }

        if (st.esp.health) {
            const float hp = 0.86f;
            ImVec2 h0(boxMin.x - 8.f, boxMin.y + 2.f), h1(boxMin.x - 5.f, boxMax.y - 2.f);
            d->AddRectFilled(ImVec2(h0.x - 1.f, h0.y - 1.f), ImVec2(h1.x + 1.f, h1.y + 1.f), C(0, 0, 0, 140));
            float fh = (h1.y - h0.y) * hp;
            d->AddRectFilledMultiColor(ImVec2(h0.x, h1.y - fh), h1,
                                       IM_COL32(150, 210, 150, 235), IM_COL32(150, 210, 150, 235),
                                       IM_COL32(200, 220, 150, 235), IM_COL32(200, 220, 150, 235));
        }

        if (st.esp.name) {
            ImVec2 ns = TextSize(font.bodyB, 11.5f, "FID");
            Text(d, font.bodyB, 11.5f, ImVec2((boxMin.x + boxMax.x) * 0.5f - ns.x * 0.5f, boxMin.y - 32.f), WithA(pal.text, 0.95f), "FID");
            ImVec2 ps = TextSize(font.sm, 9.f, "38ms");
            Text(d, font.sm, 9.f, ImVec2((boxMin.x + boxMax.x) * 0.5f - ps.x * 0.5f, boxMin.y - 19.f), WithA(pal.textMute, 0.9f), "38ms");
        }
        if (st.esp.distance) Text(d, font.bodyB, 11.f, ImVec2(boxMax.x + 7.f, boxMin.y + 1.f), WithA(pal.text, 0.85f), "24m");
        if (st.esp.weapon) {
            ImVec2 ws = TextSize(font.sm, 9.f, "M4A1-S");
            Text(d, font.sm, 9.f, ImVec2((boxMin.x + boxMax.x) * 0.5f - ws.x * 0.5f, boxMax.y + 6.f), WithA(pal.textMute, 0.9f), "M4A1-S");
        }
        if (st.esp.snapline) d->AddLine(ImVec2(a.x + 4.f, a.y + 4.f), jp.empty() ? a : jp[0], WithA(boxCol, 0.3f * alpha), 1.f);
    }

    Text(d, font.sm, 7.5f, ImVec2(b.x - 12.f - TextSize(font.sm, 7.5f, "LIVE").x, a.y + 10.f), WithA(C(255, 70, 80), 0.8f), "LIVE");

    d->AddRect(a, b, WithA(C(90, 26, 34), 0.9f), 10.f, 0, 1.f);
    d->PopClipRect();
}

// ---------------------------------------------------------------- aim panel
void rw::DrawAimPreview(ImDrawList* d, ImRect area, float time) {
    const ImVec2 a = area.Min, b = area.Max;
    const float w = b.x - a.x, h = b.y - a.y;

    d->AddRectFilled(a, b, C(11, 8, 9), 12.f);
    for (int i = 0; i < 8; ++i) {
        float t = i / 8.f;
        d->AddRectFilled(a, ImVec2(b.x, a.y + h * 0.42f * (1.f - t)), WithA(C(120, 18, 24), 0.015f), 12.f);
    }
    d->AddRect(a, b, WithA(C(255, 255, 255), 0.055f), 12.f, 0, 1.f);

    // ---- segmented hitbox picker
    const char* segs[3] = { "HEAD", "NECK", "CHEST" };
    const float sy0 = a.y + 12.f, sh = 25.f;
    const float sx0 = a.x + 12.f, sw = w - 24.f, segW = sw / 3.f;
    d->AddRectFilled(ImVec2(sx0, sy0), ImVec2(sx0 + sw, sy0 + sh), C(17, 12, 13), 7.f);
    for (int i = 0; i < 3; ++i) {
        ImVec2 p0(sx0 + segW * i, sy0), p1(sx0 + segW * (i + 1), sy0 + sh);
        bool act = (st.hitbox == i);
        ImGui::PushID(900 + i);
        ImGui::SetCursorScreenPos(p0);
        ImGui::InvisibleButton("##seg", ImVec2(segW - 2.f, sh));
        bool hov = ImGui::IsItemHovered();
        if (ImGui::IsItemClicked()) st.hitbox = i;
        ImGui::PopID();
        if (act) d->AddRectFilled(ImVec2(p0.x + 2.f, p0.y + 2.f), ImVec2(p1.x - 2.f, p1.y - 2.f), C(40, 20, 22), 6.f);
        else if (hov) d->AddRectFilled(ImVec2(p0.x + 2.f, p0.y + 2.f), ImVec2(p1.x - 2.f, p1.y - 2.f), WithA(C(255, 255, 255), 0.03f), 6.f);
        float tw = TextSize(font.smB, 9.f, segs[i]).x;
        Text(d, font.smB, 9.f, ImVec2((p0.x + p1.x) * 0.5f - tw * 0.5f, p0.y + 8.f),
             WithA(act ? pal.text : pal.textMute, act ? 1.f : 0.8f), segs[i]);
        if (act) d->AddRectFilled(ImVec2(p0.x + segW * 0.5f - 8.f, sy0 + sh - 3.f), ImVec2(p0.x + segW * 0.5f + 8.f, sy0 + sh - 1.f), WithA(pal.accent, 0.9f), 1.f);
    }

    // ---- model
    const float top = sy0 + sh + 10.f;
    const float bottom = b.y - 56.f;
    float ph = bottom - top;
    float pw = ph * (360.f / 420.f);
    if (pw > w - 28.f) { pw = w - 28.f; ph = pw * (420.f / 360.f); }
    const ImVec2 im0(a.x + (w - pw) * 0.5f, top + ((bottom - top) - ph) * 0.5f);
    const ImVec2 im1(im0.x + pw, im0.y + ph);

    // spotlight behind the model
    for (int i = 0; i < 12; ++i) {
        float t = i / 12.f;
        float rr = (pw * 0.55f) * (1.f - t);
        d->AddCircleFilled(ImVec2((im0.x + im1.x) * 0.5f, im0.y + ph * 0.42f), rr, WithA(C(150, 26, 32), 0.012f), 40);
    }
    if (g_hero.id) d->AddImage(g_hero.id, im0, im1, ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, 245));

    // ---- zones
    const int zone = st.hitbox < 0 || st.hitbox > 2 ? 2 : st.hitbox;
    const float zoneY[3] = { 0.098f, 0.160f, 0.300f };
    const char* zoneName[3] = { "HEAD", "NECK", "CHEST" };
    ImVec2 zp(im0.x + pw * 0.5f, im0.y + ph * zoneY[zone]);
    const float pulse = 0.5f + 0.5f * sinf(time * 3.2f);

    d->AddCircle(zp, 13.f + pulse * 2.f, WithA(pal.accent, 0.18f), 32, 1.f);
    d->AddCircle(zp, 9.f, WithA(pal.accent, 0.85f), 28, 1.2f);
    d->AddCircleFilled(zp, 1.6f, WithA(C(255, 240, 240), 0.95f), 8);
    for (int i = 0; i < 4; ++i) {
        float ang = i * 1.5708f;
        d->AddLine(ImVec2(zp.x + cosf(ang) * 11.f, zp.y + sinf(ang) * 11.f),
                   ImVec2(zp.x + cosf(ang) * 17.f, zp.y + sinf(ang) * 17.f), WithA(pal.accent, 0.5f), 1.f);
    }

    // leader to the zone name
    {
        float ex = b.x - 14.f;
        float lx = zp.x + 22.f;
        d->AddLine(ImVec2(lx, zp.y), ImVec2(ex - 34.f, zp.y), WithA(pal.accent, 0.30f), 1.f);
        d->AddCircleFilled(ImVec2(ex - 34.f, zp.y), 1.8f, WithA(pal.accent, 0.8f), 8);
        Text(d, font.smB, 9.f, ImVec2(ex - 30.f, zp.y - 5.5f), WithA(pal.text, 0.95f), zoneName[zone]);
    }

    // name / distance above the model
    Text(d, font.sm, 8.5f, ImVec2(im0.x + 2.f, top - 2.f), WithA(pal.textMute, 0.9f), "FID / 24m");

    // ---- bottom stats strip
    const float stripY = b.y - 48.f;
    d->AddLine(ImVec2(a.x + 12.f, stripY), ImVec2(b.x - 12.f, stripY), WithA(C(255, 255, 255), 0.06f), 1.f);
    const char* labels[4] = { "FOV", "SMOOTH", "MIN DMG", "HIT CHANCE" };
    char values[4][16];
    snprintf(values[0], 16, "%.0f", st.fov);
    snprintf(values[1], 16, "%.0f", st.smooth);
    snprintf(values[2], 16, "%.0f", st.minDamage);
    snprintf(values[3], 16, "%.0f%%", st.hitChance);
    float cellW = (w - 24.f) / 4.f;
    for (int i = 0; i < 4; ++i) {
        float cx = a.x + 12.f + cellW * i;
        if (i) d->AddLine(ImVec2(cx, stripY + 8.f), ImVec2(cx, b.y - 12.f), WithA(C(255, 255, 255), 0.05f), 1.f);
        Text(d, font.sm, 7.5f, ImVec2(cx + 8.f, stripY + 9.f), WithA(pal.textMute, 0.9f), labels[i]);
        Text(d, font.smB, 12.f, ImVec2(cx + 8.f, stripY + 21.f), WithA(pal.text, 0.96f), values[i]);
    }
}

// ---------------------------------------------------------------- crosshair
void rw::DrawCrosshairPreview(ImDrawList* d, ImRect area, float time) {
    const ImVec2 a = area.Min, b = area.Max;
    const float w = b.x - a.x, h = b.y - a.y;
    const ImVec2 c(a.x + w * 0.5f, a.y + h * 0.44f);

    d->PushClipRect(a, b, true);
    RRectGrad(d, a, b, 10.f, C(13, 7, 9), C(6, 3, 5));

    // ---- range floor: horizon + converging grid
    const float hy = c.y + h * 0.11f;
    d->AddLine(ImVec2(a.x, hy), ImVec2(b.x, hy), WithA(C(255, 60, 70), 0.14f), 1.f);
    for (int i = 1; i <= 10; ++i) {
        const float t = (float)i / 10.f;
        const float y = hy + (b.y - hy) * (t * t);
        d->AddLine(ImVec2(a.x, y), ImVec2(b.x, y), WithA(C(255, 60, 70), 0.11f * (1.f - t * 0.65f)), 1.f);
    }
    for (int i = -9; i <= 9; ++i) {
        const float xb = c.x + i * w * 0.115f;
        d->AddLine(ImVec2(c.x, hy), ImVec2(xb, b.y), WithA(C(255, 60, 70), 0.08f), 1.f);
    }
    // fade the grid towards the top
    d->AddRectFilledMultiColor(a, ImVec2(b.x, a.y + h * 0.32f),
                               WithA(C(13, 7, 9), 0.85f), WithA(C(13, 7, 9), 0.85f), 0, 0);

    Glow(d, c, 170.f, C(120, 14, 24), 0.13f, 12, 2.6f);

    // ---- reticle
    const float S = 3.6f;
    const float breathe = st.chDynamic ? (0.5f + 0.5f * sinf(time * 2.1f * ImMax(0.2f, st.chSpreadSpeed))) : 0.f;
    const float gap = (st.chGap + st.chSpread * 8.f * breathe) * S;
    const float len = st.chLen * S;
    const float th = ImMax(1.f, st.chThick * S * 0.55f);
    const ImU32 col = IM_COL32((int)(st.chColor.x * 255.f), (int)(st.chColor.y * 255.f),
                               (int)(st.chColor.z * 255.f), (int)(st.chAlpha * 255.f));

    auto seg = [&](ImVec2 p0, ImVec2 p1) {
        if (st.chOutline) {
            d->AddLine(ImVec2(p0.x + 1.f, p0.y + 1.f), ImVec2(p1.x + 1.f, p1.y + 1.f), IM_COL32(0, 0, 0, 175), th + 2.f);
            d->AddLine(ImVec2(p0.x - 1.f, p0.y - 1.f), ImVec2(p1.x - 1.f, p1.y - 1.f), IM_COL32(0, 0, 0, 120), th + 2.f);
        }
        d->AddLine(p0, p1, col, th);
    };

    if (st.chGlow) Glow(d, c, 34.f, IM_COL32((int)(st.chColor.x * 160.f), 8, 14, 255), 0.30f, 8, 2.2f);

    if (st.chStyle == 1) {
        const float r = ImMax(2.4f, st.chThick * S * 0.80f);
        if (st.chOutline) d->AddCircleFilled(ImVec2(c.x + 1.f, c.y + 1.f), r + 1.6f, IM_COL32(0, 0, 0, 175), 18);
        d->AddCircleFilled(c, r, col, 18);
    } else if (st.chStyle == 3) {
        const float rr = gap + len * 0.55f;
        if (st.chOutline) d->AddCircle(c, rr + 1.4f, IM_COL32(0, 0, 0, 150), 56, th + 1.8f);
        d->AddCircle(c, rr, col, 56, th);
        if (st.chDot) d->AddCircleFilled(c, ImMax(1.8f, th * 0.9f), col, 14);
    } else {
        seg(ImVec2(c.x - gap - len, c.y), ImVec2(c.x - gap, c.y));
        seg(ImVec2(c.x + gap, c.y), ImVec2(c.x + gap + len, c.y));
        seg(ImVec2(c.x, c.y - gap - len), ImVec2(c.x, c.y - gap));
        if (st.chStyle != 2) seg(ImVec2(c.x, c.y + gap), ImVec2(c.x, c.y + gap + len));
        if (st.chDot) {
            const float r = ImMax(1.5f, st.chThick * S * 0.40f);
            if (st.chOutline) d->AddCircleFilled(ImVec2(c.x + 1.f, c.y + 1.f), r + 1.3f, IM_COL32(0, 0, 0, 175), 12);
            d->AddCircleFilled(c, r, col, 12);
        }
    }

    // ---- stat strip along the bottom
    const float sy = b.y - 44.f;
    d->AddLine(ImVec2(a.x + 14.f, sy), ImVec2(b.x - 14.f, sy), WithA(C(255, 255, 255), 0.06f), 1.f);
    const char* labels[4] = { "GAP", "LENGTH", "THICKNESS", "OPACITY" };
    char values[4][16];
    snprintf(values[0], 16, "%.1f", st.chGap);
    snprintf(values[1], 16, "%.1f", st.chLen);
    snprintf(values[2], 16, "%.1f", st.chThick);
    snprintf(values[3], 16, "%.0f%%", st.chAlpha * 100.f);
    const float cellW = (w - 28.f) / 4.f;
    for (int i = 0; i < 4; ++i) {
        const float cx = a.x + 14.f + cellW * i;
        if (i) d->AddLine(ImVec2(cx, sy + 8.f), ImVec2(cx, b.y - 12.f), WithA(C(255, 255, 255), 0.05f), 1.f);
        TextSpaced(d, font.sm, 7.5f, ImVec2(cx + 10.f, sy + 9.f), WithA(pal.textMute, 0.85f), labels[i], 1.4f);
        TextNumRight(d, font.smB, 12.f, ImVec2(cx + cellW - 10.f, sy + 20.f), WithA(pal.text, 0.96f), values[i]);
    }

    // live tag
    char live[48];
    snprintf(live, sizeof live, st.chDynamic ? "DYNAMIC / %.2f" : "STATIC", st.chSpread);
    TextSpaced(d, font.sm, 8.f, ImVec2(a.x + 16.f, a.y + 14.f), WithA(st.chDynamic ? pal.accentSoft : pal.textMute, 0.7f), live, 1.8f);

    d->PopClipRect();
}
void rw::DrawCrosshairMini(ImDrawList* d, ImVec2 c, int style, ImU32 col, float s) {
    const float th = ImMax(1.f, s * 0.055f);
    const float gap = s * 0.15f, len = s * 0.26f;
    if (style == 1) {
        d->AddCircleFilled(c, s * 0.085f, col, 12);
        return;
    }
    if (style == 3) {
        d->AddCircle(c, gap + len * 0.55f, col, 30, th);
        d->AddCircleFilled(c, th * 0.9f, col, 8);
        return;
    }
    d->AddLine(ImVec2(c.x - gap - len, c.y), ImVec2(c.x - gap, c.y), col, th);
    d->AddLine(ImVec2(c.x + gap, c.y), ImVec2(c.x + gap + len, c.y), col, th);
    d->AddLine(ImVec2(c.x, c.y - gap - len), ImVec2(c.x, c.y - gap), col, th);
    if (style != 2) d->AddLine(ImVec2(c.x, c.y + gap), ImVec2(c.x, c.y + gap + len), col, th);
    d->AddCircleFilled(c, th * 0.9f, col, 8);
}