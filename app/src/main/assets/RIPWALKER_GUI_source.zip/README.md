# RIPWALKER GUI

Standalone showcase menu (Win32 + DirectX 11 + Dear ImGui). It is **not** injected into any game —
it is a separate window with working controls: sliders, toggles, dropdowns, colour pickers,
3D model preview and a live crosshair editor.

![settings](docs/preview_settings.png)

## Требования

- Windows 10 1809+ / Windows 11 (нужен DirectComposition — на нём держится скругление окна;
  если DComp недоступен, окно откатывается на обычную swap chain)
- Visual Studio 2022 или 2026 с C++ workload (MSVC + Windows SDK 10.0.22621+)
- CMake 3.21+

Внешних зависимостей нет: Dear ImGui лежит в `third_party/imgui` (1.91.5), шрифты, логотип,
аватар и 3D-модель вшиты в exe как байтовые массивы в `src/*_embed.cpp`.

## Сборка

```
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

Для VS 2026 генератор называется `"Visual Studio 18 2026"`.
Результат: `build/Release/ripwalker.exe`.

## Управление

| действие | что делает |
|---|---|
| `Insert` | показать / скрыть меню (плавный фейд, работает глобально) |
| `Esc` | закрыть меню (окно остаётся в памяти, вернуть — `Insert`) |
| крестик в шапке | выход из программы |
| драг за шапку | перетаскивание окна |
| колесо над 3D-моделью | зум модели |

Ключ запуска: `ripwalker.exe 3` открывает сразу нужную вкладку (`3` — Crosshair, `4` — Misc,
`5` — Settings). Удобно для скриншотов.

## Структура

```
src/
  main.cpp        окно, D3D11, DirectComposition, цикл рендера, хоткеи
  ui.cpp          все страницы меню, виджеты, иконки, навигация, оболочка
  ui.hpp          состояние (State) и публичный API
  preview.cpp     превью: 3D-оператор с ESP-обвязкой, прицел на полигоне, мини-иконки
  hero3d.cpp      свой парсер GLB + софтверный скиннинг-рендер модели в RGBA-буфер
  draw.hpp        низкоуровневые хелперы рисования (RRectGrad, Glow, TextSpaced, TextNumRight…)
  theme.hpp       палитра
  assets_embed.cpp / avatar_embed.cpp / font_embed.cpp / lotek_embed.cpp
                  сгенерированные байтовые массивы (PNG/TTF/GLB)
assets/
  fonts/          LOTEK.ttf + Inter (Regular/Medium/SemiBold/Bold)
  model/hero.glb  модель с ригом (34 кости)
  avatar.png      аватар 512×512 с круглой альфой
  logo_keyed.png  логотип с вычерненным в прозрачность фоном
third_party/imgui Dear ImGui 1.91.5 + бэкенды DX11/Win32
```

## Как перегенерировать вшитые ассеты

Массивы в `src/*_embed.cpp` — обычный дамп байтов. Любой файл превращается так:

```powershell
$b = [System.IO.File]::ReadAllBytes("assets\avatar.png")
$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine("// auto-generated")
[void]$sb.AppendLine("#include <cstddef>")
[void]$sb.AppendLine("extern const unsigned char kAvatarPng[];")
[void]$sb.AppendLine("extern const size_t kAvatarPng_len;")
[void]$sb.AppendLine("alignas(16) const unsigned char kAvatarPng[] = {")
for ($i = 0; $i -lt $b.Length; $i += 24) {
    $end = [Math]::Min($i + 23, $b.Length - 1)
    [void]$sb.AppendLine((($b[$i..$end] | ForEach-Object { $_.ToString() }) -join ',') + ',')
}
[void]$sb.AppendLine("};")
[void]$sb.AppendLine("const size_t kAvatarPng_len = sizeof(kAvatarPng);")
[System.IO.File]::WriteAllText("src\avatar_embed.cpp", $sb.ToString())
```

## Что внутри по вкладкам

- **Aimbot** — превью цели с сегментированным выбором зоны (HEAD / NECK / CHEST) и полосой статов.
- **Visuals** — широкий 3D-превью с чеймами и двумя карточками WORLD / EFFECTS.
- **Esp** — модель с боксом, скелетом и полосой элементов, карточки ELEMENTS / STYLE.
- **Crosshair** — полигон с перспективной сеткой, чипы стилей, полоса GAP/LENGTH/THICKNESS/OPACITY,
  пресеты цвета, динамический разброс, Reset.
- **Misc** — MOVEMENT / COMBAT / FEEDBACK / SESSION.
- **Settings** — профили конфигов (со списком и empty-state), тема, About с подписью.

## Детали реализации, которые стоит знать

- Окно `WS_POPUP` + `WS_EX_NOREDIRECTIONBITMAP`, настоящие скруглённые углы через
  `IDCompositionRectangleClip`, а не DWM-атрибут.
- MSAA 4x: рендер в мультисемпловый таргет, `ResolveSubresource` в промежуточную текстуру,
  затем `CopyResource` в бэкбуфер (прямой resolve в композишн-бэкбуфер не работает).
- Шрифты растеризуются под DPI, координаты считаются в логических пикселях и масштабируются
  при отправке.
- Числа в слайдерах рисуются `TextNumRight` — фиксированная ширина ячейки, поэтому строка не дёргается.

## Лицензии

- Dear ImGui — MIT (Omar Cornut).
- Inter — SIL Open Font License 1.1.
- LOTEK, логотип, аватар и GLB-модель — ассеты автора проекта, права у их владельцев.
- Код GUI — как есть, без гарантий.
