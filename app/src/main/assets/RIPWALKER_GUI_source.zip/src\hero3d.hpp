// RIPWALKER :: tiny GLB loader + software skinning renderer
#pragma once

#include "imgui.h"
#include <cstdint>
#include <string>
#include <vector>

namespace rw {

struct HeroVertex {
    float px, py, pz;
    float nx, ny, nz;
    float u, v;
    int   j[4] = { 0, 0, 0, 0 };
    float w[4] = { 1, 0, 0, 0 };
};

struct HeroModel {
    bool ok = false;
    std::vector<HeroVertex> verts;
    std::vector<uint32_t>   idx;
    std::vector<ImVec2>     bindBones;   // joints in mesh space (bind pose)
    std::vector<std::string> boneNames;
    std::vector<std::pair<int, int>> bonePairs;
    int texW = 0, texH = 0;
    std::vector<uint32_t> tex;           // RGBA8
    ImVec2 bbMin{ 0, 0 }, bbMax{ 0, 0 };
    float  height = 1.f;
};

bool LoadHeroGLB(const void* data, size_t len, HeroModel& out);
bool DecodeImageRGBA(const void* data, size_t len, int& w, int& h, std::vector<uint32_t>& rgba);

// Renders the model into an RGBA buffer; joints come back in 0..1 screen space.
void RenderHero(HeroModel& m, int w, int h, float yaw, float pitch, float zoom,
                float time, uint32_t* fb, std::vector<ImVec2>& jointsOut);

} // namespace rw
