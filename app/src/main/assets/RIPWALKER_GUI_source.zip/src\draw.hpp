// RIPWALKER :: low level drawing helpers
#pragma once

#include "theme.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include <vector>
#include <cstring>

namespace rw {

// ---------------------------------------------------------------- primitives
inline void QuadGrad(ImDrawList* d, ImVec2 a, ImVec2 b, ImU32 top, ImU32 bot) {
    d->AddRectFilledMultiColor(a, b, top, top, bot, bot);
}

inline void QuadGradH(ImDrawList* d, ImVec2 a, ImVec2 b, ImU32 left, ImU32 right) {
    d->AddRectFilledMultiColor(a, b, left, right, right, left);
}

// Rounded rect with a vertical gradient: sliced so corners stay round.
inline void RRectGrad(ImDrawList* d, ImVec2 a, ImVec2 b, float r, ImU32 cTop, ImU32 cBot) {
    float h = b.y - a.y;
    if (h <= 0.f || b.x <= a.x) return;
    if (r <= 0.5f || h < 4.f) { QuadGrad(d, a, b, cTop, cBot); return; }
    r = ImMin(r, ImMin(h * 0.5f, (b.x - a.x) * 0.5f));
    const int steps = ImMax(2, (int)(h * 0.5f));
    const float stepH = h / steps;
    for (int i = 0; i < steps; ++i) {
        float y0 = a.y + stepH * i;
        float y1 = y0 + stepH + (i == steps - 1 ? 0.6f : 0.4f);
        float t = (float)i / (float)(steps - 1);
        float inset = 0.f;
        if (y0 - a.y < r) {
            float dy = r - (y0 - a.y);
            inset = r - sqrtf(ImMax(0.f, r * r - dy * dy));
        } else if (b.y - y1 < r) {
            float dy = r - (b.y - y1);
            inset = r - sqrtf(ImMax(0.f, r * r - dy * dy));
        }
        d->AddRectFilled(ImVec2(a.x + inset, y0), ImVec2(b.x - inset, y1), Mix(cTop, cBot, t));
    }
}

inline void ShadowRect(ImDrawList* d, ImVec2 a, ImVec2 b, float r, float spread, float alpha, ImU32 col, int steps = 12) {
    for (int i = steps; i >= 1; --i) {
        float e = spread * ((float)i / (float)steps);
        float al = alpha * (1.f - (float)i / (float)steps) * 0.55f + alpha * 0.06f;
        d->AddRect(ImVec2(a.x - e, a.y - e * 1.4f), ImVec2(b.x + e, b.y + e), WithA(col, al), r + e, 0, 1.6f);
    }
}

inline void Glow(ImDrawList* d, ImVec2 c, float radius, ImU32 col, float alpha = 1.f, int rings = 14, float power = 1.8f) {
    if (radius <= 0.f) return;
    for (int i = 0; i < rings; ++i) {
        float t = (float)i / (float)rings;
        float rr = radius * (1.f - t);
        float a = alpha * powf(1.f - t, power) / (float)rings * 2.2f;
        d->AddCircleFilled(c, rr, WithA(col, a), 48);
    }
}

// soft drop shadow under a character
inline void GroundShadow(ImDrawList* d, ImVec2 c, float rx, float ry, ImU32 col, float alpha) {
    for (int i = 10; i >= 1; --i) {
        float t = (float)i / 10.f;
        d->AddEllipseFilled(ImVec2(c.x, c.y), ImVec2(rx * t, ry * t), WithA(col, alpha * (1.f - t) * 0.22f), 0.f, 40);
    }
}

// tapered capsule polygon
inline int BuildCapsule(ImVec2* out, ImVec2 p0, ImVec2 p1, float r0, float r1, int seg = 7) {
    ImVec2 dir(p1.x - p0.x, p1.y - p0.y);
    float len = sqrtf(dir.x * dir.x + dir.y * dir.y);
    if (len < 0.0001f) { dir = ImVec2(0.f, 1.f); len = 1.f; }
    ImVec2 n(dir.x / len, dir.y / len);
    ImVec2 perp(-n.y, n.x);
    int k = 0;
    for (int i = 0; i <= seg; ++i) {
        float a = IM_PI * 0.5f + (float)i / (float)seg * IM_PI;
        float ca = cosf(a), sa = sinf(a);
        out[k++] = ImVec2(p1.x + (perp.x * ca + n.x * sa) * r1, p1.y + (perp.y * ca + n.y * sa) * r1);
    }
    for (int i = 0; i <= seg; ++i) {
        float a = -IM_PI * 0.5f + (float)i / (float)seg * IM_PI;
        float ca = cosf(a), sa = sinf(a);
        out[k++] = ImVec2(p0.x + (perp.x * ca + n.x * sa) * r0, p0.y + (perp.y * ca + n.y * sa) * r0);
    }
    return k;
}

// polygon filled with a left->right lighting gradient
inline void PolyLit(ImDrawList* d, const ImVec2* pts, int n, ImU32 dark, ImU32 light) {
    if (n < 3) return;
    float minx = pts[0].x, maxx = pts[0].x;
    for (int i = 1; i < n; ++i) { minx = ImMin(minx, pts[i].x); maxx = ImMax(maxx, pts[i].x); }
    float span = ImMax(1.f, maxx - minx);
    ImVec2 uv = d->_Data->TexUvWhitePixel;
    int vtx = d->_VtxCurrentIdx;
    d->PrimReserve((n - 2) * 3, n);
    for (int i = 0; i < n; ++i) {
        float t = (pts[i].x - minx) / span;
        d->PrimWriteVtx(pts[i], uv, Mix(dark, light, t));
    }
    for (int i = 1; i < n - 1; ++i) {
        d->PrimWriteIdx((ImDrawIdx)vtx);
        d->PrimWriteIdx((ImDrawIdx)(vtx + i));
        d->PrimWriteIdx((ImDrawIdx)(vtx + i + 1));
    }
}

inline void Limb(ImDrawList* d, ImVec2 p0, ImVec2 p1, float r0, float r1, ImU32 dark, ImU32 light, int seg = 7) {
    ImVec2 poly[32];
    int n = BuildCapsule(poly, p0, p1, r0, r1, seg);
    PolyLit(d, poly, n, dark, light);
}

// ---------------------------------------------------------------- text
struct FontSet {
    ImFont* tiny = nullptr;
    ImFont* sm = nullptr;
    ImFont* smB = nullptr;
    ImFont* body = nullptr;
    ImFont* bodyB = nullptr;
    ImFont* h2 = nullptr;
    ImFont* h1 = nullptr;
    ImFont* logo = nullptr;
    ImFont* big = nullptr;
    float szTiny = 9.f, szSmall = 11.f, szBody = 12.5f, szH2 = 15.f, szH1 = 19.f, szLogo = 15.f, szBig = 28.f;
};

inline FontSet font;

inline ImVec2 TextSize(ImFont* f, float size, const char* s, const char* end = nullptr) {
    if (!f) return ImVec2(0, 0);
    return f->CalcTextSizeA(size, FLT_MAX, 0.f, s, end);
}

inline void Text(ImDrawList* d, ImFont* f, float size, ImVec2 p, ImU32 col, const char* s, const char* end = nullptr) {
    if (f) d->AddText(f, size, p, col, s, end);
}

inline float TextSpaced(ImDrawList* d, ImFont* f, float size, ImVec2 p, ImU32 col, const char* s, float tracking) {
    float x = p.x;
    const char* c = s;
    while (*c) {
        char buf[2] = { *c, 0 };
        if (d && f) d->AddText(f, size, ImVec2(x, p.y), col, buf);
        x += (f ? f->CalcTextSizeA(size, FLT_MAX, 0.f, buf).x : 0.f) + tracking;
        ++c;
    }
    return x - p.x;
}

inline float SpacedWidth(ImFont* f, float size, const char* s, float tracking) {
    float x = 0.f;
    if (!f) return 0.f;
    for (const char* c = s; *c; ++c) {
        char buf[2] = { *c, 0 };
        x += f->CalcTextSizeA(size, FLT_MAX, 0.f, buf).x + tracking;
    }
    return x;
}

// right aligned numbers with fixed cells: "1" and "8" take the same width,
// so nothing on the row shifts while a slider is dragged
inline void TextNumRight(ImDrawList* d, ImFont* f, float size, ImVec2 rightTop, ImU32 col, const char* s) {
    if (!f || !s || !*s) return;
    const float cw = TextSize(f, size, "0").x;
    const int n = (int)strlen(s);
    float x = rightTop.x - cw * (float)n;
    for (int i = 0; i < n; ++i) {
        char b[2] = { s[i], 0 };
        const float w = TextSize(f, size, b).x;
        if (d) d->AddText(f, size, ImVec2(x + (cw - w) * 0.5f, rightTop.y), col, b);
        x += cw;
    }
}

inline void TextRight(ImDrawList* d, ImFont* f, float size, ImVec2 rightTop, ImU32 col, const char* s) {
    ImVec2 sz = TextSize(f, size, s);
    Text(d, f, size, ImVec2(rightTop.x - sz.x, rightTop.y), col, s);
}

inline void TextCenter(ImDrawList* d, ImFont* f, float size, ImVec2 center, ImU32 col, const char* s) {
    ImVec2 sz = TextSize(f, size, s);
    Text(d, f, size, ImVec2(center.x - sz.x * 0.5f, center.y - sz.y * 0.5f), col, s);
}

} // namespace rw
