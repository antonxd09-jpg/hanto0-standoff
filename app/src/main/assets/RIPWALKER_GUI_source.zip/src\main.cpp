// RIPWALKER :: standalone menu host (Win32 + DirectX 11 + Dear ImGui)
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"
#include "ui.hpp"
#include "hero3d.hpp"

#include <d3d11.h>
#include <dcomp.h>
#include <dwmapi.h>
#include <tchar.h>
#include <windows.h>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "dcomp.lib")

using namespace rw;

static ID3D11Device* g_dev = nullptr;
static ID3D11DeviceContext* g_ctx = nullptr;
static IDXGISwapChain* g_swap = nullptr;
static ID3D11RenderTargetView* g_rtv = nullptr;
static ID3D11Texture2D*        g_msaaTex = nullptr;
static ID3D11RenderTargetView* g_msaaRtv = nullptr;
static ID3D11Texture2D*        g_resolveTex = nullptr;
static ID3D11ShaderResourceView* g_desktop = nullptr;
static IDCompositionDevice* g_dcDev = nullptr;
static IDCompositionTarget* g_dcTarget = nullptr;
static IDCompositionVisual* g_dcVisual = nullptr;
static bool g_useDComp = false;
static float g_cornerRadius = 14.f;
static UINT g_width = 0, g_height = 0;
static float g_scale = 1.f;
static bool g_wantOpen = true;
static volatile bool g_toggleReq = false;

// embedded assets
extern const unsigned char kLogoPng[];
extern const size_t kLogoPng_len;
extern const unsigned char kAvatarPng[];
extern const size_t kAvatarPng_len;
extern const unsigned char kHeroGlb[];
extern const size_t kHeroGlb_len;

namespace rw {
    TexRef g_logo;
    TexRef g_avatar;
    TexRef g_hero;
    std::vector<ImVec2> g_heroJoints;
    std::vector<std::pair<int, int>> g_heroPairs;
}

static rw::HeroModel g_heroModel;
static std::vector<uint32_t> g_heroPixels;
static ID3D11Texture2D* g_heroTex2D = nullptr;
static const int HERO_W = 360;
static const int HERO_H = 420;

static ID3D11ShaderResourceView* MakeTexRGBA(const uint32_t* pix, int w, int h) {
    D3D11_TEXTURE2D_DESC td = {};
    td.Width = (UINT)w; td.Height = (UINT)h; td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_IMMUTABLE; td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA sd = {};
    sd.pSysMem = pix; sd.SysMemPitch = (UINT)w * 4;
    ID3D11Texture2D* tex = nullptr;
    if (FAILED(g_dev->CreateTexture2D(&td, &sd, &tex)) || !tex) return nullptr;
    ID3D11ShaderResourceView* srv = nullptr;
    g_dev->CreateShaderResourceView(tex, nullptr, &srv);
    tex->Release();
    return srv;
}

static bool CreateHeroTexture(int w, int h) {
    D3D11_TEXTURE2D_DESC td = {};
    td.Width = (UINT)w; td.Height = (UINT)h; td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    if (FAILED(g_dev->CreateTexture2D(&td, nullptr, &g_heroTex2D)) || !g_heroTex2D) return false;
    ID3D11ShaderResourceView* srv = nullptr;
    g_dev->CreateShaderResourceView(g_heroTex2D, nullptr, &srv);
    rw::g_hero.id = (ImTextureID)(intptr_t)srv;
    rw::g_hero.w = w;
    rw::g_hero.h = h;
    return srv != nullptr;
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

static void ScaleDrawData(ImDrawData* dd, float s) {
    if (!dd || s == 1.f) return;
    for (int i = 0; i < dd->CmdListsCount; ++i) {
        ImDrawList* dl = dd->CmdLists[i];
        for (int v = 0; v < dl->VtxBuffer.Size; ++v) {
            dl->VtxBuffer[v].pos.x *= s;
            dl->VtxBuffer[v].pos.y *= s;
        }
        for (int c = 0; c < dl->CmdBuffer.Size; ++c) {
            ImDrawCmd& cmd = dl->CmdBuffer[c];
            cmd.ClipRect.x *= s; cmd.ClipRect.y *= s;
            cmd.ClipRect.z *= s; cmd.ClipRect.w *= s;
        }
    }
    dd->DisplaySize.x *= s;
    dd->DisplaySize.y *= s;
}

// ------------------------------------------------------------------ screen grab
static ID3D11ShaderResourceView* CaptureDesktop(ID3D11Device* dev, UINT w, UINT h) {
    HDC screen = ::GetDC(nullptr);
    if (!screen) return nullptr;

    BITMAPINFO bi = {};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = (LONG)w;
    bi.bmiHeader.biHeight = -(LONG)h;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    HDC mem = ::CreateCompatibleDC(screen);
    HBITMAP hbm = ::CreateDIBSection(mem, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!hbm || !bits) {
        if (hbm) ::DeleteObject(hbm);
        ::DeleteDC(mem);
        ::ReleaseDC(nullptr, screen);
        return nullptr;
    }
    HGDIOBJ oldMem = ::SelectObject(mem, hbm);

    // cheap two-pass blur so the dimmed desktop does not feel noisy
    const int sw = (int)ImMax(16u, w / 6), sh = (int)ImMax(16u, h / 6);
    BITMAPINFO bism = bi;
    bism.bmiHeader.biWidth = sw;
    bism.bmiHeader.biHeight = -sh;
    void* smallBits = nullptr;
    HDC smallDc = ::CreateCompatibleDC(screen);
    HBITMAP hbmSmall = ::CreateDIBSection(smallDc, &bism, DIB_RGB_COLORS, &smallBits, nullptr, 0);
    if (hbmSmall && smallBits) {
        HGDIOBJ oldSmall = ::SelectObject(smallDc, hbmSmall);
        ::SetStretchBltMode(smallDc, HALFTONE);
        ::SetBrushOrgEx(smallDc, 0, 0, nullptr);
        ::StretchBlt(smallDc, 0, 0, sw, sh, screen, 0, 0, (int)w, (int)h, SRCCOPY);
        ::SetStretchBltMode(mem, HALFTONE);
        ::SetBrushOrgEx(mem, 0, 0, nullptr);
        ::StretchBlt(mem, 0, 0, (int)w, (int)h, smallDc, 0, 0, sw, sh, SRCCOPY);
        ::SelectObject(smallDc, oldSmall);
    } else {
        ::BitBlt(mem, 0, 0, (int)w, (int)h, screen, 0, 0, SRCCOPY | CAPTUREBLT);
    }
    if (hbmSmall) ::DeleteObject(hbmSmall);
    ::DeleteDC(smallDc);

    std::vector<unsigned char> pixels((size_t)w * h * 4);
    memcpy(pixels.data(), bits, pixels.size());

    ::SelectObject(mem, oldMem);
    ::DeleteObject(hbm);
    ::DeleteDC(mem);
    ::ReleaseDC(nullptr, screen);

    D3D11_TEXTURE2D_DESC td = {};
    td.Width = w;
    td.Height = h;
    td.MipLevels = 1;
    td.ArraySize = 1;
    td.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_IMMUTABLE;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA sd = {};
    sd.pSysMem = pixels.data();
    sd.SysMemPitch = w * 4;

    ID3D11Texture2D* tex = nullptr;
    ID3D11ShaderResourceView* srv = nullptr;
    if (FAILED(dev->CreateTexture2D(&td, &sd, &tex)) || !tex) return nullptr;
    D3D11_SHADER_RESOURCE_VIEW_DESC svd = {};
    svd.Format = td.Format;
    svd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    svd.Texture2D.MipLevels = 1;
    dev->CreateShaderResourceView(tex, &svd, &srv);
    tex->Release();
    return srv;
}

// ------------------------------------------------------------------ d3d
static bool CreateD3D() {
    UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
    D3D_FEATURE_LEVEL fl;
    const D3D_FEATURE_LEVEL fls[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags, fls, 2,
                                  D3D11_SDK_VERSION, &g_dev, &fl, &g_ctx);
    if (hr == DXGI_ERROR_UNSUPPORTED)
        hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, flags, fls, 2,
                              D3D11_SDK_VERSION, &g_dev, &fl, &g_ctx);
    if (FAILED(hr) || !g_dev) return false;

    IDXGIDevice* dxgiDev = nullptr;
    if (SUCCEEDED(g_dev->QueryInterface(IID_PPV_ARGS(&dxgiDev))) && dxgiDev) {
        IDCompositionDevice* dv = nullptr;
        if (SUCCEEDED(DCompositionCreateDevice(dxgiDev, IID_PPV_ARGS(&dv))) && dv) {
            g_dcDev = dv;
            g_useDComp = true;
        }
        dxgiDev->Release();
    }
    return true;
}

// the rounded window is a composition visual clipped by a rounded rect
static bool PrepareComposition(HWND hwnd) {
    if (!g_useDComp || !g_dcDev) return false;
    if (FAILED(g_dcDev->CreateTargetForHwnd(hwnd, TRUE, &g_dcTarget)) || !g_dcTarget) { g_useDComp = false; return false; }
    if (FAILED(g_dcDev->CreateVisual(&g_dcVisual)) || !g_dcVisual) { g_useDComp = false; return false; }
    return true;
}

static bool CreateSwapchain(HWND hwnd) {
    IDXGIDevice* dxgiDev = nullptr;
    if (FAILED(g_dev->QueryInterface(IID_PPV_ARGS(&dxgiDev))) || !dxgiDev) return false;
    IDXGIAdapter* ad = nullptr;
    dxgiDev->GetAdapter(&ad);
    IDXGIFactory2* fac = nullptr;
    if (ad) ad->GetParent(IID_PPV_ARGS(&fac));
    if (!fac) { if (ad) ad->Release(); dxgiDev->Release(); return false; }

    DXGI_SWAP_CHAIN_DESC1 sd = {};
    sd.Width = g_width;
    sd.Height = g_height;
    sd.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    sd.SampleDesc.Count = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.BufferCount = 2;
    sd.SwapEffect = DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
    sd.Scaling = DXGI_SCALING_STRETCH;
    sd.AlphaMode = DXGI_ALPHA_MODE_IGNORE;

    IDXGISwapChain1* sc1 = nullptr;
    HRESULT hr = E_FAIL;
    if (g_useDComp) hr = fac->CreateSwapChainForComposition(dxgiDev, &sd, nullptr, &sc1);
    if (FAILED(hr) || !sc1) {
        g_useDComp = false;
        sd.AlphaMode = DXGI_ALPHA_MODE_IGNORE;
        hr = fac->CreateSwapChainForHwnd(dxgiDev, hwnd, &sd, nullptr, nullptr, &sc1);
    }
    fac->Release();
    if (ad) ad->Release();
    dxgiDev->Release();
    if (FAILED(hr) || !sc1) return false;
    g_swap = sc1;

    if (g_useDComp && g_dcDev && g_dcVisual && g_dcTarget) {
        g_dcVisual->SetContent(sc1);
        IDCompositionRectangleClip* clip = nullptr;
        if (SUCCEEDED(g_dcDev->CreateRectangleClip(&clip)) && clip) {
            const float r = g_cornerRadius * g_scale;
            clip->SetLeft(0.f);
            clip->SetTop(0.f);
            clip->SetRight((float)g_width);
            clip->SetBottom((float)g_height);
            clip->SetTopLeftRadiusX(r); clip->SetTopLeftRadiusY(r);
            clip->SetTopRightRadiusX(r); clip->SetTopRightRadiusY(r);
            clip->SetBottomLeftRadiusX(r); clip->SetBottomLeftRadiusY(r);
            clip->SetBottomRightRadiusX(r); clip->SetBottomRightRadiusY(r);
            g_dcVisual->SetClip(clip);
            clip->Release();
        }
        g_dcTarget->SetRoot(g_dcVisual);
        g_dcDev->Commit();
    }

    ID3D11Texture2D* back = nullptr;
    g_swap->GetBuffer(0, IID_PPV_ARGS(&back));
    if (back) {
        g_dev->CreateRenderTargetView(back, nullptr, &g_rtv);
        D3D11_TEXTURE2D_DESC bd = {};
        back->GetDesc(&bd);
        UINT levels = 0;
        g_dev->CheckMultisampleQualityLevels(bd.Format, 4, &levels);
        if (levels > 0 && !getenv("RW_NOAA")) {
            D3D11_TEXTURE2D_DESC md = bd;
            md.SampleDesc.Count = 4;
            md.SampleDesc.Quality = 0;
            md.BindFlags = D3D11_BIND_RENDER_TARGET;
            if (SUCCEEDED(g_dev->CreateTexture2D(&md, nullptr, &g_msaaTex))) {
                if (FAILED(g_dev->CreateRenderTargetView(g_msaaTex, nullptr, &g_msaaRtv))) {
                    g_msaaTex->Release(); g_msaaTex = nullptr;
                }
            }
        }
        back->Release();
    }

    if (g_msaaRtv) {
        D3D11_TEXTURE2D_DESC rd = {};
        rd.Width = g_width;
        rd.Height = g_height;
        rd.MipLevels = 1;
        rd.ArraySize = 1;
        rd.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
        rd.SampleDesc.Count = 1;
        rd.Usage = D3D11_USAGE_DEFAULT;
        rd.BindFlags = 0;
        g_dev->CreateTexture2D(&rd, nullptr, &g_resolveTex);
    }
    return true;
}

static void DestroyDevice() {
    if (g_desktop) { g_desktop->Release(); g_desktop = nullptr; }
    if (g_dcVisual) { g_dcVisual->Release(); g_dcVisual = nullptr; }
    if (g_dcTarget) { g_dcTarget->Release(); g_dcTarget = nullptr; }
    if (g_dcDev) { g_dcDev->Release(); g_dcDev = nullptr; }
    if (g_msaaRtv) { g_msaaRtv->Release(); g_msaaRtv = nullptr; }
    if (g_msaaTex) { g_msaaTex->Release(); g_msaaTex = nullptr; }
    if (g_resolveTex) { g_resolveTex->Release(); g_resolveTex = nullptr; }
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    if (g_swap) { g_swap->Release(); g_swap = nullptr; }
    if (g_ctx) { g_ctx->Release(); g_ctx = nullptr; }
    if (g_dev) { g_dev->Release(); g_dev = nullptr; }
}

static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wp, lp)) return true;
    switch (msg) {
        case WM_HOTKEY:
            if (wp == 1) g_toggleReq = true;
            return 0;
        case WM_KEYDOWN:
            if (wp == VK_ESCAPE) { g_wantOpen = false; g_toggleReq = false; return 0; }
            if (wp == VK_INSERT) { g_toggleReq = true; return 0; }
            break;
        case WM_SYSCOMMAND:
            if ((wp & 0xfff0) == SC_KEYMENU) return 0;
            break;
        case WM_DESTROY:
            ::PostQuitMessage(0);
            return 0;
    }
    return ::DefWindowProcW(hwnd, msg, wp, lp);
}

extern const unsigned char kFontRegular[];
extern const size_t kFontRegular_len;
extern const unsigned char kFontSemiBold[];
extern const size_t kFontSemiBold_len;
extern const unsigned char kFontBold[];
extern const size_t kFontBold_len;
extern const unsigned char kFontLotek[];
extern const size_t kFontLotek_len;

static void LoadFonts(float s) {
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->AddFontDefault();

    ImFontConfig base;
    base.OversampleH = 2;
    base.OversampleV = 1;
    base.PixelSnapH = true;
    base.RasterizerMultiply = 1.02f;
    base.FontDataOwnedByAtlas = false;

    auto addMem = [&](const unsigned char* data, size_t len, float px) -> ImFont* {
        if (!data || !len) return io.FontDefault;
        ImFontConfig cfg = base;
        ImFont* f = io.Fonts->AddFontFromMemoryTTF((void*)data, (int)len, px * s, &cfg);
        return f ? f : io.FontDefault;
    };

    font.tiny  = addMem(kFontRegular,  kFontRegular_len,  9.5f);
    font.sm    = addMem(kFontLotek,    kFontLotek_len,   11.f);
    font.smB   = addMem(kFontLotek,    kFontLotek_len,   11.f);
    font.body  = addMem(kFontLotek,    kFontLotek_len,   12.5f);
    font.bodyB = addMem(kFontLotek,    kFontLotek_len,   12.5f);
    font.h2    = addMem(kFontSemiBold, kFontSemiBold_len, 15.f);
    font.h1    = addMem(kFontLotek,    kFontLotek_len,    21.f);
    font.logo  = addMem(kFontLotek,    kFontLotek_len,    16.f);
    font.big   = addMem(kFontLotek,    kFontLotek_len,    30.f);

    io.FontGlobalScale = 1.f / s;
}

static BOOL CALLBACK MonEnumProc(HMONITOR h, HDC, LPRECT, LPARAM lp) {
    auto* v = reinterpret_cast<std::vector<RECT>*>(lp);
    MONITORINFO mi = {};
    mi.cbSize = sizeof(mi);
    if (::GetMonitorInfoW(h, &mi)) v->push_back(mi.rcMonitor);
    return TRUE;
}

static HWND Host() {
    HWND h = ::GetActiveWindow();
    if (!h) h = ::FindWindowW(nullptr, L"RIPWALKER");
    return h;
}
static POINT g_dragCur{};
static RECT  g_dragWin{};

void rw::DragHostBegin() {
    ::GetCursorPos(&g_dragCur);
    HWND h = Host();
    if (h) ::GetWindowRect(h, &g_dragWin);
}
void rw::DragHostUpdate() {
    HWND h = Host();
    if (!h) return;
    POINT p;
    ::GetCursorPos(&p);
    ::SetWindowPos(h, nullptr, g_dragWin.left + (p.x - g_dragCur.x), g_dragWin.top + (p.y - g_dragCur.y),
                   0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}
void rw::DragHostEnd() {}

int main(int argc, char** argv) {
    // optional: open a given tab ("2" or "--tab=2") - used by the screenshot scripts
    for (int i = 1; i < argc; ++i) {
        if (!argv[i]) continue;
        const char* a = argv[i];
        if (a[0] >= '0' && a[0] <= '9') st.tab = atoi(a);
        else if (strncmp(a, "--tab=", 6) == 0) st.tab = atoi(a + 6);
    }

    typedef BOOL(WINAPI* SetCtxFn)(DPI_AWARENESS_CONTEXT);
    if (auto p = (SetCtxFn)::GetProcAddress(::GetModuleHandleW(L"user32.dll"), "SetProcessDpiAwarenessContext"))
        p(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    else
        ::SetProcessDPIAware();

    {
        const int logicalW = 920, logicalH = 600;
        g_width = (UINT)(logicalW * g_scale);
        g_height = (UINT)(logicalH * g_scale);
    }

    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0, 0, ::GetModuleHandleW(nullptr),
                       nullptr, ::LoadCursorW(nullptr, IDC_ARROW), nullptr, nullptr, L"RIPWALKER", nullptr };
    ::RegisterClassExW(&wc);

    // open on the second monitor when it exists
    RECT monRect = { 0, 0, ::GetSystemMetrics(SM_CXSCREEN), ::GetSystemMetrics(SM_CYSCREEN) };
    {
        std::vector<RECT> mons;
        ::EnumDisplayMonitors(nullptr, nullptr, MonEnumProc, (LPARAM)&mons);
        if (mons.size() > 1) {
            for (auto& r : mons) {
                if (!(r.left == 0 && r.top == 0)) { monRect = r; break; }
            }
        } else if (mons.size() == 1) {
            monRect = mons[0];
        }
    }
    const int px = monRect.left + ((monRect.right - monRect.left) - (int)g_width) / 2;
    const int py = monRect.top + ((monRect.bottom - monRect.top) - (int)g_height) / 2;

    if (!CreateD3D()) { ::UnregisterClassW(wc.lpszClassName, wc.hInstance); return 1; }

    DWORD exStyle = WS_EX_TOPMOST | WS_EX_TOOLWINDOW | (g_useDComp ? WS_EX_NOREDIRECTIONBITMAP : 0);
    HWND hwnd = ::CreateWindowExW(exStyle, wc.lpszClassName, L"RIPWALKER", WS_POPUP,
                                  px, py, (int)g_width, (int)g_height, nullptr, nullptr, wc.hInstance, nullptr);
    if (!hwnd) { DestroyDevice(); ::UnregisterClassW(wc.lpszClassName, wc.hInstance); return 1; }

    if (!PrepareComposition(hwnd)) {
        ::DestroyWindow(hwnd);
        hwnd = ::CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, wc.lpszClassName, L"RIPWALKER", WS_POPUP,
                                 px, py, (int)g_width, (int)g_height, nullptr, nullptr, wc.hInstance, nullptr);
        if (!hwnd) { DestroyDevice(); ::UnregisterClassW(wc.lpszClassName, wc.hInstance); return 1; }
    }

    if (!CreateSwapchain(hwnd)) {
        DestroyDevice(); ::DestroyWindow(hwnd); ::UnregisterClassW(wc.lpszClassName, wc.hInstance); return 1;
    }
    ::RegisterHotKey(hwnd, 1, MOD_NOREPEAT, VK_INSERT);

    UINT dpi = 96;
    if (auto fn = (UINT(WINAPI*)(HWND))::GetProcAddress(::GetModuleHandleW(L"user32.dll"), "GetDpiForWindow"))
        dpi = fn(hwnd);
    g_scale = ImClamp(dpi / 96.f, 0.75f, 2.5f);

    // overlay mode: no desktop snapshot needed\r\n    g_desktop = nullptr;

    ::ShowWindow(hwnd, SW_SHOW);
    ::UpdateWindow(hwnd);
    ::SetForegroundWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    ImGui::StyleColorsDark();

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_dev, g_ctx);

    LoadFonts(g_scale);

    {
        int lw = 0, lh = 0;
        std::vector<uint32_t> lpix;
        if (rw::DecodeImageRGBA(kLogoPng, kLogoPng_len, lw, lh, lpix)) {
            rw::g_logo.id = (ImTextureID)(intptr_t)MakeTexRGBA(lpix.data(), lw, lh);
            rw::g_logo.w = lw;
            rw::g_logo.h = lh;
        }
        if (rw::DecodeImageRGBA(kAvatarPng, kAvatarPng_len, lw, lh, lpix)) {
            rw::g_avatar.id = (ImTextureID)(intptr_t)MakeTexRGBA(lpix.data(), lw, lh);
            rw::g_avatar.w = lw;
            rw::g_avatar.h = lh;
        }
        rw::LoadHeroGLB(kHeroGlb, kHeroGlb_len, g_heroModel);
        g_heroPixels.assign((size_t)HERO_W * HERO_H, 0);
        if (g_heroModel.ok) {
            rw::g_heroPairs = g_heroModel.bonePairs;
            CreateHeroTexture(HERO_W, HERO_H);
            FILE* lf = nullptr;
            if (fopen_s(&lf, "C:\\RIPWALKER_GUI\\model_log.txt", "w") == 0 && lf) {
                fprintf(lf, "verts=%zu idx=%zu bones=%zu pairs=%zu tex=%dx%d\n",
                        g_heroModel.verts.size(), g_heroModel.idx.size(),
                        g_heroModel.boneNames.size(), g_heroModel.bonePairs.size(),
                        g_heroModel.texW, g_heroModel.texH);
                for (size_t bi = 0; bi < g_heroModel.boneNames.size() && bi < 40; ++bi) fprintf(lf, "bone[%zu]=%s\n", bi, g_heroModel.boneNames[bi].c_str());
                fclose(lf);
            }
        }
    }

    float openT = 0.f;
    bool done = false;

    while (!done) {
        MSG msg;
        while (::PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            ::TranslateMessage(&msg);
            ::DispatchMessageW(&msg);
            if (msg.message == WM_QUIT) done = true;
        }
        if (done) break;

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();

        if (g_toggleReq) {
            g_toggleReq = false;
            g_wantOpen = !g_wantOpen;
            if (g_wantOpen) {
                ::ShowWindow(hwnd, SW_SHOWNOACTIVATE);
                ::SetForegroundWindow(hwnd);
            }
        }
        openT = Approach(openT, g_wantOpen ? 1.f : 0.f, 9.f, ImGui::GetIO().DeltaTime);
        if (openT <= 0.004f && !g_wantOpen) {
            if (::IsWindowVisible(hwnd)) ::ShowWindow(hwnd, SW_HIDE);
            ::Sleep(12);
            continue;
        }

        // logical coordinate space: divide by dpi scale, multiply back on submit
        io.DisplaySize = ImVec2(g_width / g_scale, g_height / g_scale);
        if (io.MousePos.x > -1e5f && io.MousePos.y > -1e5f)
            io.MousePos = ImVec2(io.MousePos.x / g_scale, io.MousePos.y / g_scale);

        ImGui::NewFrame();

        ImDrawList* bgd = ImGui::GetBackgroundDrawList();
        if (g_desktop)
            bgd->AddImage((ImTextureID)(intptr_t)g_desktop, ImVec2(0, 0), io.DisplaySize);

        if (g_heroModel.ok && g_heroTex2D) {
            memset(g_heroPixels.data(), 0, g_heroPixels.size() * sizeof(uint32_t));
            if (st.heroSpin) st.heroYaw += (float)io.DeltaTime * 0.30f;
            rw::RenderHero(g_heroModel, HERO_W, HERO_H, st.heroYaw, st.heroPitch, st.heroZoom,
                           (float)ImGui::GetTime(), g_heroPixels.data(), rw::g_heroJoints);
            g_ctx->UpdateSubresource(g_heroTex2D, 0, nullptr, g_heroPixels.data(), HERO_W * 4, 0);
        }

        rw::RenderMenu(io.DisplaySize.x, io.DisplaySize.y, openT, io.DeltaTime);

        ImGui::EndFrame();
        ImGui::Render();

        ImDrawData* dd = ImGui::GetDrawData();
        ScaleDrawData(dd, g_scale);

        const float clear[4] = { 0.02f, 0.015f, 0.03f, 1.f };
        ID3D11RenderTargetView* rt = g_msaaRtv ? g_msaaRtv : g_rtv;
        g_ctx->OMSetRenderTargets(1, &rt, nullptr);
        g_ctx->ClearRenderTargetView(rt, clear);
        ImGui_ImplDX11_RenderDrawData(dd);
        if (g_msaaRtv && g_resolveTex) {
            ID3D11Texture2D* back = nullptr;
            g_swap->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&back);
            if (back) {
                g_ctx->ResolveSubresource(g_resolveTex, 0, g_msaaTex, 0, DXGI_FORMAT_B8G8R8A8_UNORM);
                g_ctx->CopyResource(back, g_resolveTex);
                back->Release();
            }
        }
        g_swap->Present(1, 0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    DestroyDevice();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return 0;
}
