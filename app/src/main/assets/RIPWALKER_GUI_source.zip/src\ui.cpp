// RIPWALKER :: menu shell, widgets and pages
#define IMGUI_DEFINE_MATH_OPERATORS
#include "ui.hpp"
#include "imgui_internal.h"
#include <windows.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <unordered_map>
#include <vector>

using namespace rw;

namespace {

float g_dt = 1.f / 60.f;
float g_time = 0.f;

std::unordered_map<ImGuiID, float> g_anim;

float& Anim(ImGuiID id, float init = 0.f) {
    auto it = g_anim.find(id);
    if (it == g_anim.end()) it = g_anim.emplace(id, init).first;
    return it->second;
}

struct HitRes { bool hover = false, click = false, active = false; };

HitRes HitBox(const char* id, ImVec2 a, ImVec2 b) {
    ImGui::SetCursorScreenPos(a);
    ImGui::InvisibleButton(id, ImVec2(ImMax(1.f, b.x - a.x), ImMax(1.f, b.y - a.y)));
    HitRes r;
    r.hover = ImGui::IsItemHovered();
    r.active = ImGui::IsItemActive();
    r.click = ImGui::IsItemClicked(ImGuiMouseButton_Left);
    return r;
}

bool PopupOpen() {
    return ImGui::IsPopupOpen("", ImGuiPopupFlags_AnyPopupId | ImGuiPopupFlags_AnyPopupLevel);
}


static void DrawWaveBg(ImDrawList* d, ImVec2 a, ImVec2 b, float t, float mul) {
    const float w = b.x - a.x, h = b.y - a.y;
    d->AddRectFilled(a, b, C(3, 2, 3));

    const int waves = 20;
    for (int i = 0; i < waves; ++i) {
        float fy = (i + 1) / (float)(waves + 1);
        float baseY = h * fy;
        float speed = 24.f + (i % 5) * 7.f;
        float amp = 7.f + (i % 7) * 3.2f;
        float phase = t * speed * 0.09f + i * 2.1f;

        ImVec2 pts[96];
        for (int k = 0; k < 96; ++k) {
            float x = w * (k / 95.f);
            float y = baseY + sinf(x * 0.0075f + phase) * amp + sinf(x * 0.0031f - phase * 0.7f) * amp * 0.45f;
            pts[k] = ImVec2(a.x + x, a.y + y);
        }
        d->AddPolyline(pts, 96, WithA(C(255, 15, 35), 0.045f * mul), 0, 8.f);
        d->AddPolyline(pts, 96, WithA(C(255, 15, 35), 0.11f * mul), 0, 3.2f);
        d->AddPolyline(pts, 96, WithA(C(255, 60, 70), 0.70f * mul), 0, 1.2f);
    }

    for (int i = 0; i < 90; ++i) {
        float px = fmodf(37.f * i + t * (7.f + (i % 5) * 3.f), w);
        float py = fmodf(91.f * i * 1.7f + t * (11.f + (i % 7) * 2.f), h);
        float al = 0.18f + 0.28f * (0.5f + 0.5f * sinf(t * 2.f + i));
        d->AddCircleFilled(ImVec2(a.x + px, a.y + py), 1.5f, WithA(C(255, 46, 56), al * mul), 6);
        d->AddCircleFilled(ImVec2(a.x + px, a.y + py), 5.f, WithA(C(255, 20, 30), 0.05f * mul), 8);
    }
}
// ---------------------------------------------------------------- widgets
bool ToggleW(const char* id, bool& value, ImVec2 center) {
    const float W = 36.f, H = 18.f;
    ImVec2 a(center.x - W * 0.5f, center.y - H * 0.5f);
    ImVec2 b(center.x + W * 0.5f, center.y + H * 0.5f);

    HitRes hit = HitBox(id, a, b);
    if (hit.click) value = !value;

    ImDrawList* d = ImGui::GetWindowDrawList();
    ImGuiID uid = ImGui::GetID(id);
    float& t = Anim(uid, value ? 1.f : 0.f);
    float& hov = Anim(uid + 1, 0.f);
    t = Approach(t, value ? 1.f : 0.f, 22.f, g_dt);
    hov = Approach(hov, hit.hover ? 1.f : 0.f, 16.f, g_dt);

    d->AddRectFilled(a, b, Mix(C(29, 25, 27), C(214, 26, 40), t), H * 0.5f);
    d->AddRect(a, b, WithA(Mix(C(60, 44, 48), C(255, 90, 100), t), 0.6f + 0.25f * hov), H * 0.5f, 0, 1.f);

    float kx = a.x + 9.f + t * (W - 18.f);
    d->AddCircleFilled(ImVec2(kx, center.y), 6.3f, Mix(C(130, 120, 122), C(252, 246, 246), t), 20);
    return hit.click;
}

bool SliderW(const char* id, float& value, float mn, float mx, ImVec2 trackA, float w) {
    const float cy = trackA.y;
    ImRect hit(trackA.x - 6.f, cy - 9.f, trackA.x + w + 6.f, cy + 9.f);
    HitRes r = HitBox(id, hit.Min, hit.Max);
    if (r.active) {
        float m = ImGui::GetIO().MousePos.x;
        float t = Saturate((m - trackA.x) / w);
        value = mn + t * (mx - mn);
        r.click = true;
    }
    value = ImClamp(value, mn, mx);
    float t = (value - mn) / ImMax(0.0001f, (mx - mn));

    ImDrawList* d = ImGui::GetWindowDrawList();
    ImGuiID uid = ImGui::GetID(id);
    float& tt = Anim(uid, t);
    float& hov = Anim(uid + 1, 0.f);
    tt = Approach(tt, t, 32.f, g_dt);
    hov = Approach(hov, (r.hover || r.active) ? 1.f : 0.f, 16.f, g_dt);

    ImVec2 t0(trackA.x, cy - 1.25f), t1(trackA.x + w, cy + 1.25f);
    d->AddRectFilled(t0, t1, C(44, 44, 49), 2.f, 2.f);
    float fx = trackA.x + w * tt;
    if (tt > 0.002f) d->AddRectFilled(t0, ImVec2(fx, t1.y), C(214, 30, 44), 2.f, 2.f);
    float kr = 4.2f + 0.5f * hov;
    d->AddCircleFilled(ImVec2(fx, cy), kr, C(250, 244, 244), 18);
    return r.click;
}
void KeyNameOf(int vk, char* out, size_t n) {
    out[0] = 0;
    switch (vk) {
        case 0: ImFormatString(out, n, "none"); return;
        case 1: ImFormatString(out, n, "mouse1"); return;
        case 2: ImFormatString(out, n, "mouse2"); return;
        case 4: ImFormatString(out, n, "mouse3"); return;
        case 5: ImFormatString(out, n, "mouse4"); return;
        case 6: ImFormatString(out, n, "mouse5"); return;
        case 32: ImFormatString(out, n, "space"); return;
        case 16: ImFormatString(out, n, "shift"); return;
        case 17: ImFormatString(out, n, "ctrl"); return;
        case 18: ImFormatString(out, n, "alt"); return;
        case 9: ImFormatString(out, n, "tab"); return;
        case 20: ImFormatString(out, n, "caps"); return;
        case 37: ImFormatString(out, n, "left"); return;
        case 38: ImFormatString(out, n, "up"); return;
        case 39: ImFormatString(out, n, "right"); return;
        case 40: ImFormatString(out, n, "down"); return;
        case 45: ImFormatString(out, n, "insert"); return;
        case 46: ImFormatString(out, n, "delete"); return;
        case 36: ImFormatString(out, n, "home"); return;
        case 35: ImFormatString(out, n, "end"); return;
        case 33: ImFormatString(out, n, "pgup"); return;
        case 34: ImFormatString(out, n, "pgdn"); return;
        case 27: ImFormatString(out, n, "esc"); return;
        default: break;
    }
    if (vk >= 0x30 && vk <= 0x39) { ImFormatString(out, n, "%c", (char)vk); return; }
    if (vk >= 0x41 && vk <= 0x5A) { ImFormatString(out, n, "%c", (char)vk); return; }
    if (vk >= 0x70 && vk <= 0x87) { ImFormatString(out, n, "F%d", vk - 0x6F); return; }
    ImFormatString(out, n, "0x%02X", vk);
}

struct KeyHitState { bool waiting = false; float since = 0.f; };
std::unordered_map<ImGuiID, KeyHitState> g_keyhit;

void KeyBindW(const char* id, int& vk, ImVec2 a, ImVec2 b) {
    HitRes r = HitBox(id, a, b);
    ImGuiID uid = ImGui::GetID(id);
    KeyHitState& ks = g_keyhit[uid];
    if (r.click) { ks.waiting = true; ks.since = g_time; }

    if (ks.waiting && g_time - ks.since > 0.12f) {
        for (int i = 1; i < 255; ++i) {
            if (i == VK_LBUTTON || i == VK_RBUTTON) continue;
            if (GetAsyncKeyState(i) & 0x8000) {
                if (i == VK_ESCAPE) ks.waiting = false;
                else { vk = i; ks.waiting = false; }
                break;
            }
        }
    }

    ImDrawList* d = ImGui::GetWindowDrawList();
    ImU32 bg = r.hover ? C(31, 31, 32) : C(23, 23, 23);
    float& hp = Anim(uid, 0.f);
    hp = Approach(hp, r.hover ? 1.f : 0.f, 14.f, g_dt);

    RRectGrad(d, a, b, 6.f, Mix(bg, C(36, 36, 37), hp), Mix(C(18, 18, 18), C(26, 26, 27), hp));
    d->AddRect(a, b, WithA(ks.waiting ? pal.accent : pal.cardLineHi, 0.35f + 0.25f * hp), 6.f, 0, 1.f);

    char name[32];
    if (ks.waiting) {
        int dots = (int)(fmodf(g_time * 3.f, 3.f));
        ImFormatString(name, sizeof name, "%.*s", dots + 1, "...");
        TextCenter(d, font.smB, font.szSmall, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), WithA(pal.accentSoft, 1.f), name);
    } else {
        KeyNameOf(vk, name, sizeof name);
        TextCenter(d, font.smB, font.szSmall, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), WithA(pal.text, 0.9f), name);
    }
}

void ComboW(const char* id, int& value, const char* const* items, int count, ImVec2 a, ImVec2 b) {
    HitRes r = HitBox(id, a, b);
    ImDrawList* d = ImGui::GetWindowDrawList();
    ImGuiID uid = ImGui::GetID(id);
    float& hp = Anim(uid, 0.f);
    hp = Approach(hp, r.hover ? 1.f : 0.f, 14.f, g_dt);

    ImU32 bg = Mix(C(23, 23, 23), C(31, 31, 32), hp);
    RRectGrad(d, a, b, 6.f, bg, Dark(bg, 0.75f));
    d->AddRect(a, b, WithA(pal.cardLineHi, 0.35f + 0.3f * hp), 6.f, 0, 1.f);

    const char* label = (value >= 0 && value < count) ? items[value] : "-";
    Text(d, font.smB, font.szSmall, ImVec2(a.x + 9.f, (a.y + b.y) * 0.5f - TextSize(font.smB, font.szSmall, label).y * 0.5f),
         WithA(pal.text, 0.92f), label);

    // chevron
    ImVec2 ch(b.x - 12.f, (a.y + b.y) * 0.5f);
    d->AddLine(ImVec2(ch.x - 3.f, ch.y - 2.f), ImVec2(ch.x, ch.y + 1.5f), WithA(pal.textDim, 0.9f), 1.2f);
    d->AddLine(ImVec2(ch.x + 3.f, ch.y - 2.f), ImVec2(ch.x, ch.y + 1.5f), WithA(pal.textDim, 0.9f), 1.2f);

    if (r.click) ImGui::OpenPopup(id);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(5, 5));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, 8.f);
    ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.f);
    ImGui::PushStyleColor(ImGuiCol_PopupBg, V4(C(19, 19, 19), 0.98f));
    ImGui::PushStyleColor(ImGuiCol_Border, V4(C(54, 54, 55), 1.f));
    ImGui::SetNextWindowPos(ImVec2(a.x, b.y + 5.f), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ImVec2(ImMax(140.f, b.x - a.x), 0.f), ImGuiCond_Appearing);
    if (ImGui::BeginPopup(id)) {
        for (int i = 0; i < count; ++i) {
            char iid[32]; ImFormatString(iid, sizeof iid, "##it%d", i);
            bool sel = (i == value);
            ImVec2 ip = ImGui::GetCursorScreenPos();
            float iw = ImGui::GetContentRegionAvail().x;
            HitRes ih = HitBox(iid, ip, ImVec2(ip.x + iw, ip.y + 24.f));
            ImDrawList* pd = ImGui::GetWindowDrawList();
            if (sel || ih.hover)
                pd->AddRectFilled(ip, ImVec2(ip.x + iw, ip.y + 24.f), WithA(sel ? pal.accent : C(255, 255, 255), sel ? 0.14f : 0.05f), 5.f);
            Text(pd, font.sm, font.szSmall, ImVec2(ip.x + 8.f, ip.y + 5.f), WithA(sel ? pal.accentSoft : pal.text, 0.95f), items[i]);
            if (sel) pd->AddCircleFilled(ImVec2(ip.x + iw - 9.f, ip.y + 12.f), 2.4f, WithA(pal.accentSoft, 1.f), 10);
            if (ih.click) { value = i; ImGui::CloseCurrentPopup(); }
        }
        ImGui::EndPopup();
    }
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(3);
}

void ColorW(const char* id, ImVec4& col, ImVec2 a, float size) {
    ImVec2 b(a.x + size, a.y + size);
    HitRes r = HitBox(id, a, b);
    ImDrawList* d = ImGui::GetWindowDrawList();
    ImU32 c = IM_COL32((int)(col.x * 255), (int)(col.y * 255), (int)(col.z * 255), 255);
    d->AddRectFilled(ImVec2(a.x - 2.f, a.y - 2.f), ImVec2(b.x + 2.f, b.y + 2.f), WithA(c, 0.18f), 7.f);
    d->AddRectFilled(a, b, c, 6.f);
    d->AddRect(a, b, WithA(C(255, 255, 255), r.hover ? 0.35f : 0.16f), 6.f, 0, 1.f);

    if (r.click) ImGui::OpenPopup(id);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 10));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, 10.f);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(6, 6));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, V4(C(19, 19, 19), 0.98f));
    ImGui::PushStyleColor(ImGuiCol_Border, V4(C(54, 54, 55), 1.f));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 5.f);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, V4(C(26, 26, 27), 1.f));
    ImGui::SetNextWindowPos(ImVec2(a.x - 40.f, b.y + 8.f), ImGuiCond_Appearing);
    if (ImGui::BeginPopup(id)) {
        ImGui::ColorPicker4("##pick", &col.x,
            ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoSidePreview |
            ImGuiColorEditFlags_PickerHueBar | ImGuiColorEditFlags_NoLabel |
            ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_AlphaPreviewHalf);
        ImGui::EndPopup();
    }
    ImGui::PopStyleColor(3);
    ImGui::PopStyleVar(4);
}

bool ButtonW(const char* id, const char* label, ImVec2 a, ImVec2 b, bool accent) {
    HitRes r = HitBox(id, a, b);
    ImDrawList* d = ImGui::GetWindowDrawList();
    ImGuiID uid = ImGui::GetID(id);
    float& hp = Anim(uid, 0.f);
    hp = Approach(hp, r.hover ? 1.f : 0.f, 16.f, g_dt);
    float push = r.active ? 1.f : 0.f;

    ImVec2 o(0.f, push);
    ImU32 top, bot;
    if (accent) {
        top = Mix(Bright(pal.accent, 1.15f), Bright(pal.accent, 1.32f), hp);
        bot = Mix(pal.accentDeep, pal.accent, hp);

    } else {
        top = Mix(C(25, 25, 26), C(34, 34, 35), hp);
        bot = Mix(C(19, 19, 19), C(25, 25, 26), hp);
    }
    ImVec2 a2(a.x, a.y + o.y), b2(b.x, b.y + o.y);
    RRectGrad(d, a2, b2, 8.f, top, bot);
    d->AddRect(a2, b2, WithA(accent ? C(255, 255, 255) : pal.cardLineHi, accent ? 0.14f : 0.35f), 8.f, 0, 1.f);
    d->AddLine(ImVec2(a2.x + 8.f, a2.y + 1.2f), ImVec2(b2.x - 8.f, a2.y + 1.2f), WithA(C(255, 255, 255), 0.10f), 1.f);
    TextCenter(d, font.smB, font.szSmall, ImVec2((a2.x + b2.x) * 0.5f, (a2.y + b2.y) * 0.5f),
               accent ? C(255, 255, 255) : WithA(pal.text, 0.9f), label);
    return r.click;
}

// ---------------------------------------------------------------- icons
enum IconId { IC_AIM = 0, IC_EYE, IC_BOX, IC_SLIDER, IC_GEAR, IC_POWER, IC_SAVE, IC_TARGET, IC_CROSS };

// every icon lives in the same 0.8 * s box and uses one stroke weight
void DrawIcon(ImDrawList* d, int id, ImVec2 c, float s, ImU32 col, float th = 1.5f) {
    const float e = s * 0.40f;   // half extent
    const float r = s * 0.30f;   // main radius
    switch (id) {
        case IC_AIM: {
            d->AddCircle(c, r, col, 24, th);
            d->AddCircleFilled(c, s * 0.05f, col, 8);
            const float g0 = r + s * 0.055f, g1 = e;
            d->AddLine(ImVec2(c.x, c.y - g0), ImVec2(c.x, c.y - g1), col, th);
            d->AddLine(ImVec2(c.x, c.y + g0), ImVec2(c.x, c.y + g1), col, th);
            d->AddLine(ImVec2(c.x - g0, c.y), ImVec2(c.x - g1, c.y), col, th);
            d->AddLine(ImVec2(c.x + g0, c.y), ImVec2(c.x + g1, c.y), col, th);
            break;
        }
        case IC_EYE:
            d->PathClear();
            d->PathArcTo(ImVec2(c.x, c.y + s * 0.15f), s * 0.40f, IM_PI * 1.20f, IM_PI * 1.80f, 18);
            d->PathStroke(col, 0, th);
            d->PathClear();
            d->PathArcTo(ImVec2(c.x, c.y - s * 0.15f), s * 0.40f, IM_PI * 0.20f, IM_PI * 0.80f, 18);
            d->PathStroke(col, 0, th);
            d->AddCircleFilled(c, s * 0.095f, col, 12);
            break;
        case IC_BOX: {
            ImVec2 p0(c.x - e, c.y - e), p1(c.x + e, c.y + e);
            d->AddRect(p0, p1, col, 2.f, 0, th);
            break;
        }
        case IC_SLIDER: {
            const float ys[3] = { -0.24f, 0.f, 0.24f };
            const float kx[3] = { -0.13f, 0.19f, -0.01f };
            for (int i = 0; i < 3; ++i) {
                const float y = c.y + ys[i] * s;
                d->AddLine(ImVec2(c.x - e, y), ImVec2(c.x + e, y), col, th);
                d->AddCircleFilled(ImVec2(c.x + kx[i] * s, y), s * 0.075f, col, 8);
            }
            break;
        }
        case IC_GEAR: {
            d->AddCircle(c, s * 0.22f, col, 22, th);
            for (int i = 0; i < 6; ++i) {
                const float a = i * IM_PI / 3.f + 0.26f;
                d->AddLine(ImVec2(c.x + cosf(a) * s * 0.27f, c.y + sinf(a) * s * 0.27f),
                           ImVec2(c.x + cosf(a) * e, c.y + sinf(a) * e), col, th);
            }
            break;
        }
        case IC_POWER:
            d->PathClear();
            d->PathArcTo(c, s * 0.34f, IM_PI * 0.32f, IM_PI * 1.68f, 22);
            d->PathStroke(col, 0, th);
            d->AddLine(ImVec2(c.x, c.y - e), ImVec2(c.x, c.y - s * 0.02f), col, th);
            break;
        case IC_SAVE:
            d->AddRect(ImVec2(c.x - e, c.y - e), ImVec2(c.x + e, c.y + e), col, 2.f, 0, th);
            d->AddRect(ImVec2(c.x - s * 0.18f, c.y - e), ImVec2(c.x + s * 0.18f, c.y - s * 0.06f), col, 1.f, 0, th);
            break;
        case IC_TARGET:
            d->AddCircle(c, e, col, 24, th);
            d->AddCircle(c, s * 0.16f, col, 16, th);
            d->AddCircleFilled(c, s * 0.045f, col, 8);
            break;
        case IC_CROSS: {
            const float g = s * 0.09f;
            d->AddLine(ImVec2(c.x - e, c.y), ImVec2(c.x - g, c.y), col, th);
            d->AddLine(ImVec2(c.x + g, c.y), ImVec2(c.x + e, c.y), col, th);
            d->AddLine(ImVec2(c.x, c.y - e), ImVec2(c.x, c.y - g), col, th);
            d->AddLine(ImVec2(c.x, c.y + g), ImVec2(c.x, c.y + e), col, th);
            d->AddCircleFilled(c, s * 0.045f, col, 8);
            break;
        }
        default: break;
    }
}

// ---------------------------------------------------------------- logo
void LogoMark(ImDrawList* d, ImVec2 c, float size, float alpha) {
    const float r = size * 0.5f;
    ImVec2 hex[6];
    for (int i = 0; i < 6; ++i) {
        float a = -IM_PI * 0.5f + i * IM_PI / 3.f;
        hex[i] = ImVec2(c.x + cosf(a) * r, c.y + sinf(a) * r);
    }

    d->AddConvexPolyFilled(hex, 6, WithA(C(22, 22, 22), 0.95f * alpha));
    // accent arc on the left
    d->AddPolyline(hex, 6, WithA(pal.accent, 0.85f * alpha), ImDrawFlags_Closed, 1.5f);
    d->AddPolyline(hex, 3, WithA(pal.accentSoft, 0.95f * alpha), 0, 1.6f);

    // monogram "R"
    const float u = size * 0.09f;
    ImU32 mono = WithA(C(244, 244, 249), 0.96f * alpha);
    d->AddRectFilled(ImVec2(c.x - u * 2.0f, c.y - u * 3.4f), ImVec2(c.x - u * 0.4f, c.y + u * 3.4f), mono, u * 0.3f);
    d->PathArcTo(ImVec2(c.x - u * 0.4f, c.y - u * 1.9f), u * 1.55f, -IM_PI * 0.5f, IM_PI * 0.5f, 14);
    d->PathStroke(mono, 0, u * 1.6f);
    // leg + arrow
    d->AddLine(ImVec2(c.x - u * 0.35f, c.y + u * 0.5f), ImVec2(c.x + u * 1.9f, c.y + u * 3.4f), mono, u * 1.6f);
    ImVec2 tri[3] = {
        ImVec2(c.x + u * 2.0f, c.y + u * 3.6f),
        ImVec2(c.x + u * 0.55f, c.y + u * 3.2f),
        ImVec2(c.x + u * 1.7f, c.y + u * 2.05f)
    };
    d->AddConvexPolyFilled(tri, 3, mono);
    // motion ticks
    for (int i = 0; i < 3; ++i) {
        float yy = c.y - u * 2.0f + i * u * 1.9f;
        d->AddLine(ImVec2(c.x - u * 3.4f, yy), ImVec2(c.x - u * 2.6f, yy), WithA(pal.accentSoft, (0.5f - i * 0.12f) * alpha), 1.3f);
    }
}

// ---------------------------------------------------------------- stars
struct Star { float x, y, r, ph, sp, a; };
std::vector<Star> g_stars;
bool g_starsReady = false;

void InitStars() {
    g_stars.clear();
    unsigned int seed = 20261029u;
    auto rnd = [&]() { seed = seed * 1664525u + 1013904223u; return (seed >> 8) / 16777216.f; };
    for (int i = 0; i < 120; ++i) {
        Star s;
        s.x = rnd(); s.y = rnd();
        s.r = 0.5f + rnd() * 1.1f;
        s.ph = rnd() * 6.283f;
        s.sp = 0.4f + rnd() * 1.6f;
        s.a = 0.06f + rnd() * 0.22f;
        g_stars.push_back(s);
    }
    g_starsReady = true;
}

void DrawStars(ImDrawList* d, ImVec2 a, ImVec2 b, float t, float density) {
    if (!g_starsReady) InitStars();
    const float w = b.x - a.x, h = b.y - a.y;
    const int count = (int)(g_stars.size() * Saturate(density));
    for (int i = 0; i < count; ++i) {
        Star& s = g_stars[i];
        float x = fmodf(s.x + t * 0.0035f * (0.4f + s.r), 1.f);
        float y = s.y + sinf(t * 0.15f + s.ph) * 0.004f;
        ImVec2 p(a.x + x * w, a.y + y * h);
        float edge = ImMin(ImMin(p.x - a.x, b.x - p.x), ImMin(p.y - a.y, b.y - p.y));
        float fade = Saturate(edge / 90.f);
        float tw = 0.55f + 0.45f * sinf(t * s.sp + s.ph);
        float al = s.a * tw * fade;
        d->AddCircleFilled(p, s.r, WithA(C(210, 210, 214), al), 6);
        if (s.r > 1.28f) Glow(d, p, s.r * 6.f, C(171, 171, 174), al * 0.35f, 5, 2.4f);
    }
    // constellations
    for (size_t i = 0; i < g_stars.size() / 2; i += 3) {
        const Star& s0 = g_stars[i];
        for (size_t j = i + 1; j < g_stars.size() / 2; ++j) {
            const Star& s1 = g_stars[j];
            float dx = s1.x - s0.x, dy = s1.y - s0.y;
            float dist = sqrtf(dx * dx + dy * dy);
            if (dist < 0.16f) {
                ImVec2 p0(a.x + fmodf(s0.x + t * 0.0035f, 1.f) * w, a.y + s0.y * h);
                ImVec2 p1(a.x + fmodf(s1.x + t * 0.0035f, 1.f) * w, a.y + s1.y * h);
                d->AddLine(p0, p1, WithA(C(162, 162, 165), 0.055f * Saturate(density)), 1.f);
                break;
            }
        }
    }
    // shooting star
    float period = 8.5f;
    float ph = fmodf(t, period) / period;
    if (ph < 0.09f) {
        float k = ph / 0.09f;
        ImVec2 p0(a.x + w * (0.05f + k * 0.55f), a.y + h * (0.12f + k * 0.35f));
        ImVec2 p1(p0.x - 70.f, p0.y - 34.f);
        d->AddLine(p0, p1, WithA(C(218, 218, 222), 0.55f * sinf(k * IM_PI)), 1.3f);
        d->AddCircleFilled(p0, 1.6f, WithA(C(255, 255, 255), 0.8f * sinf(k * IM_PI)), 8);
    }
}

// ---------------------------------------------------------------- card + rows
struct CardBox { ImVec2 a, b; };

CardBox CardAt(ImVec2 a, ImVec2 b, const char* title, const char* tag = nullptr) {
    ImDrawList* d = ImGui::GetWindowDrawList();
    RRectGrad(d, a, b, 12.f, C(18, 18, 18), C(13, 10, 21));
    d->AddRect(a, b, WithA(pal.cardLine, 0.85f), 12.f, 0, 1.f);
    d->AddLine(ImVec2(a.x + 12.f, a.y + 1.f), ImVec2(b.x - 12.f, a.y + 1.f), WithA(C(255, 255, 255), 0.045f), 1.f);
    d->AddRectFilled(ImVec2(a.x + 14.f, a.y + 13.f), ImVec2(a.x + 17.f, a.y + 26.f), WithA(pal.accent, 0.9f), 1.5f);
    TextSpaced(d, font.smB, 9.5f, ImVec2(a.x + 23.f, a.y + 13.5f), WithA(pal.text, 0.62f), title, 1.7f);
    if (tag) {
        ImVec2 sz = TextSize(font.sm, 9.f, tag);
        ImVec2 t0(b.x - 14.f - sz.x - 16.f, a.y + 11.f);
        d->AddRectFilled(t0, ImVec2(b.x - 14.f, a.y + 27.f), WithA(pal.accent, 0.13f), 5.f);
        Text(d, font.sm, 9.f, ImVec2(t0.x + 8.f, a.y + 14.5f), WithA(pal.accentSoft, 0.9f), tag);
    }
    return CardBox{ a, b };
}

struct RC {
    ImVec2 a, b;
    float y = 0.f;
    float rh = 29.f;
    float labelX, rightX;
    void Next() { y += rh; }
    float Mid() const { return y + rh * 0.5f; }
};

RC Rows(CardBox c, float rh = 22.f) {
    RC rc;
    rc.a = c.a; rc.b = c.b;
    rc.y = c.a.y + 30.f;
    rc.rh = rh;
    rc.labelX = c.a.x + 15.f;
    rc.rightX = c.b.x - 15.f;
    return rc;
}

void RowHover(RC& rc) {
    if (PopupOpen()) return;
    ImVec2 m = ImGui::GetIO().MousePos;
    ImVec2 a(rc.a.x + 6.f, rc.y + 2.f), b(rc.b.x - 6.f, rc.y + rc.rh - 2.f);
    if (m.x >= a.x && m.x <= b.x && m.y >= a.y && m.y <= b.y) {
        ImGui::GetWindowDrawList()->AddRectFilled(a, b, WithA(C(255, 255, 255), 0.022f), 6.f);
    }
}

void RowLabel(RC& rc, const char* label, ImU32 col) {
    ImDrawList* d = ImGui::GetWindowDrawList();
    ImVec2 sz = TextSize(font.body, font.szBody, label);
    Text(d, font.body, font.szBody, ImVec2(rc.labelX, rc.Mid() - sz.y * 0.5f), col, label);
}

void RowToggle(RC& rc, const char* id, const char* label, bool& v) {
    RowHover(rc);
    RowLabel(rc, label, WithA(pal.text, v ? 0.95f : 0.72f));
    ToggleW(id, v, ImVec2(rc.rightX - 21.f, rc.Mid()));
    rc.Next();
}

void RowSlider(RC& rc, const char* id, const char* label, float& v, float mn, float mx, const char* fmt, float w = 104.f) {
    RowHover(rc);
    RowLabel(rc, label, WithA(pal.text, 0.78f));
    char buf[32]; ImFormatString(buf, sizeof buf, fmt, v);
    TextNumRight(ImGui::GetWindowDrawList(), font.smB, font.szSmall, ImVec2(rc.rightX, rc.Mid() - 5.f), WithA(pal.accentSoft, 0.9f), buf);
    SliderW(id, v, mn, mx, ImVec2(rc.rightX - 40.f - w, rc.Mid()), w);
    rc.Next();
}

void RowCombo(RC& rc, const char* id, const char* label, int& v, const char* const* items, int n, float w = 116.f) {
    RowHover(rc);
    RowLabel(rc, label, WithA(pal.text, 0.78f));
    ComboW(id, v, items, n, ImVec2(rc.rightX - w, rc.Mid() - 12.f), ImVec2(rc.rightX, rc.Mid() + 12.f));
    rc.Next();
}

void RowKey(RC& rc, const char* id, const char* label, int& vk) {
    RowHover(rc);
    RowLabel(rc, label, WithA(pal.text, 0.78f));
    KeyBindW(id, vk, ImVec2(rc.rightX - 84.f, rc.Mid() - 12.f), ImVec2(rc.rightX, rc.Mid() + 12.f));
    rc.Next();
}

void RowColor(RC& rc, const char* id, const char* label, ImVec4& col) {
    RowHover(rc);
    RowLabel(rc, label, WithA(pal.text, 0.78f));
    ColorW(id, col, ImVec2(rc.rightX - 22.f, rc.Mid() - 11.f), 22.f);
    rc.Next();
}

void RowInfo(RC& rc, const char* label, const char* value) {
    RowHover(rc);
    RowLabel(rc, label, WithA(pal.text, 0.72f));
    TextRight(ImGui::GetWindowDrawList(), font.sm, font.szSmall, ImVec2(rc.rightX, rc.Mid() - 5.f), WithA(pal.textMute, 1.f), value);
    rc.Next();
}

// dashed frame + folder glyph + caption, for lists without any items
void EmptyNote(ImDrawList* d, ImVec2 a, ImVec2 b, const char* text) {
    d->AddRect(a, b, WithA(C(255, 255, 255), 0.07f), 8.f, 0, 1.f);
    d->AddRectFilled(a, b, WithA(C(255, 255, 255), 0.012f), 8.f);
    const float cx = (a.x + b.x) * 0.5f;
    const float cy = a.y + 27.f;
    const ImU32 gc = WithA(pal.textMute, 0.55f);
    d->AddRect(ImVec2(cx - 10.f, cy - 5.f), ImVec2(cx + 10.f, cy + 7.f), gc, 2.f, 0, 1.3f);
    d->AddLine(ImVec2(cx - 10.f, cy - 5.f), ImVec2(cx - 3.f, cy - 5.f), gc, 1.3f);
    d->AddLine(ImVec2(cx - 3.f, cy - 5.f), ImVec2(cx - 1.f, cy - 8.f), gc, 1.3f);
    d->AddLine(ImVec2(cx - 1.f, cy - 8.f), ImVec2(cx + 6.f, cy - 8.f), gc, 1.3f);
    d->AddLine(ImVec2(cx + 6.f, cy - 8.f), ImVec2(cx + 8.f, cy - 5.f), gc, 1.3f);
    TextCenter(d, font.tiny, 8.5f, ImVec2(cx, cy + 17.f), WithA(pal.textMute, 0.8f), text);
}

void Divider(RC& rc) {
    ImDrawList* d = ImGui::GetWindowDrawList();
    d->AddLine(ImVec2(rc.a.x + 14.f, rc.y), ImVec2(rc.b.x - 14.f, rc.y), WithA(C(255, 255, 255), 0.035f), 1.f);
}

// ---------------------------------------------------------------- pages
const float PANEL_W = 920.f, PANEL_H = 600.f, RAIL_W = 206.f;

struct Layout { float x0, x1, y0, y1; };
Layout g_layout;

float CardH(int rows, float rh = 22.f) { return 36.f + rows * rh + 24.f; }

void PageAimbot() {
    ImDrawList* d = ImGui::GetWindowDrawList();
    const float x0 = g_layout.x0, y0 = g_layout.y0;

    static const char* hitboxes[] = { "Head", "Neck", "Chest", "Stomach", "Nearest" };
    static const char* prio[] = { "Damage", "Distance", "Crosshair", "Threat" };
    static const char* target[] = { "Nearest", "Lowest HP", "Highest Threat", "Random" };

    const float pw = 320.f;
    const float cx = x0 + pw + 16.f;
    const float cw = g_layout.x1 - cx;
    const float bottom = y0 + 466.f;

    CardBox cp = CardAt(ImVec2(x0, y0), ImVec2(x0 + pw, bottom), "TARGET VIEW");
    DrawAimPreview(d, ImRect(ImVec2(cp.a.x + 10.f, cp.a.y + 32.f), ImVec2(cp.b.x - 10.f, cp.b.y - 10.f)), g_time);

    CardBox c1 = CardAt(ImVec2(cx, y0), ImVec2(cx + cw, y0 + CardH(8)), "AIMBOT");
    RC r1 = Rows(c1);
    RowToggle(r1, "aim_on", "Enabled", st.aimOn);
    RowToggle(r1, "aim_silent", "Silent Aim", st.silent);
    RowToggle(r1, "aim_walls", "Through Walls", st.throughWalls);
    RowToggle(r1, "aim_auto", "Auto Fire", st.autofire);
    RowKey(r1, "aim_key", "Aim Key", st.aimKey);
    RowSlider(r1, "aim_fov", "Field of View", st.fov, 0.f, 180.f, "%.0f");
    RowSlider(r1, "aim_smooth", "Smoothness", st.smooth, 1.f, 60.f, "%.0f");
    RowCombo(r1, "aim_hb", "Hitbox", st.hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));


    float ty = y0 + CardH(8) + 14.f;
    CardBox c2 = CardAt(ImVec2(cx, ty), ImVec2(cx + cw, ty + CardH(6)), "TARGETING");
    RC r2 = Rows(c2);
    RowSlider(r2, "tg_dmg", "Min Damage", st.minDamage, 0.f, 100.f, "%.0f");
    RowSlider(r2, "tg_hc", "Hit Chance", st.hitChance, 0.f, 100.f, "%.0f");
    RowCombo(r2, "tg_mode", "Target Mode", st.targetMode, target, IM_ARRAYSIZE(target));
    RowToggle(r2, "tg_dyn", "Dynamic FOV", st.dynamicFov);
    RowToggle(r2, "tg_stop", "Quick Stop", st.quickStop);

    RowToggle(r2, "tg_team", "Ignore Team", st.ignoreTeam);
}
void PageVisuals() {
    ImDrawList* d = ImGui::GetWindowDrawList();
    const float x0 = g_layout.x0, y0 = g_layout.y0, x1 = g_layout.x1;

    static const char* sounds[] = { "Default", "Neverlose", "Metallic", "Soft" };
    static const char* markers[] = { "Cross", "X", "Dot", "Circle" };

    // ---- wide model strip: this tab must not mirror Esp
    CardBox cp = CardAt(ImVec2(x0, y0), ImVec2(x1, y0 + 240.f), "MODEL PREVIEW", "CHAMS");
    ImVec2 ia(cp.a.x + 1.f, cp.a.y + 34.f), ib(cp.b.x - 1.f, cp.b.y - 1.f);
    d->PushClipRect(ia, ib, true);
    RRectGrad(d, ia, ib, 10.f, C(14, 8, 10), C(8, 5, 7));
    for (float sy = ia.y + 5.f; sy < ib.y; sy += 5.f)
        d->AddLine(ImVec2(ia.x, sy), ImVec2(ib.x, sy), WithA(C(255, 60, 70), 0.022f), 1.f);

    float mh = (ib.y - ia.y) - 8.f;
    float mw = mh * ((float)g_hero.w / (float)(g_hero.h ? g_hero.h : 1));
    if (mw > 210.f) {
        mw = 210.f;
        mh = mw * ((float)(g_hero.h ? g_hero.h : 1) / (float)ImMax(1, g_hero.w));
    }
    ImVec2 m0(ia.x + 200.f - mw * 0.5f, ia.y + (ib.y - ia.y) * 0.5f - mh * 0.5f);
    ImVec2 m1(m0.x + mw, m0.y + mh);
    ImVec2 mc((m0.x + m1.x) * 0.5f, (m0.y + m1.y) * 0.5f);

    Glow(d, mc, 190.f, C(120, 14, 24), 0.16f, 12, 2.4f);
    d->AddLine(ImVec2(m0.x - 34.f, m1.y + 3.f), ImVec2(m1.x + 34.f, m1.y + 3.f), WithA(C(255, 70, 80), 0.12f), 1.f);

    if (g_hero.id) {
        int a8 = (st.chamsType == 2) ? 96 : 255;
        ImU32 tint = IM_COL32_WHITE;
        if (st.esp.chams && st.chamsType == 0)
            tint = IM_COL32((int)(st.boxCol.x * 255.f), (int)(st.boxCol.y * 255.f), (int)(st.boxCol.z * 255.f), a8);
        else
            tint = IM_COL32(255, 255, 255, a8);
        if (st.glow)
            d->AddImage(g_hero.id, ImVec2(m0.x - 5.f, m0.y - 5.f), ImVec2(m1.x + 5.f, m1.y + 5.f),
                        ImVec2(0, 0), ImVec2(1, 1), WithA(ImGui::ColorConvertFloat4ToU32(st.boxCol), 0.22f));
        d->AddImage(g_hero.id, m0, m1, ImVec2(0, 0), ImVec2(1, 1), tint);
    }
    d->PopClipRect();

    // right hand controls inside the strip
    const float rx = ib.x - 216.f;
    TextSpaced(d, font.sm, 8.5f, ImVec2(rx, cp.a.y + 50.f), WithA(pal.text, 0.5f), "CHAMS STYLE", 1.6f);
    const char* chips[3] = { "FLAT", "TEXTURED", "GHOST" };
    for (int i = 0; i < 3; ++i) {
        ImVec2 p0(rx + i * 70.f, cp.a.y + 64.f), p1(p0.x + 64.f, p0.y + 22.f);
        char id[24];
        ImFormatString(id, sizeof id, "vchip%d", i);
        HitRes h = HitBox(id, p0, p1);
        bool act = (st.chamsType == i);
        d->AddRectFilled(p0, p1, WithA(act ? pal.accent : C(255, 255, 255), act ? 0.15f : (h.hover ? 0.06f : 0.03f)), 6.f);
        d->AddRect(p0, p1, WithA(act ? pal.accent : C(255, 255, 255), act ? 0.55f : 0.10f), 6.f, 0, 1.f);
        TextCenter(d, font.smB, 8.5f, ImVec2((p0.x + p1.x) * 0.5f, p0.y + 7.f),
                   WithA(act ? pal.accentSoft : pal.textDim, act ? 1.f : 0.8f), chips[i]);
        if (h.click) st.chamsType = i;
    }

    TextSpaced(d, font.sm, 8.5f, ImVec2(rx, cp.a.y + 102.f), WithA(pal.text, 0.5f), "CHAMS COLOR", 1.6f);
    ColorW("vis_chcol", st.boxCol, ImVec2(ib.x - 46.f, cp.a.y + 98.f), 22.f);

    Text(d, font.body, font.szBody, ImVec2(rx, cp.a.y + 140.f), WithA(pal.text, 0.78f), "Chams");
    ToggleW("vis_chams", st.esp.chams, ImVec2(ib.x - 40.f, cp.a.y + 148.f));
    Text(d, font.body, font.szBody, ImVec2(rx, cp.a.y + 172.f), WithA(pal.text, 0.78f), "Glow");
    ToggleW("vis_glow", st.glow, ImVec2(ib.x - 40.f, cp.a.y + 180.f));

    // ---- bottom row
    const float by = y0 + 240.f + 14.f;
    const float bw = (x1 - x0 - 14.f) * 0.5f;

    CardBox cw = CardAt(ImVec2(x0, by), ImVec2(x0 + bw, by + CardH(5, 34.f)), "WORLD");
    RC rw = Rows(cw, 34.f);
    RowColor(rw, "w_sky", "Skybox Color", st.skyCol);
    RowSlider(rw, "w_bright", "Sky Brightness", st.skyBright, 0.f, 1.f, "%.2f", 92.f);
    RowSlider(rw, "w_fog", "Fog Density", st.fog, 0.f, 1.f, "%.2f", 92.f);
    RowToggle(rw, "w_rain", "Rain", st.rain);
    RowToggle(rw, "w_tp", "Third Person", st.thirdperson);

    CardBox ce = CardAt(ImVec2(x0 + bw + 14.f, by), ImVec2(x1, by + CardH(5, 34.f)), "EFFECTS");
    RC re = Rows(ce, 34.f);
    RowToggle(re, "fx_marker", "Hit Marker", st.dmgInfo);
    RowToggle(re, "fx_tracer", "Bullet Tracer", st.tracer);
    RowToggle(re, "fx_dmg", "Damage Info", st.dmgInfo);
    RowCombo(re, "fx_snd", "Hit Sound", st.hitSoundIdx, sounds, IM_ARRAYSIZE(sounds), 118.f);
    RowCombo(re, "fx_mark", "Marker Style", st.marker, markers, IM_ARRAYSIZE(markers), 118.f);
}

void PageCrosshair() {
    ImDrawList* d = ImGui::GetWindowDrawList();
    const float x0 = g_layout.x0, y0 = g_layout.y0, x1 = g_layout.x1;
    const float vpH = 300.f;

    // ---- range viewport across the whole width
    CardBox cp = CardAt(ImVec2(x0, y0), ImVec2(x1, y0 + vpH), "CROSSHAIR", "LIVE");
    ImVec2 a(cp.a.x + 1.f, cp.a.y + 34.f), b(cp.b.x - 1.f, cp.b.y - 1.f);
    DrawCrosshairPreview(d, ImRect(a, b), g_time);

    // ---- shape chips floating over the stage
    static const char* shapes[] = { "Classic", "Dot", "T-Shape", "Ring" };
    const float chipW = 44.f, chipH = 30.f, chipGap = 8.f;
    const float tw = chipW * 4.f + chipGap * 3.f;
    ImVec2 c0(b.x - 16.f - tw, a.y + 12.f);
    ImVec2 q0(c0.x - 8.f, c0.y - 6.f), q1(c0.x + tw + 8.f, c0.y + chipH + 6.f);
    d->AddRectFilled(q0, q1, WithA(C(11, 6, 8), 0.80f), 11.f);
    d->AddRect(q0, q1, WithA(C(255, 255, 255), 0.07f), 11.f, 0, 1.f);
    for (int i = 0; i < 4; ++i) {
        ImVec2 p0(c0.x + i * (chipW + chipGap), c0.y), p1(p0.x + chipW, p0.y + chipH);
        char id[24];
        ImFormatString(id, sizeof id, "chs%d", i);
        HitRes h = HitBox(id, p0, p1);
        const bool act = (st.chStyle == i);
        if (act) d->AddRectFilled(p0, p1, WithA(pal.accent, 0.16f), 8.f);
        else if (h.hover) d->AddRectFilled(p0, p1, WithA(C(255, 255, 255), 0.05f), 8.f);
        if (act) d->AddRect(p0, p1, WithA(pal.accent, 0.50f), 8.f, 0, 1.f);
        DrawCrosshairMini(d, ImVec2((p0.x + p1.x) * 0.5f, (p0.y + p1.y) * 0.5f), i,
                          act ? pal.accentSoft : WithA(pal.textDim, 0.85f), 32.f);
        if (h.click) st.chStyle = i;
    }

    // ---- controls row
    const float by = y0 + vpH + 14.f;
    const float cw = (x1 - x0 - 24.f) / 3.f;
    const float yTop = by, yBot = g_layout.y1;

    CardBox c1 = CardAt(ImVec2(x0, yTop), ImVec2(x0 + cw, yBot), "GEOMETRY");
    RC r1 = Rows(c1, 30.f);
    RowSlider(r1, "ch_gap", "Gap", st.chGap, 0.f, 20.f, "%.1f", 62.f);
    RowSlider(r1, "ch_len", "Length", st.chLen, 0.f, 20.f, "%.1f", 62.f);
    RowSlider(r1, "ch_thick", "Thickness", st.chThick, 0.5f, 5.f, "%.1f", 62.f);
    RowToggle(r1, "ch_dot", "Center Dot", st.chDot);

    const float bx2 = x0 + cw + 12.f;
    CardBox c2 = CardAt(ImVec2(bx2, yTop), ImVec2(bx2 + cw, yBot), "COLOR");
    RC r2 = Rows(c2, 30.f);
    {
        RowHover(r2);
        RowLabel(r2, "Color", WithA(pal.text, 0.78f));
        static const ImVec4 sw[6] = {
            ImVec4(0.95f, 0.12f, 0.16f, 1.f), ImVec4(1.f, 1.f, 1.f, 1.f),
            ImVec4(0.30f, 0.95f, 0.45f, 1.f), ImVec4(0.25f, 0.85f, 0.95f, 1.f),
            ImVec4(0.98f, 0.84f, 0.30f, 1.f), ImVec4(0.72f, 0.42f, 0.98f, 1.f)
        };
        const float sS = 16.f, sG = 6.f;
        float sx = r2.rightX - (sS * 6.f + sG * 5.f);
        for (int i = 0; i < 6; ++i) {
            ImVec2 p0(sx + i * (sS + sG), r2.Mid() - sS * 0.5f), p1(p0.x + sS, p0.y + sS);
            char id[24];
            ImFormatString(id, sizeof id, "sw%d", i);
            HitRes h = HitBox(id, p0, p1);
            const ImVec2 sc((p0.x + p1.x) * 0.5f, (p0.y + p1.y) * 0.5f);
            const bool act = (fabsf(st.chColor.x - sw[i].x) < 0.02f && fabsf(st.chColor.y - sw[i].y) < 0.02f &&
                              fabsf(st.chColor.z - sw[i].z) < 0.02f);
            d->AddCircleFilled(sc, sS * 0.5f, ImGui::ColorConvertFloat4ToU32(sw[i]), 20);
            if (act) d->AddCircle(sc, sS * 0.5f + 2.f, WithA(pal.text, 0.9f), 22, 1.2f);
            else if (h.hover) d->AddCircle(sc, sS * 0.5f + 2.f, WithA(pal.text, 0.35f), 22, 1.f);
            if (h.click) st.chColor = sw[i];
        }
        r2.Next();
    }
    RowSlider(r2, "ch_alpha", "Opacity", st.chAlpha, 0.2f, 1.f, "%.2f", 62.f);
    RowToggle(r2, "ch_outline", "Outline", st.chOutline);
    RowToggle(r2, "ch_glow", "Glow", st.chGlow);

    const float bx3 = x0 + cw * 2.f + 24.f;
    CardBox c3 = CardAt(ImVec2(bx3, yTop), ImVec2(bx3 + cw, yBot), "DYNAMIC");
    RC r3 = Rows(c3, 30.f);
    RowToggle(r3, "ch_dyn", "Dynamic Spread", st.chDynamic);
    RowSlider(r3, "ch_spread", "Spread", st.chSpread, 0.f, 1.f, "%.2f", 62.f);
    RowSlider(r3, "ch_speed", "Pulse Speed", st.chSpreadSpeed, 0.2f, 3.f, "%.1f", 62.f);
    {
        RowHover(r3);
        if (ButtonW("ch_reset", "Reset Defaults", ImVec2(r3.labelX, r3.Mid() - 12.f), ImVec2(r3.rightX, r3.Mid() + 12.f), false)) {
            st.chStyle = 0;
            st.chGap = 4.f; st.chLen = 6.f; st.chThick = 1.4f; st.chAlpha = 0.92f;
            st.chSpread = 0.6f; st.chSpreadSpeed = 1.f;
            st.chDot = true; st.chOutline = true; st.chGlow = true; st.chDynamic = false;
            st.chColor = ImVec4(0.95f, 0.12f, 0.16f, 1.f);
        }
        r3.Next();
    }
}
void PageEsp() {
    ImDrawList* d = ImGui::GetWindowDrawList();
    const float x0 = g_layout.x0, y0 = g_layout.y0;
    const float previewW = 392.f;
    const float colA = 262.f;

    static const char* styles[] = { "Corner", "Full Box" };

    const float cx = x0 + previewW + 16.f;
    DrawEspPreview(d, ImRect(ImVec2(x0, y0), ImVec2(x0 + previewW, g_layout.y1)), g_time);

    CardBox c1 = CardAt(ImVec2(cx, y0), ImVec2(cx + colA, y0 + CardH(8)), "ELEMENTS");
    RC r1 = Rows(c1);
    RowToggle(r1, "esp_box", "Box", st.esp.box);
    RowToggle(r1, "esp_skel", "Skeleton", st.esp.skeleton);
    RowToggle(r1, "esp_hp", "Health Bar", st.esp.health);
    RowToggle(r1, "esp_name", "Name", st.esp.name);
    RowToggle(r1, "esp_dist", "Distance", st.esp.distance);
    RowToggle(r1, "esp_weap", "Weapon", st.esp.weapon);
    RowToggle(r1, "esp_snap", "Snapline", st.esp.snapline);
    RowToggle(r1, "esp_fill", "Box Fill", st.esp.fill);

    float y = y0 + CardH(8) + 14.f;
    CardBox c2 = CardAt(ImVec2(cx, y), ImVec2(cx + colA, y + CardH(5)), "STYLE");
    RC r2 = Rows(c2);
    RowCombo(r2, "esp_bstyle", "Box Style", st.esp.boxStyle, styles, IM_ARRAYSIZE(styles), 96.f);
    RowSlider(r2, "esp_skth", "Skeleton Width", st.skelThick, 0.5f, 3.f, "%.1f", 80.f);
    RowSlider(r2, "esp_op", "Overlay Opacity", st.boxOpacity, 0.2f, 1.f, "%.2f", 80.f);
    RowColor(r2, "esp_boxcol", "Box Color", st.boxCol);
    RowColor(r2, "esp_skcol", "Skeleton Color", st.skelCol);
}
void PageMisc() {
    const float x0 = g_layout.x0, y0 = g_layout.y0;
    const float colA = 322.f;
    const float bx = x0 + colA + 16.f;
    const float wB = g_layout.x1 - bx;

    static const char* sounds[] = { "Default", "Neverlose", "Metallic", "Soft" };
    static const char* markers[] = { "Cross", "X", "Dot", "Circle" };

    CardBox c1 = CardAt(ImVec2(x0, y0), ImVec2(x0 + colA, y0 + CardH(5, 34.f)), "MOVEMENT");
    RC r1 = Rows(c1, 34.f);
    RowToggle(r1, "mv_bhop", "Bunnyhop", st.bhop);
    RowToggle(r1, "mv_strafe", "Auto Strafe", st.autostrafe);
    RowKey(r1, "mv_key", "Jump Key", st.jumpKey);
    RowSlider(r1, "mv_gain", "Strafe Gain", st.strafe, 0.f, 2.f, "%.2f");
    RowToggle(r1, "mv_tp", "Third Person", st.thirdperson);

    float y = y0 + CardH(5, 34.f) + 14.f;
    CardBox c2 = CardAt(ImVec2(x0, y), ImVec2(x0 + colA, y + CardH(4, 34.f)), "COMBAT");
    RC r2 = Rows(c2, 34.f);
    RowToggle(r2, "cb_norec", "No Recoil", st.norecoil);
    RowToggle(r2, "cb_nospread", "No Spread", st.nospread);
    RowToggle(r2, "cb_rapid", "Rapid Fire", st.rapid);
    RowToggle(r2, "cb_glove", "Glove Override", st.glove);

    CardBox c3 = CardAt(ImVec2(bx, y0), ImVec2(bx + wB, y0 + CardH(5, 34.f)), "FEEDBACK");
    RC r3 = Rows(c3, 34.f);
    RowToggle(r3, "fb_dmg", "Damage Info", st.dmgInfo);
    RowToggle(r3, "fb_sound", "Hit Sound", st.hitSound);
    RowCombo(r3, "fb_snd", "Sound Pack", st.hitSoundIdx, sounds, IM_ARRAYSIZE(sounds));
    RowCombo(r3, "fb_marker", "Marker Style", st.marker, markers, IM_ARRAYSIZE(markers));
    RowSlider(r3, "fb_vol", "Volume", st.volume, 0.f, 1.f, "%.2f");

    float y2 = y0 + CardH(5, 34.f) + 14.f;
    CardBox c4 = CardAt(ImVec2(bx, y2), ImVec2(bx + wB, y2 + CardH(4, 34.f)), "SESSION", "136");
    RC r4 = Rows(c4, 34.f);
    RowInfo(r4, "Uptime", "01:42:18");
    RowInfo(r4, "Build", "v136 / x64");
    RowInfo(r4, "Status", "undetected");
    {
        ImDrawList* d = ImGui::GetWindowDrawList();
        float cy = c4.b.y - 34.f;
        d->AddLine(ImVec2(c4.a.x + 14.f, cy - 6.f), ImVec2(c4.b.x - 14.f, cy - 6.f), WithA(C(255, 255, 255), 0.05f), 1.f);
        TextSpaced(d, font.sm, 8.5f, ImVec2(c4.a.x + 14.f, cy + 1.f), WithA(pal.textMute, 0.85f), "MADE IN", 1.6f);
        TextRight(d, font.smB, 11.f, ImVec2(c4.b.x - 14.f, cy - 1.f), WithA(pal.accentSoft, 0.95f), "@g00ws");
    }
}

void PageSettings() {
    const float x0 = g_layout.x0, y0 = g_layout.y0;
    const float colA = 322.f;
    const float bx = x0 + colA + 16.f;
    const float wB = g_layout.x1 - bx;

    int cfgCount = 0;
    for (int i = 0; i < 4; ++i) if (st.cfgAlive[i]) ++cfgCount;
    char cfgTag[16];
    ImFormatString(cfgTag, sizeof cfgTag, "%d / 12", cfgCount);

    CardBox c1 = CardAt(ImVec2(x0, y0), ImVec2(x0 + colA, y0 + 262.f), "PROFILE", cfgTag);
    RC r1 = Rows(c1, 34.f);
    // config name input
    RowHover(r1);
    RowLabel(r1, "Config Name", WithA(pal.text, 0.78f));
    {
        ImGui::SetCursorScreenPos(ImVec2(r1.rightX - 150.f, r1.Mid() - 12.f));
        ImGui::SetNextItemWidth(150.f);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(9, 6));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6.f);
        ImGui::PushStyleColor(ImGuiCol_FrameBg, V4(C(23, 23, 23), 1.f));
        ImGui::PushStyleColor(ImGuiCol_Text, V4(pal.text, 0.95f));
        ImGui::PushStyleColor(ImGuiCol_TextSelectedBg, V4(pal.accent, 0.35f));
        ImGui::PushStyleColor(ImGuiCol_Border, V4(C(54, 54, 55), 0.6f));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.f);
        ImGui::InputText("##cfgname", st.cfg, sizeof(st.cfg));
        ImGui::PopStyleVar(3);
        ImGui::PopStyleColor(4);
    }
    r1.Next();
    static const char* slots[] = { "default", "legit_void", "hvh_main", "stream" };
    RowCombo(r1, "st_slot", "Config Slot", *(int*)&st.hitbox, slots, IM_ARRAYSIZE(slots));
    {
        RowHover(r1);
        RowLabel(r1, "Config Actions", WithA(pal.text, 0.78f));
        ButtonW("st_save", "Save", ImVec2(r1.rightX - 150.f, r1.Mid() - 12.f), ImVec2(r1.rightX - 78.f, r1.Mid() + 12.f), true);
        ButtonW("st_load", "Load", ImVec2(r1.rightX - 70.f, r1.Mid() - 12.f), ImVec2(r1.rightX, r1.Mid() + 12.f), false);
        r1.Next();
    }
    // saved configs list (with a real empty state)
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const float lx0 = x0 + 10.f, lx1 = x0 + colA - 10.f;
        float ly = y0 + 150.f;
        dl->AddLine(ImVec2(x0 + 14.f, ly - 12.f), ImVec2(x0 + colA - 14.f, ly - 12.f), WithA(C(255, 255, 255), 0.04f), 1.f);
        TextSpaced(dl, font.sm, 8.5f, ImVec2(x0 + 15.f, ly - 6.f), WithA(pal.text, 0.5f), "SAVED CONFIGS", 1.5f);

        if (cfgCount == 0) {
            EmptyNote(dl, ImVec2(lx0, ly + 10.f), ImVec2(lx1, ly + 96.f), "no configs yet - press save");
        } else {
            for (int i = 0; i < 4; ++i) {
                if (!st.cfgAlive[i]) continue;
                char id[32];
                ImFormatString(id, sizeof id, "cfg_row%d", i);
                ImVec2 ra(lx0 + 2.f, ly + 10.f), rb(lx1 - 2.f, ly + 30.f);
                HitRes h = HitBox(id, ra, rb);
                if (h.hover)
                    dl->AddRectFilled(ra, rb, WithA(C(255, 255, 255), 0.028f), 5.f);
                bool sel = (i == *(int*)&st.hitbox);
                dl->AddCircleFilled(ImVec2(ra.x + 10.f, (ra.y + rb.y) * 0.5f), 2.2f,
                                    sel ? WithA(pal.accentSoft, 0.95f) : WithA(pal.textMute, 0.55f), 8);
                Text(dl, font.body, font.szBody, ImVec2(ra.x + 20.f, ra.y + 4.f),
                     WithA(pal.text, sel ? 0.95f : 0.72f), slots[i]);

                char rid[32];
                ImFormatString(rid, sizeof rid, "cfg_del%d", i);
                ImVec2 da(rb.x - 18.f, ra.y + 3.f), db(rb.x - 4.f, rb.y - 3.f);
                HitRes dh = HitBox(rid, da, db);
                ImU32 xc = dh.hover ? pal.bad : WithA(pal.textMute, 0.6f);
                dl->AddLine(ImVec2(da.x + 4.f, da.y + 4.f), ImVec2(da.x + 10.f, db.y - 4.f), xc, 1.3f);
                dl->AddLine(ImVec2(da.x + 10.f, da.y + 4.f), ImVec2(da.x + 4.f, db.y - 4.f), xc, 1.3f);
                if (dh.click) st.cfgAlive[i] = false;
                ly += 22.f;
            }
        }
    }

    float y = y0 + 262.f + 14.f;
    CardBox c2 = CardAt(ImVec2(x0, y), ImVec2(x0 + colA, y + CardH(5)), "APPEARANCE");
    RC r2 = Rows(c2);
    RowColor(r2, "st_accent", "Accent Color", st.accent);
    RowSlider(r2, "st_stars", "Star Density", st.starDensity, 0.f, 1.f, "%.2f");
    RowSlider(r2, "st_dim", "Backdrop Dim", st.dimAmount, 0.2f, 0.9f, "%.2f");
    RowToggle(r2, "st_anim", "Animations", st.animations);
    RowToggle(r2, "st_undet", "Stream Proof", st.streamProof);

    CardBox c3 = CardAt(ImVec2(bx, y0), ImVec2(bx + wB, g_layout.y1), "ABOUT", "BUILD 136");
    ImDrawList* d = ImGui::GetWindowDrawList();
    ImVec2 cc(bx + wB * 0.5f, y0 + 96.f);
    if (g_logo.id) {
        float ls = 118.f;
        d->AddImage(g_logo.id, ImVec2(cc.x - ls * 0.5f, cc.y - ls * 0.5f),
                    ImVec2(cc.x + ls * 0.5f, cc.y + ls * 0.5f), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE);
    } else {
        LogoMark(d, cc, 62.f, 1.f);
    }
    TextSpaced(d, font.logo, font.szLogo, ImVec2(cc.x - SpacedWidth(font.logo, font.szLogo, "RIPWALKER", 2.0f) * 0.5f, cc.y + 46.f),
               WithA(pal.text, 0.96f), "RIPWALKER", 2.0f);
    const char* sub = "standoff 2 / external suite";
    TextCenter(d, font.sm, font.szSmall, ImVec2(cc.x, cc.y + 70.f), WithA(pal.textMute, 1.f), sub);

    d->AddLine(ImVec2(bx + 24.f, y0 + 196.f), ImVec2(bx + wB - 24.f, y0 + 196.f), WithA(C(255, 255, 255), 0.05f), 1.f);
    Text(d, font.sm, font.szSmall, ImVec2(bx + 24.f, y0 + 210.f), WithA(pal.textDim, 0.9f), "Build");
    TextRight(d, font.smB, font.szSmall, ImVec2(bx + wB - 24.f, y0 + 210.f), WithA(pal.text, 0.85f), "so2-clean v136");
    Text(d, font.sm, font.szSmall, ImVec2(bx + 24.f, y0 + 232.f), WithA(pal.textDim, 0.9f), "Backend");
    TextRight(d, font.smB, font.szSmall, ImVec2(bx + wB - 24.f, y0 + 232.f), WithA(pal.text, 0.85f), "DirectX 11");
    Text(d, font.sm, font.szSmall, ImVec2(bx + 24.f, y0 + 254.f), WithA(pal.textDim, 0.9f), "Author");
    TextRight(d, font.smB, font.szSmall, ImVec2(bx + wB - 24.f, y0 + 254.f), WithA(pal.text, 0.85f), "kindmops");

    // ---- signature / credit stamp
    {
        const float sy = y0 + 300.f;
        d->AddLine(ImVec2(bx + 24.f, sy), ImVec2(bx + wB - 24.f, sy), WithA(C(255, 255, 255), 0.055f), 1.f);

        ImVec2 avc(bx + 24.f + 32.f, sy + 48.f);
        const float avr = 32.f;
        if (g_avatar.id) {
            d->AddImageRounded(g_avatar.id, ImVec2(avc.x - avr, avc.y - avr), ImVec2(avc.x + avr, avc.y + avr),
                               ImVec2(0.f, 0.f), ImVec2(1.f, 1.f), IM_COL32_WHITE, avr);
        } else {
            d->AddCircleFilled(avc, avr, C(40, 26, 28), 40);
            d->AddCircleFilled(avc, avr, WithA(pal.accent, 0.10f), 40);
            TextCenter(d, font.h1, 18.f, avc, WithA(C(255, 224, 224), 1.f), "G");
        }
        d->AddCircle(avc, avr, WithA(pal.accentSoft, 0.55f), 56, 1.2f);
        d->AddCircle(avc, avr + 3.5f, WithA(pal.accent, 0.16f), 56, 1.f);

        const float tx = avc.x + avr + 16.f;
        TextSpaced(d, font.sm, 10.f, ImVec2(tx, sy + 14.f), WithA(pal.textMute, 0.85f), "MADE IN", 3.0f);
        const char* handle = "@g00ws";
        float hw = SpacedWidth(font.big, 36.f, handle, 0.4f);
        TextSpaced(d, font.big, 36.f, ImVec2(tx - 1.f, sy + 28.f), WithA(pal.text, 0.98f), handle, 0.4f);
        d->AddRectFilledMultiColor(ImVec2(tx, sy + 78.f), ImVec2(tx + hw, sy + 80.f),
                                   WithA(pal.accentSoft, 0.95f), WithA(pal.accent, 0.02f),
                                   WithA(pal.accent, 0.02f), WithA(pal.accentSoft, 0.95f));
        Text(d, font.sm, font.szTiny, ImVec2(bx + 24.f, sy + 94.f), WithA(pal.textMute, 0.7f),
             "standoff 2 / external renderer / directx 11");
    }
    ButtonW("st_unload", "Unload Cheat", ImVec2(bx + 24.f, g_layout.y1 - 52.f), ImVec2(bx + wB - 24.f, g_layout.y1 - 18.f), false);
}

// ---------------------------------------------------------------- rail
struct NavItem { const char* label; const char* hint; int icon; };
const NavItem kNav[] = {
    { "Aimbot", "target acquisition", IC_AIM },
    { "Visuals", "world & models", IC_EYE },
    { "Esp", "player overlay", IC_BOX },
    { "Crosshair", "reticle editor", IC_CROSS },
    { "Misc", "movement & combat", IC_SLIDER },
    { "Settings", "config & theme", IC_GEAR },
};

} // namespace

// ---------------------------------------------------------------- shell
void rw::RenderMenu(float screenW, float screenH, float openAlpha, float dt) {
    g_dt = ImClamp(dt, 0.0005f, 0.1f);
    g_time = (float)ImGui::GetTime();
    SyncPalette(st.accent);


    const ImVec2 av(0.f, 0.f), bv(screenW, screenH);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
    ImGui::SetNextWindowPos(av);
    ImGui::SetNextWindowSize(bv);
    ImGui::Begin("##ripwalker_root", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

    const float ease = EaseOutCubic(Saturate(openAlpha));
    const ImVec2 a(0.f, 0.f);
    const ImVec2 b(screenW, screenH);

    // drag the panel by its header
    {
        ImGui::SetCursorScreenPos(ImVec2(a.x + RAIL_W + 6.f, a.y + 4.f));
        ImGui::InvisibleButton("##panel_drag", ImVec2(PANEL_W - RAIL_W - 58.f, 40.f));
        if (ImGui::IsItemActivated()) DragHostBegin();
        if (ImGui::IsItemActive()) DragHostUpdate();
        if (ImGui::IsItemDeactivated()) DragHostEnd();
        if (ImGui::IsItemHovered()) ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeAll);
    }

    ImDrawList* d = ImGui::GetWindowDrawList();
    d->PushClipRect(a, b, true);

    DrawWaveBg(d, a, b, g_time, 0.20f);
    Glow(d, ImVec2(a.x + PANEL_W * 0.78f, a.y + 30.f), 320.f, C(120, 12, 22), 0.20f, 16, 2.4f);
    Glow(d, ImVec2(a.x + PANEL_W * 0.12f, b.y - 10.f), 260.f, C(90, 8, 18), 0.14f, 14, 2.6f);
    d->AddRect(ImVec2(a.x + 0.5f, a.y + 0.5f), ImVec2(b.x - 0.5f, b.y - 0.5f), WithA(C(96, 24, 32), 0.75f),
               13.f, 0, 1.f);

    // rail
    d->AddRectFilled(a, ImVec2(a.x + RAIL_W, b.y), WithA(C(10, 8, 16), 0.72f), 16.f, ImDrawFlags_RoundCornersLeft);
    d->AddRectFilled(ImVec2(a.x + RAIL_W - 16.f, a.y), ImVec2(a.x + RAIL_W, b.y), WithA(C(10, 8, 16), 0.72f));
    d->AddLine(ImVec2(a.x + RAIL_W, a.y + 14.f), ImVec2(a.x + RAIL_W, b.y - 14.f), WithA(C(255, 255, 255), 0.055f), 1.f);

    // logo block
    ImVec2 lc(a.x + 34.f, a.y + 40.f);
    if (g_logo.id) {
        float ls = 30.f;
        d->AddImage(g_logo.id, ImVec2(lc.x - ls * 0.5f, lc.y - ls * 0.5f), ImVec2(lc.x + ls * 0.5f, lc.y + ls * 0.5f),
                    ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE);
    } else {
        LogoMark(d, lc, 32.f, 1.f);
    }
    TextSpaced(d, font.logo, font.szLogo, ImVec2(a.x + 58.f, a.y + 31.f), WithA(pal.text, 0.96f), "RIPWALKER", 1.5f);
    TextSpaced(d, font.sm, 8.f, ImVec2(a.x + 59.f, a.y + 49.f), WithA(pal.textMute, 1.f), "SO2 / V136", 1.0f);

    // nav
    static int navSel = -1;
    float navY = a.y + 92.f;
    const int navCount = IM_ARRAYSIZE(kNav);
    if (navSel < 0) navSel = st.tab;
    for (int i = 0; i < navCount; ++i) {
        float iy = navY + i * 44.f;
        ImVec2 na(a.x + 12.f, iy), nb(a.x + RAIL_W - 12.f, iy + 38.f);
        bool sel = (st.tab == i);
        char id[32]; ImFormatString(id, sizeof id, "nav%d", i);
        HitRes h = HitBox(id, na, nb);
        if (h.click) st.tab = i;

        ImGuiID uid = ImGui::GetID(id);
        float& hv = Anim(uid, 0.f);
        hv = Approach(hv, h.hover ? 1.f : 0.f, 14.f, g_dt);

        if (sel) {
            float& sv = Anim(uid + 7, 0.f);
            sv = Approach(sv, 1.f, 16.f, g_dt);
            RRectGrad(d, na, nb, 8.f, WithA(pal.accent, 0.16f * sv), WithA(pal.accentDeep, 0.20f * sv));
            d->AddRectFilled(ImVec2(na.x, na.y + 8.f), ImVec2(na.x + 2.4f, nb.y - 8.f), WithA(pal.accentSoft, 0.9f), 1.2f);

        } else if (hv > 0.01f) {
            d->AddRectFilled(na, nb, WithA(C(255, 255, 255), 0.035f * hv), 8.f);
        }

        ImU32 icol = sel ? pal.accentSoft : WithA(pal.textDim, 0.75f + 0.25f * hv);
        DrawIcon(d, kNav[i].icon, ImVec2(na.x + 25.f, (na.y + nb.y) * 0.5f), 18.f, icol, 1.6f);
        Text(d, sel ? font.h2 : font.h2, 15.f, ImVec2(na.x + 48.f, (na.y + nb.y) * 0.5f - 8.f),
             sel ? WithA(pal.text, 0.98f) : WithA(pal.textDim, 0.85f), kNav[i].label);
    }

    // user card
    {
        ImVec2 ua(a.x + 12.f, b.y - 78.f), ub(a.x + RAIL_W - 12.f, b.y - 14.f);
        RRectGrad(d, ua, ub, 12.f, C(34, 24, 26), C(20, 14, 15));
        d->AddRect(ua, ub, WithA(pal.accent, 0.22f), 12.f, 0, 1.f);

        ImVec2 avc(ua.x + 29.f, (ua.y + ub.y) * 0.5f);
        const float avr = 19.f;
        d->AddCircleFilled(avc, avr + 3.f, WithA(pal.accent, 0.10f), 40);
        if (g_avatar.id) {
            d->AddImageRounded(g_avatar.id, ImVec2(avc.x - avr, avc.y - avr), ImVec2(avc.x + avr, avc.y + avr),
                               ImVec2(0.f, 0.f), ImVec2(1.f, 1.f), IM_COL32_WHITE, avr);
        } else {
            d->AddCircleFilled(avc, avr, C(40, 26, 28), 40);
            TextCenter(d, font.bodyB, font.szBody, avc, WithA(C(255, 224, 224), 1.f), "K");
        }
        d->AddCircle(avc, avr, WithA(pal.accent, 0.80f), 48, 1.3f);

        Text(d, font.bodyB, font.szBody, ImVec2(ua.x + 54.f, ua.y + 13.f), WithA(pal.text, 0.97f), "kindmops");
        ImVec2 c0(ua.x + 54.f, ua.y + 33.f), c1(ua.x + 100.f, ua.y + 47.f);
        d->AddRectFilled(c0, c1, WithA(pal.accent, 0.16f), 4.f);
        TextCenter(d, font.sm, font.szTiny, ImVec2((c0.x + c1.x) * 0.5f, c0.y + 3.f),
                   WithA(pal.accentSoft, 0.95f), "LIFETIME");

        // connection state + build tag
        d->AddCircleFilled(ImVec2(ua.x + 58.f, ub.y - 12.f), 2.4f, WithA(pal.good, 0.95f), 10);
        d->AddCircleFilled(ImVec2(ua.x + 58.f, ub.y - 12.f), 6.f, WithA(pal.good, 0.10f), 12);
        TextSpaced(d, font.tiny, 8.f, ImVec2(ua.x + 65.f, ub.y - 17.f), WithA(pal.good, 0.85f), "CONNECTED", 0.9f);
        TextRight(d, font.tiny, 8.f, ImVec2(ub.x - 12.f, ub.y - 17.f), WithA(pal.textMute, 0.85f), "v14.0");
    }

    // header
    const float x0 = a.x + RAIL_W + 22.f;
    const float x1 = b.x - 22.f;
    g_layout.x0 = x0; g_layout.x1 = x1;
    g_layout.y0 = a.y + 78.f; g_layout.y1 = b.y - 28.f;

    const char* tabTitle = kNav[st.tab].label;
    const float titleW = SpacedWidth(font.h1, font.szH1, tabTitle, -0.3f);
    TextSpaced(d, font.h1, font.szH1, ImVec2(x0, a.y + 22.f), WithA(pal.text, 0.97f), tabTitle, -0.3f);

    // breadcrumb: Settings > config & theme
    {
        const float cx = x0 + titleW + 14.f;
        const float cy = a.y + 33.f;
        d->AddLine(ImVec2(cx, cy - 4.5f), ImVec2(cx + 4.5f, cy), WithA(pal.textMute, 0.85f), 1.3f);
        d->AddLine(ImVec2(cx + 4.5f, cy), ImVec2(cx, cy + 4.5f), WithA(pal.textMute, 0.85f), 1.3f);
        char crumb[80];
        int ci = 0;
        for (const char* p = kNav[st.tab].hint; *p && ci < 79; ++p)
            crumb[ci++] = (*p >= 'a' && *p <= 'z') ? (char)(*p - 32) : *p;
        crumb[ci] = 0;
        TextSpaced(d, font.sm, 9.f, ImVec2(cx + 13.f, a.y + 28.f), WithA(pal.textMute, 0.9f), crumb, 1.5f);
    }

    // header right: status + close
    {
        ImVec2 cc(b.x - 22.f - 14.f, a.y + 30.f);
        HitRes ch = HitBox("close_btn", ImVec2(cc.x - 14.f, cc.y - 14.f), ImVec2(cc.x + 14.f, cc.y + 14.f));
        d->AddCircleFilled(cc, 14.f, WithA(ch.hover ? pal.bad : C(255, 255, 255), ch.hover ? 0.16f : 0.035f), 30);
        d->AddCircle(cc, 14.f, WithA(ch.hover ? C(255, 140, 148) : C(255, 255, 255), ch.hover ? 0.55f : 0.10f), 30, 1.f);
        ImU32 ccol = ch.hover ? C(255, 236, 238) : WithA(pal.textDim, 0.85f);
        d->AddLine(ImVec2(cc.x - 4.4f, cc.y - 4.4f), ImVec2(cc.x + 4.4f, cc.y + 4.4f), ccol, 1.5f);
        d->AddLine(ImVec2(cc.x + 4.4f, cc.y - 4.4f), ImVec2(cc.x - 4.4f, cc.y + 4.4f), ccol, 1.5f);
        if (ch.click) PostQuitMessage(0);

        // status pill: even (Inter) type, fixed width so it never breathes
        const char* status = "UNDETECTED";
        ImVec2 p1(cc.x - 26.f, a.y + 40.f);
        ImVec2 p0(p1.x - 92.f, a.y + 20.f);
        d->AddRectFilled(p0, p1, WithA(pal.good, 0.08f), 10.f);
        d->AddRect(p0, p1, WithA(pal.good, 0.22f), 10.f, 0, 1.f);
        d->AddCircleFilled(ImVec2(p0.x + 12.f, (p0.y + p1.y) * 0.5f), 3.f, WithA(pal.good, 0.95f), 12);
        TextSpaced(d, font.tiny, 9.f, ImVec2(p0.x + 20.f, p0.y + 5.5f), WithA(pal.good, 0.92f), status, 1.2f);
    }

    // divider under header
    d->AddLine(ImVec2(x0, a.y + 64.f), ImVec2(x1, a.y + 64.f), WithA(C(255, 255, 255), 0.05f), 1.f);

    // page content (slide-in on switch)
    if (st.tab != st.prevTab) { st.prevTab = st.tab; st.pageAlpha = 0.f; }
    st.pageAlpha = Approach(st.pageAlpha, 1.f, 12.f, g_dt);

    switch (st.tab) {
        case 0: PageAimbot(); break;
        case 1: PageVisuals(); break;
        case 2: PageEsp(); break;
        case 3: PageCrosshair(); break;
        case 4: PageMisc(); break;
        case 5: PageSettings(); break;
        default: PageAimbot(); break;
    }

    d->PopClipRect();
    ImGui::End();
    ImGui::PopStyleVar(2);
}
