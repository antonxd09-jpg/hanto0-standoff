// RIPWALKER :: gui state + api
#pragma once

#include "draw.hpp"
#include <string>
#include <vector>

namespace rw {

void DragHostBegin();
void DragHostUpdate();
void DragHostEnd();

struct TexRef { ImTextureID id = (ImTextureID)0; int w = 0, h = 0; };
extern TexRef g_logo;
extern TexRef g_avatar;
extern TexRef g_hero;
extern std::vector<ImVec2> g_heroJoints;
extern std::vector<std::pair<int, int>> g_heroPairs;

struct EspOpts {
    bool box = true;
    bool skeleton = true;
    bool health = true;
    bool name = true;
    bool distance = true;
    bool weapon = true;
    bool snapline = false;
    bool chams = false;
    bool fill = false;
    bool armor = false;
    int  boxStyle = 0; // 0 = corner, 1 = full
};

struct State {
    int   tab = 0;
    float pageAlpha = 1.f;
    float navY = -1.f;
    float navCur = -1.f;
    float openT = 0.f;
    int   prevTab = 0;

    // aimbot
    bool  aimOn = true, silent = true, throughWalls = false, autofire = true;
    int   aimKey = 6; // mouse5
    float fov = 180.f, smooth = 12.f, minDamage = 86.f, hitChance = 74.f, delay = 45.f;
    int   hitbox = 1, priority = 0, targetMode = 0;
    bool  ignoreTeam = true, dynamicFov = false, quickStop = true, backtrack = false;

    // esp
    EspOpts esp;
    int   boxStyle = 0;
    float skelThick = 1.f, boxOpacity = 0.9f;
    ImVec4 boxCol = ImVec4(0.94f, 0.94f, 0.95f, 1.f);
    ImVec4 skelCol = ImVec4(0.85f, 0.85f, 0.88f, 1.f);
    bool  glow = false;
    bool  tracer = true;
    bool  streamProof = true;

    // visuals
    ImVec4 skyCol = ImVec4(0.55f, 0.55f, 0.58f, 1.f);
    float fog = 0.35f, skyBright = 0.7f;
    bool  rain = false;
    int   chamsType = 0, knifeModel = 0;
    bool  glove = true, localModel = false;

    // crosshair
    int   chStyle = 0;                 // 0 cross, 1 dot, 2 t-shape, 3 ring
    float chGap = 4.f, chLen = 6.f, chThick = 1.4f, chAlpha = 0.92f, chSpread = 0.6f, chSpreadSpeed = 1.f;
    bool  chDot = true, chOutline = true, chGlow = true, chDynamic = false;
    ImVec4 chColor = ImVec4(0.95f, 0.12f, 0.16f, 1.f);

    // misc
    bool  bhop = true, autostrafe = true, thirdperson = false, norecoil = true, nospread = false, rapid = false;
    int   jumpKey = 32;
    float strafe = 1.f;
    bool  dmgInfo = true, hitSound = true;
    int   hitSoundIdx = 0, marker = 0;
    float volume = 0.6f;

    // settings
    char  cfg[64] = "legit_void";
    bool  cfgAlive[4] = { true, true, true, true };
    ImVec4 accent = ImVec4(0.95f, 0.12f, 0.16f, 1.f);
    float starDensity = 1.f, dimAmount = 0.55f;
    bool  animations = true;

    // window
    float fps = 0.f;
    float panelX = 0.f, panelY = 0.f;
    bool  panelPlaced = false;

    // hero model preview
    float heroYaw = 0.35f, heroPitch = -0.04f, heroZoom = 1.0f;
    bool  heroSpin = false;
};

inline State st;

// menu shell (full app window is a dimmed backdrop, menu is centred)
void RenderMenu(float screenW, float screenH, float openAlpha, float dt);

// preview renderers
void DrawAimPreview(ImDrawList* d, ImRect area, float time);
void DrawEspPreview(ImDrawList* d, ImRect area, float time);
void DrawCrosshairPreview(ImDrawList* d, ImRect area, float time);
void DrawCrosshairMini(ImDrawList* d, ImVec2 c, int style, ImU32 col, float s);

} // namespace rw
