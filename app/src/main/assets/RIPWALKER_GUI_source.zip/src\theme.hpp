// RIPWALKER :: visual theme + math helpers
#pragma once

#include "imgui.h"
#include <cmath>
#include <cstdint>

namespace rw {

// ---------------------------------------------------------------- colors
inline ImU32 C(int r, int g, int b, int a = 255) { return IM_COL32(r, g, b, a); }

inline int ClampI(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

inline ImU32 WithA(ImU32 c, float a01) {
    int a = (int)(((c >> 24) & 0xFF) * (a01 < 0.f ? 0.f : (a01 > 1.f ? 1.f : a01)) + 0.5f);
    return (c & 0x00FFFFFFu) | ((ImU32)ClampI(a, 0, 255) << 24);
}

inline ImU32 Mix(ImU32 a, ImU32 b, float t) {
    t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
    int ar = (a >> 0) & 0xFF, ag = (a >> 8) & 0xFF, ab = (a >> 16) & 0xFF, aa = (a >> 24) & 0xFF;
    int br = (b >> 0) & 0xFF, bg = (b >> 8) & 0xFF, bb = (b >> 16) & 0xFF, ba = (b >> 24) & 0xFF;
    int r = (int)(ar + (br - ar) * t + 0.5f);
    int g = (int)(ag + (bg - ag) * t + 0.5f);
    int bl = (int)(ab + (bb - ab) * t + 0.5f);
    int al = (int)(aa + (ba - aa) * t + 0.5f);
    return IM_COL32(r, g, bl, al);
}

inline ImU32 Bright(ImU32 c, float k) {
    if (k <= 1.f) return c;
    float rr = (float)((c >> 0) & 0xFF) * k;
    float gg = (float)((c >> 8) & 0xFF) * k;
    float bb = (float)((c >> 16) & 0xFF) * k;
    int r = (int)(rr > 255.f ? 255.f : rr);
    int g = (int)(gg > 255.f ? 255.f : gg);
    int b = (int)(bb > 255.f ? 255.f : bb);
    return IM_COL32(r, g, b, (c >> 24) & 0xFF);
}

inline ImU32 Dark(ImU32 c, float k) {
    int r = (int)(((c >> 0) & 0xFF) * k);
    int g = (int)(((c >> 8) & 0xFF) * k);
    int b = (int)(((c >> 16) & 0xFF) * k);
    return IM_COL32(r, g, b, (c >> 24) & 0xFF);
}

inline ImVec4 V4(ImU32 c, float alphaMul = 1.f) {
    return ImVec4(((c >> 0) & 0xFF) / 255.f,
                  ((c >> 8) & 0xFF) / 255.f,
                  ((c >> 16) & 0xFF) / 255.f,
                  (((c >> 24) & 0xFF) / 255.f) * alphaMul);
}

// ---------------------------------------------------------------- math
inline float Approach(float cur, float target, float speed, float dt) {
    float k = 1.f - std::exp(-speed * dt);
    return cur + (target - cur) * k;
}

inline float EaseOutCubic(float t) {
    t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
    float u = 1.f - t;
    return 1.f - u * u * u;
}

inline float EaseInOut(float t) {
    t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
    return t * t * (3.f - 2.f * t);
}

inline float Saturate(float v) { return v < 0.f ? 0.f : (v > 1.f ? 1.f : v); }

// ---------------------------------------------------------------- palette
struct Palette {
    ImU32 accent      = C(232, 232, 236);
    ImU32 accentDeep  = C(128, 128, 134);
    ImU32 accentSoft  = C(247, 247, 250);
    ImU32 bgTop       = C(11, 11, 12);
    ImU32 bgBottom    = C(6, 6, 7);
    ImU32 rail        = C(8, 8, 9);
    ImU32 card        = C(16, 16, 17);
    ImU32 cardTop     = C(22, 22, 24);
    ImU32 cardLine    = C(33, 33, 36);
    ImU32 cardLineHi  = C(58, 58, 64);
    ImU32 text        = C(235, 235, 238);
    ImU32 textDim     = C(148, 148, 154);
    ImU32 textMute    = C(98, 98, 104);
    ImU32 good        = C(176, 184, 178);
    ImU32 warn        = C(196, 186, 158);
    ImU32 bad         = C(214, 148, 148);
    ImU32 track       = C(34, 34, 37);
};
inline Palette pal;

inline void SyncPalette(const ImVec4& accent) {
    ImU32 a = IM_COL32((int)(accent.x * 255), (int)(accent.y * 255), (int)(accent.z * 255), 255);
    pal.accent = a;
    pal.accentDeep = Dark(a, 0.55f);
    pal.accentSoft = Mix(a, C(255, 255, 255), 0.55f);
}

} // namespace rw
