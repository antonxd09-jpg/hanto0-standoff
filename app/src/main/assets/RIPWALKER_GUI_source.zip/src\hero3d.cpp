// RIPWALKER :: GLB -> skinned software renderer
#include "hero3d.hpp"
#include "imgui_internal.h"

#include <windows.h>
#include <wincodec.h>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <map>

#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")

namespace rw {
namespace {

template<class T> static inline T rmin(T a, T b) { return a < b ? a : b; }
template<class T> static inline T rmax(T a, T b) { return a > b ? a : b; }

// ------------------------------------------------------------------ json
struct JVal {
    enum Type { Nul, Bool, Num, Str, Arr, Obj } t = Nul;
    double n = 0;
    bool b = false;
    std::string s;
    std::vector<JVal> a;
    std::vector<std::pair<std::string, JVal>> o;

    const JVal* get(const char* k) const {
        for (auto& kv : o) if (kv.first == k) return &kv.second;
        return nullptr;
    }
    const JVal* at(int i) const { return (i >= 0 && i < (int)a.size()) ? &a[i] : nullptr; }
};

struct JParser {
    const char* p;
    const char* end;

    void ws() { while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) ++p; }
    bool lit(const char* s) {
        size_t n = strlen(s);
        if (end - p < (ptrdiff_t)n) return false;
        if (memcmp(p, s, n) != 0) return false;
        p += n;
        return true;
    }
    std::string str() {
        std::string out;
        if (p < end && *p == '"') ++p;
        while (p < end && *p != '"') {
            char c = *p++;
            if (c == '\\' && p < end) {
                char e = *p++;
                switch (e) {
                    case 'n': out += '\n'; break;
                    case 't': out += '\t'; break;
                    case 'r': out += '\r'; break;
                    case 'b': out += '\b'; break;
                    case 'f': out += '\f'; break;
                    case '/': out += '/'; break;
                    case '\\': out += '\\'; break;
                    case '"': out += '"'; break;
                    case 'u': {
                        unsigned cp = 0;
                        for (int i = 0; i < 4 && p < end; ++i) {
                            char h = *p++;
                            cp <<= 4;
                            if (h >= '0' && h <= '9') cp |= (unsigned)(h - '0');
                            else if (h >= 'a' && h <= 'f') cp |= (unsigned)(h - 'a' + 10);
                            else if (h >= 'A' && h <= 'F') cp |= (unsigned)(h - 'A' + 10);
                        }
                        out += (cp < 128) ? (char)cp : '?';
                        break;
                    }
                    default: out += e; break;
                }
            } else out += c;
        }
        if (p < end && *p == '"') ++p;
        return out;
    }
    JVal value(int depth = 0) {
        JVal v;
        if (depth > 64) return v;
        ws();
        if (p >= end) return v;
        char c = *p;
        if (c == '{') {
            ++p; v.t = JVal::Obj;
            for (;;) {
                ws();
                if (p >= end) break;
                if (*p == '}') { ++p; break; }
                if (*p == ',') { ++p; continue; }
                std::string k = str();
                ws();
                if (p < end && *p == ':') ++p;
                JVal val = value(depth + 1);
                v.o.emplace_back(std::move(k), std::move(val));
            }
        } else if (c == '[') {
            ++p; v.t = JVal::Arr;
            for (;;) {
                ws();
                if (p >= end) break;
                if (*p == ']') { ++p; break; }
                if (*p == ',') { ++p; continue; }
                v.a.push_back(value(depth + 1));
            }
        } else if (c == '"') {
            v.t = JVal::Str; v.s = str();
        } else if (c == 't') {
            lit("true"); v.t = JVal::Bool; v.b = true;
        } else if (c == 'f') {
            lit("false"); v.t = JVal::Bool; v.b = false;
        } else if (c == 'n') {
            lit("null"); v.t = JVal::Nul;
        } else {
            char* e = nullptr;
            v.n = strtod(p, &e);
            if (e && e > p) p = e; else ++p;
            v.t = JVal::Num;
        }
        return v;
    }
};

// ------------------------------------------------------------------ math
struct Mat4 { float m[16]; };

Mat4 Identity() { Mat4 r{}; r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.f; return r; }

Mat4 Mul(const Mat4& A, const Mat4& B) {
    Mat4 C{};
    for (int c = 0; c < 4; ++c)
        for (int r = 0; r < 4; ++r) {
            float s = 0;
            for (int k = 0; k < 4; ++k) s += A.m[k * 4 + r] * B.m[c * 4 + k];
            C.m[c * 4 + r] = s;
        }
    return C;
}

void XformPoint(const Mat4& M, float x, float y, float z, float& ox, float& oy, float& oz) {
    ox = M.m[0] * x + M.m[4] * y + M.m[8] * z + M.m[12];
    oy = M.m[1] * x + M.m[5] * y + M.m[9] * z + M.m[13];
    oz = M.m[2] * x + M.m[6] * y + M.m[10] * z + M.m[14];
}

void XformDir(const Mat4& M, float x, float y, float z, float& ox, float& oy, float& oz) {
    ox = M.m[0] * x + M.m[4] * y + M.m[8] * z;
    oy = M.m[1] * x + M.m[5] * y + M.m[9] * z;
    oz = M.m[2] * x + M.m[6] * y + M.m[10] * z;
}

Mat4 FromTRS(float tx, float ty, float tz, float qx, float qy, float qz, float qw,
             float sx, float sy, float sz) {
    Mat4 r = Identity();
    float xx = qx * qx, yy = qy * qy, zz = qz * qz;
    float xy = qx * qy, xz = qx * qz, yz = qy * qz;
    float wx = qw * qx, wy = qw * qy, wz = qw * qz;
    r.m[0] = (1 - 2 * (yy + zz)) * sx;
    r.m[1] = (2 * (xy + wz)) * sx;
    r.m[2] = (2 * (xz - wy)) * sx;
    r.m[4] = (2 * (xy - wz)) * sy;
    r.m[5] = (1 - 2 * (xx + zz)) * sy;
    r.m[6] = (2 * (yz + wx)) * sy;
    r.m[8] = (2 * (xz + wy)) * sz;
    r.m[9] = (2 * (yz - wx)) * sz;
    r.m[10] = (1 - 2 * (xx + yy)) * sz;
    r.m[12] = tx; r.m[13] = ty; r.m[14] = tz;
    return r;
}

// ------------------------------------------------------------------ accessors
struct Gltf {
    const JVal* root = nullptr;
    const uint8_t* bin = nullptr;
    size_t binLen = 0;

    int compCount(const std::string& t) const {
        if (t == "SCALAR") return 1;
        if (t == "VEC2") return 2;
        if (t == "VEC3") return 3;
        if (t == "VEC4") return 4;
        if (t == "MAT4") return 16;
        return 0;
    }

    bool readAccessor(int idx, std::vector<float>& out, int& comps) const {
        out.clear();
        comps = 0;
        const JVal* acc = root->get("accessors") ? root->get("accessors")->at(idx) : nullptr;
        if (!acc) return false;
        const JVal* typeJ = acc->get("type");
        if (!typeJ) return false;
        comps = compCount(typeJ->s);
        int count = (int)(acc->get("count") ? acc->get("count")->n : 0);
        int bvIdx = (int)(acc->get("bufferView") ? acc->get("bufferView")->n : -1);
        if (bvIdx < 0 || comps <= 0) return false;

        const JVal* bv = root->get("bufferViews")->at(bvIdx);
        int bvOff = (int)(bv->get("byteOffset") ? bv->get("byteOffset")->n : 0);
        int accOff = (int)(acc->get("byteOffset") ? acc->get("byteOffset")->n : 0);
        const JVal* strideJ = bv->get("byteStride");
        int stride = strideJ ? (int)strideJ->n : 0;
        int ctype = (int)(acc->get("componentType") ? acc->get("componentType")->n : 5126);

        int compSize = 4;
        if (ctype == 5120 || ctype == 5121) compSize = 1;
        else if (ctype == 5122 || ctype == 5123) compSize = 2;
        int elem = compSize * comps;
        if (stride == 0) stride = elem;

        size_t base = (size_t)bvOff + (size_t)accOff;
        if (base + (size_t)(count - 1) * stride + elem > binLen) return false;

        out.resize((size_t)count * comps);
        for (int i = 0; i < count; ++i) {
            const uint8_t* src = bin + base + (size_t)i * stride;
            for (int c = 0; c < comps; ++c) {
                float v = 0;
                const uint8_t* q = src + c * compSize;
                switch (ctype) {
                    case 5126: memcpy(&v, q, 4); break;
                    case 5123: { uint16_t u; memcpy(&u, q, 2); v = (float)u; break; }
                    case 5122: { int16_t s; memcpy(&s, q, 2); v = (float)s; break; }
                    case 5121: v = (float)q[0]; break;
                    case 5120: v = (float)(int8_t)q[0]; break;
                    case 5125: { uint32_t u; memcpy(&u, q, 4); v = (float)u; break; }
                    default: break;
                }
                out[(size_t)i * comps + c] = v;
            }
        }
        return true;
    }
};

// ------------------------------------------------------------------ wic
static bool DecodePNG(const uint8_t* data, size_t len, int& w, int& h, std::vector<uint32_t>& rgba) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    IWICImagingFactory* fac = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                IID_PPV_ARGS(&fac)))) return false;

    IWICStream* stream = nullptr;
    IWICBitmapDecoder* dec = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICFormatConverter* conv = nullptr;
    bool ok = false;

    if (SUCCEEDED(fac->CreateStream(&stream)) &&
        SUCCEEDED(stream->InitializeFromMemory((BYTE*)data, (DWORD)len)) &&
        SUCCEEDED(fac->CreateDecoderFromStream(stream, nullptr, WICDecodeMetadataCacheOnDemand, &dec)) &&
        SUCCEEDED(dec->GetFrame(0, &frame))) {
        UINT uw = 0, uh = 0;
        if (SUCCEEDED(frame->GetSize(&uw, &uh)) && uw && uh) {
            if (SUCCEEDED(fac->CreateFormatConverter(&conv)) &&
                SUCCEEDED(conv->Initialize(frame, GUID_WICPixelFormat32bppBGRA, WICBitmapDitherTypeNone,
                                           nullptr, 0, WICBitmapPaletteTypeCustom))) {
                std::vector<uint8_t> tmp((size_t)uw * uh * 4);
                if (SUCCEEDED(conv->CopyPixels(nullptr, uw * 4, (UINT)tmp.size(), tmp.data()))) {
                    w = (int)uw; h = (int)uh;
                    rgba.resize((size_t)uw * uh);
                    for (size_t i = 0; i < rgba.size(); ++i) {
                        uint8_t b = tmp[i * 4 + 0], g = tmp[i * 4 + 1], r = tmp[i * 4 + 2], a = tmp[i * 4 + 3];
                        rgba[i] = (uint32_t)r | ((uint32_t)g << 8) | ((uint32_t)b << 16) | ((uint32_t)a << 24);
                    }
                    ok = true;
                }
            }
        }
    }
    if (conv) conv->Release();
    if (frame) frame->Release();
    if (dec) dec->Release();
    if (stream) stream->Release();
    fac->Release();
    return ok;
}

// ------------------------------------------------------------------ nodes
struct NodeT {
    std::string name;
    Mat4 local = Identity();
    std::vector<int> kids;
    int mesh = -1;
    int skin = -1;
    int parent = -1;
    // defaults for animation
    float t[3] = { 0, 0, 0 };
    float r[4] = { 0, 0, 0, 1 };
    float s[3] = { 1, 1, 1 };
    bool hasMatrix = false;
};

struct Skin {
    std::vector<int> joints;
    std::vector<Mat4> invBind;
};

struct Chan {
    int node = -1;
    int path = 0; // 0 t, 1 r, 2 s
    int sampler = -1;
};

struct Sampler {
    std::vector<float> times;
    std::vector<float> values;
    int comps = 0;
};

} // namespace

bool LoadHeroGLB(const void* data, size_t len, HeroModel& out) {
    out = HeroModel{};
    const uint8_t* b = (const uint8_t*)data;
    if (len < 20 || memcmp(b, "glTF", 4) != 0) return false;

    uint32_t jsonLen = 0;
    memcpy(&jsonLen, b + 12, 4);
    if (20 + jsonLen > len) return false;

    std::string js((const char*)b + 20, jsonLen);
    JParser jp{ js.c_str(), js.c_str() + js.size() };
    JVal root = jp.value();

    size_t off = 20 + jsonLen;
    const uint8_t* bin = nullptr;
    size_t binLen = 0;
    while (off + 8 <= len) {
        uint32_t clen = 0, ctype = 0;
        memcpy(&clen, b + off, 4);
        memcpy(&ctype, b + off + 4, 4);
        if (ctype == 0x004E4942 && off + 8 + clen <= len) { bin = b + off + 8; binLen = clen; break; }
        off += 8 + clen;
    }
    if (!bin) return false;

    Gltf g;
    g.root = &root;
    g.bin = bin;
    g.binLen = binLen;

    // --- nodes
    std::vector<NodeT> nodes;
    if (const JVal* jn = root.get("nodes")) {
        nodes.resize(jn->a.size());
        for (size_t i = 0; i < jn->a.size(); ++i) {
            const JVal& n = jn->a[i];
            NodeT t;
            if (const JVal* nm = n.get("name")) t.name = nm->s;
            if (const JVal* ch = n.get("children")) for (auto& c : ch->a) t.kids.push_back((int)c.n);
            if (const JVal* m = n.get("mesh")) t.mesh = (int)m->n;
            if (const JVal* s = n.get("skin")) t.skin = (int)s->n;
            if (const JVal* mx = n.get("matrix")) {
                for (int k = 0; k < 16; ++k) t.local.m[k] = (float)mx->a[k].n;
                t.hasMatrix = true;
            } else {
                if (const JVal* tr = n.get("translation")) for (int k = 0; k < 3; ++k) t.t[k] = (float)tr->a[k].n;
                if (const JVal* ro = n.get("rotation")) for (int k = 0; k < 4; ++k) t.r[k] = (float)ro->a[k].n;
                if (const JVal* sc = n.get("scale")) for (int k = 0; k < 3; ++k) t.s[k] = (float)sc->a[k].n;
                t.local = FromTRS(t.t[0], t.t[1], t.t[2], t.r[0], t.r[1], t.r[2], t.r[3], t.s[0], t.s[1], t.s[2]);
            }
            nodes[i] = t;
        }
        for (size_t i = 0; i < nodes.size(); ++i)
            for (int k : nodes[i].kids) if (k >= 0 && k < (int)nodes.size()) nodes[k].parent = (int)i;
    }

    // --- mesh primitive
    const JVal* meshes = root.get("meshes");
    if (!meshes || meshes->a.empty()) return false;
    const JVal* prim = meshes->a[0].get("primitives")->at(0);
    if (!prim) return false;
    const JVal* attrs = prim->get("attributes");
    if (!attrs) return false;
    auto accIdx = [&](const char* k) -> int {
        const JVal* v = attrs->get(k);
        return v ? (int)v->n : -1;
    };

    std::vector<float> pos, nrm, uv, joints, weights;
    int cp = 0, cn = 0, cu = 0, cj = 0, cw = 0;
    if (!g.readAccessor(accIdx("POSITION"), pos, cp) || cp != 3) return false;
    if (accIdx("NORMAL") >= 0) g.readAccessor(accIdx("NORMAL"), nrm, cn);
    if (accIdx("TEXCOORD_0") >= 0) g.readAccessor(accIdx("TEXCOORD_0"), uv, cu);
    if (accIdx("JOINTS_0") >= 0) g.readAccessor(accIdx("JOINTS_0"), joints, cj);
    if (accIdx("WEIGHTS_0") >= 0) g.readAccessor(accIdx("WEIGHTS_0"), weights, cw);

    std::vector<float> idxF;
    int ci = 0;
    if (const JVal* ind = prim->get("indices")) g.readAccessor((int)ind->n, idxF, ci);

    const int vcount = (int)(pos.size() / 3);
    if (!vcount) return false;

    out.verts.resize(vcount);
    for (int i = 0; i < vcount; ++i) {
        HeroVertex& v = out.verts[i];
        v.px = pos[i * 3 + 0]; v.py = pos[i * 3 + 1]; v.pz = pos[i * 3 + 2];
        if (cn == 3) { v.nx = nrm[i * 3 + 0]; v.ny = nrm[i * 3 + 1]; v.nz = nrm[i * 3 + 2]; }
        else { v.nx = 0; v.ny = 1; v.nz = 0; }
        if (cu >= 2) { v.u = uv[i * 2 + 0]; v.v = uv[i * 2 + 1]; }
        if (cj == 4 && cw == 4) {
            for (int k = 0; k < 4; ++k) {
                v.j[k] = (int)joints[i * 4 + k];
                v.w[k] = weights[i * 4 + k];
            }
            float sum = v.w[0] + v.w[1] + v.w[2] + v.w[3];
            if (sum > 0.0001f) { for (int k = 0; k < 4; ++k) v.w[k] /= sum; }
            else { v.w[0] = 1; v.w[1] = v.w[2] = v.w[3] = 0; }
        }
    }

    out.idx.clear();
    if (!idxF.empty()) for (float f : idxF) out.idx.push_back((uint32_t)f);
    else for (int i = 0; i < vcount; ++i) out.idx.push_back((uint32_t)i);

    // --- skin
    Skin skin;
    if (const JVal* skins = root.get("skins")) {
        const JVal* s0 = skins->at(0);
        if (s0) {
            if (const JVal* jj = s0->get("joints")) for (auto& x : jj->a) skin.joints.push_back((int)x.n);
            if (const JVal* ib = s0->get("inverseBindMatrices")) {
                std::vector<float> mats; int cm = 0;
                if (g.readAccessor((int)ib->n, mats, cm) && cm == 16) {
                    skin.invBind.resize(mats.size() / 16);
                    for (size_t i = 0; i < skin.invBind.size(); ++i)
                        for (int k = 0; k < 16; ++k) skin.invBind[i].m[k] = mats[i * 16 + k];
                }
            }
        }
    }

    // --- texture
    if (const JVal* imgs = root.get("images")) {
        if (const JVal* img0 = imgs->at(0)) {
            const JVal* bvJ = img0->get("bufferView");
            if (bvJ) {
                const JVal* bv = root.get("bufferViews")->at((int)bvJ->n);
                if (bv) {
                    int off2 = (int)(bv->get("byteOffset") ? bv->get("byteOffset")->n : 0);
                    int l2 = (int)(bv->get("byteLength") ? bv->get("byteLength")->n : 0);
                    if (off2 >= 0 && l2 > 0 && (size_t)(off2 + l2) <= binLen)
                        DecodePNG(bin + off2, (size_t)l2, out.texW, out.texH, out.tex);
                }
            }
        }
    }
    if (out.tex.empty()) { out.texW = out.texH = 2; out.tex.assign(4, 0xFFFFFFFFu); }

    // --- static bounds (bind pose)
    float mnx = 1e9f, mny = 1e9f, mnz = 1e9f, mxx = -1e9f, mxy = -1e9f, mxz = -1e9f;
    for (auto& v : out.verts) {
        mnx = rmin(mnx, v.px); mny = rmin(mny, v.py); mnz = rmin(mnz, v.pz);
        mxx = rmax(mxx, v.px); mxy = rmax(mxy, v.py); mxz = rmax(mxz, v.pz);
    }
    out.height = rmax(0.0001f, mxy - mny);
    out.bbMin = ImVec2(mnx, mny);
    out.bbMax = ImVec2(mxx, mxy);

    // --- bones (bind pose world positions)
    {
        std::vector<Mat4> world(nodes.size(), Identity());
        std::vector<int> order;
        // build order via BFS from roots
        std::vector<int> stack;
        for (size_t i = 0; i < nodes.size(); ++i) if (nodes[i].parent < 0) stack.push_back((int)i);
        while (!stack.empty()) {
            int ni = stack.back(); stack.pop_back();
            order.push_back(ni);
            for (int k : nodes[ni].kids) stack.push_back(k);
        }
        for (int ni : order) {
            if (nodes[ni].parent >= 0) world[ni] = Mul(world[nodes[ni].parent], nodes[ni].local);
            else world[ni] = nodes[ni].local;
        }
        out.bindBones.resize(skin.joints.size());
        out.boneNames.resize(skin.joints.size());
        for (size_t i = 0; i < skin.joints.size(); ++i) {
            int ni = skin.joints[i];
            out.bindBones[i] = ImVec2(world[ni].m[12], world[ni].m[13]);
            out.boneNames[i] = nodes[ni].name;
        }
    }

    // bake the mesh node transform into the vertices so bones (world space) match
    {
        std::vector<Mat4> world(nodes.size(), Identity());
        std::vector<int> order;
        std::vector<int> stack;
        for (size_t i = 0; i < nodes.size(); ++i) if (nodes[i].parent < 0) stack.push_back((int)i);
        while (!stack.empty()) {
            int ni = stack.back(); stack.pop_back();
            order.push_back(ni);
            for (int k : nodes[ni].kids) stack.push_back(k);
        }
        for (int ni : order) {
            world[ni] = (nodes[ni].parent >= 0) ? Mul(world[nodes[ni].parent], nodes[ni].local) : nodes[ni].local;
        }
        int meshNode = -1;
        for (size_t i = 0; i < nodes.size(); ++i) if (nodes[i].mesh >= 0) { meshNode = (int)i; break; }
        if (meshNode >= 0) {
            Mat4 M = world[meshNode];
            for (auto& v : out.verts) {
                float x, y, z;
                XformPoint(M, v.px, v.py, v.pz, x, y, z);
                v.px = x; v.py = y; v.pz = z;
                float nx, ny, nz;
                XformDir(M, v.nx, v.ny, v.nz, nx, ny, nz);
                v.nx = nx; v.ny = ny; v.nz = nz;
            }
        }
        float mnx = 1e9f, mny = 1e9f, mnz = 1e9f, mxx = -1e9f, mxy = -1e9f, mxz = -1e9f;
        for (auto& v : out.verts) {
            mnx = rmin(mnx, v.px); mny = rmin(mny, v.py); mnz = rmin(mnz, v.pz);
            mxx = rmax(mxx, v.px); mxy = rmax(mxy, v.py); mxz = rmax(mxz, v.pz);
        }
        out.height = rmax(0.0001f, mxy - mny);
        out.bbMin = ImVec2(mnx, mny);
        out.bbMax = ImVec2(mxx, mxy);
    }

    // the rig often lives in a different scale space than the mesh: normalise it
    if (!out.bindBones.empty()) {
        // align the rig by feet + head instead of the full bbox (props skew it)
        float footY = 1e9f, headY = -1e9f;
        for (size_t i = 0; i < out.bindBones.size(); ++i) {
            footY = rmin(footY, out.bindBones[i].y);
            if (out.boneNames[i].find("Head") != std::string::npos) headY = rmax(headY, out.bindBones[i].y);
        }
        if (headY < footY) headY = footY + 0.0001f;

        // foot centre of the rig
        float jfx = 0.f;
        int jfc = 0;
        for (size_t i = 0; i < out.bindBones.size(); ++i)
            if (out.bindBones[i].y < footY + (headY - footY) * 0.06f) { jfx += out.bindBones[i].x; ++jfc; }
        jfx = jfc ? jfx / jfc : 0.f;

        // foot centre of the mesh
        float vfx = 0.f;
        int vfc = 0;
        float cut = out.bbMin.y + (out.bbMax.y - out.bbMin.y) * 0.05f;
        for (auto& v : out.verts)
            if (v.py < cut) { vfx += v.px; ++vfc; }
        vfx = vfc ? vfx / vfc : (out.bbMin.x + out.bbMax.x) * 0.5f;

        float k = (out.bbMax.y - out.bbMin.y) * 0.99f / rmax(0.0001f, headY - footY);
        for (auto& b : out.bindBones) {
            b.x = (b.x - jfx) * k + vfx;
            b.y = (b.y - footY) * k + out.bbMin.y;
        }
    }

    // bone pairs for the skeleton overlay
    auto findBone = [&](const char* suffix) -> int {
        size_t sl = strlen(suffix);
        for (size_t i = 0; i < out.boneNames.size(); ++i) {
            const std::string& n = out.boneNames[i];
            size_t pos = n.find(suffix);
            if (pos == std::string::npos) continue;
            size_t after = pos + sl;
            if (after == n.size() || n[after] == '_') return (int)i;
        }
        return -1;
    };
    auto link = [&](const char* x, const char* y) {
        int i = findBone(x), j = findBone(y);
        if (i >= 0 && j >= 0) out.bonePairs.push_back({ i, j });
    };
    link("Hips", "Spine");
    link("Spine", "Spine1");
    link("Spine1", "Spine2");
    link("Spine2", "Neck");
    link("Neck", "Head");
    link("Spine2", "LeftShoulder");
    link("Spine2", "RightShoulder");
    link("LeftShoulder", "LeftArm");
    link("LeftArm", "LeftForeArm");
    link("LeftForeArm", "LeftHand");
    link("RightShoulder", "RightArm");
    link("RightArm", "RightForeArm");
    link("RightForeArm", "RightHand");
    link("Hips", "LeftUpLeg");
    link("LeftUpLeg", "LeftLeg");
    link("LeftLeg", "LeftFoot");
    link("Hips", "RightUpLeg");
    link("RightUpLeg", "RightLeg");
    link("RightLeg", "RightFoot");

    out.ok = true;
    return true;
}

// ------------------------------------------------------------------ render
void RenderHero(HeroModel& m, int w, int h, float yaw, float pitch, float zoom,
                float time, uint32_t* fb, std::vector<ImVec2>& jointsOut) {
    jointsOut.clear();
    if (!m.ok) return;

    // plain bind-pose render (no animation playback) - stable and predictable
    const float cy = cosf(yaw), sy = sinf(yaw);
    const float cx = cosf(pitch), sx = sinf(pitch);

    float mnx = 1e9f, mny = 1e9f, mnz = 1e9f, mxx = -1e9f, mxy = -1e9f, mxz = -1e9f;
    for (auto& v : m.verts) {
        float x1 = v.px * cy + v.pz * sy;
        float z1 = -v.px * sy + v.pz * cy;
        float y2 = v.py * cx - z1 * sx;
        float z2 = v.py * sx + z1 * cx;
        mnx = rmin(mnx, x1); mny = rmin(mny, y2); mnz = rmin(mnz, z2);
        mxx = rmax(mxx, x1); mxy = rmax(mxy, y2); mxz = rmax(mxz, z2);
    }
    const float cxm = (mnx + mxx) * 0.5f, cym = (mny + mxy) * 0.5f, czm = (mnz + mxz) * 0.5f;
    const float modelH = rmax(1e-4f, mxy - mny);
    const float modelW = rmax(1e-4f, mxx - mnx);
    float sc = (float)h * 0.86f / modelH;
    sc = rmin(sc, (float)w * 0.94f / modelW);
    const float scale = sc * zoom;
    const float ox = w * 0.5f, oy = h * 0.5f;

    std::vector<float> sxv(m.verts.size()), syv(m.verts.size()), szv(m.verts.size());
    std::vector<float> nxr(m.verts.size()), nyr(m.verts.size());

    for (size_t i = 0; i < m.verts.size(); ++i) {
        const HeroVertex& v = m.verts[i];
        float x1 = v.px * cy + v.pz * sy;
        float z1 = -v.px * sy + v.pz * cy;
        float y2 = v.py * cx - z1 * sx;
        float z2 = v.py * sx + z1 * cx;

        float nx1 = v.nx * cy + v.nz * sy;
        float nz1 = -v.nx * sy + v.nz * cy;
        float ny2 = v.ny * cx - nz1 * sx;
        float nz2 = v.ny * sx + nz1 * cx;

        sxv[i] = ox + (x1 - cxm) * scale;
        syv[i] = oy - (y2 - cym) * scale;
        szv[i] = z2 + 3.f;
        nxr[i] = nx1;
        nyr[i] = ny2;
        (void)nz2;
    }

    std::vector<float> zbuf((size_t)w * h, 1e9f);

    const float Lx = 0.45f, Ly = 0.72f, Lz = -0.52f;

    for (size_t t = 0; t + 2 < m.idx.size(); t += 3) {
        uint32_t i0 = m.idx[t], i1 = m.idx[t + 1], i2 = m.idx[t + 2];
        if (i0 >= m.verts.size() || i1 >= m.verts.size() || i2 >= m.verts.size()) continue;

        float x0 = sxv[i0], y0 = syv[i0], x1 = sxv[i1], y1 = syv[i1], x2 = sxv[i2], y2 = syv[i2];
        // backface cull (screen space, CCW front)
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (area >= -0.01f) continue;

        int minX = (int)rmax(0.f, rmin(x0, rmin(x1, x2)));
        int maxX = (int)rmin((float)w - 1, rmax(x0, rmax(x1, x2)));
        int minY = (int)rmax(0.f, rmin(y0, rmin(y1, y2)));
        int maxY = (int)rmin((float)h - 1, rmax(y0, rmax(y1, y2)));
        if (minX > maxX || minY > maxY) continue;

        const float inv = 1.f / area;
        const HeroVertex& v0 = m.verts[i0];
        const HeroVertex& v1 = m.verts[i1];
        const HeroVertex& v2 = m.verts[i2];
        const float z0 = szv[i0], z1 = szv[i1], z2 = szv[i2];

        for (int py = minY; py <= maxY; ++py) {
            float fy = py + 0.5f;
            for (int px = minX; px <= maxX; ++px) {
                float fx = px + 0.5f;
                float w0 = ((x1 - fx) * (y2 - fy) - (x2 - fx) * (y1 - fy)) * inv;
                float w1 = ((x2 - fx) * (y0 - fy) - (x0 - fx) * (y2 - fy)) * inv;
                float w2 = 1.f - w0 - w1;
                if (w0 < 0 || w1 < 0 || w2 < 0) continue;

                float z = w0 * z0 + w1 * z1 + w2 * z2;
                size_t pi = (size_t)py * w + px;
                if (z >= zbuf[pi]) continue;

                float u = w0 * v0.u + w1 * v1.u + w2 * v2.u;
                float vv = w0 * v0.v + w1 * v1.v + w2 * v2.v;
                int tx = (int)(u * m.texW) % m.texW; if (tx < 0) tx += m.texW;
                int ty = (int)(vv * m.texH) % m.texH; if (ty < 0) ty += m.texH;
                uint32_t tc = m.tex[(size_t)ty * m.texW + tx];
                uint32_t a = tc >> 24;
                if (a < 40) continue;

                float nx = w0 * nxr[i0] + w1 * nxr[i1] + w2 * nxr[i2];
                float ny = w0 * nyr[i0] + w1 * nyr[i1] + w2 * nyr[i2];
                float nz = 0.85f;
                float nl = sqrtf(nx * nx + ny * ny + nz * nz);
                if (nl < 1e-5f) nl = 1.f;
                nx /= nl; ny /= nl; nz /= nl;
                float diff = rmax(0.f, nx * Lx + ny * Ly + nz * Lz);
                float shade = 0.52f + 0.72f * diff;
                float rim = powf(1.f - rmax(0.f, nz), 3.f) * 0.22f;

                int r = (int)((tc & 0xFF) * shade);
                int g = (int)(((tc >> 8) & 0xFF) * shade);
                int b = (int)(((tc >> 16) & 0xFF) * shade);
                r = (int)rmin(255.f, r + rim * 190.f);
                g = (int)rmin(255.f, g + rim * 32.f);
                b = (int)rmin(255.f, b + rim * 46.f);

                zbuf[pi] = z;
                fb[pi] = (uint32_t)r | ((uint32_t)g << 8) | ((uint32_t)b << 16) | (0xFF000000u);
            }
        }
    }

    // joints for the overlay
    jointsOut.resize(m.bindBones.size());
    for (size_t i = 0; i < m.bindBones.size(); ++i) {
        float x = m.bindBones[i].x * cy + m.bindBones[i].y * 0.0f; // only x/y used by bind rig
        float bx = m.bindBones[i].x;
        float by = m.bindBones[i].y;
        (void)x;
        float x1 = bx * cy;
        float z1 = -bx * sy;
        float y2 = by * cx - z1 * sx;
        jointsOut[i] = ImVec2((ox + (x1 - cxm) * scale) / w, (oy - (y2 - cym) * scale) / h);
    }
}

bool DecodeImageRGBA(const void* data, size_t len, int& w, int& h, std::vector<uint32_t>& rgba) {
    return DecodePNG((const uint8_t*)data, len, w, h, rgba);
}

} // namespace rw
