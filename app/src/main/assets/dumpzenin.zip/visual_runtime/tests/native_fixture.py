
# ================================================================================
# Источник: @imguisource_bot | ImGui Source: @ImGui_Source_FIXNEY | shit src 🧨: @il2cpp_src
# ================================================================================

"""Оригинальный ELF в Unicorn; адреса — исходные RVA."""
import hashlib
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM
from unicorn.arm64_const import *
CONFIG={'image':'module_analysis/libmodule.so','sha256':'b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b',
        'page':0x1000,'stack':0x100000000,'input':0x110000000,'output':0x120000000,'stop':0x130000000,'tls':0x140000000}
class Native:
    def __init__(self):
        self.stream=open(CONFIG['image'],'rb')
        assert hashlib.file_digest(self.stream,'sha256').hexdigest()==CONFIG['sha256']
        self.stream.seek(0);elf=ELFFile(self.stream);self.uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
        for s in elf.iter_segments():
            if s['p_type']!='PT_LOAD':continue
            begin=s['p_vaddr']&-CONFIG['page'];end=(s['p_vaddr']+s['p_memsz']+CONFIG['page']-1)&-CONFIG['page']
            self.uc.mem_map(begin,end-begin);self.uc.mem_write(s['p_vaddr'],s.data())
        for name,size in [('stack',0x10000),('input',0x2000),('output',0x40000),('stop',0x1000),('tls',0x1000)]:self.uc.mem_map(CONFIG[name],size)
        self.uc.reg_write(UC_ARM64_REG_TPIDR_EL0,CONFIG['tls'])
    def run(self,entry,args=(),limit=20000000):
        self.uc.reg_write(UC_ARM64_REG_SP,CONFIG['stack']+0xf000);self.uc.reg_write(UC_ARM64_REG_LR,CONFIG['stop'])
        for i,value in enumerate(args):self.uc.reg_write(UC_ARM64_REG_X0+i,value)
        self.uc.emu_start(entry,CONFIG['stop'],count=limit)
        assert self.uc.reg_read(UC_ARM64_REG_PC)==CONFIG['stop']
        return self.uc.reg_read(UC_ARM64_REG_X0)
