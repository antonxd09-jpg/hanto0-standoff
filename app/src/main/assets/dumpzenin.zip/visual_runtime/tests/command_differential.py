#!/usr/bin/env python3

# ================================================================================
# Source code from @imguisource_bot
# Primary: t.me/ImGui_Source_FIXNEY (ImGui Source)
# Secondary: t.me/il2cpp_src (shit src 🧨)
# ================================================================================

"""Побайтовое сравнение очередей с исходным ARM64 на синтетических кешах."""
import ctypes
import hashlib
import json
import random
import struct
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import *

CONFIG = {
    'image': 'module_analysis/libmodule.so',
    'sha256': 'b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b',
    'library': 'visual_runtime/tests/command_bridge.so',
    'report': 'visual_runtime/tests/command_verification.json',
    'page': 0x1000, 'stack': 0x100000000, 'vector': 0x110000000,
    'output': 0x120000000, 'settings': 0x130000000, 'tls': 0x140000000,
    'stop': 0x150000000, 'cache': 0x777e5c0, 'cache_count': 32,
    'cache_stride': 0x890, 'cache_size': 0x11200, 'capacity': 5000,
    'materials': 0x382290, 'colors': 0x382654, 'validator': 0x198128,
    'bounds_failure': 0x125954, 'material_cases': 180, 'color_cases': 120,
    'seed': 813775, 'instruction_limit': 2000000,
}

def main():
    rng = random.Random(CONFIG['seed'])
    image = open(CONFIG['image'], 'rb')
    assert hashlib.file_digest(image, 'sha256').hexdigest() == CONFIG['sha256']
    image.seek(0)
    elf = ELFFile(image)
    uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
    for segment in elf.iter_segments():
        if segment['p_type'] != 'PT_LOAD':
            continue
        begin = segment['p_vaddr'] & -CONFIG['page']
        end = (segment['p_vaddr'] + segment['p_memsz'] + CONFIG['page'] - 1) & -CONFIG['page']
        uc.mem_map(begin, end - begin)
        uc.mem_write(segment['p_vaddr'], segment.data())
    for key, size in [('stack', 0x200000), ('vector', 0x1000), ('output', 0x40000),
                      ('settings', 0x1000), ('tls', 0x1000), ('stop', 0x1000)]:
        uc.mem_map(CONFIG[key], size)
    imports = {int(a, 16): name for a, name in
               (line.split() for line in Path('visual_runtime/test_inputs/imports.tsv').read_text().splitlines())}
    native_status = 0
    def ret(value):
        uc.reg_write(UC_ARM64_REG_X0, value)
        uc.reg_write(UC_ARM64_REG_PC, uc.reg_read(UC_ARM64_REG_LR))
    def hook(uc, address, size, user):
        nonlocal native_status
        if address == CONFIG['stop']:
            uc.emu_stop()
        elif address == CONFIG['validator']:
            pointer = uc.reg_read(UC_ARM64_REG_X0)
            ret(int(pointer != 0 and pointer & 7 != 7))
        elif address == CONFIG['bounds_failure']:
            native_status = 1
            uc.emu_stop()
        elif address in imports:
            name = imports[address]
            if name != 'wmemchr':
                raise AssertionError(f'unexpected import {name}')
            base = uc.reg_read(UC_ARM64_REG_X0)
            wanted = uc.reg_read(UC_ARM64_REG_X1) & 0xffffffff
            count = uc.reg_read(UC_ARM64_REG_X2)
            match = 0
            for index in range(count):
                if struct.unpack('<I', uc.mem_read(base + index * 4, 4))[0] == wanted:
                    match = base + index * 4
                    break
            ret(match)
    uc.hook_add(UC_HOOK_CODE, hook)
    lib = ctypes.CDLL(str(Path(CONFIG['library']).resolve()))
    lib.material_commands.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t)]
    lib.color_commands.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t)]
    for fn in [lib.material_commands, lib.color_commands]:
        fn.restype = ctypes.c_int
    compared = 0
    boundary_failures = 0
    for mode, cases, stride in [('materials', CONFIG['material_cases'], 0x20),
                                ('colors', CONFIG['color_cases'], 0x30)]:
        for case in range(cases):
            bank = bytearray(CONFIG['cache_size'])
            active_count = 32 if case == 0 else rng.randrange(0, 9)
            for index in range(active_count):
                base = index * CONFIG['cache_stride']
                bank[base + 0x888] = rng.choice([1, 2, 255])
                count = 64 if case == 0 else (65 if case in [1, 2] else rng.randrange(0, 10))
                struct.pack_into('<Q', bank, base + 0x600, count)
                for slot in range(min(count, 64)):
                    struct.pack_into('<Qi', bank, base + slot * 0x18 + 8,
                                     rng.choice([0, 7, 0x1000, rng.getrandbits(64)]),
                                     rng.randrange(-5, 20))
                struct.pack_into('<QQ', bank, base + 0x610,
                                 rng.choice([0, 7, 0x2000, 0x2008]),
                                 rng.choice([0, 7, 0x3000, 0x3008]))
                style = [-2147483648, -1, 0, 12, 13, 2147483647][case % 6]
                struct.pack_into('<i', bank, base + 0x640, style)
                struct.pack_into('<i', bank, base + 0x760, (case % 17) - 2)
                struct.pack_into('<i', bank, base + 0x87c, rng.randrange(-3, 7))
                bank[base + 0x72c] = 1 if case in [0, 1, 2] else rng.choice([0, 1, 255])
                bank[base + 0x84c] = 1 if case == 0 else rng.choice([0, 1, 255])
                bank[base + 0x75d] = rng.randrange(256)
                if case in [0, 1, 2]:
                    struct.pack_into('<QQ', bank, base + 0x610, 0x2000, 0x3000)
            settings = bytearray(rng.getrandbits(8) for _ in range(0x24))
            settings[0] = 1 if case in [0, 1, 2] else rng.choice([0, 1, 255])
            settings[1] = rng.choice([0, 1, 255])
            # Произвольные float bits включают NaN: эта функция должна их копировать.
            prefix_count = case % 5
            prefix = bytes(rng.getrandbits(8) for _ in range(prefix_count * stride))
            uc.mem_write(CONFIG['cache'], bytes(bank))
            uc.mem_write(CONFIG['settings'], bytes(settings))
            uc.mem_write(CONFIG['output'], prefix + bytes(CONFIG['capacity'] * stride - len(prefix)))
            uc.mem_write(CONFIG['vector'], struct.pack('<QQQ', CONFIG['output'],
                         CONFIG['output'] + len(prefix), CONFIG['output'] + CONFIG['capacity'] * stride))
            uc.reg_write(UC_ARM64_REG_SP, CONFIG['stack'] + 0x1ff000)
            uc.reg_write(UC_ARM64_REG_TPIDR_EL0, CONFIG['tls'])
            uc.reg_write(UC_ARM64_REG_LR, CONFIG['stop'])
            uc.reg_write(UC_ARM64_REG_X0, CONFIG['vector'])
            uc.reg_write(UC_ARM64_REG_X1, CONFIG['settings'])
            native_status = 0
            uc.emu_start(CONFIG[mode], CONFIG['stop'] + 4, count=CONFIG['instruction_limit'])
            assert native_status or uc.reg_read(UC_ARM64_REG_PC) == CONFIG['stop']
            end = struct.unpack('<Q', uc.mem_read(CONFIG['vector'] + 8, 8))[0]
            native = bytes(uc.mem_read(CONFIG['output'] + len(prefix), end - CONFIG['output'] - len(prefix)))
            output = ctypes.create_string_buffer(CONFIG['capacity'] * stride)
            size = ctypes.c_size_t()
            input_buffer = ctypes.create_string_buffer(bytes(bank))
            setting_buffer = ctypes.create_string_buffer(bytes(settings))
            if mode == 'materials':
                status = lib.material_commands(input_buffer, output, ctypes.byref(size))
            else:
                status = lib.color_commands(input_buffer, setting_buffer, output, ctypes.byref(size))
            cpp = output.raw[:size.value * stride]
            # Три padding-байта native не пишет; сравниваются остальные поля.
            if mode == 'materials':
                native = b''.join(native[i:i+25] + native[i+28:i+32] for i in range(0, len(native), stride))
                cpp = b''.join(cpp[i:i+25] + cpp[i+28:i+32] for i in range(0, len(cpp), stride))
            assert status == native_status, (mode, case, status, native_status)
            assert native == cpp, (mode, case, len(native), len(cpp),
                                   next((i for i, (a,b) in enumerate(zip(native, cpp)) if a != b), None))
            assert bytes(uc.mem_read(CONFIG['output'], len(prefix))) == prefix
            compared += 1
            boundary_failures += status
    report = {'source_sha256': CONFIG['sha256'], 'cases': compared,
              'material_cases': CONFIG['material_cases'], 'color_cases': CONFIG['color_cases'],
              'caught_native_bounds_failures': boundary_failures,
              'comparison': 'all initialized command fields, order, count, existing native prefix, bounds-failure position',
              'validator': 'controlled synthetic predicate on both paths; original Unity validity routine intercepted',
              'native_rvas': [hex(CONFIG['materials']), hex(CONFIG['colors'])],
              'result': 'passed', 'game_runtime_tested': False}
    Path(CONFIG['report']).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)

if __name__ == '__main__':
    main()
