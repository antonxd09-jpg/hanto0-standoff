#!/usr/bin/env python3

# ================================================================================
# Do not re-upload without credits:
# Bot: @imguisource_bot
# ImGui Source: @ImGui_Source_FIXNEY
# shit src 🧨: @il2cpp_src
# ================================================================================

"""Битовые сравнения цветокоррекции и всех пикселей LUT; native не перехватывается."""
import ctypes,json,random,struct
from pathlib import Path
from native_fixture import Native,CONFIG as N
CONFIG={'library':'visual_runtime/tests/post_bridge.so','report':'visual_runtime/tests/post_verification.json',
        'color':0x31fdf4,'lut':0x320118,'color_cases':500,'lut_cases':5,'pixels':32768,'seed':320118}
def main():
    rng=random.Random(CONFIG['seed']);native=Native();uc=native.uc
    lib=ctypes.CDLL(str(Path(CONFIG['library']).resolve()))
    lib.color_transform.argtypes=[ctypes.c_void_p]*3;lib.color_transform.restype=None
    lib.color_lut.argtypes=[ctypes.c_void_p]*2;lib.color_lut.restype=None
    for case in range(CONFIG['color_cases']):
        p=[rng.uniform(.1,2)for _ in range(6)]+[rng.uniform(-.5,.5)]+[rng.uniform(0,2)for _ in range(3)]+[.21763764]
        rgb=[rng.uniform(-.1,2)for _ in range(3)]
        if case<3:rgb=[[0,0,0],[1,1,1],[.5,.5,.5]][case]
        a,b=struct.pack('<11f',*p),struct.pack('<3f',*rgb);uc.mem_write(N['input'],a+b)
        native.run(CONFIG['color'],[N['input'],N['input']+len(a),N['output']])
        output=ctypes.create_string_buffer(12);pa=ctypes.create_string_buffer(a);pb=ctypes.create_string_buffer(b)
        lib.color_transform(pa,pb,output)
        assert bytes(uc.mem_read(N['output'],12))==output.raw,('color',case)
    for case in range(CONFIG['lut_cases']):
        p=[rng.uniform(-100,100),rng.uniform(-100,100),*[rng.random()for _ in range(3)],rng.uniform(-180,180),rng.uniform(-100,100),rng.uniform(-100,100),rng.uniform(-100,100)]
        if case==0:p=[0,0,1,1,1,0,0,0,0]
        a=struct.pack('<9f',*p);uc.mem_write(N['input'],a);native.run(CONFIG['lut'],[N['input'],N['output']])
        output=ctypes.create_string_buffer(CONFIG['pixels']*4);pa=ctypes.create_string_buffer(a);lib.color_lut(pa,output)
        expected=bytes(uc.mem_read(N['output'],CONFIG['pixels']*4));actual=output.raw
        assert expected==actual,('lut',case,next((i for i,(x,y)in enumerate(zip(expected,actual))if x!=y),None))
    native.run(CONFIG['lut'],[N['input'],0])
    report={'source_sha256':N['sha256'],'native_rvas':[hex(CONFIG['color']),hex(CONFIG['lut'])],
            'color_cases':CONFIG['color_cases'],'lut_cases':CONFIG['lut_cases'],'lut_pixels_compared':CONFIG['pixels']*CONFIG['lut_cases'],
            'comparison':'bit-exact RGB32F outputs and all RGBA8 LUT pixels; null-output return',
            'native_calls_intercepted':False,'result':'passed','game_runtime_tested':False}
    Path(CONFIG['report']).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
