#!/usr/bin/env python3

# ================================================================================
# TG Links: bot=t.me/imguisource_bot main=t.me/ImGui_Source_FIXNEY extra=t.me/il2cpp_src
# ================================================================================

"""Сравнение классификации map shader names с исходным ARM64."""
import ctypes,json,random
from pathlib import Path
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import *
from native_fixture import Native,CONFIG as N
CONFIG={'library':'visual_runtime/tests/world_bridge.so','report':'visual_runtime/tests/world_verification.json',
        'entry':0x2be840,'memcmp':0x67f6c0,'seed':2840,'mutations':300}
def main():
    rng=random.Random(CONFIG['seed']);native=Native();uc=native.uc
    def hook(uc,address,size,user):
        n=uc.reg_read(UC_ARM64_REG_X2)
        a=bytes(uc.mem_read(uc.reg_read(UC_ARM64_REG_X0),n));b=bytes(uc.mem_read(uc.reg_read(UC_ARM64_REG_X1),n))
        uc.reg_write(UC_ARM64_REG_X0,((a>b)-(a<b))&0xffffffffffffffff)
        uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
    uc.hook_add(UC_HOOK_CODE,hook,begin=CONFIG['memcmp'],end=CONFIG['memcmp'])
    lib=ctypes.CDLL(str(Path(CONFIG['library']).resolve()));lib.material_classify.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32];lib.material_classify.restype=ctypes.c_uint32
    names=[b'',b'Mobile/Diffuse',b'SO2/Maps/Fog/HalloweenFogDiffuse',b'SO2/Transparent/Diffuse AlphaTest DoubleSided',b'SO2/Maps/VertexWind',b'Legacy Shaders/Transparent/Diffuse',b'SO2/Maps/Fog/HalloweenFogDiffuseTransparent',b'Standard',b'Custom/MobileDiffuseWithLightmap',b'SO2/Maps/Window']
    cases=list(names)
    for i in range(CONFIG['mutations']):
        if i&1:
            name=bytearray(rng.choice(names[1:]));name[rng.randrange(len(name))]=rng.randrange(256);cases.append(bytes(name))
        else:cases.append(bytes(rng.randrange(256)for _ in range(rng.randrange(0,64))))
    count=0
    for name in cases:
        uc.mem_write(N['input'],name+b'\0');buffer=ctypes.create_string_buffer(name)
        for flag in [0,1,2,3,0xffffffff]:
            expected=native.run(CONFIG['entry'],[N['input'],len(name),flag])&0xffffffff
            actual=lib.material_classify(buffer,len(name),flag)
            assert expected==actual,(name,flag,expected,actual)
            count+=1
    report={'source_sha256':N['sha256'],'native_rva':hex(CONFIG['entry']),'cases':count,
        'comparison':'return value for exact names, length/byte mutations, arbitrary bytes and variant-bit combinations',
        'memcmp':'controlled equivalent libc comparator','result':'passed','game_runtime_tested':False}
    Path(CONFIG['report']).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
