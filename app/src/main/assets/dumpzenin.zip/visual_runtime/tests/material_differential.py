#!/usr/bin/env python3

# ================================================================================
# Source Distribution:
#   Bot:     https://t.me/imguisource_bot
#   Primary: https://t.me/ImGui_Source_FIXNEY (ImGui Source)
#   Second:  https://t.me/il2cpp_src (shit src 🧨)
# ================================================================================

"""Сравнение изменений пакета и трассы вызовов Unity с исходным ARM64."""
import ctypes
import hashlib
import json
import random
import struct
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import *

CONFIG = {
    'image': 'module_analysis/libmodule.so',
    'sha256': 'b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b',
    'library': 'visual_runtime/tests/material_bridge.so',
    'report': 'visual_runtime/tests/material_verification.json',
    'entry': 0x3756cc, 'ids': 0x777c5d0, 'guard': 0x777c6a0,
    'get_shader': 0x19cbdc, 'set_shader': 0x19cca8, 'set_queue': 0x19cf1c,
    'set_float': 0x19d360, 'set_vector': 0x19d5a8,
    'page': 0x1000, 'stack': 0x100000000, 'packet': 0x110000000,
    'tls': 0x120000000, 'stop': 0x130000000, 'packet_size': 0xf4,
    'cases': 600, 'seed': 3756, 'event_size': 40, 'event_limit': 40,
    'pack_cases': 600, 'pack_entry': 0x36f44c, 'source_size': 0x11c,
    'source': 0x110000400,
    'instruction_limit': 10000,
}

def main():
    rng = random.Random(CONFIG['seed'])
    image = open(CONFIG['image'], 'rb')
    assert hashlib.file_digest(image, 'sha256').hexdigest() == CONFIG['sha256']
    image.seek(0)
    elf = ELFFile(image)
    uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
    for segment in elf.iter_segments():
        if segment['p_type'] != 'PT_LOAD': continue
        begin = segment['p_vaddr'] & -CONFIG['page']
        end = (segment['p_vaddr'] + segment['p_memsz'] + CONFIG['page'] - 1) & -CONFIG['page']
        uc.mem_map(begin, end - begin)
        uc.mem_write(segment['p_vaddr'], segment.data())
    for name, size in [('stack', 0x10000), ('packet', 0x1000), ('tls', 0x1000), ('stop', 0x1000)]:
        uc.mem_map(CONFIG[name], size)
    uc.mem_write(CONFIG['guard'], b'\x01')
    uc.reg_write(UC_ARM64_REG_TPIDR_EL0, CONFIG['tls'])
    lib = ctypes.CDLL(str(Path(CONFIG['library']).resolve()))
    lib.material_apply.argtypes = [ctypes.c_float, ctypes.c_uint64, ctypes.c_uint64,
        ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p, ctypes.c_uint64, ctypes.c_void_p]
    lib.material_apply.restype = ctypes.c_size_t
    lib.material_pack.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_uint8, ctypes.c_void_p]
    lib.material_pack.restype = None
    events = []
    current = 0
    def ret(value=0):
        uc.reg_write(UC_ARM64_REG_X0, value)
        uc.reg_write(UC_ARM64_REG_PC, uc.reg_read(UC_ARM64_REG_LR))
    def event(kind, prop=0, obj=0, values=(0,0,0,0)):
        events.append(struct.pack('<IIQQ4I', kind, prop & 0xffffffff,
            uc.reg_read(UC_ARM64_REG_X0), obj, *values))
    def hook(uc, address, size, user):
        if address == CONFIG['stop']:
            uc.emu_stop()
        elif address == CONFIG['get_shader']:
            event(0); ret(current)
        elif address == CONFIG['set_shader']:
            event(1, obj=uc.reg_read(UC_ARM64_REG_X1)); ret()
        elif address == CONFIG['set_queue']:
            event(2, uc.reg_read(UC_ARM64_REG_X1)); ret()
        elif address == CONFIG['set_float']:
            event(3, uc.reg_read(UC_ARM64_REG_X1), values=(uc.reg_read(UC_ARM64_REG_S0),0,0,0)); ret()
        elif address == CONFIG['set_vector']:
            event(4, uc.reg_read(UC_ARM64_REG_X1), values=struct.unpack('<4I',
                uc.mem_read(uc.reg_read(UC_ARM64_REG_X2), 16))); ret()
    uc.hook_add(UC_HOOK_CODE, hook)
    styles = [-2147483648, -1, *range(13), 13, 2147483647]
    alphas = [-float('inf'), -1.0, -0.0, 0.0, 0.25, 1.0, 1.5, float('inf'), float('nan')]
    total_events = 0
    for case in range(CONFIG['cases']):
        style = styles[case % len(styles)]
        values = [rng.uniform(-5.0, 8.0) for _ in range(60)]
        packet = struct.pack('<i60f', style, *values)
        alpha = alphas[(case // len(styles)) % len(alphas)]
        material = rng.getrandbits(64)
        shader = rng.getrandbits(64)
        current = shader if case & 1 else rng.getrandbits(64)
        queue = rng.randrange(-100, 4000)
        ids = struct.pack('<47i', *[rng.randrange(-2147483648, 2147483648) for _ in range(47)])
        uc.mem_write(CONFIG['packet'], packet)
        uc.mem_write(CONFIG['ids'], ids)
        uc.reg_write(UC_ARM64_REG_SP, CONFIG['stack'] + 0xf000)
        uc.reg_write(UC_ARM64_REG_LR, CONFIG['stop'])
        uc.reg_write(UC_ARM64_REG_X0, material)
        uc.reg_write(UC_ARM64_REG_X1, shader)
        uc.reg_write(UC_ARM64_REG_X2, CONFIG['packet'])
        uc.reg_write(UC_ARM64_REG_W3, queue & 0xffffffff)
        uc.reg_write(UC_ARM64_REG_S0, struct.unpack('<I', struct.pack('<f', alpha))[0])
        events.clear()
        uc.emu_start(CONFIG['entry'], CONFIG['stop'] + 4, count=CONFIG['instruction_limit'])
        assert uc.reg_read(UC_ARM64_REG_PC) == CONFIG['stop'], (case, hex(uc.reg_read(UC_ARM64_REG_PC)))
        portable_packet = ctypes.create_string_buffer(packet)
        portable_ids = ctypes.create_string_buffer(ids)
        trace = ctypes.create_string_buffer(CONFIG['event_size'] * CONFIG['event_limit'])
        count = lib.material_apply(alpha, material, shader, portable_packet, queue, portable_ids, current, trace)
        native = b''.join(events)
        portable = trace.raw[:count * CONFIG['event_size']]
        assert native == portable, (case, style, alpha, len(events), count,
            next((i for i,(a,b) in enumerate(zip(native, portable)) if a != b), None))
        assert bytes(uc.mem_read(CONFIG['packet'], CONFIG['packet_size'])) == portable_packet.raw[:CONFIG['packet_size']], (case, 'packet')
        total_events += count
    flag_offsets = [0x04,0x34,0x35,0x50,0x70,0x71,0x84,0x9c,0xb8,0xc8,0xd8,0xec,0xf8]
    edges = [-float('inf'), -100.0, -0.0, 0.0, 1.0, 100.0, float('inf'), float('nan')]
    for case in range(CONFIG['pack_cases']):
        style = styles[case % len(styles)]
        source = bytearray(struct.pack('<71f', *[rng.uniform(-2000,2000) for _ in range(71)]))
        for offset in flag_offsets: source[offset] = rng.choice([0,1,255])
        if case < len(edges): struct.pack_into('<f', source, 0x28, edges[case])
        behind = rng.randrange(256)
        uc.mem_write(CONFIG['source'], bytes(source))
        uc.mem_write(CONFIG['packet'], b'\xa5' * CONFIG['packet_size'])
        uc.reg_write(UC_ARM64_REG_SP, CONFIG['stack'] + 0xf000)
        uc.reg_write(UC_ARM64_REG_LR, CONFIG['stop'])
        uc.reg_write(UC_ARM64_REG_X0, CONFIG['source'])
        uc.reg_write(UC_ARM64_REG_W1, style & 0xffffffff)
        uc.reg_write(UC_ARM64_REG_W2, behind)
        uc.reg_write(UC_ARM64_REG_X8, CONFIG['packet'])
        uc.emu_start(CONFIG['pack_entry'], CONFIG['stop'] + 4, count=CONFIG['instruction_limit'])
        assert uc.reg_read(UC_ARM64_REG_PC) == CONFIG['stop']
        portable_source = ctypes.create_string_buffer(bytes(source))
        portable_packet = ctypes.create_string_buffer(CONFIG['packet_size'])
        lib.material_pack(portable_source, style, behind, portable_packet)
        native = bytes(uc.mem_read(CONFIG['packet'], CONFIG['packet_size']))
        portable = portable_packet.raw
        assert native == portable, ('pack', case, style,
            next((hex(i), native[i:i+8].hex(), portable[i:i+8].hex()) for i,(a,b) in enumerate(zip(native,portable)) if a != b))
    report = {'source_sha256': CONFIG['sha256'], 'native_rva': hex(CONFIG['entry']),
        'cases': CONFIG['cases'], 'events_compared': total_events, 'styles': styles,
        'packet_cases': CONFIG['pack_cases'], 'packet_native_rva': hex(CONFIG['pack_entry']),
        'alpha_edges': ['-inf','negative','-0','0','fraction','1','above 1','+inf','NaN'],
        'comparison': 'full 244-byte mutated packet and ordered engine-call trace including scalar/vector bits',
        'engine': 'controlled recording adapters on both paths; no game objects invoked',
        'result': 'passed', 'game_runtime_tested': False}
    Path(CONFIG['report']).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)

if __name__ == '__main__': main()
