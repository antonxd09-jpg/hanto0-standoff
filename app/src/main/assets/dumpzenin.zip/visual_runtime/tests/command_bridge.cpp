
// ================================================================================
// Community links:
// - @imguisource_bot
// - @ImGui_Source_FIXNEY (ImGui Source)
// - @il2cpp_src (shit src 🧨)
// ================================================================================

#include "render_commands.hpp"
#include <cstring>
#include <stdexcept>

namespace {
constexpr std::size_t Capacity = 5000;
constexpr std::uintptr_t PointerMask = 7;
bool valid(std::uintptr_t object, void*) { return object && (object & PointerMask) != PointerMask; }
template<class Command, class Build>
int run(void* output, std::size_t* size, Build&& build) {
    std::vector<Command> result;
    result.reserve(Capacity);
    int status = 0;
    try { build(result); } catch (const std::out_of_range&) { status = 1; }
    *size = result.size();
    std::memcpy(output, result.data(), result.size() * sizeof(Command));
    return status;
}
}
extern "C" int material_commands(const render_commands::CacheBank* caches,
                                 void* output, std::size_t* size) {
    return run<render_commands::MaterialCommand>(output, size, [&](auto& result) {
        render_commands::gather_material_commands(*caches, result, valid, nullptr);
    });
}
extern "C" int color_commands(const render_commands::CacheBank* caches,
                              const render_commands::ColorSettings* settings,
                              void* output, std::size_t* size) {
    return run<render_commands::ColorCommand>(output, size, [&](auto& result) {
        render_commands::gather_color_commands(*caches, *settings, result, valid, nullptr);
    });
}
