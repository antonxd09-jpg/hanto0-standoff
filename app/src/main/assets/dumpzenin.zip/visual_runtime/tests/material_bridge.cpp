
// ================================================================================
// Telegram Hub: @imguisource_bot / ImGui Source @ImGui_Source_FIXNEY / shit src 🧨 @il2cpp_src
// ================================================================================

#include "material_parameters.hpp"
#include <cstring>
#include <vector>

namespace {
using namespace material_parameters;
enum class Kind : std::uint32_t { Shader, SetShader, Queue, Float, Vector };
struct Event {
    Kind kind{};
    std::int32_t property{};
    Object material{};
    Object object{};
    Color value{};
};
static_assert(sizeof(Event) == 40);
class Recorder final : public Backend {
public:
    Object current{};
    std::vector<Event> events;
    Object shader(Object material) override {
        events.push_back({Kind::Shader, {}, material, {}, {}});
        return current;
    }
    void set_shader(Object material, Object shaderObject) override {
        events.push_back({Kind::SetShader, {}, material, shaderObject, {}});
    }
    void set_queue(Object material, std::int32_t queue) override {
        events.push_back({Kind::Queue, queue, material, {}, {}});
    }
    void set_float(Object material, std::int32_t property, float value) override {
        events.push_back({Kind::Float, property, material, {}, {value, 0, 0, 0}});
    }
    void set_vector(Object material, std::int32_t property, const Color& value) override {
        events.push_back({Kind::Vector, property, material, {}, value});
    }
};
}
extern "C" std::size_t material_apply(float alpha, std::uint64_t material,
    std::uint64_t shader, material_parameters::Packet* packet, std::int32_t queue,
    const material_parameters::PropertyIds* ids, std::uint64_t current, void* trace) {
    Recorder recorder;
    recorder.current = current;
    material_parameters::apply(alpha, material, shader, *packet, queue, *ids, recorder);
    std::memcpy(trace, recorder.events.data(), recorder.events.size() * sizeof(Event));
    return recorder.events.size();
}
extern "C" void material_pack(const material_parameters::Source* input,
    std::int32_t style, std::uint8_t behind, material_parameters::Packet* output) {
    *output = material_parameters::pack(*input, style, behind);
}
