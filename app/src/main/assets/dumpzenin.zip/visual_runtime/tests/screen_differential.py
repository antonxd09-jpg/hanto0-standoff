#!/usr/bin/env python3

# ================================================================================
# Скачано через бота @imguisource_bot
# Каналы проекта:
# -> ImGui Source: t.me/ImGui_Source_FIXNEY
# -> shit src 🧨: t.me/il2cpp_src
# ================================================================================

"""Native-сравнение геометрии ESP; NaN payload зависит от архитектуры."""
import ctypes,json,math,random,struct
from pathlib import Path
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import *
from native_fixture import Native,CONFIG as N
CONFIG={'library':'visual_runtime/tests/screen_bridge.so','report':'visual_runtime/tests/screen_verification.json',
        'prepare':0x449f30,'project':0x449bb0,'validate':0x449d10,'simple':0x4455e4,'skeleton':0x44523c,
        'getter':0x2b6574,'preview':0x6cb98c8,'cases':240,'seed':44923}
def main():
    rng=random.Random(CONFIG['seed']);native=Native();uc=native.uc;scale=(1.,1.)
    uc.mem_write(CONFIG['preview'],bytes(16))
    def hook(uc,address,size,user):
        uc.mem_write(uc.reg_read(UC_ARM64_REG_X0),struct.pack('<f',scale[0]))
        uc.mem_write(uc.reg_read(UC_ARM64_REG_X1),struct.pack('<f',scale[1]))
        uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
    uc.hook_add(UC_HOOK_CODE,hook,begin=CONFIG['getter'],end=CONFIG['getter'])
    lib=ctypes.CDLL(str(Path(CONFIG['library']).resolve()))
    lib.screen_prepare.argtypes=[ctypes.c_void_p]*4;lib.screen_prepare.restype=None
    lib.screen_project.argtypes=[ctypes.c_void_p]*4;lib.screen_project.restype=ctypes.c_bool
    lib.screen_validate.argtypes=[ctypes.c_void_p]*3;lib.screen_validate.restype=ctypes.c_bool
    for name in ['screen_simple','screen_skeleton']:
        fn=getattr(lib,name);fn.argtypes=[ctypes.c_float]+[ctypes.c_void_p]*5;fn.restype=ctypes.c_bool
    edges=[float('nan'),float('inf'),float('-inf'),0.,-0.,-1.,1e-44,1.,2.]
    nan_pairs=0;counts={}
    for mode in ['prepare','project','validate','simple','skeleton']:
        counts[mode]=0
        for case in range(CONFIG['cases']):
            m=[rng.uniform(-.2,.2)for _ in range(16)];m[0]=rng.uniform(.5,1.5);m[5]=rng.uniform(.5,1.5)
            m[3]=m[7]=m[11]=m[12]=m[13]=m[14]=0.;m[15]=1.
            p=[rng.uniform(-.5,.5),rng.uniform(-.8,.2),rng.uniform(.1,2)]
            d=[rng.uniform(640,2800),rng.uniform(480,1272)]
            scale=(edges[case]if case<len(edges)else rng.uniform(.1,2),rng.uniform(.1,2))
            if mode=='project'and case<len(edges):p[case%3]=edges[case]
            t=[rng.uniform(-2,2)for _ in range(16)]
            if mode=='prepare'and case<3:t[case*4]=edges[case]
            packed=[struct.pack('<3f',*p),struct.pack('<16f',*m),struct.pack('<16f',*t),struct.pack('<2f',*d),struct.pack('<2f',*scale)]
            pointers=[]
            for index,data in enumerate(packed):
                pointer=N['input']+index*0x100;uc.mem_write(pointer,data);pointers.append(pointer)
            buffers=[ctypes.create_string_buffer(value)for value in packed]
            size=76 if mode=='prepare'else 8 if mode=='project'else 16
            initial=bytes([0xa5])*size;uc.mem_write(N['output'],initial);output=ctypes.create_string_buffer(initial,size)
            if mode=='prepare':
                native.run(CONFIG[mode],[N['output'],pointers[1],pointers[2],pointers[3]])
                lib.screen_prepare(buffers[1],buffers[2],buffers[3],output)
            elif mode=='project':
                expected_return=bool(native.run(CONFIG[mode],[pointers[0],pointers[1],pointers[3],N['output']])&1)
                actual_return=lib.screen_project(buffers[0],buffers[1],buffers[3],output)
            elif mode=='validate':
                rect=struct.pack('<4f',rng.uniform(-100,1000),rng.uniform(-100,500),rng.uniform(-100,3000),rng.uniform(-100,1600))
                address=N['input']+0x500;uc.mem_write(address,rect);item=ctypes.create_string_buffer(rect)
                expected_return=bool(native.run(CONFIG[mode],[address,address+8,pointers[3]])&1)
                actual_return=lib.screen_validate(item,buffers[3],buffers[4])
            else:
                stroke=rng.uniform(0,4)
                if mode=='simple':data=packed[0];item=buffers[0]
                else:
                    bones=[]
                    for index in range(16):bones.extend([p[0]+rng.uniform(-.15,.15),p[1]+rng.uniform(0,1.7),p[2]+rng.uniform(-.05,.05)])
                    if case==0:bones=[0.]*48
                    if case==1:bones[3:]=[0.]*45
                    data=struct.pack('<48f',*bones);item=ctypes.create_string_buffer(data)
                address=N['input']+0x500;uc.mem_write(address,data)
                uc.reg_write(UC_ARM64_REG_S0,struct.unpack('<I',struct.pack('<f',stroke))[0])
                expected_return=bool(native.run(CONFIG[mode],[address,pointers[1],pointers[3],N['output'],N['output']+8])&1)
                actual_return=getattr(lib,'screen_'+mode)(stroke,item,buffers[1],buffers[3],buffers[4],output)
            if mode!='prepare':assert expected_return==actual_return,(mode,case,'return',expected_return,actual_return,scale)
            expected=bytes(uc.mem_read(N['output'],size));actual=output.raw
            for offset in range(0,size,4):
                a,b=expected[offset:offset+4],actual[offset:offset+4]
                if a==b:continue
                af,bf=struct.unpack('<f',a)[0],struct.unpack('<f',b)[0]
                if math.isnan(af)and math.isnan(bf):nan_pairs+=1;continue
                raise AssertionError((mode,case,hex(offset),af,bf,scale))
            counts[mode]+=1
    report={'source_sha256':N['sha256'],'cases':sum(counts.values()),'by_function':counts,
        'comparison':'returns and exact output bits; pairs of NaNs compare by class, not payload/sign',
        'nan_payload_differences':nan_pairs,'ui_scale':'controlled stable getter snapshot on both paths',
        'result':'passed','game_runtime_tested':False}
    Path(CONFIG['report']).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
