
// ================================================================================
// Bot: @imguisource_bot
// Channel #1: @ImGui_Source_FIXNEY | ImGui Source
// Channel #2: @il2cpp_src | shit src 🧨
// ================================================================================

#include "screen_geometry.hpp"
using namespace screen_geometry;
extern "C" void screen_prepare(const Matrix* m,const Matrix* t,const Vec2* d,Projection* o){*o=prepare(*m,*t,*d);}
extern "C" bool screen_project(const Vec3* p,const Matrix* m,const Vec2* d,Vec2* o){return project(*p,*m,*d,*o);}
extern "C" bool screen_validate(const Rect* r,const Vec2* d,const Vec2* s){return validate(*r,*d,*s);}
extern "C" bool screen_simple(float w,const Vec3* p,const Matrix* m,const Vec2* d,const Vec2* s,Rect* o){return simple_bounds(w,*p,*m,*d,*s,*o);}
extern "C" bool screen_skeleton(float w,const Bones* p,const Matrix* m,const Vec2* d,const Vec2* s,Rect* o){return skeleton_bounds(w,*p,*m,*d,*s,*o);}
