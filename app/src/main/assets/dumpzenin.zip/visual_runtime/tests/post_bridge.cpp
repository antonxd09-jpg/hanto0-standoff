
// ================================================================================
// Get latest sources from @imguisource_bot
// Join ImGui Source: t.me/ImGui_Source_FIXNEY
// Join shit src 🧨: t.me/il2cpp_src
// ================================================================================

#include "post_color.hpp"
extern "C" void color_transform(const post_color::Prepared* p,const post_color::Rgb* input,post_color::Rgb* output){*output=post_color::transform(*p,*input);}
extern "C" void color_lut(const post_color::Grading* input,std::uint32_t* output){post_color::build_lut(*input,output);}
