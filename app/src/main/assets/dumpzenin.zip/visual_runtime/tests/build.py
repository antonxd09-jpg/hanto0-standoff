#!/usr/bin/env python3

# ================================================================================
# [METADATA]
# BOT=https://t.me/imguisource_bot
# MAIN_CHANNEL=https://t.me/ImGui_Source_FIXNEY
# EXTRA_CHANNEL=https://t.me/il2cpp_src
# ================================================================================

"""Host-сборка и необязательные сравнения с исходным ARM64."""
import argparse,subprocess,sys
from pathlib import Path
CONFIG={'root':Path('visual_runtime'),'compiler':'g++','standard':'-std=c++17','flags':['-Wall','-Wextra','-Werror','-O2','-ffp-contract=off']}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--native',action='store_true');args=p.parse_args()
    root=CONFIG['root'];base=[CONFIG['compiler'],CONFIG['standard'],*CONFIG['flags'],'-fPIC','-shared','-I'+str(root/'include')]
    targets={
        'command_bridge.so':['src/render_commands.cpp','tests/command_bridge.cpp'],
        'material_bridge.so':['src/material_parameters.cpp','src/material_packet.cpp','tests/material_bridge.cpp'],
        'post_bridge.so':['src/post_color.cpp','tests/post_bridge.cpp'],
        'screen_bridge.so':['src/screen_geometry.cpp','tests/screen_bridge.cpp'],
        'world_bridge.so':['src/world_materials.cpp','tests/world_bridge.cpp']}
    for name,files in targets.items():subprocess.run(base+[str(root/f)for f in files]+['-o',str(root/'tests'/name)],check=True)
    t=root/'components/trajectory_mesh'
    subprocess.run(base+['-I'+str(t),str(t/'trajectory_mesh.cpp'),str(t/'test_bridge.cpp'),'-o',str(root/'tests/trajectory_bridge.so')],check=True)
    r=root/'components/renderer_swap';binary=root/'tests/renderer_swap_test'
    subprocess.run([CONFIG['compiler'],CONFIG['standard'],*CONFIG['flags'],'-pthread','-I'+str(r),str(r/'renderer_swap.cpp'),str(r/'tests/renderer_swap_test.cpp'),'-ldl','-o',str(binary)],check=True)
    subprocess.run([str(binary.resolve())],check=True)
    if args.native:
        for name in ['command_differential.py','material_differential.py','post_differential.py','screen_differential.py','world_differential.py']:
            subprocess.run([sys.executable,str(root/'tests'/name)],check=True)
        subprocess.run([sys.executable,str(t/'differential.py')],check=True)
if __name__=='__main__':main()
