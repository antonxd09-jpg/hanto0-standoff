
// ================================================================================
// Telegram bot: t.me/imguisource_bot
// Telegram channel (ImGui Source): t.me/ImGui_Source_FIXNEY
// Telegram channel (shit src 🧨): t.me/il2cpp_src
// ================================================================================

#include "world_materials.hpp"
extern "C" std::uint32_t material_classify(const char* data,std::size_t size,std::uint32_t flags){return static_cast<std::uint32_t>(world_materials::classify({data,size},flags));}
