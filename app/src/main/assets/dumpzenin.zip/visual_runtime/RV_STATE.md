# Состояние полного визуального переноса

## Текущее продолжение

В общий проект добавлены post_color (0x31fdf4,0x320118), screen_geometry
(0x449f30,0x449bb0,0x449d10,0x4455e4,0x44523c), world_materials (0x2be840).
Перенесены исходники trajectory_mesh и renderer_swap из сохранённых архивов.
Единый include/link check g++ успешен. CMake 3.28.1 configure/build Release прошли. Android/игра не запускались.
Текущие результаты — tests/*_verification.json и coverage.json.

LUT использует FCVTAS (0x320318..320320), не trunc из псевдокода.
Simple bounds ограничивает stroke снизу единицей через FMAXNM (0x4456ec).
Порядок сложений правой и нижней границ сохранён. Finite outputs геометрии
совпали побитово; две пары NaN сравниваются по классу, не по payload/sign.
UI scale getter 0x2b6574 в тестах заменён стабильным снимком.

Основной ESP: 0x43f24c, void(void), 180 настроек, global 0x6cb0040 size 0x384.
Его 3918 строк диагностического вывода и schema скопированы в analysis/checkpoint.
Это ещё не порт основной отрисовки. Внимание: 0x44ceb8 — glyph/atlas оружейной
иконки, не box draw; 0x44c4b4 — прямоугольный stroke с цветовыми аргументами.

При сбросе рабочей папки исходный ELF восстанавливается из сохранённого APK
libfile_d3ed630a0234819189ad9f39be8046f1, fix tg @crack_komarq.apk.
SHA256 ELF b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b.
visual_extract.zip версия 3 сохранён как libfile_eb80e107df78819193732400bd5e045e.

## Предыдущая стадия

Запрос остаётся полным: chams, ESP, гранаты, мир, post FX, обработка карт и
связанные функции. Общий модуль не завершён. Не выдавать этот пакет за весь визуал.

Новые завершённые переносы: `pack` (0x36f44c), `apply` (0x3756cc),
`gather_material_commands` (0x382290), `gather_color_commands` (0x382654).
Host C++17 сборка успешна. 1500 дифференциальных проверок успешны:
600 packet, 600 apply, 180 material queue, 120 color queue; 7165 engine events.
Сравнение выполнялось с контролируемой проверкой объектов/движковыми адаптерами,
а не внутри игры. Native assertions заменены исключением out_of_range.

Свойства материалов: 47 строк подтверждены вызовами original 0x3752a8 и
байтами rodata; runtime property IDs не выдумываются, передаются снаружи.
Пакет builder возвращается native по hidden X8; source X0, style W1,
behindWalls W2. Apply: alpha S0, material X0, shader X1, packet X2, queue W3.
0x19d360: material X0, property W1, scalar S0. 0x19d5a8: vector pointer X2.
Сигнатуры и поведение подтверждены дифференциальной трассой.

Новые диагностические decompile: 17 корневых функций material_roots.txt.
Ghidra trace может включать соседние функции после неразмеченных noreturn
throw-thunks. Например 0x377560 и 0x378a90 — 0x14-byte throw thunks,
а не показанный вслед за ними большой unordered_map. Не переносить расширенный
диагностический вывод механически. ABI читать по ARM64.

Ранее сохранённый visual_extract.zip версия 3:
libfile_eb80e107df78819193732400bd5e045e. Там полный диагностический ESP
0x43f24c и 85 других decompile; 180 ESP settings, 201 per-map settings.
Схема карты stride 0x4b4. Самостоятельные реализации ESP/chams runtime/world/
post FX/map runtime ещё не готовы. Траектории: отдельный trajectory_mesh.zip
с 350 native differential cases, не вся система гранат.

Остаются: создание/восстановление материалов и renderer caches; исходные shaders
и asset lifecycle; интеграция command queues с Unity; перевод основного ESP и
его draw helpers; цельные гранаты, world, post FX, map processing; Android проверка.
