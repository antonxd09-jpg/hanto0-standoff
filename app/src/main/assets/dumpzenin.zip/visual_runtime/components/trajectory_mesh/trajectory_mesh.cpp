
// ================================================================================
// Get latest sources from @imguisource_bot
// Join ImGui Source: t.me/ImGui_Source_FIXNEY
// Join shit src 🧨: t.me/il2cpp_src
// ================================================================================

#include "trajectory_mesh.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>

namespace trajectory_mesh {
namespace {

static_assert(sizeof(Vec3) == 0xc && sizeof(Vec4) == 0x10);
static_assert(sizeof(Track) == 0x1090);
static_assert(offsetof(Track, points) == 8);
static_assert(offsetof(Track, times) == 0x968);
static_assert(offsetof(Track, marks) == 0xfa8);
static_assert(offsetof(Track, count) == 0x1070);
static_assert(offsetof(Track, lifetime_time) == 0x1078);
static_assert(offsetof(Track, expiry_time) == 0x1080);
static_assert(offsetof(Track, opacity) == 0x1088);
static_assert(offsetof(Buffer, starts) == 0x13e00);
static_assert(offsetof(Buffer, end_and_kind) == 0x27c00);
static_assert(offsetof(Buffer, corners) == 0x42400);
static_assert(offsetof(Buffer, payload) == 0x5cc00);
static_assert(offsetof(Buffer, indices) == 0xfbc00);
static_assert(offsetof(Buffer, count) == 0x100b80);
static_assert(sizeof(Buffer) == 0x100b84);

float distance(const Vec3& a, const Vec3& b) noexcept {
    const float x = a.x - b.x, y = a.y - b.y, z = a.z - b.z;
    return std::sqrt(std::fma(z, z, std::fma(x, x, y * y)));
}

Vec4 blend(const Vec4& first, const Vec4& last, float t) noexcept {
    return {std::fma(last.x - first.x, t, first.x),
            std::fma(last.y - first.y, t, first.y),
            std::fma(last.z - first.z, t, first.z),
            std::fma(last.w - first.w, t, first.w)};
}

Vec4 point(const Vec3& value) noexcept { return {value.x, value.y, value.z, 1.0f}; }

bool accepted(const Vec3& value, double time) noexcept {
    return std::isfinite(value.x) && std::isfinite(value.y) && std::isfinite(value.z) && std::isfinite(time);
}

} // namespace

void reset(Buffer& output) noexcept { output.count = 0; }

std::size_t vertex_count(const Buffer& output) noexcept {
    return output.count < 0 ? 0 : std::min(static_cast<std::size_t>(output.count), Config::quad_capacity) * Config::vertices_per_quad;
}

std::size_t index_count(const Buffer& output) noexcept {
    return output.count < 0 ? 0 : std::min(static_cast<std::size_t>(output.count), Config::quad_capacity) * Config::indices_per_quad;
}

bool append(Buffer& output, float kind, const Vec3& start, const Vec3& end,
            const std::array<Vec4, Config::payload_count>& attributes) noexcept {
    if (output.count < 0 || static_cast<std::size_t>(output.count) >= Config::quad_capacity) return false;
    const auto quad = static_cast<std::size_t>(output.count);
    const auto first = quad * Config::vertices_per_quad;
    for (std::size_t i = 0; i < Config::vertices_per_quad; ++i) {
        const auto index = first + i;
        const auto& source = i < Config::vertices_per_quad / 2 ? start : end;
        const float padding = Config::sides[i] + Config::sides[i];
        output.positions[index] = {source.x + padding, source.y + padding, source.z + padding};
        output.starts[index] = start;
        output.end_and_kind[index] = {end.x, end.y, end.z, kind};
        output.corners[index] = {Config::sides[i], Config::ends[i], 0, 0};
        for (std::size_t stream = 0; stream < Config::payload_count; ++stream)
            std::memcpy(&output.payload[stream][index], &attributes[stream], sizeof(Vec4));
    }
    const auto base = static_cast<std::uint16_t>(first);
    const auto at = quad * Config::indices_per_quad;
    output.indices[at] = base;
    output.indices[at + 1] = base | 1;
    output.indices[at + 2] = base | 2;
    output.indices[at + 3] = base;
    output.indices[at + 4] = base | 2;
    output.indices[at + 5] = base | 3;
    ++output.count;
    return true;
}

void build(Buffer& output, const std::array<Track, Config::track_capacity>& tracks,
           std::size_t track_count, double now, const Palette& palette) noexcept {
    reset(output);
    track_count = std::min(track_count, Config::track_capacity);
    for (std::size_t track_index = 0; track_index < track_count; ++track_index) {
        const auto& track = tracks[track_index];
        std::array<std::size_t, Config::point_capacity> kept{};
        std::array<bool, Config::point_capacity> marked{};
        std::array<float, Config::point_capacity> distances{};
        std::size_t used{};
        const auto limit = std::min(track.count, static_cast<std::uint64_t>(Config::point_capacity));
        for (std::size_t i = 0; i < limit; ++i) {
            if (!accepted(track.points[i], track.times[i])) continue;
            if (used && distance(track.points[i], track.points[kept[used - 1]]) < Config::duplicate_distance) {
                marked[used - 1] = marked[used - 1] || track.marks[i] != 0;
                continue;
            }
            kept[used] = i;
            marked[used] = track.marks[i] != 0;
            ++used;
        }
        if (!used) continue;
        for (std::size_t i = 1; i < used; ++i)
            distances[i] = distances[i - 1] + distance(track.points[kept[i]], track.points[kept[i - 1]]);
        const float length = distances[used - 1];
        const float denominator = length >= Config::minimum_length ? length : Config::minimum_length;
        const float expiry = track.expiry_time <= Config::expiry_cutoff
            ? static_cast<float>(track.expiry_time - now) : Config::no_expiry;
        const float opacity = std::isfinite(track.opacity) ? track.opacity : 1.0f;
        const Vec4 lifetime{static_cast<float>(track.lifetime_time - now), expiry, opacity, 0};
        for (std::size_t i = 0; i + 1 < used; ++i) {
            const Vec4 previous = i ? point(track.points[kept[i - 1]]) : Vec4{};
            const Vec4 next = i + 2 < used ? point(track.points[kept[i + 2]]) : Vec4{};
            const Vec4 timing{static_cast<float>(track.times[kept[i]] - now),
                              static_cast<float>(track.times[kept[i + 1]] - now), distances[i], distances[i + 1]};
            const std::array<Vec4, Config::payload_count> attributes{{previous, next, timing, lifetime,
                blend(palette.start, palette.end, distances[i] / denominator),
                blend(palette.start, palette.end, distances[i + 1] / denominator)}};
            if (!append(output, static_cast<float>(Kind::segment), track.points[kept[i]], track.points[kept[i + 1]], attributes)) return;
        }
        for (std::size_t i = 1; i + 1 < used; ++i) {
            if (!marked[i]) continue;
            const float time = static_cast<float>(track.times[kept[i]] - now);
            const Vec4 timing{time, time, distances[i], distances[i]};
            const std::array<Vec4, Config::payload_count> attributes{{{}, {}, timing, lifetime, palette.marker, palette.marker}};
            if (!append(output, static_cast<float>(Kind::mark), track.points[kept[i]], track.points[kept[i]], attributes)) return;
        }
        const auto last = used - 1;
        const float time = static_cast<float>(track.times[kept[last]] - now);
        const Vec4 timing{time, time, length, length};
        const std::array<Vec4, Config::payload_count> attributes{{{}, {}, timing, lifetime, palette.marker, palette.marker}};
        if (!append(output, static_cast<float>(Kind::endpoint), track.points[kept[last]], track.points[kept[last]], attributes)) return;
    }
}

} // namespace trajectory_mesh
