# Native visual functions state

Готовы trajectory_mesh.hpp/.cpp: полные функции append (RVA 0x343a24) и build (RVA 0x343464), построение меша траекторий. Никаких runtime вызовов в исходную библиотеку. Host сборка и 350 побайтовых сравнений с настоящим ARM64 прошли. В игре не запускалось. Не называть эту пару всем визуалом или готовым ESP.

Исправления по фактическому сравнению: порог expiry — double 1e20 (RVA 0x683730); градиент — fused FMLA; нечисловые координаты/времена отбрасываются; NaN/Inf opacity заменяется на 1.0. Константы corners: RVA 0x683060 = {-1,1,1,-1}, RVA 0x680a00 = {0,0,1,1}. Native layout проверен static_assert.

Настоящий ESP подтверждён через схему: fn_43f0b8 возвращает native RVA 0x6cb0040, размер настроек 0x384/0x388 в snapshot. 0x15edac складывает этот указатель в первый слот регистрации, 0x15d3d8 связывает его с началом snapshot. Main ESP: RVA 0x43f24c..0x44523c; читает поля enabled/box/name/armor/health/weapon/flags по тем же смещениям, что были сняты из сериализатора. Полные ссылки на чтения в visual_extract/analysis/esp_global_refs.json. Это точная локализация, не прежние кандидаты.

В Ghidra read-only проходе (последний успешный session 73137) 35 helpers ESP декомпилировались, 0x43f24c получил timeout. Они лежат в visual_extract/draw_pseudocode. Не передавать их как компилируемые CPP. Helpers 0x449f30/0x44a264/0x44a610/0x44a6e4 относятся к draw пути; дальше читать их точные ABI и переносить следующий модуль. Граф из core checkpoint содержит только BL: для полного восстановления учитывать tail B и ADR, не только ADRP/ADD.

Последний visual_extract.zip сохранён как libfile_eb80e107df78819193732400bd5e045e v1; в нём ресурсы и прежний анализ, а новые draw helpers текущей работы ещё нужно сохранить отдельным checkpoint. Две прежние ложные ветки: 0x343d68 = GrenadeTrajectoryBatch, 0x2ab5b4/0x2abf48 = журнал missed/mismatched, не ESP полосы.

Незавершено: весь ESP renderer, chams/glow/world/post FX, retarget/moving parts и прочая интеграция. Не выдавать .bin/.asm/GLSL/JSON за запрошенный набор CPP-функций.
