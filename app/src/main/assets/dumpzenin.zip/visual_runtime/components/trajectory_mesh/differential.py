#!/usr/bin/env python3

# ================================================================================
# Эксклюзив от @imguisource_bot
# Канал: @ImGui_Source_FIXNEY (ImGui Source)
# Резерв: @il2cpp_src (shit src 🧨)
# ================================================================================

"""Сравнение C++ с исходными ARM64-функциями на синтетических данных."""
import ctypes,hashlib,json,random,struct
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *

CONFIG={'image':'module_analysis/libmodule.so','sha256':'b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b',
 'library':'visual_runtime/tests/trajectory_bridge.so','output_size':0x100b84,'track_size':0x1090,'track_capacity':8,
 'append':0x343a24,'build':0x343464,'stack':0x100000000,'input':0x110000000,
 'output':0x120000000,'tls':0x130000000,'stop':0x140000000,'page':0x1000,
 'seed':90431,'append_cases':260,'build_cases':90}

def main():
    rng=random.Random(CONFIG['seed']);f=open(CONFIG['image'],'rb')
    assert hashlib.file_digest(f,'sha256').hexdigest()==CONFIG['sha256'];f.seek(0)
    elf=ELFFile(f);uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
    for s in elf.iter_segments():
        if s['p_type']!='PT_LOAD':continue
        start=s['p_vaddr']&-CONFIG['page'];end=(s['p_vaddr']+s['p_memsz']+CONFIG['page']-1)&-CONFIG['page']
        uc.mem_map(start,end-start);uc.mem_write(s['p_vaddr'],s.data())
    for key,size in [('stack',0x200000),('input',0x100000),('output',0x200000),('tls',0x1000),('stop',0x1000)]:uc.mem_map(CONFIG[key],size)
    uc.reg_write(UC_ARM64_REG_TPIDR_EL0,CONFIG['tls'])
    imports={int(a,16):name for a,name in(line.split()for line in Path('visual_runtime/test_inputs/imports.tsv').read_text().splitlines())}
    def hook(uc,address,size,user):
        if address==CONFIG['stop']:uc.emu_stop();return
        if address not in imports:return
        name=imports[address]
        if name=='memset':
            destination=uc.reg_read(UC_ARM64_REG_X0);value=uc.reg_read(UC_ARM64_REG_X1)&255;count=uc.reg_read(UC_ARM64_REG_X2)
            uc.mem_write(destination,bytes([value])*count);uc.reg_write(UC_ARM64_REG_X0,destination);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR));return
        raise RuntimeError(f'unexpected native import {name} at {address:#x}')
    uc.hook_add(UC_HOOK_CODE,hook)
    lib=ctypes.CDLL(str(Path(CONFIG['library']).resolve()));lib.test_append.argtypes=[ctypes.c_void_p,ctypes.c_float,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p];lib.test_append.restype=ctypes.c_bool
    lib.test_build.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_double,ctypes.c_void_p];lib.test_build.restype=None
    size=CONFIG['output_size'];initial=bytes([0xa5])*size;cpp=ctypes.create_string_buffer(size)
    def fp(value):return struct.unpack('<I',struct.pack('<f',value))[0]
    def dp(value):return struct.unpack('<Q',struct.pack('<d',value))[0]
    def call(entry,args,scalar,double=False):
        stack=CONFIG['stack']+0x1ff000;uc.reg_write(UC_ARM64_REG_SP,stack);uc.reg_write(UC_ARM64_REG_LR,CONFIG['stop'])
        uc.reg_write(UC_ARM64_REG_D0 if double else UC_ARM64_REG_S0,dp(scalar)if double else fp(scalar))
        for i,value in enumerate(args[:8]):uc.reg_write(UC_ARM64_REG_X0+i,value)
        for i,value in enumerate(args[8:]):uc.mem_write(stack+i*8,struct.pack('<Q',value))
        uc.emu_start(entry,CONFIG['stop']+4,count=4000000)
        assert uc.reg_read(UC_ARM64_REG_PC)==CONFIG['stop']
        return uc.reg_read(UC_ARM64_REG_X0)&1
    def compare(label):
        native=bytes(uc.mem_read(CONFIG['output'],size));portable=cpp.raw
        if native!=portable:
            offset=next(i for i,(a,b)in enumerate(zip(native,portable))if a!=b)
            raise AssertionError(f'{label}: byte {offset:#x}, native={native[offset:offset+16].hex()}, cpp={portable[offset:offset+16].hex()}, counts={struct.unpack_from("<i",native,0x100b80)[0]}/{struct.unpack_from("<i",portable,0x100b80)[0]}')
    for case in range(CONFIG['append_cases']):
        q=[0,1,1695,1696,1697][case]if case<5 else rng.randrange(1698)
        base=bytearray(initial);struct.pack_into('<i',base,0x100b80,q);uc.mem_write(CONFIG['output'],bytes(base));ctypes.memmove(cpp,bytes(base),size)
        points=struct.pack('<6f',*[rng.uniform(-100,100)for _ in range(6)])
        attributes=struct.pack('<24f',*[rng.uniform(-5,5)for _ in range(24)])
        uc.mem_write(CONFIG['input'],points+attributes);a=CONFIG['input'];tag=float(case%3)
        native=call(CONFIG['append'],[CONFIG['output'],a,a+12,*[a+24+i*16 for i in range(6)]],tag)
        values=ctypes.create_string_buffer(points+attributes)
        result=lib.test_append(cpp,tag,ctypes.addressof(values),ctypes.addressof(values)+12,ctypes.addressof(values)+24)
        assert bool(native)==result;compare(f'append {case}')
    for case in range(CONFIG['build_cases']):
        tracks=bytearray(CONFIG['track_size']*8)
        count=[0,1,8,99][case]if case<4 else rng.randrange(1,10)
        now=rng.uniform(-20,20)
        for track in range(8):
            offset=track*CONFIG['track_size'];points_count=200 if case==3 else rng.randrange(0,30)
            struct.pack_into('<Qddf',tracks,offset+0x1070,points_count,now+rng.random()*5,now+rng.random()*6,rng.uniform(-1,3))
            previous=[0.,0.,0.]
            for index in range(points_count):
                position=previous if index and rng.random()<0.18 else [rng.uniform(-30,30)for _ in range(3)]
                struct.pack_into('<3f',tracks,offset+8+index*12,*position);previous=position
                struct.pack_into('<d',tracks,offset+0x968+index*8,now+index*0.02)
                tracks[offset+0xfa8+index]=1 if case==3 or rng.random()<0.2 else 0
        if case in [4,5,6,7]:struct.pack_into('<f',tracks,8,[float('inf'),float('-inf'),float('nan'),-0.0][case-4])
        if case in [8,9]:struct.pack_into('<d',tracks,0x968,float('inf')if case==8 else float('nan'))
        if case in [10,11,12]:struct.pack_into('<f',tracks,0x1088,[float('inf'),float('-inf'),float('nan')][case-10])
        if case in [13,14]:struct.pack_into('<d',tracks,0x1080,[1e20,1e21][case-13])
        palette=struct.pack('<12f',*[rng.uniform(0,1)for _ in range(12)])
        uc.mem_write(CONFIG['input'],bytes(tracks));palette_address=CONFIG['input']+0x10000;uc.mem_write(palette_address,palette)
        uc.mem_write(CONFIG['output'],initial);ctypes.memmove(cpp,initial,size)
        call(CONFIG['build'],[CONFIG['input'],count,palette_address,CONFIG['output']],now,True)
        track_buffer=ctypes.create_string_buffer(bytes(tracks));palette_buffer=ctypes.create_string_buffer(palette)
        lib.test_build(cpp,track_buffer,count,now,palette_buffer);compare(f'build {case}')
    result={'source_sha256':CONFIG['sha256'],'native_append_rva':hex(CONFIG['append']),'native_build_rva':hex(CONFIG['build']),'append_cases':CONFIG['append_cases'],'build_cases':CONFIG['build_cases'],'comparison':'all output bytes and append return value','buffer_bytes':size,'result':'passed','game_runtime_tested':False}
    Path('visual_runtime/tests/trajectory_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
