
// ================================================================================
// Uploaded to @imguisource_bot
// Sub: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Sub: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

#pragma once
#include <array>
#include <cstddef>
#include <cstdint>

namespace trajectory_mesh {

struct Config {
    static constexpr std::size_t track_capacity = 8;
    static constexpr std::size_t point_capacity = 200;
    static constexpr std::size_t quad_capacity = 0x6a0;
    static constexpr std::size_t vertices_per_quad = 4;
    static constexpr std::size_t indices_per_quad = 6;
    static constexpr std::size_t payload_count = 6;
    static constexpr std::size_t vertex_capacity = quad_capacity * vertices_per_quad;
    static constexpr std::size_t index_capacity = quad_capacity * indices_per_quad;
    static constexpr float duplicate_distance = 0.002f;
    static constexpr float minimum_length = 0.0001f;
    static constexpr float no_expiry = 1e20f;
    static constexpr float bounds_padding = 2.0f;
    static constexpr double expiry_cutoff = 1e20;
    static constexpr std::array<float, vertices_per_quad> sides{{-1, 1, 1, -1}};
    static constexpr std::array<float, vertices_per_quad> ends{{0, 0, 1, 1}};
};

struct Vec3 { float x{}, y{}, z{}; };
struct Vec4 { float x{}, y{}, z{}, w{}; };

// Карта 0x1090 байт проверена по чтениям ARM64-функции.
struct Track {
    std::uint64_t opaque{};
    std::array<Vec3, Config::point_capacity> points{};
    std::array<double, Config::point_capacity> times{};
    std::array<std::uint8_t, Config::point_capacity> marks{};
    std::uint64_t count{};
    double lifetime_time{};
    double expiry_time{};
    float opacity{};
    std::uint32_t padding{};
};

struct Palette { Vec4 start{}, end{}, marker{}; };

// Потоки соответствуют VertexAttribute Position, Normal, Tangent,
// TexCoord0 и TexCoord1..6 исходного шейдера. Normal/Tangent несут данные,
// а не освещение поверхности.
struct Buffer {
    std::array<Vec3, Config::vertex_capacity> positions;
    std::array<Vec3, Config::vertex_capacity> starts;
    std::array<Vec4, Config::vertex_capacity> end_and_kind;
    std::array<Vec4, Config::vertex_capacity> corners;
    std::array<std::array<Vec4, Config::vertex_capacity>, Config::payload_count> payload;
    std::array<std::uint16_t, Config::index_capacity> indices;
    std::int32_t count{};
};

enum class Kind : std::uint8_t { segment, mark, endpoint };

void reset(Buffer& output) noexcept;
std::size_t vertex_count(const Buffer& output) noexcept;
std::size_t index_count(const Buffer& output) noexcept;

// Полная функция добавления quad; возвращает false при заполнении буфера.
bool append(Buffer& output, float kind, const Vec3& start, const Vec3& end,
            const std::array<Vec4, Config::payload_count>& payload) noexcept;

// Полный проход по траекториям: фильтрация, слияние близких точек,
// длина пути, градиенты, времена, внутренние маркеры и конечная точка.
void build(Buffer& output,
           const std::array<Track, Config::track_capacity>& tracks,
           std::size_t count, double now, const Palette& palette) noexcept;

} // namespace trajectory_mesh
