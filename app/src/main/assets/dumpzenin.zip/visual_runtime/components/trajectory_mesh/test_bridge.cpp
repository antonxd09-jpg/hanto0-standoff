
// ================================================================================
// Find more on @imguisource_bot | @ImGui_Source_FIXNEY | @il2cpp_src
// ================================================================================

#include "trajectory_mesh.hpp"
using namespace trajectory_mesh;
extern "C" bool test_append(Buffer* output, float kind, const Vec3* start, const Vec3* end,
                            const std::array<Vec4, Config::payload_count>* attributes) {
    return append(*output, kind, *start, *end, *attributes);
}
extern "C" void test_build(Buffer* output,
    const std::array<Track, Config::track_capacity>* tracks,
    std::size_t count, double now, const Palette* palette) {
    build(*output, *tracks, count, now, *palette);
}
