#!/usr/bin/env python3

# ================================================================================
# Эксклюзив от @imguisource_bot
# Канал: @ImGui_Source_FIXNEY (ImGui Source)
# Резерв: @il2cpp_src (shit src 🧨)
# ================================================================================

"""Восстановить resolver из дампа методов и соответствующего ELF64."""
import argparse
import hashlib
import json
import struct
from pathlib import Path

CONFIG = {
    "elf_sha256": "ba0966976204fa3f7a2755c9588d32299fe7eb794b712c9f1a444e046cbe7c13",
    "prefix_size": 16,
    "header_format": "<16sHHIQQQIHHHHHH",
    "program_format": "<IIQQQQQQ",
    "load_segment": 1,
    "executable": 1,
    "methods": {
        "alive": "UnityEngine.Object$$op_Implicit",
        "retain": "System.Runtime.InteropServices.GCHandle$$Alloc",
        "target": "System.Runtime.InteropServices.GCHandle$$GetTarget",
        "release": "System.Runtime.InteropServices.GCHandle$$FreeHandle",
        "skinned_mesh": "UnityEngine.SkinnedMeshRenderer$$get_sharedMesh",
        "set_skinned_mesh": "UnityEngine.SkinnedMeshRenderer$$set_sharedMesh",
        "offscreen": "UnityEngine.SkinnedMeshRenderer$$get_updateWhenOffscreen",
        "set_offscreen": "UnityEngine.SkinnedMeshRenderer$$set_updateWhenOffscreen",
        "filter_mesh": "UnityEngine.MeshFilter$$get_sharedMesh",
        "set_filter_mesh": "UnityEngine.MeshFilter$$set_sharedMesh",
        "materials": "UnityEngine.Renderer$$GetSharedMaterialArray",
        "set_materials": "UnityEngine.Renderer$$set_sharedMaterials",
    },
    "alloc_parameter": "(Il2CppObject* p, const MethodInfo* method)",
    "begin": "// BEGIN RESOLVER",
    "end": "// END RESOLVER",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("elf", type=Path)
    parser.add_argument("script", type=Path)
    parser.add_argument("cpp", type=Path)
    args = parser.parse_args()
    raw = args.elf.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != CONFIG["elf_sha256"]:
        raise ValueError("Нужна проверка ABI новой сборки перед сменой resolver")
    header = struct.unpack_from(CONFIG["header_format"], raw)
    segments = [struct.unpack_from(CONFIG["program_format"], raw, header[5] + n * header[9])
                for n in range(header[10])]
    methods = json.loads(args.script.read_text())["ScriptMethod"]
    records = []
    for member, name in CONFIG["methods"].items():
        matches = [item for item in methods if item["Name"] == name and
                   (member != "retain" or CONFIG["alloc_parameter"] in item["Signature"])]
        if len(matches) != 1:
            raise ValueError(f"Неоднозначная сигнатура {name}: {len(matches)}")
        record = matches[0]
        address = record["Address"]
        for kind, flags, offset, virtual, _, size, _, _ in segments:
            if (kind == CONFIG["load_segment"] and flags & CONFIG["executable"] and
                virtual <= address and address + CONFIG["prefix_size"] <= virtual + size):
                file_offset = offset + address - virtual
                prefix = raw[file_offset:file_offset + CONFIG["prefix_size"]]
                break
        else:
            raise ValueError(f"Метод вне исполняемого PT_LOAD: {name}")
        records.append(dict(member=member, name=name, rva=address, file_offset=file_offset,
                            prefix=prefix.hex(), signature=record["Signature"]))
    code = ["[[maybe_unused]] constexpr Binding kBindings[] = {"]
    for item in records:
        values = ", ".join(f"0x{value:02x}" for value in bytes.fromhex(item["prefix"]))
        code.append(f'    {{"{item["member"]}", 0x{item["rva"]:x}, {{{values}}}}},')
    code += ["};", "[[maybe_unused]] void bind_functions(std::uintptr_t base, Api& api) {"]
    code += [f'    api.{item["member"]} = reinterpret_cast<decltype(api.{item["member"]})>(base + kBindings[{index}].rva);'
             for index, item in enumerate(records)]
    code.append("}")
    current = args.cpp.read_text()
    first, remaining = current.split(CONFIG["begin"], 1)
    _, last = remaining.split(CONFIG["end"], 1)
    args.cpp.write_text(first + CONFIG["begin"] + "\n" + "\n".join(code) + "\n" + CONFIG["end"] + last)
    output = args.cpp.parent / "resolver.json"
    output.write_text(json.dumps({"input_sha256": digest, "address_kind": "ELF RVA", "methods": records}, indent=2) + "\n")
    print(f"Resolved {len(records)} methods")


if __name__ == "__main__":
    main()
