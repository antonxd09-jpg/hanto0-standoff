
// ================================================================================
// Source published by: @imguisource_bot
// Follow: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Backup: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

namespace renderer_swap {

using Object = void*;
using Slot = std::uint64_t;
using Handle = std::uintptr_t;

enum class Kind { skinned, mesh_filter };
enum class Result {
    applied, restored, unchanged, not_found, ownership_lost,
    invalid_argument, wrong_thread, rooting_failed, write_rejected
};

// Нативные сигнатуры проверены по ARM64, включая возврат GCHandle в x0.
// Это ABI игры. Готовый resolver определён в renderer_swap.cpp.
struct Api {
    using Method = const void*;
    bool (*alive)(Object, Method){};
    Handle (*retain)(Object, Method){};
    Object (*target)(Handle, Method){};
    void (*release)(Handle, Method){};
    Object (*skinned_mesh)(Object, Method){};
    void (*set_skinned_mesh)(Object, Object, Method){};
    bool (*offscreen)(Object, Method){};
    void (*set_offscreen)(Object, bool, Method){};
    Object (*filter_mesh)(Object, Method){};
    void (*set_filter_mesh)(Object, Object, Method){};
    Object (*materials)(Object, Method){};
    void (*set_materials)(Object, Object, Method){};

    bool complete() const noexcept;
    // base — load bias ELF игры в текущем процессе, не база исходного модуля.
    // Проверяются исполняемые PT_LOAD и байты каждой связанной функции.
    static bool bind(std::uintptr_t base, Api& output, std::string& error);
};

struct Replacement {
    Kind kind{Kind::skinned};
    Object mesh_owner{};        // SkinnedMeshRenderer либо MeshFilter.
    Object renderer{};          // Для skinned обязан совпадать с mesh_owner.
    Object mesh{};              // nullptr скрывает геометрию.
    Object material_array{};    // Настоящий Material[] из Unity, не std::vector.
};

class Controller {
public:
    // Создавать, применять и уничтожать на одном Unity-потоке.
    explicit Controller(Api api);
    ~Controller();
    Controller(const Controller&) = delete;
    Controller& operator=(const Controller&) = delete;
    Controller(Controller&&) = delete;
    Controller& operator=(Controller&&) = delete;

    Result apply(Slot slot, const Replacement& replacement);
    Result restore(Slot slot);
    Result restore_all();
    std::size_t active_count() const noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

const char* name(Result result) noexcept;

} // namespace renderer_swap
