
// ================================================================================
// Telegram:
// - Bot: https://t.me/imguisource_bot
// - ImGui Source: https://t.me/ImGui_Source_FIXNEY
// - shit src 🧨: https://t.me/il2cpp_src
// ================================================================================

#include "renderer_swap.hpp"
#include <cassert>
#include <iostream>
#include <thread>
#include <unordered_map>
#include <unordered_set>

using namespace renderer_swap;

namespace {
struct Node { bool live{true}; Object mesh{}; Object materials{}; bool offscreen{}; };
struct Engine {
    std::unordered_map<Object, Node> objects;
    std::unordered_map<Handle, Object> roots;
    Handle next{1};
    unsigned calls{};
    int fail_after{-1};
} engine;

Object object(std::uintptr_t id) { return reinterpret_cast<Object>(id); }
bool alive(Object value, Api::Method) { ++engine.calls; return engine.objects.count(value) && engine.objects.at(value).live; }
Handle retain(Object value, Api::Method) {
    ++engine.calls;
    if (engine.fail_after == 0) return {};
    if (engine.fail_after > 0) --engine.fail_after;
    Handle result = engine.next++;
    engine.roots.emplace(result, value);
    return result;
}
Object target(Handle handle, Api::Method) { ++engine.calls; return engine.roots.at(handle); }
void release(Handle handle, Api::Method) { ++engine.calls; assert(engine.roots.erase(handle) == 1); }
Object get_mesh(Object value, Api::Method) { ++engine.calls; return engine.objects.at(value).mesh; }
void set_mesh(Object value, Object mesh, Api::Method) { ++engine.calls; engine.objects.at(value).mesh = mesh; }
Object get_materials(Object value, Api::Method) { ++engine.calls; return engine.objects.at(value).materials; }
void set_materials(Object value, Object materials, Api::Method) { ++engine.calls; engine.objects.at(value).materials = materials; }
bool get_offscreen(Object value, Api::Method) { ++engine.calls; return engine.objects.at(value).offscreen; }
void set_offscreen(Object value, bool enabled, Api::Method) { ++engine.calls; engine.objects.at(value).offscreen = enabled; }

Api api() {
    return {alive, retain, target, release, get_mesh, set_mesh, get_offscreen,
            set_offscreen, get_mesh, set_mesh, get_materials, set_materials};
}
void reset() {
    assert(engine.roots.empty());
    engine = {};
    for (auto id : {11u,12u,13u,21u,22u,23u,31u,32u}) engine.objects.emplace(object(id), Node{});
    engine.objects.at(object(11)).mesh = object(21);
    engine.objects.at(object(11)).materials = object(31);
    engine.objects.at(object(12)).mesh = object(21);
    engine.objects.at(object(13)).materials = object(31);
}
Replacement skin(Object mesh = object(22), Object materials = object(32)) {
    return {Kind::skinned, object(11), object(11), mesh, materials};
}
void original_skin() {
    const auto& node = engine.objects.at(object(11));
    assert(node.mesh == object(21) && node.materials == object(31) && !node.offscreen);
}
} // namespace

int main() {
    unsigned cases{};
    reset();
    {
        Controller swap(api());
        assert(swap.apply(1, skin()) == Result::applied);
        assert(engine.objects.at(object(11)).mesh == object(22));
        assert(engine.objects.at(object(11)).materials == object(32));
        assert(engine.objects.at(object(11)).offscreen);
        assert(swap.restore(1) == Result::restored); original_skin(); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin());
        const auto next = engine.next;
        for (unsigned index{}; index != 2000; ++index) swap.apply(1, skin());
        assert(swap.active_count() == 1);
        assert(engine.roots.size() == 6);
        assert(engine.next == next);
        swap.restore(1); original_skin(); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin());
        engine.objects.at(object(11)).mesh = object(23);
        engine.objects.at(object(11)).materials = object(33);
        assert(swap.restore(1) == Result::ownership_lost);
        assert(engine.objects.at(object(11)).mesh == object(23));
        assert(engine.objects.at(object(11)).materials == object(33)); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin());
        engine.objects.at(object(11)).mesh = object(23);
        engine.objects.at(object(11)).materials = object(33);
        swap.apply(1, skin());
        swap.restore(1);
        assert(engine.objects.at(object(11)).mesh == object(23));
        assert(engine.objects.at(object(11)).materials == object(33));
        assert(!engine.objects.at(object(11)).offscreen); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin(nullptr, nullptr));
        assert(!engine.objects.at(object(11)).mesh);
        assert(!engine.objects.at(object(11)).offscreen);
        swap.restore(1); original_skin(); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, {Kind::mesh_filter, object(12), object(13), object(22), object(32)});
        assert(engine.objects.at(object(12)).mesh == object(22));
        assert(engine.objects.at(object(13)).materials == object(32));
        swap.restore(1);
        assert(engine.objects.at(object(12)).mesh == object(21));
        assert(engine.objects.at(object(13)).materials == object(31)); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin());
        engine.objects.at(object(11)).live = false;
        assert(swap.restore(1) == Result::ownership_lost);
        assert(swap.active_count() == 0); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin());
        engine.objects.at(object(21)).live = false;
        assert(swap.restore(1) == Result::restored);
        assert(!engine.objects.at(object(11)).mesh); ++cases;
    }
    reset();
    {
        Controller swap(api());
        const unsigned before = engine.calls;
        std::thread worker([&] {
            assert(swap.apply(1, skin()) == Result::wrong_thread);
            assert(swap.restore_all() == Result::wrong_thread);
        });
        worker.join(); assert(engine.calls == before); ++cases;
    }
    reset();
    {
        for (int fail{}; fail != 6; ++fail) {
            Controller swap(api());
            engine.fail_after = fail;
            assert(swap.apply(1, skin()) == Result::rooting_failed);
            original_skin(); assert(engine.roots.empty());
        }
        engine.fail_after = -1; ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin());
        engine.fail_after = 0;
        assert(swap.apply(1, skin(object(23))) == Result::rooting_failed);
        assert(engine.objects.at(object(11)).mesh == object(22));
        engine.fail_after = -1;
        swap.restore(1); original_skin(); ++cases;
    }
    reset();
    {
        Controller swap(api());
        swap.apply(1, skin());
        swap.apply(1, {Kind::mesh_filter, object(12), object(13), object(22), object(32)});
        original_skin(); assert(swap.active_count() == 1); ++cases;
    }
    reset();
    {
        Controller swap(api()); swap.apply(1, skin());
    }
    original_skin(); assert(engine.roots.empty()); ++cases;
    reset();
    {
        Controller swap(api());
        assert(swap.apply(1, skin(object(22), nullptr)) == Result::invalid_argument);
        assert(swap.restore(1) == Result::not_found); original_skin(); ++cases;
    }
    assert(engine.roots.empty());
    std::cout << "lifecycle scenarios passed: " << cases << "\n";
}
