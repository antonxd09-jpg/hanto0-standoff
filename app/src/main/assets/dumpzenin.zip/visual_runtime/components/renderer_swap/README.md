# Renderer Swap

Часть 1: C++17-реализация восстановленного механизма замены меша и материалов. Два самостоятельных исходника: `renderer_swap.hpp` и `renderer_swap.cpp`. Сторонний SDK и исходная библиотека для их компиляции не нужны. При создании Controller ничего не меняется; запись начинается только после явного `apply`.

## Подключение

```cpp
#include "renderer_swap.hpp"

// Выполняется на Unity-потоке. Объекты уже получены из AssetBundle/сцены.
bool bind_renderer_api(std::uintptr_t game_load_bias,
                       renderer_swap::Api& api, std::string& error) {
    return renderer_swap::Api::bind(game_load_bias, api, error);
}

renderer_swap::Result replace_body(renderer_swap::Controller& controller,
                                   renderer_swap::Slot slot,
                                   void* renderer, void* mesh, void* materials) {
    return controller.apply(slot, {renderer_swap::Kind::skinned,
                                   renderer, renderer, mesh, materials});
}

renderer_swap::Result replace_weapon(renderer_swap::Controller& controller,
                                     renderer_swap::Slot slot,
                                     void* filter, void* renderer,
                                     void* mesh, void* materials) {
    return controller.apply(slot, {renderer_swap::Kind::mesh_filter,
                                   filter, renderer, mesh, materials});
}
```

`Api::bind` принимает load bias ELF игры в текущем процессе. Это база того ELF, из которого сделаны предоставленные dump/script, а не база библиотеки с исходной подменой. Встроенный resolver содержит проверенные RVA и первые 16 байт каждой функции. Проверяются исполняемые PT_LOAD и совпадение всех 12 префиксов. При несовпадении bind возвращает false, не вызывая функции игры.

Из полученного Api создаётся долгоживущий `Controller`. Одинаковый `slot` обозначает одну замену. `restore(slot)` возвращает оригинал; `restore_all()` очищает все замены. Деструктор на том же потоке также вызывает восстановление. Controller и все его методы, включая чтение состояния и уничтожение, должны использоваться на одном Unity-потоке. Проверка thread ID защищает от смены потока, но не определяет самостоятельно, какой поток является Unity-потоком.

`mesh` — настоящий UnityEngine.Mesh*, `materials` — настоящий UnityEngine.Material[]*. OBJ/PNG и адрес файлового буфера в эти параметры передавать нельзя. Для MeshFilter отдельно передаются сам фильтр и связанный с ним MeshRenderer. Для SkinnedMeshRenderer оба указателя совпадают. Скелет и bind poses заменяемого меша должны быть совместимы с существующими bones рендерера.

`apply` с `mesh=nullptr` и `material_array=nullptr` скрывает геометрию с последующим восстановлением. Для ненулевого меша необходим массив материалов. На повторных вызовах с теми же объектами GCHandle заново не выделяются. Материалы можно переустановить при повторном apply. Существующий Animator, transforms и bones этот модуль не меняет.

## Восстановленная логика

Основа: исходные ELF RVA `0x1ecfa8` (подмена SkinnedMeshRenderer), `0x1ed0ec` (скрытие), `0x1edbb4` (снимок оригинала), `0x1ed194` (возврат). Для MeshFilter проверены getter `0x36ad40`, setter `0x369b28` и очистка `0x3997a4` в исходном модуле. RVA в этом абзаце относятся к модулю с подменой; RVA в `resolver.json` — к ELF игры.

Исходный слот SkinnedMeshRenderer имеет такую структуру:

| Смещение в байтах | Поле |
| --- | --- |
| 0x00 | renderer |
| 0x08 | его GC handle |
| 0x10 | оригинальный sharedMesh |
| 0x18 | GC handle оригинального меша |
| 0x20 | оригинальный массив материалов |
| 0x28 | GC handle массива |
| 0x30 | исходный updateWhenOffscreen |
| 0x31 | оригинал сохранён |
| 0x32 | замена применена |
| 0x38 | последний установленный меш |

Восстановление выполняется, только если текущий sharedMesh равен последнему установленному мешу. Чужая смена меша остаётся нетронутой. Если apply вызывается после чужой смены, новый меш и материалы становятся новым оригиналом; исходный offscreen-флаг сохраняется, как в разобранном коде. При утрате native-объекта очистка освобождает GC roots, не вызывая setter уничтоженного renderer. Если уничтожен только оригинальный Mesh, при восстановлении назначается nullptr.

Возврат материалов привязан к владению мешем: отдельное чужое изменение материалов при неизменном установленном меше не считается передачей владения. Это соответствует исследованной ветке, а не независимому владению каждым свойством.

Реализация использует собственные C++-структуры вместо копирования необработанной памяти исходного слота. Добавлены удержание установленных объектов через normal GCHandle, проверка потока, проверка записи меша и проверка resolver. Это восстановленная реализация механизма, а не заявление об идентичности всего исходного контроллера.

## Проверки

Скомпилировано g++ с C++17, `-Wall -Wextra -Werror`. На синтетическом Unity backend прошли 14 сценариев, в том числе 2000 повторных apply без дополнительных GC allocations, утрата владения, повторный захват после чужой смены, скрытие, уничтожение renderer/оригинала, смена владельца слота, отказ GC allocation и вызов с другого потока.

AddressSanitizer и UndefinedBehaviorSanitizer прошли. LeakSanitizer недоступен под ptrace в этой среде; утечки GC handles отдельно проверяются тестовым backend. C++-ветка resolver с dl_iterate_phdr дополнительно проверена компилятором на хосте с включённой веткой AArch64; это не Android-сборка. Android NDK-сборка и запуск в игре не выполнены.

```sh
g++ -std=c++17 -Wall -Wextra -Werror -pthread -I. \
    renderer_swap.cpp tests/renderer_swap_test.cpp -o renderer_swap_test
./renderer_swap_test
```

Проверенные адреса и сигнатуры: `resolver.json`. Их источник — предоставленный script.json и ELF с SHA-256 `ba0966976204fa3f7a2755c9588d32299fe7eb794b712c9f1a444e046cbe7c13`. Для воспроизведения resolver:

```sh
python3 build_resolver.py /path/to/game.so /path/to/script.json renderer_swap.cpp
```

После обновления игры нужны новые RVA, машинные префиксы и проверка ABI; генератор намеренно отклоняет другую сборку по SHA-256.

## Граница этой части

Здесь реализована сама замена и возврат Mesh/Material[]. Загрузка AssetBundle, получение игровых renderer, меню выбора, привязка нового скелета по retarget-картам, springs, отдельные движущиеся детали оружия и полная интеграция игрового контроллера в эту часть не входят. Следующий модуль — привязка скелета и retarget персонажей.
