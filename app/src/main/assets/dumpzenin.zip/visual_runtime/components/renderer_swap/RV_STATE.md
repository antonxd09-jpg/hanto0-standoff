# Renderer swap state

Дата: 2026-11-03. Запрос: логика подмены после извлечения ресурсов.

Доставляемый модуль: renderer_swap.hpp / renderer_swap.cpp, восстановленные snapshot/apply/hide/restore для SkinnedMeshRenderer и базовая MeshFilter-ветка, normal GC roots, привязка к 12 проверенным функциям ELF игры. Без зависимости от исходной библиотеки. Вызовы по RVA через встроенный resolver; источник адресов и префиксов — script.json и реальные PT_LOAD.

Исходный модуль SHA256 b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b. ELF игры SHA256 ba0966976204fa3f7a2755c9588d32299fe7eb794b712c9f1a444e046cbe7c13. Входы текущего рабочего дерева: module_analysis/libmodule.so, upload/libunity.so, model_swap/input/script.json и dump.cs. Большие входы в новый архив не включать.

Проверенная семантика: 0x1ecfa8, 0x1ed0ec, 0x1edbb4, 0x1ed194 (исходный ELF RVA). Слот 0x40 bytes; подробная карта в README. Обёртки 0x19c120/sharedMesh, 0x19c1ec/set_sharedMesh, 0x19b000/GetSharedMaterialArray, 0x19b4fc/set_sharedMaterials, 0x19c7a8/get_updateWhenOffscreen, 0x19c874/set_updateWhenOffscreen. Имена проверены по строкам и ARM64. MeshFilter wrappers 0x36ad40/0x369b28. Вызовы игровых методов проверены по сигнатурам и инструкции ARM64. GCHandle Alloc — normal=2, возвращает handle в x0; используется приватный статический GetTarget(IntPtr), а не instance get_Target с byref-this.

14 сценариев host fake-backend прошли под ASan/UBSan с ASAN_OPTIONS=detect_leaks=0. LSan не работает под ptrace. Тесты не являются запуском нативного кода игры. Нативная ветка resolver синтаксически скомпилирована на хосте с -D__aarch64__; полноценный NDK отсутствует. В игре не запускалось. Не называть это полным восстановлением всего changer.

Следующий модуль: retarget / создание префаба / синхронизация костей. Его исходные узлы: fn_1ef038, fn_1ef8ac и функции после 0x1f0ae8. Файлы в model_extract/pseudocode. Текстовые карты уже извлечены в model_extract/exported/models/text. Оружейные moving-parts: 0x39f88c, 0x39fc10, дополнительные корни 0x39796c. Результаты decompile новых wrappers находятся в model_swap/evidence. Не передавать raw Ghidra как готовый C++.

Ресурсный архив model_resources.zip сохранён ранее отдельно. Ragebot checkpoint core-source.zip не изменялся и остаётся неполным по своим исходным задачам.
