
// ================================================================================
// Все обновления тут:
// Бот: https://t.me/imguisource_bot
// Канал: https://t.me/ImGui_Source_FIXNEY (ImGui Source)
// Второй: https://t.me/il2cpp_src (shit src 🧨)
// ================================================================================

#include "renderer_swap.hpp"
#include <array>
#include <cstring>
#include <stdexcept>
#include <thread>
#include <unordered_map>
#include <utility>
#if defined(__linux__) || defined(__ANDROID__)
#include <link.h>
#endif

namespace renderer_swap {
namespace {

struct Binding {
    const char* name;
    std::uintptr_t rva;
    std::array<unsigned char, 16> bytes;
};

// CONFIG: автоматически восстановленный resolver этой сборки.
// Источник RVA: script.json, байты: PT_LOAD предоставленного ELF.
// BEGIN RESOLVER
[[maybe_unused]] constexpr Binding kBindings[] = {
    {"alive", 0x693772c, {0xfe, 0x57, 0xbe, 0xa9, 0xf4, 0x4f, 0x01, 0xa9, 0x14, 0x3c, 0x03, 0xf0, 0xd5, 0xfc, 0x02, 0xf0}},
    {"retain", 0x6a06570, {0xe1, 0x03, 0x1f, 0xaa, 0x42, 0x00, 0x80, 0x52, 0xfc, 0x6c, 0x24, 0x15, 0x00, 0x34, 0x40, 0xf9}},
    {"target", 0x6a089b4, {0xec, 0x63, 0x24, 0x15, 0xfe, 0x0f, 0x1c, 0xf8, 0xf8, 0x5f, 0x01, 0xa9, 0xf6, 0x57, 0x02, 0xa9}},
    {"release", 0x6a025d0, {0xcc, 0x7c, 0x24, 0x15, 0xe8, 0x03, 0x01, 0x2a, 0xe1, 0x03, 0x02, 0xaa, 0x02, 0x0c, 0x01, 0xf8}},
    {"skinned_mesh", 0x72fc8ac, {0xfe, 0x57, 0xbe, 0xa9, 0xf4, 0x4f, 0x01, 0xa9, 0x33, 0xee, 0x02, 0xb0, 0xf4, 0x03, 0x00, 0xaa}},
    {"set_skinned_mesh", 0x72eedc0, {0xfe, 0x0f, 0x1d, 0xf8, 0xf6, 0x57, 0x01, 0xa9, 0xf4, 0x4f, 0x02, 0xa9, 0x93, 0xee, 0x02, 0xd0}},
    {"offscreen", 0x72fa060, {0xfe, 0x0f, 0x1e, 0xf8, 0xf4, 0x4f, 0x01, 0xa9, 0x33, 0xee, 0x02, 0xf0, 0xf4, 0x03, 0x00, 0xaa}},
    {"set_offscreen", 0x73031bc, {0xfe, 0x57, 0xbe, 0xa9, 0xf4, 0x4f, 0x01, 0xa9, 0xf4, 0xed, 0x02, 0xd0, 0xf3, 0x03, 0x01, 0x2a}},
    {"filter_mesh", 0x72dcad8, {0xfe, 0x57, 0xbe, 0xa9, 0xf4, 0x4f, 0x01, 0xa9, 0x33, 0xef, 0x02, 0x90, 0xf4, 0x03, 0x00, 0xaa}},
    {"set_filter_mesh", 0x73070f4, {0xfe, 0x0f, 0x1d, 0xf8, 0xf6, 0x57, 0x01, 0xa9, 0xf4, 0x4f, 0x02, 0xa9, 0xd3, 0xed, 0x02, 0xd0}},
    {"materials", 0x7303b70, {0xfe, 0x0f, 0x1e, 0xf8, 0xf4, 0x4f, 0x01, 0xa9, 0xf3, 0xed, 0x02, 0xd0, 0xf4, 0x03, 0x00, 0xaa}},
    {"set_materials", 0x72ff268, {0x01, 0x00, 0x00, 0x14, 0x81, 0x00, 0x00, 0xb4, 0x22, 0x18, 0x40, 0xb9, 0x80, 0x00, 0x00, 0xb4}},
};
[[maybe_unused]] void bind_functions(std::uintptr_t base, Api& api) {
    api.alive = reinterpret_cast<decltype(api.alive)>(base + kBindings[0].rva);
    api.retain = reinterpret_cast<decltype(api.retain)>(base + kBindings[1].rva);
    api.target = reinterpret_cast<decltype(api.target)>(base + kBindings[2].rva);
    api.release = reinterpret_cast<decltype(api.release)>(base + kBindings[3].rva);
    api.skinned_mesh = reinterpret_cast<decltype(api.skinned_mesh)>(base + kBindings[4].rva);
    api.set_skinned_mesh = reinterpret_cast<decltype(api.set_skinned_mesh)>(base + kBindings[5].rva);
    api.offscreen = reinterpret_cast<decltype(api.offscreen)>(base + kBindings[6].rva);
    api.set_offscreen = reinterpret_cast<decltype(api.set_offscreen)>(base + kBindings[7].rva);
    api.filter_mesh = reinterpret_cast<decltype(api.filter_mesh)>(base + kBindings[8].rva);
    api.set_filter_mesh = reinterpret_cast<decltype(api.set_filter_mesh)>(base + kBindings[9].rva);
    api.materials = reinterpret_cast<decltype(api.materials)>(base + kBindings[10].rva);
    api.set_materials = reinterpret_cast<decltype(api.set_materials)>(base + kBindings[11].rva);
}
// END RESOLVER

bool is_alive(const Api& api, Object object) {
    return object && api.alive(object, nullptr);
}

class Root {
    const Api* api_{};
    Handle value_{};
public:
    explicit Root(const Api& api) : api_(&api) {}
    ~Root() { clear(); }
    Root(const Root&) = delete;
    Root& operator=(const Root&) = delete;
    Root(Root&& other) noexcept : api_(other.api_), value_(std::exchange(other.value_, {})) {}
    Root& operator=(Root&& other) noexcept {
        if (this != &other) {
            clear(); api_ = other.api_; value_ = std::exchange(other.value_, {});
        }
        return *this;
    }
    bool set(Object object) {
        if (get() == object) return true;
        Handle next = object ? api_->retain(object, nullptr) : Handle{};
        if (object && !next) return false;
        if (next && api_->target(next, nullptr) != object) {
            api_->release(next, nullptr);
            return false;
        }
        clear(); value_ = next;
        return true;
    }
    Object get() const { return value_ ? api_->target(value_, nullptr) : nullptr; }
    void clear() noexcept {
        if (value_) api_->release(std::exchange(value_, {}), nullptr);
    }
};

struct Entry {
    Kind kind;
    Root owner, renderer, original_mesh, original_materials, installed_mesh, installed_materials;
    bool original_offscreen{};
    bool applied{};
    Entry(const Api& api, Kind type) : kind(type), owner(api), renderer(api),
        original_mesh(api), original_materials(api), installed_mesh(api), installed_materials(api) {}
};

Object mesh(const Api& api, const Entry& entry) {
    return entry.kind == Kind::skinned
        ? api.skinned_mesh(entry.owner.get(), nullptr)
        : api.filter_mesh(entry.owner.get(), nullptr);
}

void set_mesh(const Api& api, const Entry& entry, Object object) {
    if (entry.kind == Kind::skinned) api.set_skinned_mesh(entry.owner.get(), object, nullptr);
    else api.set_filter_mesh(entry.owner.get(), object, nullptr);
}

// Чужая замена не перезаписывается при очистке.
Result undo(const Api& api, Entry& entry) {
    if (!entry.applied) return Result::unchanged;
    if (!is_alive(api, entry.owner.get()) || mesh(api, entry) != entry.installed_mesh.get()) {
        entry.applied = false;
        return Result::ownership_lost;
    }
    Object original = entry.original_mesh.get();
    if (original && !is_alive(api, original)) original = nullptr;
    set_mesh(api, entry, original);
    if (is_alive(api, entry.renderer.get()) && entry.original_materials.get())
        api.set_materials(entry.renderer.get(), entry.original_materials.get(), nullptr);
    if (entry.kind == Kind::skinned)
        api.set_offscreen(entry.owner.get(), entry.original_offscreen, nullptr);
    entry.applied = false;
    return Result::restored;
}

} // namespace

bool Api::complete() const noexcept {
    return alive && retain && target && release && skinned_mesh && set_skinned_mesh &&
        offscreen && set_offscreen && filter_mesh && set_filter_mesh && materials && set_materials;
}

bool Api::bind(std::uintptr_t base, Api& output, std::string& error) {
    output = {};
    error.clear();
#if defined(__aarch64__) && (defined(__linux__) || defined(__ANDROID__))
    struct Search {
        std::uintptr_t base;
        bool found{};
        bool verified{};
        std::string failed;
    } search{base, false, false, {}};
    dl_iterate_phdr([](dl_phdr_info* module, std::size_t, void* pointer) {
        auto& state = *static_cast<Search*>(pointer);
        if (module->dlpi_addr != state.base) return 0;
        state.found = true;
        for (const auto& binding : kBindings) {
            bool mapped = false;
            for (ElfW(Half) index{}; index != module->dlpi_phnum; ++index) {
                const auto& segment = module->dlpi_phdr[index];
                if (segment.p_type == PT_LOAD && (segment.p_flags & PF_X) &&
                    binding.rva >= segment.p_vaddr && binding.bytes.size() <= segment.p_memsz &&
                    binding.rva - segment.p_vaddr <= segment.p_memsz - binding.bytes.size()) {
                    mapped = true; break;
                }
            }
            if (!mapped || std::memcmp(reinterpret_cast<const void*>(state.base + binding.rva),
                                        binding.bytes.data(), binding.bytes.size())) {
                state.failed = binding.name;
                return 1;
            }
        }
        state.verified = true;
        return 1;
    }, &search);
    if (!search.found) { error = "ELF load bias not found"; return false; }
    if (!search.verified) { error = "build mismatch: " + search.failed; return false; }
    bind_functions(base, output);
    return output.complete();
#else
    (void)base;
    error = "native binding requires AArch64 ELF";
    return false;
#endif
}

struct Controller::Impl {
    Api api;
    std::thread::id thread{std::this_thread::get_id()};
    std::unordered_map<Slot, std::unique_ptr<Entry>> entries;
    explicit Impl(Api value) : api(value) {}
    bool on_thread() const { return std::this_thread::get_id() == thread; }
};

Controller::Controller(Api api) {
    if (!api.complete()) throw std::invalid_argument("incomplete renderer ABI");
    impl_ = std::make_unique<Impl>(api);
}

Controller::~Controller() {
    if (impl_ && impl_->on_thread()) restore_all();
}

Result Controller::apply(Slot slot, const Replacement& request) {
    auto& state = *impl_;
    if (!state.on_thread()) return Result::wrong_thread;
    const auto& api = state.api;
    if ((request.kind != Kind::skinned && request.kind != Kind::mesh_filter) ||
        !is_alive(api, request.mesh_owner) || !is_alive(api, request.renderer) ||
        (request.mesh && !is_alive(api, request.mesh)) ||
        (request.kind == Kind::skinned && request.mesh_owner != request.renderer) ||
        (request.mesh && !request.material_array)) return Result::invalid_argument;

    auto iterator = state.entries.find(slot);
    if (iterator != state.entries.end() &&
        (iterator->second->owner.get() != request.mesh_owner ||
         iterator->second->renderer.get() != request.renderer || iterator->second->kind != request.kind)) {
        undo(api, *iterator->second);
        state.entries.erase(iterator);
        iterator = state.entries.end();
    }

    std::unique_ptr<Entry> fresh;
    Entry* entry{};
    if (iterator == state.entries.end()) {
        fresh = std::make_unique<Entry>(api, request.kind);
        entry = fresh.get();
        if (!entry->owner.set(request.mesh_owner) || !entry->renderer.set(request.renderer))
            return Result::rooting_failed;
    } else entry = iterator->second.get();

    // Все нужные GC roots создаются до первого изменения Unity-объектов.
    Root next_mesh(api), next_materials(api);
    const bool same_mesh_root = entry->applied && entry->installed_mesh.get() == request.mesh;
    const bool same_material_root = entry->applied && entry->installed_materials.get() == request.material_array;
    if ((!same_mesh_root && !next_mesh.set(request.mesh)) ||
        (!same_material_root && !next_materials.set(request.material_array)))
        return Result::rooting_failed;
    Object current = mesh(api, *entry);
    bool owned = entry->applied && current == entry->installed_mesh.get();
    if (!owned) {
        Root original_mesh(api), original_materials(api);
        Object materials = api.materials(request.renderer, nullptr);
        if (!materials || !original_mesh.set(current) || !original_materials.set(materials))
            return Result::rooting_failed;
        entry->original_mesh = std::move(original_mesh);
        entry->original_materials = std::move(original_materials);
        if (!entry->applied && request.kind == Kind::skinned)
            entry->original_offscreen = api.offscreen(request.mesh_owner, nullptr);
    }

    // Выделение узла таблицы завершается до изменений Unity.
    const bool inserted = static_cast<bool>(fresh);
    if (fresh) state.entries.emplace(slot, std::move(fresh));
    // При одинаковом меше setter пропускается; материалы можно переустановить.
    if (current != request.mesh) {
        set_mesh(api, *entry, request.mesh);
        if (mesh(api, *entry) != request.mesh) {
            if (inserted) state.entries.erase(slot);
            return Result::write_rejected;
        }
    }
    if (request.material_array) api.set_materials(request.renderer, request.material_array, nullptr);
    if (request.kind == Kind::skinned && request.mesh)
        api.set_offscreen(request.mesh_owner, true, nullptr);
    if (!same_mesh_root) entry->installed_mesh = std::move(next_mesh);
    if (!same_material_root) entry->installed_materials = std::move(next_materials);
    entry->applied = true;
    return Result::applied;
}

Result Controller::restore(Slot slot) {
    auto& state = *impl_;
    if (!state.on_thread()) return Result::wrong_thread;
    auto iterator = state.entries.find(slot);
    if (iterator == state.entries.end()) return Result::not_found;
    Result result = undo(state.api, *iterator->second);
    state.entries.erase(iterator);
    return result;
}

Result Controller::restore_all() {
    auto& state = *impl_;
    if (!state.on_thread()) return Result::wrong_thread;
    Result result = Result::unchanged;
    for (auto& [slot, entry] : state.entries) {
        (void)slot;
        Result current = undo(state.api, *entry);
        if (current == Result::ownership_lost || result != Result::ownership_lost) result = current;
    }
    state.entries.clear();
    return result;
}

std::size_t Controller::active_count() const noexcept { return impl_->entries.size(); }

const char* name(Result result) noexcept {
    switch (result) {
    case Result::applied: return "applied";
    case Result::restored: return "restored";
    case Result::unchanged: return "unchanged";
    case Result::not_found: return "not_found";
    case Result::ownership_lost: return "ownership_lost";
    case Result::invalid_argument: return "invalid_argument";
    case Result::wrong_thread: return "wrong_thread";
    case Result::rooting_failed: return "rooting_failed";
    case Result::write_rejected: return "write_rejected";
    }
    return "unknown";
}

} // namespace renderer_swap
