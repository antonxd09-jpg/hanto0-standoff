
// ================================================================================
// -----------------[ TELEGRAM SOURCE ]-----------------
// * BOT:     t.me/imguisource_bot
// * CHANNEL: t.me/ImGui_Source_FIXNEY (ImGui Source)
// * CH 2:    t.me/il2cpp_src (shit src 🧨)
// -----------------------------------------------------
// ================================================================================

#pragma once
#include <array>
#include <cstddef>
#include <cstdint>

namespace material_parameters {
struct Config {
    static constexpr std::uintptr_t ApplyRva = 0x3756cc;
    static constexpr std::uintptr_t PackRva = 0x36f44c;
    static constexpr std::uintptr_t PropertiesRva = 0x3752a8;
    static constexpr std::uintptr_t PropertyIdsRva = 0x777c5d0;
    static constexpr std::size_t PropertyCount = 47;
    static constexpr std::size_t PayloadFloats = 60;
    static constexpr std::size_t SourceSize = 0x11c;
    static constexpr float Percent = 0.01f;
    static constexpr std::size_t FirstAlphaWord = 4;
    static constexpr std::size_t SecondAlphaWord = 8;
    static constexpr std::size_t FirstColorWord = 1;
    static constexpr std::size_t SecondColorWord = 5;
    static constexpr std::size_t FillColorWord = 9;
    static constexpr std::size_t BehindWallsWord = 13;
    static constexpr std::size_t BloomIntensityWord = 51;
    static constexpr std::size_t BloomRadiusWord = 52;
    static constexpr std::size_t BloomColorWord = 53;
    static constexpr std::size_t BloomHiddenColorWord = 57;
    static constexpr std::int32_t FirstQueue = 0xc1c;
    static constexpr std::int32_t SecondQueue = 0xc1d;
    static constexpr float MinAlpha = 0.0f;
    static constexpr float MaxAlpha = 1.0f;
    static constexpr float Zero = 0.0f;
};
enum class Property : std::size_t {
    Color, HiddenColor, BehindWalls, WeaponMode, Overlay, Metallic, Roughness,
    Exponent, FresnelFilling, OriginalOverlay, FillColor, Strength, EnableAnim,
    AnimSpeed, Speed, Gloss, Fresnel, WireThickness, WireSmoothing, Glow,
    OriginalTexture, EnablePulse, Pulse, PulseMin, Distortion, Opacity,
    Reflection, EnableBlur, BlurStrength, Grain, BlurSize, Tint, Reflectivity,
    Facets, HueSpread, Heat, Plates, Frost, Cracks, GlyphSize, Background,
    RainSpeed, OverlayLayer, BloomColor, BloomHiddenColor, BloomIntensity, BloomRadius
};
using Object = std::uint64_t;
using PropertyIds = std::array<std::int32_t, Config::PropertyCount>;
using Color = std::array<float, 4>;
struct Packet {
    std::int32_t style{};
    std::array<float, Config::PayloadFloats> values{};
};
using Source = std::array<std::byte, Config::SourceSize>;
static_assert(sizeof(Packet) == 0xf4);
static_assert(offsetof(Packet, values) == 4);

// Контракт адаптера Unity. Это не объявления ABI функций исходной библиотеки.
struct Backend {
    virtual ~Backend() = default;
    virtual Object shader(Object material) = 0;
    virtual void set_shader(Object material, Object shader) = 0;
    virtual void set_queue(Object material, std::int32_t queue) = 0;
    virtual void set_float(Object material, std::int32_t property, float value) = 0;
    virtual void set_vector(Object material, std::int32_t property, const Color& value) = 0;
};

const std::array<const char*, Config::PropertyCount>& property_names() noexcept;
Packet pack(const Source&, std::int32_t style, std::uint8_t behindWalls) noexcept;
// Как native 0x3756cc, изменяет два alpha-поля перед применением параметров.
void apply(float alpha, Object material, Object shader, Packet& packet,
           std::int32_t queue, const PropertyIds&, Backend&);
}
