
// ================================================================================
// Find more on @imguisource_bot | @ImGui_Source_FIXNEY | @il2cpp_src
// ================================================================================

#pragma once
#include "material_parameters.hpp"
#include "render_commands.hpp"
#include "post_color.hpp"
#include "screen_geometry.hpp"
#include "world_materials.hpp"
#include "trajectory_mesh.hpp"
#include "renderer_swap.hpp"
