
// ================================================================================
// TG Project: @imguisource_bot
// Main: @ImGui_Source_FIXNEY - ImGui Source
// Additional: @il2cpp_src - shit src 🧨
// ================================================================================

#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace render_commands {
struct Config {
    static constexpr std::size_t CacheCount = 32;
    static constexpr std::size_t CacheStride = 0x890;
    static constexpr std::size_t RendererLimit = 64;
    static constexpr std::size_t RendererStride = 0x18;
    static constexpr std::size_t RendererPointer = 0x08;
    static constexpr std::size_t RendererSlot = 0x10;
    static constexpr std::size_t RendererCount = 0x600;
    static constexpr std::size_t FirstMaterial = 0x610;
    static constexpr std::size_t SecondMaterial = 0x618;
    static constexpr std::size_t FirstStyle = 0x640;
    static constexpr std::size_t FirstEnabled = 0x72c;
    static constexpr std::size_t Flags = 0x75d;
    static constexpr std::size_t SecondStyle = 0x760;
    static constexpr std::size_t SecondEnabled = 0x84c;
    static constexpr std::size_t SecondMode = 0x87c;
    static constexpr std::size_t Active = 0x888;
    static constexpr std::int32_t StyleMin = 0;
    static constexpr std::int32_t StyleMax = 12;
    static constexpr std::int32_t FallbackStyle = 2;
    static constexpr std::int32_t FirstMode = 0;
    static constexpr std::int32_t ColorMode = 1;
    static constexpr std::array<std::int32_t, 11> SecondStyles{
        0, 1, 2, 3, 4, 5, 6, 7, 10, 11, 12
    };
    // Все адреса — RVA исходного ELF. Адреса Ghidra выше на 0x100000.
    static constexpr std::uintptr_t CacheRva = 0x777e5c0;
    static constexpr std::uintptr_t MaterialsRva = 0x382290;
    static constexpr std::uintptr_t ColorsRva = 0x382654;
    static constexpr std::uintptr_t StyleTableRva = 0x703ca8;
};
using Cache = std::array<std::byte, Config::CacheStride>;
using CacheBank = std::array<Cache, Config::CacheCount>;
using ObjectValidator = bool (*)(std::uintptr_t, void*);

struct MaterialCommand {
    std::uint64_t renderer{};
    std::uint64_t material{};
    std::int32_t mode{};
    std::int32_t style{};
    std::uint8_t flags{};
    std::array<std::uint8_t, 3> padding{};
    std::int32_t slot{};
};
struct ColorCommand {
    std::uint64_t renderer{};
    std::int32_t mode{};
    std::array<float, 4> first{};
    std::array<float, 4> second{};
    std::int32_t slot{};
};
struct ColorSettings {
    std::uint8_t enabled{};
    std::uint8_t secondEnabled{};
    std::array<std::uint8_t, 2> padding{};
    std::array<float, 4> first{};
    std::array<float, 4> second{};
};
static_assert(sizeof(MaterialCommand) == 0x20);
static_assert(offsetof(MaterialCommand, flags) == 0x18);
static_assert(offsetof(MaterialCommand, slot) == 0x1c);
static_assert(sizeof(ColorCommand) == 0x30);
static_assert(offsetof(ColorCommand, first) == 0x0c);
static_assert(offsetof(ColorCommand, second) == 0x1c);
static_assert(offsetof(ColorCommand, slot) == 0x2c);
static_assert(sizeof(ColorSettings) == 0x24);
static_assert(offsetof(ColorSettings, first) == 0x04);
static_assert(offsetof(ColorSettings, second) == 0x14);

// Дополняют очередь. Validator реализует проверку Unity-объектов вызывающей стороны.
// Превышение 64 слотов вызывает std::out_of_range на том же шаге, что native assert.
void gather_material_commands(const CacheBank&, std::vector<MaterialCommand>&,
                              ObjectValidator, void* context);
void gather_color_commands(const CacheBank&, const ColorSettings&,
                           std::vector<ColorCommand>&, ObjectValidator, void* context);
}
