
// ================================================================================
// +------------------------------------------------+
// | TG Bot: @imguisource_bot                       |
// | ImGui Source: @ImGui_Source_FIXNEY                        |
// | shit src 🧨: @il2cpp_src                        |
// +------------------------------------------------+
// ================================================================================

#pragma once
#include <cstdint>
#include <string_view>
namespace world_materials {
struct Config {static constexpr std::uintptr_t ClassifyRva=0x2be840;static constexpr std::uint32_t VariantBit=1;};
enum class Family : std::uint32_t {
    diffuse=0,fog=1,cutout=2,wind=3,transparent=4,transparent_fog=5,
    standard=6,other=7,window=8,fallback=9
};
// Имена enum назначены по проверенным строкам. Значения повторяют native.
Family classify(std::string_view name,std::uint32_t variantFlags) noexcept;
}
