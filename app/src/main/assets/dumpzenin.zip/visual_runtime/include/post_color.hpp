
// ================================================================================
// TG Project: @imguisource_bot
// Main: @ImGui_Source_FIXNEY - ImGui Source
// Additional: @il2cpp_src - shit src 🧨
// ================================================================================

#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
namespace post_color {
struct Config {
    static constexpr std::uintptr_t ColorRva=0x31fdf4, LutRva=0x320118;
    static constexpr std::size_t Side=32, SlicePixels=Side*Side, Pixels=SlicePixels*Side;
};
using Rgb=std::array<float,3>;
using Prepared=std::array<float,11>;
using Lut=std::array<std::uint32_t,Config::Pixels>;
struct Grading {
    float temperature{},tint{};
    Rgb filter{};
    float hue{},saturation{},brightness{},contrast{};
};
static_assert(sizeof(Grading)==0x24);
Prepared prepare(const Grading&) noexcept;
Rgb transform(const Prepared&,const Rgb&) noexcept;
// Строка: green; red меняется быстрее blue. nullptr — native no-op.
void build_lut(const Grading&,std::uint32_t* rgba) noexcept;
}
