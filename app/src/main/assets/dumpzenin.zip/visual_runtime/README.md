# Visual Runtime — текущий перенос

Один C++17 проект: материалы, геометрия ESP, цветокоррекция, классификация материалов
мира, меш траекторий и контроллер замены мешей. Полный запрошенный визуал ещё
не реализован. Точное состояние — coverage.json. Входной заголовок —
include/visual_runtime.hpp; реализации — src/ и components/.

| Исходный ELF RVA | C++ | Проверка |
|---|---|---|
| `0x36f44c` | `material_parameters::pack` | 600 побайтовых сравнений всех 244 байт |
| `0x3756cc` | `material_parameters::apply` | 600 сравнений пакета и трассы вызовов |
| `0x382290` | `render_commands::gather_material_commands` | 180 сравнений очередей |
| `0x382654` | `render_commands::gather_color_commands` | 120 сравнений очередей |
| `0x31fdf4` | `post_color::transform` | 500 RGB сравнений |
| `0x320118` | `post_color::prepare + build_lut` | 5 LUT, 163840 пикселей |
| `0x449f30` | `screen_geometry::prepare` | 240 случаев |
| `0x449bb0` | `screen_geometry::project` | 240 случаев |
| `0x449d10` | `screen_geometry::validate` | 240 случаев |
| `0x4455e4` | `screen_geometry::simple_bounds` | 240 случаев |
| `0x44523c` | `screen_geometry::skeleton_bounds` | 240 случаев |
| `0x2be840` | `world_materials::classify` | 1550 случаев |
| `0x343a24` | `trajectory_mesh::append` | 260 случаев |
| `0x343464` | `trajectory_mesh::build` | 90 случаев |

В общий проект включён renderer_swap: snapshot, замена и восстановление мешей и
материалов, 14 host lifecycle сценариев. Его проверяемый resolver привязан к
отдельной сборке игры, указанной в components/renderer_swap/resolver.json.

Всего — 5105 native differential случаев и 14 host lifecycle сценариев.
Единый include/link check всех реализаций прошёл на g++. Геометрия сравнивается
побитово на конечных значениях; две пары NaN сравниваются по классу, поскольку
знак/payload invalid float arithmetic отличается между ARM64 и x86. UI scale —
контролируемый стабильный снимок getter. Вычисления цветокоррекции и LUT не
перехватываются. Пределы движковых адаптеров описаны ниже.

Главная отрисовка ESP, chams cache/material lifetime, весь grenade runtime,
world overlays, post FX кроме цветокоррекции, применение настроек карт и остальные
эффекты ещё не завершены. Диагностика в analysis/ не является готовым C++.

`include/` и `src/` содержат C++17 без вызовов исходной библиотеки.
`tests/` содержит воспроизводимые проверки исходного ARM64 через Unicorn и
мосты для host-сборки. Проверены 13 стилей материалов, дополнительные некорректные
значения стиля, граничные alpha, NaN/Inf, обе очереди, порядок проходов,
невалидные объекты и переполнение лимита 64 renderer-слотов.

`Backend` — объявленный здесь контракт адаптера Unity. Для подключения к игре
нужны его реальные реализации. `ObjectValidator` также передаётся вызывающей
стороной. Проверки используют одинаковые контролируемые адаптеры для native и
C++, не запускают настоящие Unity-объекты и не доказывают работоспособность
интеграции в игре.

`CacheBank` сохраняет проверенную раскладку исходного кеша: 32 записи по 0x890
байт. Это не раскладка Unity-объекта. `Source` — 0x11c байт параметров одного
материала; `pack` преобразует их в пакет 0xf4 байт. `apply` изменяет alpha в этом
пакете, как исходная функция. Очереди дополняются, а не очищаются.

У `MaterialCommand` три байта padding не имеют native-значения и в C++ обнулены.
`gather_*` при достижении слота 64 выбрасывает `std::out_of_range`; исходная
функция на этом шаге вызывает assertion handler. Уже записанные команды
сохраняются. Сопоставление в проверках учитывает эту оговорённую замену.

Собирались исходники и тестовые мосты посредством g++ с C++17, `-O2`,
`-Wall -Wextra -Werror`; для материалов `-ffp-contract=off`.
CMake 3.28.1 configure/build Release также прошли. Android NDK и запуск
в игре не проверялись.

Зависимости native-проверок — requirements.txt. Для сборки всех мостов и запуска
всех проверок из папки, содержащей visual_runtime/:

```sh
python3 visual_runtime/tests/build.py --native
```

Отдельные команды для первоначальных функций:

```sh
g++ -std=c++17 -Wall -Wextra -Werror -O2 -fPIC -shared -Ivisual_runtime/include visual_runtime/src/render_commands.cpp visual_runtime/tests/command_bridge.cpp -o visual_runtime/tests/command_bridge.so
g++ -std=c++17 -Wall -Wextra -Werror -O2 -ffp-contract=off -fPIC -shared -Ivisual_runtime/include visual_runtime/src/material_parameters.cpp visual_runtime/src/material_packet.cpp visual_runtime/tests/material_bridge.cpp -o visual_runtime/tests/material_bridge.so
python3 visual_runtime/tests/command_differential.py
python3 visual_runtime/tests/material_differential.py
```

Тестам нужны `unicorn`, `pyelftools`, исходный ELF по пути из CONFIG и
`visual_extract/analysis/imports.tsv` для проверки очередей. При другом расположении
путей изменяется только CONFIG тестового скрипта.

SHA256 исходного ELF:
`b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b`.
Все обозначенные RVA относятся к этому файлу. Ghidra показывает его с базой
0x100000. Оригинальные имена C++-символов не восстановлены; имена здесь назначены
по механике функций.
