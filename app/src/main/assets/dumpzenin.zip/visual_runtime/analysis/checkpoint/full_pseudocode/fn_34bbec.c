
// ================================================================================
// Official Telegram Bot: t.me/imguisource_bot
// Official Channels:
// 1. ImGui Source -> t.me/ImGui_Source_FIXNEY
// 2. shit src 🧨 -> t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x34bbec */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fn_34bbec(byte *param_1)

{
  long *plVar1;
  bool bVar2;
  int iVar3;
  long lVar4;
  undefined auVar5 [16];
  undefined auVar6 [16];
  undefined auVar7 [16];
  undefined auVar8 [16];
  bool bVar9;
  bool bVar10;
  byte bVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  uint uVar14;
  long lVar15;
  long lVar16;
  long lVar17;
  byte *pbVar18;
  undefined4 uVar19;
  uint uVar20;
  undefined *puVar21;
  ulong uVar22;
  uint uVar23;
  long *plVar24;
  long *plVar25;
  long lVar26;
  long lVar27;
  long *plVar28;
  undefined8 uVar29;
  undefined8 *puVar30;
  char cVar31;
  short sVar32;
  short sVar33;
  short sVar34;
  byte bVar49;
  byte bVar50;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  float fVar41;
  float fVar42;
  undefined8 uVar43;
  byte bVar51;
  byte bVar52;
  byte bVar53;
  byte bVar54;
  byte bVar55;
  undefined auVar44 [16];
  undefined auVar45 [16];
  undefined auVar46 [16];
  undefined auVar47 [16];
  undefined auVar48 [16];
  undefined8 uVar56;
  undefined auVar57 [16];
  ulong uVar58;
  undefined8 uVar59;
  undefined8 uVar60;
  undefined auVar61 [16];
  undefined auVar62 [16];
  float fVar63;
  double dVar64;
  undefined8 uVar65;
  float fVar66;
  undefined4 uVar67;
  float fVar68;
  float fVar69;
  float fVar70;
  float fVar71;
  undefined8 uVar72;
  undefined4 uStack_2d8c;
  float fStack_2d6c;
  float fStack_2d44;
  float fStack_2d40;
  float fStack_2d30;
  float fStack_2d20;
  float fStack_2d1c;
  long lStack_2d10;
  undefined8 uStack_2cd8;
  float fStack_2ca0;
  undefined8 uStack_2c88;
  undefined8 uStack_2c80;
  float fStack_2c78;
  float fStack_2c74;
  float fStack_2c70;
  float fStack_2c6c;
  float fStack_2c68;
  float fStack_2c64;
  char cStack_2c60;
  undefined auStack_2c5f [15];
  undefined8 uStack_2c50;
  undefined8 uStack_2c48;
  undefined8 uStack_2c40;
  undefined8 uStack_2c38;
  undefined8 uStack_2c30;
  undefined8 uStack_2c28;
  undefined8 uStack_2c20;
  undefined8 uStack_2c18;
  undefined8 uStack_2c10;
  undefined auStack_2c08 [8];
  long lStack_2c00;
  long lStack_2bf8;
  undefined auStack_2bf0 [16];
  undefined auStack_2be0 [4];
  undefined auStack_2bdc [4];
  undefined8 auStack_2bd8 [377];
  ulong uStack_2010;
  char cStack_2008;
  undefined auStack_2007 [15];
  undefined auStack_1ff8 [16];
  undefined auStack_1fe8 [13];
  undefined3 uStack_1fdb;
  undefined5 uStack_1fd8;
  ulong uStack_1fd3;
  char cStack_1fc8;
  float fStack_1fc4;
  float fStack_1fc0;
  float fStack_1fbc;
  float fStack_1fb8;
  undefined8 uStack_1fb0;
  undefined4 uStack_1fa8;
  float fStack_1fa4;
  float fStack_1fa0;
  undefined uStack_1f9c;
  undefined2 uStack_1f9b;
  undefined4 uStack_1f99;
  undefined uStack_1f95;
  float fStack_1f94;
  undefined8 uStack_1f90;
  undefined4 uStack_1f88;
  float fStack_1f84;
  float fStack_1f80;
  float fStack_1f7c;
  float fStack_1f78;
  float fStack_1f74;
  undefined auStack_1f70 [264];
  undefined auStack_1e68 [20];
  undefined auStack_1e54 [32];
  float afStack_1e34 [53];
  long lStack_1d60;
  undefined auStack_1d54 [32];
  float fStack_1d34;
  float fStack_1d30;
  float afStack_1d28 [5];
  undefined auStack_1d14 [4];
  undefined8 uStack_1d10;
  undefined8 uStack_1d08;
  undefined8 uStack_1d00;
  undefined8 uStack_1cf8;
  undefined8 uStack_1cf0;
  undefined8 uStack_1ce8;
  undefined8 uStack_1ce0;
  undefined8 uStack_1b0;
  float fStack_1a8;
  float fStack_1a4;
  undefined8 uStack_1a0;
  undefined8 uStack_198;
  undefined8 uStack_190;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined8 uStack_180;
  undefined *puStack_178;
  undefined8 uStack_170;
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined8 uStack_158;
  byte *pbStack_150;
  undefined *puStack_148;
  undefined8 uStack_140;
  undefined8 uStack_138;
  undefined8 uStack_130;
  undefined8 uStack_128;
  byte *pbStack_120;
  undefined *puStack_118;
  undefined8 uStack_110;
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f8;
  byte *pbStack_f0;
  undefined *puStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  long lStack_b8;
  
  lVar4 = tpidr_el0;
  lStack_b8 = *(long *)(lVar4 + 0x28);
  bVar11 = param_1[0x128];
  if ((bRam0000000007874e68 == 1) && (bVar11 == 0)) {
    bRam0000000007874e68 = 0;
    PTR_DAT_0654ad20[0x1c] = 1;
  }
  if ((*param_1 | bVar11) == 0) {
    imp_memset(&uStack_1fb0,0,0x1e00);
    lVar15 = 0;
    do {
      lVar16 = lVar15 + 0x50;
      *(undefined *)((long)&uStack_1f90 + lVar15) = 0;
      auStack_1f70[lVar15 + -4] = 0;
      *(undefined8 *)((long)&uStack_1fb0 + lVar15) = 0;
      *(undefined8 *)((long)&uStack_1fa8 + lVar15) = 0;
      *(undefined *)((long)&fStack_1fa0 + lVar15) = 0;
      *(undefined8 *)(auStack_1f70 + lVar15) = 0;
      *(undefined8 *)(auStack_1f70 + lVar15 + 6) = 0;
      lVar15 = lVar16;
    } while (lVar16 != 0x1e00);
    imp_memcpy(0x7873068,&uStack_1fb0,0x1e00);
    cRam0000000007875ad8 = '\0';
    uRam0000000007875ae0 = 0;
    uRam0000000007875ae4 = 0;
    fRam0000000007875ae8 = 0.0;
    fRam0000000007875aec = 0.0;
    fRam0000000007875af0 = 0.0;
    uRam0000000007875af4 = uRam0000000007875af4 & 0xffffff00;
    uRam0000000007875af8 = 0;
    uRam0000000007875b00 = uRam0000000007875b00 & 0xffffff00;
    fRam0000000007875b04 = 0.0;
    fRam0000000007875b08 = 0.0;
    cRam0000000007875b0c = '\0';
    uRam0000000007875b0d = (uint7)_uRam0000000007875b0d & 0xffffff;
    _uRam0000000007875b0d = (ulong)uRam0000000007875b0d;
    if (*(long *)(lVar4 + 0x28) == lStack_b8) {
      cRam0000000007875ad8 = 0;
      uRam0000000007875ae0 = 0;
      uRam0000000007875ae4 = 0;
      fRam0000000007875ae8 = 0.0;
      fRam0000000007875aec = 0.0;
      fRam0000000007875af0 = 0.0;
      uRam0000000007875af8 = 0;
      fRam0000000007875b04 = 0.0;
      fRam0000000007875b08 = 0.0;
      cRam0000000007875b0c = 0;
      uRam0000000007875b18 = 0;
      uRam0000000007875b20 = 0;
      uRam0000000007875b28 = 0;
      fRam0000000007875b30 = 0.0;
      fRam0000000007875b34 = 0.0;
      fRam0000000007875b38 = 0.0;
      return;
    }
    goto LAB_0044e7e4;
  }
  lVar15 = 0;
  do {
    lVar16 = lVar15 + 0x40;
    *(undefined8 *)(auStack_2c08 + lVar15 + -8) = 0;
    auStack_2c08[lVar15] = 0;
    auStack_2bf0[lVar15 + -8] = 0;
    auStack_2bdc[lVar15] = 0;
    *(undefined8 *)((long)auStack_2bd8 + lVar15) = 0;
    lVar15 = lVar16;
  } while (lVar16 != 0xc00);
  fn_63d380(0x7873040);
  imp_memcpy(&uStack_2c10,0x7874e78,0xc5c);
  fn_63d3ac(0x7873040);
  lVar15 = fn_59b958();
  uVar29 = *(undefined8 *)(lVar15 + 8);
  uStack_2c88 = uVar29;
  lVar16 = fn_59bb54();
  lVar17 = fn_59b80c();
  uStack_2c48 = 0;
  uStack_2c50 = 0;
  uStack_2c38 = 0;
  uStack_2c40 = 0;
  uStack_2c28 = 0;
  uStack_2c30 = 0;
  uStack_2c18 = 0;
  uStack_2c20 = 0;
  bVar11 = fn_4322a0(&uStack_2c50);
  if ((((lVar16 == 0) || (lVar17 == 0)) || ((float)uVar29 <= 0.0)) ||
     ((float)((ulong)uVar29 >> 0x20) <= 0.0)) {
    imp_memset(&uStack_1fb0,0,0x1e00);
    lVar15 = 0;
    do {
      lVar16 = lVar15 + 0x50;
      *(undefined *)((long)&uStack_1f90 + lVar15) = 0;
      auStack_1f70[lVar15 + -4] = 0;
      *(undefined8 *)((long)&uStack_1fb0 + lVar15) = 0;
      *(undefined8 *)((long)&uStack_1fa8 + lVar15) = 0;
      *(undefined *)((long)&fStack_1fa0 + lVar15) = 0;
      *(undefined8 *)(auStack_1f70 + lVar15) = 0;
      *(undefined8 *)(auStack_1f70 + lVar15 + 6) = 0;
      lVar15 = lVar16;
    } while (lVar16 != 0x1e00);
    imp_memcpy(0x7873068,&uStack_1fb0,0x1e00);
LAB_0044d848:
    cRam0000000007875ad8 = '\0';
    uRam0000000007875ae0 = 0;
    uRam0000000007875ae4 = 0;
    fRam0000000007875ae8 = 0.0;
    fRam0000000007875aec = 0.0;
    fRam0000000007875af0 = 0.0;
    uRam0000000007875af4 = uRam0000000007875af4 & 0xffffff00;
    uRam0000000007875af8 = 0;
    uRam0000000007875b00 = uRam0000000007875b00 & 0xffffff00;
    fRam0000000007875b04 = 0.0;
    fRam0000000007875b08 = 0.0;
    cRam0000000007875b0c = '\0';
    uRam0000000007875b0d = (uint7)_uRam0000000007875b0d & 0xffffff;
    _uRam0000000007875b0d = (ulong)uRam0000000007875b0d;
    uRam0000000007875b20 = 0;
    uRam0000000007875b18 = 0;
    fRam0000000007875b30 = 0.0;
    fRam0000000007875b34 = 0.0;
    uRam0000000007875b28 = 0;
    fRam0000000007875b38 = 0.0;
  }
  else {
    fVar35 = *(float *)(lVar15 + 0x18);
    fVar36 = 0.1;
    if (fVar35 <= 0.1) {
      fVar36 = fVar35;
    }
    fVar42 = 0.0;
    if (0.0 <= fVar35) {
      fVar42 = fVar36;
    }
    fVar36 = (float)fn_42c7f0();
    if ((bVar11 & 1) == 0) {
      imp_memset(&uStack_1fb0,0,0x1e00);
      lVar15 = 0;
      do {
        lVar27 = lVar15 + 0x50;
        *(undefined *)((long)&uStack_1f90 + lVar15) = 0;
        auStack_1f70[lVar15 + -4] = 0;
        *(undefined8 *)((long)&uStack_1fb0 + lVar15) = 0;
        *(undefined8 *)((long)&uStack_1fa8 + lVar15) = 0;
        *(undefined *)((long)&fStack_1fa0 + lVar15) = 0;
        *(undefined8 *)(auStack_1f70 + lVar15) = 0;
        *(undefined8 *)(auStack_1f70 + lVar15 + 6) = 0;
        lVar15 = lVar27;
      } while (lVar27 != 0x1e00);
LAB_0044d7d4:
      imp_memcpy(0x7873068,&uStack_1fb0,0x1e00);
    }
    else {
      if (*param_1 == 0) {
        imp_memset(&uStack_1fb0,0,0x1e00);
        lVar15 = 0;
        do {
          lVar27 = lVar15 + 0x50;
          *(undefined *)((long)&uStack_1f90 + lVar15) = 0;
          auStack_1f70[lVar15 + -4] = 0;
          *(undefined8 *)((long)&uStack_1fb0 + lVar15) = 0;
          *(undefined8 *)((long)&uStack_1fa8 + lVar15) = 0;
          *(undefined *)((long)&fStack_1fa0 + lVar15) = 0;
          *(undefined8 *)(auStack_1f70 + lVar15) = 0;
          *(undefined8 *)(auStack_1f70 + lVar15 + 6) = 0;
          lVar15 = lVar27;
        } while (lVar27 != 0x1e00);
        goto LAB_0044d7d4;
      }
      lVar15 = 0x1e00;
      puVar21 = (undefined *)0x78730b4;
      do {
        lVar15 = lVar15 + -0x50;
        *puVar21 = 0;
        puVar21 = puVar21 + 0x50;
      } while (lVar15 != 0);
      if (uStack_2010 != 0) {
        uVar22 = 0;
        plVar1 = (long *)0x7873068;
        do {
          lVar15 = uVar22 * 0x40;
          lVar27 = 0x1e00;
          lVar26 = *(long *)*(undefined (*) [16])(auStack_2c08 + lVar15 + -8);
          plVar24 = plVar1;
          do {
            if ((*(char *)((long)plVar24 + 0x4d) != '\0') && (*plVar24 == lVar26))
            goto LAB_0044bf14;
            lVar27 = lVar27 + -0x50;
            plVar24 = plVar24 + 10;
          } while (lVar27 != 0);
          lVar27 = 0x1e00;
          plVar24 = plVar1;
          do {
            if (*(char *)((long)plVar24 + 0x4d) == '\0') goto LAB_0044bee8;
            lVar27 = lVar27 + -0x50;
            plVar24 = plVar24 + 10;
          } while (lVar27 != 0);
          lVar27 = 0x1e00;
          plVar25 = (long *)0x0;
          plVar28 = plVar1;
          do {
            plVar24 = plVar25;
            if (((*(char *)((long)plVar28 + 0x4c) == '\0') &&
                (plVar24 = plVar28, plVar25 != (long *)0x0)) &&
               (*(float *)(plVar25 + 9) <= *(float *)(plVar28 + 9))) {
              plVar24 = plVar25;
            }
            lVar27 = lVar27 + -0x50;
            plVar28 = plVar28 + 10;
            plVar25 = plVar24;
          } while (lVar27 != 0);
          if (plVar24 != (long *)0x0) {
LAB_0044bee8:
            *(undefined *)(plVar24 + 2) = 0;
            *(undefined8 *)((long)plVar24 + 0x14) = 0;
            *(undefined8 *)((long)plVar24 + 0x19) = 0;
            *(undefined8 *)((long)plVar24 + 0x24) = 0;
            *(undefined8 *)((long)plVar24 + 0x34) = 0;
            *(undefined8 *)((long)plVar24 + 0x2c) = 0;
            *(undefined *)((long)plVar24 + 0x3c) = 0;
            *(undefined8 *)((long)plVar24 + 0x46) = 0;
            plVar24[8] = 0;
            *plVar24 = lVar26;
            plVar24[1] = 0;
            *(undefined *)((long)plVar24 + 0x4d) = 1;
LAB_0044bf14:
            auVar61 = *(undefined (*) [16])(auStack_2bf0 + lVar15);
            auVar44 = *(undefined (*) [16])(auStack_2be0 + lVar15);
            auVar5 = *(undefined (*) [16])(auStack_2c08 + lVar15 + -8);
            lVar27 = *(long *)(auStack_2bf0 + lVar15 + -8);
            lVar15 = (&lStack_2c00)[uVar22 * 8];
            *(undefined *)((long)plVar24 + 0x4c) = 1;
            plVar24[8] = auVar44._8_8_;
            plVar24[7] = auVar44._0_8_;
            plVar24[6] = auVar61._8_8_;
            plVar24[5] = auVar61._0_8_;
            plVar24[4] = lVar27;
            plVar24[3] = lVar15;
            plVar24[2] = auVar5._8_8_;
            plVar24[1] = auVar5._0_8_;
          }
        } while ((uVar22 < 0x2f) && (uVar22 = uVar22 + 1, uVar22 < uStack_2010));
      }
      fVar37 = *(float *)(param_1 + 8);
      lStack_2d10 = 0;
      fVar35 = 2.0;
      if (fVar37 <= 2.0) {
        fVar35 = fVar37;
      }
      fVar41 = 0.5;
      if (0.5 <= fVar37) {
        fVar41 = fVar35;
      }
      if ((param_1[0xc] != 0) && (param_1[0x30] != 0)) {
        fn_45899c();
        uStack_1fa8 = *(undefined4 *)(param_1 + 0x28);
        fVar37 = *(float *)(param_1 + 0x2c);
        fVar35 = 1.0;
        if (fVar37 <= 1.0) {
          fVar35 = fVar37;
        }
        fStack_1fa4 = 0.0;
        if (0.0 <= fVar37) {
          fStack_1fa4 = fVar35;
        }
        uStack_1fb0._0_4_ = (float)*(undefined8 *)(param_1 + 0x20);
        uStack_1fb0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x20) >> 0x20);
        uVar12 = fn_58d54c(&uStack_1fb0);
        lStack_2d10 = fn_458a44(lVar16,uVar12,uVar12);
      }
      puVar30 = (undefined8 *)0x7873068;
      lVar15 = 0;
      do {
        cVar31 = cStack_1fc8;
        if (*(char *)((long)puVar30 + 0x4d) != '\0') {
          if (*(char *)((long)puVar30 + 0x4c) == '\0') {
            fVar35 = *(float *)(puVar30 + 9) - fVar42 / 0.3;
LAB_0044c0e0:
            *(float *)(puVar30 + 9) = fVar35;
            if (fVar35 <= 0.0) {
              *puVar30 = 0;
              puVar30[1] = 0;
              *(undefined *)(puVar30 + 2) = 0;
              *(undefined8 *)((long)puVar30 + 0x14) = 0;
              *(undefined8 *)((long)puVar30 + 0x19) = 0;
              *(undefined8 *)((long)puVar30 + 0x24) = 0;
              *(undefined8 *)((long)puVar30 + 0x34) = 0;
              *(undefined8 *)((long)puVar30 + 0x2c) = 0;
              *(undefined *)((long)puVar30 + 0x3c) = 0;
              puVar30[8] = 0;
              *(undefined8 *)((long)puVar30 + 0x46) = 0;
              goto LAB_0044c094;
            }
          }
          else {
            fVar35 = fVar42 / 0.16 + *(float *)(puVar30 + 9);
            if (fVar35 < 1.0) goto LAB_0044c0e0;
            fVar35 = 1.0;
            *(undefined4 *)(puVar30 + 9) = 0x3f800000;
          }
          if (cStack_1fc8 == '\0') {
            fVar37 = 0.0;
          }
          else {
            fVar37 = *(float *)((long)puVar30 + 0x14) - fStack_1fc4;
            fVar63 = *(float *)((long)puVar30 + 0x1c) - fStack_1fbc;
            uVar12 = NEON_fmadd(fVar37,fVar37,
                                (*(float *)(puVar30 + 3) - fStack_1fc0) *
                                (*(float *)(puVar30 + 3) - fStack_1fc0));
            fVar37 = (float)NEON_fmadd(fVar63,fVar63,uVar12);
            fVar37 = SQRT(fVar37);
          }
          if (*(char *)(puVar30 + 4) == '\0') {
LAB_0044c33c:
            uVar67 = *(undefined4 *)((long)puVar30 + 0x14);
            fVar39 = *(float *)(puVar30 + 3);
            uVar12 = NEON_fmadd(uStack_2c48._4_4_,uVar67,uStack_2c38._4_4_ * fVar39);
            uVar13 = *(undefined4 *)((long)puVar30 + 0x1c);
            fVar63 = (float)NEON_fmadd(uStack_2c28._4_4_,uVar13,uVar12);
            fVar63 = uStack_2c18._4_4_ + fVar63;
            if (0.05 <= fVar63) {
              uVar12 = NEON_fmadd((undefined4)uStack_2c50,uVar67,(float)uStack_2c40 * fVar39);
              fVar40 = (float)NEON_fmadd((undefined4)uStack_2c30,uVar13,uVar12);
              if (ABS((float)uStack_2c20 + fVar40) != INFINITY) {
                uVar12 = NEON_fmadd(uStack_2c50._4_4_,uVar67,uStack_2c40._4_4_ * fVar39);
                fVar66 = (float)NEON_fmadd(uStack_2c30._4_4_,uVar13,uVar12);
                if (((ABS(uStack_2c20._4_4_ + fVar66) != INFINITY) &&
                    (fVar39 = (((float)uStack_2c20 + fVar40) / fVar63 + 1.0) * (float)uStack_2c88 *
                              0.5, ABS(fVar39) != INFINITY)) &&
                   (fVar40 = (1.0 - (uStack_2c20._4_4_ + fVar66) / fVar63) * uStack_2c88._4_4_ * 0.5
                   , ABS(fVar40) != INFINITY)) {
                  fVar63 = 260.0 / (fVar37 + 8.0);
                  fVar37 = 42.0;
                  if (fVar63 <= 42.0) {
                    fVar37 = fVar63;
                  }
                  fVar66 = 8.0;
                  if (8.0 <= fVar63) {
                    fVar66 = fVar37;
                  }
                  fVar37 = fVar41 * fVar66 * 0.38;
                  fVar63 = fVar41 * fVar66 * 0.5;
                  fVar66 = fVar63 + fVar39;
                  if (fVar37 <= fVar41 * 6.0) {
                    fVar37 = fVar41 * 6.0;
                  }
                  fVar39 = fVar39 - fVar63;
                  fVar63 = fVar40 - fVar37 * 0.5;
                  fVar40 = fVar37 * 0.5 + fVar40;
                  goto LAB_0044c474;
                }
              }
            }
          }
          else {
            fVar40 = -3.402823e+38;
            fVar63 = 3.402823e+38;
            uVar14 = 0;
            fVar66 = fVar40;
            fVar39 = fVar63;
            do {
              bVar9 = false;
              uVar12 = *(undefined4 *)((long)puVar30 + 0x24);
              if ((uVar14 & 1) != 0) {
                uVar12 = *(undefined4 *)(puVar30 + 6);
              }
              fVar38 = *(float *)(puVar30 + 5);
              if ((uVar14 & 2) != 0) {
                fVar38 = *(float *)((long)puVar30 + 0x34);
              }
              uVar13 = *(undefined4 *)((long)puVar30 + 0x2c);
              if ((uVar14 & 4) != 0) {
                uVar13 = *(undefined4 *)(puVar30 + 7);
              }
              uVar67 = NEON_fmadd(uStack_2c48._4_4_,uVar12,uStack_2c38._4_4_ * fVar38);
              fVar68 = (float)NEON_fmadd(uStack_2c28._4_4_,uVar13,uVar67);
              fVar68 = uStack_2c18._4_4_ + fVar68;
              fVar69 = 0.0;
              if (fVar68 < 0.05) {
                fVar71 = 0.0;
              }
              else {
                uVar67 = NEON_fmadd((undefined4)uStack_2c50,uVar12,(float)uStack_2c40 * fVar38);
                fVar70 = (float)NEON_fmadd((undefined4)uStack_2c30,uVar13,uVar67);
                fVar71 = 0.0;
                if (ABS((float)uStack_2c20 + fVar70) != INFINITY) {
                  uVar12 = NEON_fmadd(uStack_2c50._4_4_,uVar12,uStack_2c40._4_4_ * fVar38);
                  fVar38 = (float)NEON_fmadd(uStack_2c30._4_4_,uVar13,uVar12);
                  fVar71 = 0.0;
                  if (ABS(uStack_2c20._4_4_ + fVar38) != INFINITY) {
                    bVar9 = false;
                    fVar69 = (float)uStack_2c88 * (((float)uStack_2c20 + fVar70) / fVar68 + 1.0) *
                             0.5;
                    fVar71 = uStack_2c88._4_4_ * (1.0 - (uStack_2c20._4_4_ + fVar38) / fVar68) * 0.5
                    ;
                    if (ABS(fVar69) != INFINITY) {
                      bVar9 = INFINITY < ABS(fVar71) || ABS(fVar71) < INFINITY;
                    }
                  }
                }
              }
              if (fVar69 <= fVar39) {
                fVar39 = fVar69;
              }
              if (fVar71 <= fVar63) {
                fVar63 = fVar71;
              }
              if (fVar66 < fVar69) {
                fVar66 = fVar69;
              }
              if (fVar40 < fVar71) {
                fVar40 = fVar71;
              }
            } while ((uVar14 < 7) && (uVar14 = uVar14 + 1, bVar9));
            if ((!bVar9) ||
               ((fVar66 - fVar39 < 2.0 || fVar40 - fVar63 < 2.0) ||
                (float)uStack_2c88 * 2.5 <= fVar66 - fVar39)) goto LAB_0044c33c;
LAB_0044c474:
            fVar37 = 1.0;
            uStack_2c80 = CONCAT44((int)(fVar63 + 0.5),(int)(fVar39 + 0.5));
            fVar66 = (float)(int)(fVar66 + 0.5);
            fStack_2c74 = (float)(int)(fVar40 + 0.5);
            fStack_2c78 = fVar66;
            if (((-72.0 <= fVar66) && (-72.0 <= fStack_2c74)) &&
               (((float)(int)(fVar39 + 0.5) <= (float)uStack_2c88 + 72.0 &&
                ((float)(int)(fVar63 + 0.5) <= uStack_2c88._4_4_ + 72.0)))) {
              if (*(char *)((long)puVar30 + 0x4c) == '\0') {
                fVar35 = (float)imp_sinf();
              }
              else {
                fVar35 = 1.0 - fVar35;
                fVar35 = (float)NEON_fmadd(-(fVar35 * fVar35),fVar35,0x3f800000);
              }
              if (lStack_2d10 != 0) {
                uStack_1f90 = CONCAT44(fStack_2c74,fStack_2c78);
                uStack_1fa8 = 0;
                uStack_1fb0._0_4_ = (float)uStack_2c80;
                uStack_1fb0._4_4_ = (float)((ulong)uStack_2c80 >> 0x20);
                uStack_1f9c = (undefined)((ulong)uStack_2c80 >> 0x20);
                uStack_1f9b = (undefined2)((ulong)uStack_2c80 >> 0x28);
                uStack_1f99 = (uint)(byte)((ulong)uStack_2c80 >> 0x38);
                uStack_1f95 = 0;
                uStack_1f88 = 0;
                fStack_1f78 = 0.0;
                fStack_1fa4 = fVar35;
                fStack_1fa0 = fVar66;
                fStack_1f94 = fVar35;
                fStack_1f84 = fVar35;
                fStack_1f80 = (float)uStack_1fb0;
                fStack_1f7c = fStack_2c74;
                fStack_1f74 = fVar35;
                if (*(int *)(param_1 + 0x10) == 1) {
                  fVar39 = *(float *)(param_1 + 0x18);
                  fStack_1a8 = 0.0;
                  fVar63 = fStack_2c74 - uStack_1fb0._4_4_;
                  if (fStack_2c78 - (float)uStack_1fb0 <= fStack_2c74 - uStack_1fb0._4_4_) {
                    fVar63 = fStack_2c78 - (float)uStack_1fb0;
                  }
                  fVar40 = 0.5;
                  if (fVar39 <= 0.5) {
                    fVar40 = fVar39;
                  }
                  fVar66 = 0.1;
                  if (0.1 <= fVar39) {
                    fVar66 = fVar40;
                  }
                  fVar39 = 4.0;
                  if (4.0 <= fVar63 * fVar66) {
                    fVar39 = fVar63 * fVar66;
                  }
                  if (fVar39 <= fVar63) {
                    fVar63 = fVar39;
                  }
                  uStack_1b0._4_4_ = uStack_1fb0._4_4_ + 0.0;
                  fVar63 = (float)(int)fVar63;
                  uStack_1b0._0_4_ = fVar63 + (float)uStack_1fb0;
                  fStack_1a4 = fVar35;
                  fn_458908(lStack_2d10,&uStack_1fb0,&uStack_1b0);
                  fStack_1a8 = 0.0;
                  uStack_1b0._0_4_ = (float)uStack_1fb0 + 0.0;
                  uStack_1b0._4_4_ = fVar63 + uStack_1fb0._4_4_;
                  fStack_1a4 = fVar35;
                  fn_458908(lStack_2d10,&uStack_1fb0,&uStack_1b0);
                  fStack_1a8 = 0.0;
                  uStack_1b0._4_4_ =
                       (float)(CONCAT17((undefined)uStack_1f99,
                                        CONCAT25(uStack_1f9b,CONCAT14(uStack_1f9c,fStack_1fa0))) >>
                              0x20) + 0.0;
                  uStack_1b0._0_4_ = fStack_1fa0 - fVar63;
                  fStack_1a4 = fVar35;
                  fn_458908(lStack_2d10,&fStack_1fa0,&uStack_1b0);
                  uStack_1b0._0_4_ = fStack_1fa0 + 0.0;
                  uStack_1b0._4_4_ =
                       fVar63 + (float)(CONCAT17((undefined)uStack_1f99,
                                                 CONCAT25(uStack_1f9b,
                                                          CONCAT14(uStack_1f9c,fStack_1fa0))) >>
                                       0x20);
                  fStack_1a8 = 0.0;
                  fStack_1a4 = fVar35;
                  fn_458908(lStack_2d10,&fStack_1fa0,&uStack_1b0);
                  auVar61._0_4_ = (float)uStack_1f90 - fVar63;
                  fStack_1a8 = 0.0;
                  auVar44._0_4_ = (float)uStack_1f90 + 0.0;
                  auVar44._4_4_ = (float)((ulong)uStack_1f90 >> 0x20) + 0.0;
                  auVar44._8_8_ = 0;
                  auVar61._4_4_ = auVar44._4_4_;
                  auVar61._8_8_ = 0;
                  uStack_1b0._0_4_ = auVar61._0_4_;
                  uStack_1b0._4_4_ = auVar44._4_4_;
                  fStack_1a4 = fVar35;
                  fn_458908(auVar44,auVar61,ZEXT816(0),lStack_2d10,&uStack_1f90,&uStack_1b0);
                  uStack_1b0._0_4_ = (float)uStack_1f90 + 0.0;
                  fStack_1a8 = 0.0;
                  uStack_1b0._4_4_ = uStack_1f90._4_4_ - fVar63;
                  fStack_1a4 = fVar35;
                  fn_458908(lStack_2d10,&uStack_1f90,&uStack_1b0);
                  uStack_1b0._0_4_ = fVar63 + fStack_1f80;
                  uStack_1b0._4_4_ = fStack_1f7c + 0.0;
                  fStack_1a8 = 0.0;
                  fStack_1a4 = fVar35;
                  fn_458908(lStack_2d10,&fStack_1f80,&uStack_1b0);
                  uStack_1b0._0_4_ = fStack_1f80 + 0.0;
                  fStack_1a8 = 0.0;
                  uStack_1b0._4_4_ = fStack_1f7c - fVar63;
                  fStack_1a4 = fVar35;
                  fn_458908(lStack_2d10,&fStack_1f80,&uStack_1b0);
                  cVar31 = cStack_1fc8;
                }
                else {
                  fn_458908(lStack_2d10,&uStack_1fb0,&fStack_1fa0);
                  fn_458908(lStack_2d10,&fStack_1fa0,&uStack_1f90);
                  fn_458908(lStack_2d10,&uStack_1f90,&fStack_1f80);
                  fn_458908(lStack_2d10,&fStack_1f80,&uStack_1fb0);
                }
              }
              fVar39 = *(float *)(param_1 + 8);
              fVar63 = 2.0;
              if (fVar39 <= 2.0) {
                fVar63 = fVar39;
              }
              fVar40 = 0.5;
              if (0.5 <= fVar39) {
                fVar40 = fVar63;
              }
              if (param_1[0xc] != 0) {
                uStack_1fa8 = *(undefined4 *)(param_1 + 0x28);
                fVar39 = fVar35 * *(float *)(param_1 + 0x2c);
                fVar63 = 1.0;
                if (fVar39 <= 1.0) {
                  fVar63 = fVar39;
                }
                fStack_1fa4 = 0.0;
                if (0.0 <= fVar39) {
                  fStack_1fa4 = fVar63;
                }
                uStack_1fb0._0_4_ = (float)*(undefined8 *)(param_1 + 0x20);
                uStack_1fb0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x20) >> 0x20);
                uVar12 = fn_58d54c(&uStack_1fb0);
                if (*(int *)(param_1 + 0x10) == 1) {
                  uVar22 = NEON_ushl(CONCAT44(uVar12,uVar12),_UNK_00783fc0,4);
                  NEON_ucvtf(uVar22 & 0xff000000ff,4);
                  fn_34f264(lVar16,param_1[0x1c]);
                }
                else {
                  if (param_1[0x1c] != 0) {
                    uVar29 = NEON_fmov(0xbf800000,4);
                    uVar72 = NEON_fmov(0x3f800000,4);
                    uStack_1fb0._0_4_ = (float)uStack_2c80 + (float)uVar29;
                    fVar63 = (float)((ulong)uVar29 >> 0x20);
                    uStack_1fb0._4_4_ = (float)((ulong)uStack_2c80 >> 0x20) + fVar63;
                    uStack_1b0._0_4_ = fStack_2c78 + (float)uVar72;
                    fVar39 = (float)((ulong)uVar72 >> 0x20);
                    uStack_1b0._4_4_ = fStack_2c74 + fVar39;
                    iVar3 = (int)(long)(fVar35 * 204.0) << 0x18;
                    fn_5ba23c(lVar16,&uStack_1fb0,&uStack_1b0,iVar3,0);
                    uStack_1fb0._0_4_ = (float)uStack_2c80 + (float)uVar72;
                    uStack_1fb0._4_4_ = (float)((ulong)uStack_2c80 >> 0x20) + fVar39;
                    uStack_1b0._0_4_ = fStack_2c78 + (float)uVar29;
                    uStack_1b0._4_4_ = fStack_2c74 + fVar63;
                    fn_5ba23c(lVar16,&uStack_1fb0,&uStack_1b0,iVar3,0);
                  }
                  fn_5ba23c(lVar16,&uStack_2c80,&fStack_2c78,uVar12,0);
                }
              }
              fStack_2d6c = 0.0;
              if ((param_1[0x3c] == 0) || (*(char *)((long)puVar30 + 0x3c) == '\0')) {
                fStack_2d30 = 0.0;
                fStack_2d44 = 0.0;
                fStack_2d40 = 0.0;
              }
              else {
                fStack_2d30 = 0.0;
                fStack_2d44 = 0.0;
                fStack_2d40 = 0.0;
                if (0 < *(int *)((long)puVar30 + 0x44)) {
                  uVar14 = *(uint *)(param_1 + 0x40);
                  iVar3 = *(int *)(param_1 + 0x44);
                  fVar39 = (float)*(int *)(puVar30 + 8) / (float)*(int *)((long)puVar30 + 0x44);
                  fVar63 = 1.0;
                  if (fVar39 <= 1.0) {
                    fVar63 = fVar39;
                  }
                  fVar66 = 0.0;
                  if (0.0 <= fVar39) {
                    fVar66 = fVar63;
                  }
                  fVar63 = fVar40;
                  if (fVar40 <= 1.0) {
                    fVar63 = 1.0;
                  }
                  if (4 < iVar3) {
                    iVar3 = 5;
                  }
                  if (iVar3 < 2) {
                    iVar3 = 1;
                  }
                  uVar20 = uVar14 & 0xfffffffe;
                  if (uVar20 == 2) {
                    fStack_1a4 = fStack_2c74 - uStack_2c80._4_4_;
                    fStack_1a8 = (float)(int)(fVar63 * (float)iVar3);
                  }
                  else {
                    fStack_1a8 = fStack_2c78 - (float)uStack_2c80;
                    fStack_1a4 = (float)(int)(fVar63 * (float)iVar3);
                  }
                  fVar39 = (float)(int)(fVar40 * 3.0);
                  fVar63 = (fStack_2c78 + (float)uStack_2c80) * 0.5;
                  if ((int)uVar14 < 3) {
                    if (uVar14 == 0) {
                      fVar63 = (float)NEON_fmadd(fStack_1a8,0xbf000000,fVar63);
                      fVar38 = (uStack_2c80._4_4_ - fVar39) - fStack_1a4;
                      fStack_2d30 = 0.0;
                      fStack_2d6c = fVar39 + fStack_1a4 + 0.0;
                    }
                    else {
                      if (uVar14 == 2) {
                        fVar63 = ((float)uStack_2c80 - fVar39) - fStack_1a8;
                        fStack_2d40 = fVar39 + fStack_1a8 + 0.0;
                        fStack_2d44 = 0.0;
                        goto LAB_0044cbc0;
                      }
LAB_0044cb30:
                      fVar63 = (float)NEON_fmadd(fStack_1a8,0xbf000000,fVar63);
                      fVar38 = fVar39 + fStack_2c74 + 0.0;
                      fStack_2d6c = 0.0;
                      fStack_2d30 = fVar39 + fStack_1a4 + 0.0;
                    }
LAB_0044cb90:
                    fStack_2d44 = 0.0;
                    fStack_2d40 = 0.0;
                  }
                  else {
                    if (uVar14 != 3) {
                      if (uVar14 != 4) goto LAB_0044cb30;
                      fStack_2d6c = 0.0;
                      fVar63 = fVar63 - fStack_1a8 * 0.5;
                      fVar38 = (uStack_2c80._4_4_ + fStack_2c74) * 0.5 - fStack_1a4 * 0.5;
                      fStack_2d30 = 0.0;
                      goto LAB_0044cb90;
                    }
                    fStack_2d44 = fVar39 + fStack_1a8 + 0.0;
                    fVar63 = fVar39 + fStack_2c78 + 0.0;
                    fStack_2d40 = 0.0;
LAB_0044cbc0:
                    fStack_2d30 = 0.0;
                    fStack_2d6c = 0.0;
                    fVar38 = uStack_2c80._4_4_;
                  }
                  fVar70 = *(float *)(param_1 + 0x5c);
                  fVar69 = *(float *)(param_1 + 0x60);
                  fVar71 = *(float *)(param_1 + 0x6c);
                  fVar68 = *(float *)(param_1 + 0x70);
                  uVar72 = *(undefined8 *)(param_1 + 0x54);
                  uStack_1b0._4_4_ = (float)(int)(fVar38 + 0.5);
                  uStack_1b0._0_4_ = (float)(int)(fVar63 + 0.5);
                  fStack_1a4 = fStack_1a4 + uStack_1b0._4_4_;
                  fStack_1a8 = fStack_1a8 + (float)uStack_1b0;
                  uVar29 = *(undefined8 *)(param_1 + 100);
                  fn_5ba30c(ZEXT816(0),lVar16,&uStack_1b0,&fStack_1a8,
                            (int)(long)(fVar35 * 155.0) << 0x18,0);
                  fVar39 = fStack_1a4;
                  fVar63 = (float)uStack_1b0;
                  fStack_2c68 = fStack_1a8;
                  fStack_2c64 = fStack_1a4;
                  fStack_2c70 = (float)uStack_1b0;
                  fStack_2c6c = uStack_1b0._4_4_;
                  if (uVar20 == 2) {
                    fStack_2c6c = fStack_1a4 -
                                  (float)(int)(fVar66 * (fStack_1a4 - uStack_1b0._4_4_));
                  }
                  else {
                    fStack_2c68 = (float)uStack_1b0 +
                                  (float)(int)(fVar66 * (fStack_1a8 - (float)uStack_1b0));
                  }
                  fVar38 = fStack_2c6c;
                  if ((0.0 < fStack_2c68 - (float)uStack_1b0) && (0.0 < fStack_1a4 - fStack_2c6c)) {
                    uStack_1fb0._0_4_ = (float)uVar72;
                    uStack_1fb0._4_4_ = (float)((ulong)uVar72 >> 0x20);
                    fVar69 = (float)NEON_fmadd(fVar68 - fVar69,fVar66,fVar69);
                    uStack_1fb0._0_4_ =
                         (float)uStack_1fb0 + ((float)uVar29 - (float)uStack_1fb0) * fVar66;
                    uStack_1fb0._4_4_ =
                         uStack_1fb0._4_4_ +
                         ((float)((ulong)uVar29 >> 0x20) - uStack_1fb0._4_4_) * fVar66;
                    fVar69 = fVar35 * fVar69;
                    fVar68 = fVar37;
                    if (fVar69 <= 1.0) {
                      fVar68 = fVar69;
                    }
                    uStack_1fa8 = NEON_fmadd(fVar71 - fVar70,fVar66,fVar70);
                    fStack_1fa4 = 0.0;
                    if (0.0 <= fVar69) {
                      fStack_1fa4 = fVar68;
                    }
                    uVar13 = fn_58d54c(&uStack_1fb0);
                    uVar12 = uVar13;
                    if (param_1[0x48] != 0) {
                      uStack_1fa8 = *(undefined4 *)(param_1 + 0x5c);
                      fVar68 = fVar35 * *(float *)(param_1 + 0x60);
                      fVar66 = 1.0;
                      if (fVar68 <= 1.0) {
                        fVar66 = fVar68;
                      }
                      fStack_1fa4 = 0.0;
                      if (0.0 <= fVar68) {
                        fStack_1fa4 = fVar66;
                      }
                      uStack_1fb0._0_4_ = (float)*(undefined8 *)(param_1 + 0x54);
                      uStack_1fb0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x54) >> 0x20);
                      uVar12 = fn_58d54c(&uStack_1fb0);
                    }
                    if (param_1[0x4a] != 0) {
                      if (uVar20 == 2) {
                        fVar63 = (fVar63 + fStack_2c68) * 0.5;
                        fVar66 = fVar63;
                      }
                      else {
                        fVar39 = (fVar39 + fVar38) * 0.5;
                        fVar66 = fStack_2c68;
                        fVar38 = fVar39;
                      }
                      uVar22 = NEON_ushl(CONCAT44(uVar12,uVar12),_UNK_00783fc0,4);
                      uVar58 = NEON_ushl(CONCAT44(uVar13,uVar13),_UNK_00783fc0,4);
                      uStack_c0 = CONCAT44(fVar38,fVar66);
                      NEON_ucvtf(uVar22 & 0xff000000ff,4);
                      NEON_ucvtf(uVar58 & 0xff000000ff,4);
                      uStack_1fb0._0_4_ = fVar63;
                      uStack_1fb0._4_4_ = fVar39;
                      fn_455df4(lVar16,&uStack_1fb0,&uStack_c0,param_1[0x48]);
                    }
                    uVar67 = uVar13;
                    uVar19 = uVar12;
                    if (uVar20 == 2) {
                      uVar67 = uVar12;
                      uVar19 = uVar13;
                    }
                    fn_5ba43c(lVar16,&fStack_2c70,&fStack_2c68,uVar19,uVar13,uVar67,uVar12);
                  }
                  uVar72 = NEON_fmov(0x3f800000,4);
                  uVar29 = NEON_fmov(0xbf800000,4);
                  uStack_1fb0._0_4_ = (float)uStack_1b0 + (float)uVar29;
                  uStack_1fb0._4_4_ = uStack_1b0._4_4_ + (float)((ulong)uVar29 >> 0x20);
                  fVar63 = (float)((ulong)uVar72 >> 0x20);
                  uStack_c0 = CONCAT44(fStack_1a4 + fVar63,fStack_1a8 + (float)uVar72);
                  fn_5ba23c(ZEXT816(0),lVar16,&uStack_1fb0,&uStack_c0,
                            (int)(long)(fVar35 * 200.0) << 0x18,0);
                  if ((param_1[0x49] != 0) && (lVar27 = fn_44f9b0(), lVar27 != 0)) {
                    fn_34f5a0(&uStack_c0,8,8,&UNK_007da3ff,
                              *(uint *)(puVar30 + 8) &
                              ((int)*(uint *)(puVar30 + 8) >> 0x1f ^ 0xffffffffU));
                    fVar39 = 3.402823e+38;
                    auVar44 = fn_5c8680(fVar40 * 10.0,0x7f7fffff,ZEXT816(0),lVar27,&uStack_c0,0,0);
                    if (uVar20 == 2) {
                      uVar29 = CONCAT44(*(undefined4 *)((ulong)&fStack_2c70 | 4),
                                        ((float)uStack_1b0 + fStack_1a8) * 0.5);
                    }
                    else {
                      uVar29 = CONCAT44((uStack_1b0._4_4_ + fStack_1a4) * 0.5,fStack_2c68);
                    }
                    uStack_1fa8 = 0x3f800000;
                    fVar66 = SUB164(ZEXT816(0x3f0000003f000000),0);
                    fVar38 = SUB164(ZEXT816(0x3f0000003f000000),4);
                    uVar59 = CONCAT44(uStack_1b0._4_4_ + fVar38 * fVar39,
                                      (float)uStack_1b0 + fVar66 * auVar44._0_4_);
                    dVar64 = (double)CONCAT44(fStack_1a4,fStack_1a8) -
                             (double)CONCAT44(fVar38 * fVar39,fVar66 * auVar44._0_4_);
                    uVar43 = NEON_fcmgt(dVar64,uVar59,4);
                    uVar43 = NEON_bsl(uVar43,dVar64,uVar59,1);
                    fVar39 = fVar37;
                    if (fVar35 <= 1.0) {
                      fVar39 = fVar35;
                    }
                    uVar56 = NEON_fcmgt(uVar29,uVar43,4);
                    fStack_1fa4 = 0.0;
                    if (0.0 <= fVar35) {
                      fStack_1fa4 = fVar39;
                    }
                    uVar43 = NEON_bif(uVar43,uVar29,uVar56,1);
                    uVar29 = NEON_fcmgt(uVar59,uVar29,4);
                    uVar29 = NEON_bit(uVar43,uVar59,uVar29,1);
                    uStack_2d8c = (undefined4)((ulong)uVar29 >> 0x20);
                    uStack_1fb0._0_4_ = (float)uVar72;
                    uStack_1fb0._4_4_ = fVar63;
                    uVar14 = fn_58d54c(&uStack_1fb0);
                    uVar22 = NEON_ushl(CONCAT44(uVar14,uVar14),_UNK_00783fc0,4);
                    uVar72 = NEON_ucvtf(uVar22 & 0xff000000ff,4);
                    fVar63 = (float)((ulong)uVar72 >> 0x20) * 0.003921569;
                    auVar5._8_8_ = auVar44._8_8_;
                    auVar5._0_8_ = uVar29;
                    fn_33a490(auVar5,uStack_2d8c,ZEXT816(0),0,
                              (float)(ulong)(uVar14 & 0xff) * 0.003921569,
                              CONCAT44(fVar63,(float)uVar72 * 0.003921569),fVar63,
                              (float)(ulong)(uVar14 >> 0x18) * 0.003921569,lVar16,lVar27,&uStack_c0,
                              0,1);
                  }
                }
              }
              fVar63 = (float)(int)(fVar40 * 4.0);
              if (param_1[0x74] != 0) {
                fn_343378(*(undefined *)(puVar30 + 2));
                fn_34e8d4(&uStack_1fb0);
                if (CONCAT44(uStack_1fb0._4_4_,(float)uStack_1fb0) != 0) {
                  iVar3 = *(int *)(param_1 + 0x78);
                  fVar66 = ((float)uStack_2c80 + fStack_2c78) * 0.5;
                  fVar39 = uStack_2c80._4_4_;
                  if (iVar3 < 3) {
                    if (iVar3 == 0) {
                      fVar39 = uStack_2c80._4_4_ - fStack_2d6c;
                      fVar66 = (float)NEON_fmadd(CONCAT13(uStack_1f95,uStack_1f99._1_3_),0xbf000000,
                                                 fVar66);
                      fStack_2d6c = fStack_2d6c + fVar63 + fStack_1f94;
                      fVar39 = (fVar39 - fVar63) - fStack_1f94;
                    }
                    else if (iVar3 == 2) {
                      fVar66 = (float)uStack_2c80 - fStack_2d40;
                      fStack_2d40 = fStack_2d40 +
                                    fVar63 + (float)CONCAT13(uStack_1f95,uStack_1f99._1_3_);
                      fVar66 = (fVar66 - fVar63) - (float)CONCAT13(uStack_1f95,uStack_1f99._1_3_);
                    }
                    else {
LAB_0044d1a4:
                      fVar39 = fStack_2d30 + fStack_2c74;
                      fVar66 = (float)NEON_fmadd(CONCAT13(uStack_1f95,uStack_1f99._1_3_),0xbf000000,
                                                 fVar66);
                      fStack_2d30 = fStack_2d30 + fVar63 + fStack_1f94;
                      fVar39 = fVar63 + fVar39;
                    }
                  }
                  else if (iVar3 == 3) {
                    fVar66 = fStack_2d44 + fStack_2c78;
                    fStack_2d44 = fStack_2d44 +
                                  fVar63 + (float)CONCAT13(uStack_1f95,uStack_1f99._1_3_);
                    fVar66 = fVar63 + fVar66;
                  }
                  else {
                    if (iVar3 != 4) goto LAB_0044d1a4;
                    fVar66 = fVar66 - (float)CONCAT13(uStack_1f95,uStack_1f99._1_3_) * 0.5;
                    fVar39 = (uStack_2c80._4_4_ + fStack_2c74) * 0.5 - fStack_1f94 * 0.5;
                  }
                  fVar38 = fVar35 * *(float *)(param_1 + 0x90);
                  fStack_2c70 = (float)(int)(fVar66 + 0.5);
                  fStack_2c6c = (float)(int)(fVar39 + 0.5);
                  fStack_1a8 = *(float *)(param_1 + 0x8c);
                  fVar39 = fVar37;
                  if (fVar38 <= 1.0) {
                    fVar39 = fVar38;
                  }
                  fStack_1a4 = 0.0;
                  if (0.0 <= fVar38) {
                    fStack_1a4 = fVar39;
                  }
                  uStack_1b0._0_4_ = (float)*(undefined8 *)(param_1 + 0x84);
                  uStack_1b0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x84) >> 0x20);
                  uVar12 = fn_58d54c(&uStack_1b0);
                  fn_34ea3c(lVar16,&uStack_1fb0,&fStack_2c70,uVar12,param_1[0x81],param_1[0x94],
                            param_1[0x80]);
                }
              }
              if (param_1[0xa0] != 0) {
                iVar3 = *(int *)(param_1 + 0xe0);
                fStack_1f7c = 0.0;
                fStack_1f78 = 0.0;
                fStack_1f80 = 0.0;
                uStack_1f95 = 0;
                fStack_1f94 = 0.0;
                fStack_1fa0 = 0.0;
                uStack_1f9c = 0;
                uStack_1f9b = 0;
                uStack_1f99 = 0;
                uStack_1f88 = 0;
                fStack_1f84 = 0.0;
                uStack_1f90 = 0;
                uStack_1fa8 = 0;
                fStack_1fa4 = 0.0;
                uStack_1fb0._0_4_ = 0.0;
                uStack_1fb0._4_4_ = 0.0;
                pbVar18 = (byte *)fn_18b3c0(*(undefined *)(puVar30 + 2));
                uStack_1f9c = 0;
                if (pbVar18 != (byte *)0x0) {
                  uVar14 = (uint)*pbVar18;
                  if (*pbVar18 == 0) {
                    lVar27 = 0;
                  }
                  else {
                    lVar26 = 0;
                    do {
                      if (iVar3 == 2) {
                        uVar23 = uVar14 - 0x41;
                        uVar20 = uVar14 | 0x20;
LAB_0044d308:
                        if (0x19 < uVar23) {
                          uVar20 = uVar14;
                        }
                      }
                      else {
                        uVar20 = uVar14;
                        if (iVar3 == 1) {
                          uVar23 = uVar14 - 0x61;
                          uVar20 = uVar14 ^ 0x20;
                          goto LAB_0044d308;
                        }
                      }
                      (&uStack_1f9c)[lVar26] = (char)uVar20;
                      lVar27 = lVar26 + 1;
                    } while ((lVar26 + 1U < 0x1f) &&
                            (uVar14 = (uint)pbVar18[lVar26 + 1], lVar26 = lVar27, uVar14 != 0));
                  }
                  (&uStack_1f9c)[lVar27] = 0;
                }
                fn_34ed5c(&uStack_1fb0,param_1 + 0xa0);
                if (0.0 < fStack_1f78) {
                  bVar49 = param_1[0xe4];
                  iVar3 = *(int *)(param_1 + 0xdc);
                  fVar39 = 0.0;
                  if (bVar49 != 0) {
                    fVar39 = fVar63;
                  }
                  fVar38 = ((float)uStack_2c80 + fStack_2c78) * 0.5;
                  fVar66 = 0.0;
                  if (bVar49 != 0) {
                    fVar66 = (float)(int)(fVar40 + fVar40);
                  }
                  fVar68 = fStack_1f7c + fVar39 + fVar39;
                  fVar69 = fStack_1f78 + fVar66 + fVar66;
                  fVar40 = uStack_2c80._4_4_;
                  if (iVar3 < 3) {
                    if (iVar3 == 0) {
                      fVar40 = uStack_2c80._4_4_ - fStack_2d6c;
                      fStack_2d6c = fStack_2d6c + fVar63 + fVar69;
                      fVar68 = (float)NEON_fmadd(fVar68,0xbf000000,fVar38);
                      fVar40 = (fVar40 - fVar63) - fVar69;
                    }
                    else if (iVar3 == 2) {
                      fVar38 = (float)uStack_2c80 - fStack_2d40;
                      fStack_2d40 = fStack_2d40 + fVar63 + fVar68;
                      fVar68 = (fVar38 - fVar63) - fVar68;
                    }
                    else {
LAB_0044d414:
                      fVar40 = fStack_2d30 + fStack_2c74;
                      fVar68 = (float)NEON_fmadd(fVar68,0xbf000000,fVar38);
                      fStack_2d30 = fStack_2d30 + fVar63 + fVar69;
                      fVar40 = fVar63 + fVar40;
                    }
                  }
                  else if (iVar3 == 3) {
                    fVar38 = fStack_2d44 + fStack_2c78;
                    fStack_2d44 = fStack_2d44 + fVar63 + fVar68;
                    fVar68 = fVar63 + fVar38;
                  }
                  else {
                    if (iVar3 != 4) goto LAB_0044d414;
                    fVar68 = fVar38 - fVar68 * 0.5;
                    fVar40 = (uStack_2c80._4_4_ + fStack_2c74) * 0.5 - fVar69 * 0.5;
                  }
                  fStack_2c70 = (float)(int)(fVar68 + 0.5);
                  fStack_2c6c = (float)(int)(fVar40 + 0.5);
                  if (bVar49 != 0) {
                    uStack_1b0._4_4_ = fVar66 + fVar66 + fStack_1f78 + fStack_2c6c;
                    uStack_1b0._0_4_ = fVar39 + fVar39 + fStack_1f7c + fStack_2c70;
                    fn_5ba30c(lVar16,&fStack_2c70,&uStack_1b0,(int)(long)(fVar35 * 140.0) << 0x18,0)
                    ;
                  }
                  fVar40 = fVar35 * *(float *)(param_1 + 0xc0);
                  uStack_c0 = CONCAT44(fVar66 + fStack_2c6c,fVar39 + fStack_2c70);
                  fStack_1a8 = *(float *)(param_1 + 0xbc);
                  fVar39 = 1.0;
                  if (fVar40 <= 1.0) {
                    fVar39 = fVar40;
                  }
                  fStack_1a4 = 0.0;
                  if (0.0 <= fVar40) {
                    fStack_1a4 = fVar39;
                  }
                  uStack_1b0._0_4_ = (float)*(undefined8 *)(param_1 + 0xb4);
                  uStack_1b0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0xb4) >> 0x20);
                  uVar12 = fn_58d54c(&uStack_1b0);
                  fn_34eec4(lVar16,&uStack_1fb0,&uStack_c0,uVar12);
                }
              }
              if ((cVar31 != '\0') && (param_1[0xe8] != 0)) {
                fStack_1f7c = 0.0;
                fStack_1f78 = 0.0;
                fStack_1f80 = 0.0;
                uStack_1f95 = 0;
                fStack_1f94 = 0.0;
                fStack_1fa0 = 0.0;
                uStack_1f9c = 0;
                uStack_1f9b = 0;
                uStack_1f99 = 0;
                uStack_1f88 = 0;
                fStack_1f84 = 0.0;
                uStack_1f90 = 0;
                uStack_1fa8 = 0;
                fStack_1fa4 = 0.0;
                uStack_1fb0._0_4_ = 0.0;
                uStack_1fb0._4_4_ = 0.0;
                fn_34f08c(&uStack_1f9c,0x20);
                fn_34ed5c(&uStack_1fb0,param_1 + 0xe8);
                if (0.0 < fStack_1f78) {
                  iVar3 = *(int *)(param_1 + 0x124);
                  fVar40 = ((float)uStack_2c80 + fStack_2c78) * 0.5;
                  fVar39 = uStack_2c80._4_4_;
                  if (iVar3 < 3) {
                    if (iVar3 == 0) {
                      fVar40 = (float)NEON_fmadd(fStack_1f7c,0xbf000000,fVar40);
                      fVar39 = ((uStack_2c80._4_4_ - fStack_2d6c) - fVar63) - fStack_1f78;
                    }
                    else if (iVar3 == 2) {
                      fVar40 = (((float)uStack_2c80 - fStack_2d40) - fVar63) - fStack_1f7c;
                    }
                    else {
LAB_0044d628:
                      fVar40 = (float)NEON_fmadd(fStack_1f7c,0xbf000000,fVar40);
                      fVar39 = fVar63 + fStack_2d30 + fStack_2c74;
                    }
                  }
                  else if (iVar3 == 3) {
                    fVar40 = fVar63 + fStack_2d44 + fStack_2c78;
                  }
                  else {
                    if (iVar3 != 4) goto LAB_0044d628;
                    fVar40 = fVar40 - fStack_1f7c * 0.5;
                    fVar39 = (uStack_2c80._4_4_ + fStack_2c74) * 0.5 - fStack_1f78 * 0.5;
                  }
                  fVar35 = fVar35 * *(float *)(param_1 + 0x108);
                  fStack_2c70 = (float)(int)(fVar40 + 0.5);
                  fStack_2c6c = (float)(int)(fVar39 + 0.5);
                  fStack_1a8 = *(float *)(param_1 + 0x104);
                  if (fVar35 <= 1.0) {
                    fVar37 = fVar35;
                  }
                  fStack_1a4 = 0.0;
                  if (0.0 <= fVar35) {
                    fStack_1a4 = fVar37;
                  }
                  uStack_1b0._0_4_ = (float)*(undefined8 *)(param_1 + 0xfc);
                  uStack_1b0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0xfc) >> 0x20);
                  uVar12 = fn_58d54c(&uStack_1b0);
                  fn_34eec4(lVar16,&uStack_1fb0,&fStack_2c70,uVar12);
                }
              }
            }
          }
        }
LAB_0044c094:
        lVar27 = lVar15 + 0x50;
        puVar30 = (undefined8 *)(lVar15 + 0x78730b8);
        lVar15 = lVar27;
      } while (lVar27 != 0x1e00);
    }
    if (((param_1[0x128] == 0) ||
        (((((param_1[0x140] == 0 && (param_1[0x2d8] == 0)) && (param_1[0x19c] == 0)) &&
          ((param_1[0x1d8] == 0 && (param_1[0x214] == 0)))) &&
         ((param_1[0x250] == 0 && ((param_1[0x29c] == 0 && (param_1[0x138] == 0)))))))) ||
       ((param_1[0x129] == 0 && ((param_1[0x12a] == 0 && ((bRam0000000007874e68 & 1) == 0))))))
    goto LAB_0044d848;
    bVar9 = cStack_2008 == '\0';
    if (cStack_2008 == '\0') {
      if ((bRam0000000007874e68 & 1) != 0) {
LAB_0044d934:
        fVar35 = uStack_1fb0._4_4_;
        fStack_1fa0 = 0.0;
        uStack_1f9c = 0;
        uStack_1f9b = 0;
        uStack_1fb0._4_4_ = (float)((uint)uStack_1fb0._4_4_ & 0xffffff);
        uStack_1fa8 = 0;
        fStack_1fa4 = 0.0;
        uStack_1f99 = 0;
        cRam0000000007875ad8 = '\x01';
        uRam0000000007875ad9 = (undefined7)CONCAT44(fVar35,(float)uStack_1fb0);
        uRam0000000007875ae0 = 0;
        uRam0000000007875ae4 = 0;
        cRam0000000007875b0c = '\x01';
        fRam0000000007875aec = 0.0;
        fRam0000000007875af0 = 0.0;
        fRam0000000007875ae8 = 0.0;
        uRam0000000007875af4 = CONCAT31(uRam0000000007875af4._1_3_,0x41);
        uRam0000000007875af8 = _UNK_00783978;
        uRam0000000007875b00 = uRam0000000007875b00 & 0xffffff00;
        fRam0000000007875b04 = 0.0;
        fRam0000000007875b08 = 0.0;
        uRam0000000007875b0d = CONCAT43(0x52,(undefined3)uRam0000000007875b0d);
        _uRam0000000007875b0d = (ulong)uRam0000000007875b0d;
        fStack_1fb8 = fVar36;
        goto LAB_0044d994;
      }
      if (PTR_DAT_0654ad20[0x1c] == '\0') {
        bVar9 = false;
        bVar10 = false;
      }
      else {
        uVar22 = fn_574ac8(PTR_DAT_0654ad20,&UNK_007e267e);
        if ((uVar22 & 1) != 0) goto LAB_0044d934;
        bVar9 = false;
        bVar10 = false;
      }
    }
    else {
      uRam0000000007875b00 = auStack_1fe8._8_4_;
      uRam0000000007875af8 = auStack_1fe8._0_8_;
      uRam0000000007875ae0 = auStack_2007._7_4_;
      uRam0000000007875ae4 = auStack_2007._11_4_;
      cRam0000000007875ad8 = cStack_2008;
      uRam0000000007875ad9 = auStack_2007._0_7_;
      fRam0000000007875af0 = auStack_1ff8._8_4_;
      uRam0000000007875af4 = auStack_1ff8._12_4_;
      fRam0000000007875ae8 = auStack_1ff8._0_4_;
      fRam0000000007875aec = auStack_1ff8._4_4_;
      _uRam0000000007875b0d = uStack_1fd3;
      fRam0000000007875b04 = (float)CONCAT31(uStack_1fdb,auStack_1fe8[12]);
      fRam0000000007875b08 = (float)uStack_1fd8;
      cRam0000000007875b0c = (char)((uint5)uStack_1fd8 >> 0x20);
LAB_0044d994:
      bVar10 = cStack_2008 != '\0';
      uRam0000000007875b18 = CONCAT44(uRam0000000007875b18._4_4_,fStack_1fb8);
    }
    uVar12 = 0x41200000;
    if ((bVar9 | bVar10) == 0) {
      uVar12 = 0xc0e00000;
    }
    fVar37 = (float)NEON_fmadd(uVar12,fVar42,uRam0000000007875b18._4_4_);
    fVar35 = 1.0;
    if (fVar37 <= 1.0) {
      fVar35 = fVar37;
    }
    fVar63 = 0.0;
    fVar41 = 0.0;
    if (0.0 <= fVar37) {
      fVar41 = fVar35;
    }
    uRam0000000007875b18 = CONCAT44(fVar41,(float)uRam0000000007875b18);
    if (0.0 < fVar41 || bRam0000000007874e68 != 0) {
      if ((bVar9 == false) &&
         (fVar63 = (fVar36 - (float)uRam0000000007875b18) * 0.001, fVar63 <= 0.0)) {
        fVar63 = 0.0;
      }
      fVar36 = (float)uRam0000000007875af8 - fVar63;
      if ((bVar9 == false) && (cStack_1fc8 != '\0')) {
        cStack_1fc8 = '\x01';
        uVar12 = NEON_fmadd(fRam0000000007875ae8 - fStack_1fc4,fRam0000000007875ae8 - fStack_1fc4,
                            (fRam0000000007875aec - fStack_1fc0) *
                            (fRam0000000007875aec - fStack_1fc0));
        NEON_fmadd(fRam0000000007875af0 - fStack_1fbc,fRam0000000007875af0 - fStack_1fbc,uVar12);
      }
      fVar35 = *(float *)(param_1 + 0x1bc);
      bVar10 = bVar9;
      if (cStack_1fc8 != '\0') {
        bVar10 = true;
      }
      fVar63 = fRam0000000007875b04 - fVar63;
      if (fVar36 <= 0.0) {
        fVar36 = 0.0;
      }
      uStack_1fa8 = *(undefined4 *)(param_1 + 0x1b8);
      uStack_1fb0._0_4_ = (float)*(undefined8 *)(param_1 + 0x1b0);
      uStack_1fb0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x1b0) >> 0x20);
      uStack_c8 = 0;
      uStack_d0 = 0;
      fVar37 = 1.0;
      if (fVar35 <= 1.0) {
        fVar37 = fVar35;
      }
      uStack_d8 = 0;
      uStack_e0 = 0;
      puStack_e8 = (undefined *)0x0;
      pbStack_f0 = (byte *)0x0;
      uStack_f8 = 0;
      uStack_100 = 0;
      uStack_108 = 0;
      uStack_110 = 0;
      fStack_1fa4 = 0.0;
      if (0.0 <= fVar35) {
        fStack_1fa4 = fVar37;
      }
      puStack_118 = (undefined *)0x0;
      pbStack_120 = (byte *)0x0;
      uStack_128 = 0;
      uStack_130 = 0;
      uStack_138 = 0;
      uStack_140 = 0;
      puStack_148 = (undefined *)0x0;
      pbStack_150 = (byte *)0x0;
      uStack_158 = 0;
      uStack_160 = 0;
      uStack_168 = 0;
      uStack_170 = 0;
      puStack_178 = (undefined *)0x0;
      uStack_180._0_4_ = 0;
      uStack_180._4_4_ = 0;
      uStack_188 = 0;
      uStack_184 = 0;
      uStack_190 = 0;
      uStack_198 = 0;
      uStack_1a0 = 0;
      fStack_1a8 = 0.0;
      fStack_1a4 = 0.0;
      uStack_1b0._0_4_ = 0.0;
      uStack_1b0._4_4_ = 0.0;
      uStack_188 = fn_58d54c(&uStack_1fb0);
      fStack_1a8 = 1.131887e-38;
      fStack_1a4 = 0.0;
      uStack_190 = 0;
      uStack_1a0 = 0;
      uStack_198 = 0;
      uStack_184 = CONCAT31(uStack_184._1_3_,
                            param_1[0x19c] != 0 && (uRam0000000007875af4 & 0xff) != 0);
      uStack_1b0 = param_1 + 0x19c;
      if ((uRam0000000007875af4 & 0xff) != 0) {
        fn_34f5a0(&uStack_1a0,0x18,0x18,&UNK_007d232b);
      }
      fVar37 = *(float *)(param_1 + 0x1f8);
      uStack_1fa8 = *(undefined4 *)(param_1 + 500);
      fVar35 = 1.0;
      if (fVar37 <= 1.0) {
        fVar35 = fVar37;
      }
      fStack_1fa4 = 0.0;
      if (0.0 <= fVar37) {
        fStack_1fa4 = fVar35;
      }
      uStack_1fb0._0_4_ = (float)*(undefined8 *)(param_1 + 0x1ec);
      uStack_1fb0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x1ec) >> 0x20);
      uVar12 = fn_58d54c(&uStack_1fb0);
      puStack_178 = &UNK_007de6ec;
      uStack_160 = 0;
      uStack_170 = 0;
      uStack_168 = 0;
      fVar35 = 999.9;
      if (fVar36 <= 999.9) {
        fVar35 = fVar36;
      }
      auVar45._0_8_ = (double)fVar35;
      auVar45._8_8_ = 0;
      uStack_180 = param_1 + 0x1d8;
      fn_34f5a0(auVar45,&uStack_170,0x18,0x18,&UNK_007e6109);
      fVar37 = *(float *)(param_1 + 0x234);
      uStack_1fa8 = *(undefined4 *)(param_1 + 0x230);
      fVar35 = 1.0;
      if (fVar37 <= 1.0) {
        fVar35 = fVar37;
      }
      fStack_1fa4 = 0.0;
      if (0.0 <= fVar37) {
        fStack_1fa4 = fVar35;
      }
      uStack_1fb0._0_4_ = (float)*(undefined8 *)(param_1 + 0x228);
      uStack_1fb0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x228) >> 0x20);
      uVar12 = fn_58d54c(&uStack_1fb0);
      puStack_148 = &UNK_007fd206;
      bVar2 = false;
      if (param_1[0x214] != 0) {
        bVar2 = bVar10;
      }
      uStack_130 = 0;
      uStack_140 = 0;
      uStack_138 = 0;
      pbStack_150 = param_1 + 0x214;
      fn_34f08c(&uStack_140,0x18);
      puVar30 = (undefined8 *)(param_1 + 0x264);
      if (cRam0000000007875b14 != '\0') {
        puVar30 = (undefined8 *)(param_1 + 0x28c);
      }
      uStack_1fa8 = *(undefined4 *)(puVar30 + 1);
      fVar37 = *(float *)((long)puVar30 + 0xc);
      fVar35 = 1.0;
      if (fVar37 <= 1.0) {
        fVar35 = fVar37;
      }
      fStack_1fa4 = 0.0;
      if (0.0 <= fVar37) {
        fStack_1fa4 = fVar35;
      }
      uStack_1fb0._0_4_ = (float)*puVar30;
      uStack_1fb0._4_4_ = (float)((ulong)*puVar30 >> 0x20);
      uVar12 = fn_58d54c(&uStack_1fb0);
      puStack_118 = &UNK_007edd62;
      uStack_100 = 0;
      uStack_110 = 0;
      uStack_108 = 0;
      pbStack_120 = param_1 + 0x250;
      if (cRam0000000007875b14 == '\0') {
        fn_34f5a0(&uStack_110,0x18,0x18,&UNK_007bc1e3,
                  uRam0000000007875b0d._3_4_ &
                  ((int)uRam0000000007875b0d._3_4_ >> 0x1f ^ 0xffffffffU));
      }
      else {
        fn_34f5a0(&uStack_110,0x18,0x18,&UNK_007b8bb3,&UNK_00787db1);
      }
      fVar37 = *(float *)(param_1 + 700);
      fVar35 = 1.0;
      if (fVar37 <= 1.0) {
        fVar35 = fVar37;
      }
      fStack_1fa4 = 0.0;
      if (0.0 <= fVar37) {
        fStack_1fa4 = fVar35;
      }
      uStack_1fa8 = *(undefined4 *)(param_1 + 0x2b8);
      uStack_1fb0._0_4_ = (float)*(undefined8 *)(param_1 + 0x2b0);
      uStack_1fb0._4_4_ = (float)((ulong)*(undefined8 *)(param_1 + 0x2b0) >> 0x20);
      uVar12 = fn_58d54c(&uStack_1fb0);
      puStack_e8 = &UNK_007f18d5;
      uStack_d0 = 0;
      uStack_e0 = 0;
      fVar35 = 99.9;
      if (fVar63 <= 99.9) {
        fVar35 = fVar63;
      }
      uStack_d8 = 0;
      auVar46._0_8_ = (double)fVar35;
      auVar46._8_8_ = 0;
      pbStack_f0 = param_1 + 0x29c;
      fn_34f5a0(auVar46,&uStack_e0,0x18,0x18,&UNK_007e6109);
      uVar29 = uRam0000000007875b28;
      auVar44 = NEON_fmov(0x41600000,4);
      auVar61 = NEON_fmov(0x41300000,4);
      uVar72 = NEON_cmeq((ulong)CONCAT16(uStack_f8._4_1_,
                                         (uint6)CONCAT14(uStack_128._4_1_,
                                                         (uint)CONCAT12(uStack_158._4_1_,
                                                                        (ushort)(byte)uStack_184))),
                         0,2);
      sVar32 = (short)((ulong)uVar72 >> 0x10);
      auVar47._4_4_ = (int)sVar32;
      auVar47._0_4_ = (int)(short)uVar72;
      sVar33 = (short)((ulong)uVar72 >> 0x20);
      sVar34 = (short)((ulong)uVar72 >> 0x30);
      auVar47._12_4_ = (int)sVar34;
      auVar47._8_4_ = (int)sVar33;
      auVar44 = NEON_bsl(auVar47,auVar61,auVar44,1);
      auVar61 = NEON_fmov(0x3f800000,4);
      auVar6._12_4_ = -auVar44._12_4_ * fVar42;
      auVar6._8_4_ = -auVar44._8_4_ * fVar42;
      bVar49 = (byte)((ulong)uVar72 >> 8);
      bVar50 = (byte)((short)uVar72 >> 0xf);
      bVar51 = (byte)((ulong)uVar72 >> 0x10);
      bVar52 = (byte)((ulong)uVar72 >> 0x18);
      bVar53 = (byte)(sVar32 >> 0xf);
      bVar54 = (byte)(sVar33 >> 0xf);
      bVar55 = (byte)(sVar34 >> 0xf);
      fVar41 = (float)CONCAT13(auVar61[3] & ~bVar50,
                               CONCAT12(auVar61[2] & ~bVar50,
                                        CONCAT11(auVar61[1] & ~bVar49,auVar61[0] & ~(byte)uVar72)));
      fStack_2d20 = (float)uRam0000000007875b20;
      fStack_2d1c = (float)((ulong)uRam0000000007875b20 >> 0x20);
      fVar39 = (float)imp_expf();
      auVar6._4_4_ = -auVar44._4_4_ * fVar42;
      auVar6._0_4_ = -auVar44._0_4_ * fVar42;
      fVar40 = (float)imp_expf(auVar6);
      fVar66 = (float)imp_expf();
      fVar38 = (float)imp_expf();
      fVar37 = fRam0000000007875b30;
      cVar31 = uStack_c8._4_1_;
      fVar35 = 0.0;
      if (uStack_c8._4_1_ != '\0') {
        fVar35 = 1.0;
      }
      fVar35 = fVar35 - fRam0000000007875b30;
      auVar57._0_4_ = fStack_2d20 + (auVar61._0_4_ - fVar40) * (fVar41 - fStack_2d20);
      auVar57._4_4_ =
           fStack_2d1c +
           (auVar61._4_4_ - fVar39) *
           ((float)(CONCAT17(auVar61[7] & ~bVar53,
                             CONCAT16(auVar61[6] & ~bVar53,
                                      CONCAT15(auVar61[5] & ~bVar52,
                                               CONCAT14(auVar61[4] & ~bVar51,fVar41)))) >> 0x20) -
           fStack_2d1c);
      auVar57._8_4_ = (float)uVar29 + (auVar61._8_4_ - fVar66) * (float)uStack_2cd8;
      auVar57._12_4_ =
           (float)((ulong)uVar29 >> 0x20) +
           (auVar61._12_4_ - fVar38) * (float)((ulong)uStack_2cd8 >> 0x20);
      auVar48._8_4_ = 0x3b03126f;
      auVar48._0_8_ = 0x3b03126f3b03126f;
      auVar48._12_4_ = 0x3b03126f;
      auVar44 = NEON_fcmgt(auVar48,auVar57,4);
      auVar62._0_8_ =
           CONCAT17((byte)((uint)auVar57._4_4_ >> 0x18) & ~(bVar53 & auVar44[7]),
                    CONCAT16((byte)((uint)auVar57._4_4_ >> 0x10) & ~(bVar53 & auVar44[6]),
                             CONCAT15((byte)((uint)auVar57._4_4_ >> 8) & ~(bVar52 & auVar44[5]),
                                      CONCAT14(SUB41(auVar57._4_4_,0) & ~(bVar51 & auVar44[4]),
                                               CONCAT13((byte)((uint)auVar57._0_4_ >> 0x18) &
                                                        ~(bVar50 & auVar44[3]),
                                                        CONCAT12((byte)((uint)auVar57._0_4_ >> 0x10)
                                                                 & ~(bVar50 & auVar44[2]),
                                                                 CONCAT11((byte)((uint)auVar57._0_4_
                                                                                >> 8) &
                                                                          ~(bVar49 & auVar44[1]),
                                                                          SUB41(auVar57._0_4_,0) &
                                                                          ~((byte)uVar72 &
                                                                           auVar44[0]))))))));
      auVar62[8] = SUB41(auVar57._8_4_,0) & ~((byte)((ulong)uVar72 >> 0x20) & auVar44[8]);
      auVar62[9] = (byte)((uint)auVar57._8_4_ >> 8) & ~((byte)((ulong)uVar72 >> 0x28) & auVar44[9]);
      auVar62[10] = (byte)((uint)auVar57._8_4_ >> 0x10) & ~(bVar54 & auVar44[10]);
      auVar62[11] = (byte)((uint)auVar57._8_4_ >> 0x18) & ~(bVar54 & auVar44[11]);
      auVar62[12] = SUB41(auVar57._12_4_,0) & ~((byte)((ulong)uVar72 >> 0x30) & auVar44[12]);
      auVar62[13] = (byte)((uint)auVar57._12_4_ >> 8) &
                    ~((byte)((ulong)uVar72 >> 0x38) & auVar44[13]);
      auVar62[14] = (byte)((uint)auVar57._12_4_ >> 0x10) & ~(bVar55 & auVar44[14]);
      auVar62[15] = (byte)((uint)auVar57._12_4_ >> 0x18) & ~(bVar55 & auVar44[15]);
      uRam0000000007875b28 = auVar62._8_8_;
      uRam0000000007875b20 = auVar62._0_8_;
      fVar41 = (float)imp_expf();
      fVar36 = fVar36 / uRam0000000007875af8._4_4_;
      fVar35 = (float)NEON_fmadd(fVar35,1.0 - fVar41,fVar37);
      fRam0000000007875b30 = 0.0;
      if (0.002 <= fVar35 || cVar31 != '\0') {
        fRam0000000007875b30 = fVar35;
      }
      fStack_2ca0 = 0.0;
      if (uRam0000000007875af8._4_4_ <= 0.0) {
        fVar36 = 0.0;
      }
      if (((char)uRam0000000007875b00 != '\0') && (0.0 < fRam0000000007875b08)) {
        fStack_2ca0 = 1.0 - fVar63 / fRam0000000007875b08;
      }
      fVar42 = (float)imp_expf(fVar42 * -12.0,fVar42);
      fVar37 = *(float *)(param_1 + 0x134);
      uStack_1d10 = 0;
      fVar35 = 3.0;
      if (fVar37 <= 3.0) {
        fVar35 = fVar37;
      }
      uStack_1d08 = (ulong)uStack_1d08._6_2_ << 0x30;
      fVar41 = 0.5;
      if (0.5 <= fVar37) {
        fVar41 = fVar35;
      }
      fRam0000000007875b34 = fRam0000000007875b34 + (fVar36 - fRam0000000007875b34) * (1.0 - fVar42)
      ;
      fRam0000000007875b38 =
           fRam0000000007875b38 + (fStack_2ca0 - fRam0000000007875b38) * (1.0 - fVar42);
      fVar35 = fVar41 * 12.0;
      fVar36 = fVar41 * 24.0;
      fVar42 = fVar35 + fVar35;
      imp_memset(&uStack_1fb0,0,0x29c);
      uStack_1ce0 = 0;
      uStack_1cf8 = 0;
      uStack_1d00 = 0;
      uStack_1ce8 = 0;
      uStack_1cf0 = 0;
      if ((param_1[0x140] | param_1[0x2d8]) != 0) {
        if (param_1[0x140] != 0) {
          fn_34e8d4(&fStack_2c70,0x68);
          auVar7._8_4_ = fStack_2c68;
          auVar7._0_8_ = CONCAT44(fStack_2c6c,fStack_2c70);
          auVar7._12_4_ = fStack_2c64;
          auVar8._1_15_ = auStack_2c5f;
          auVar8[0] = cStack_2c60;
          uStack_1d08 = auVar7._8_8_;
          uStack_1d10 = CONCAT44(fStack_2c6c,fStack_2c70);
          uStack_1cf8 = auStack_2c5f._7_8_;
          uStack_1d00 = auVar8._0_8_;
        }
        fVar42 = fVar42 + fVar36 + fVar35;
      }
      puVar30 = &uStack_1a0;
      bVar10 = true;
      lVar15 = -0x140;
      lVar27 = 0x288;
      do {
        fn_34f5a0(auStack_1e54 + lVar15,0x20,0x20,&UNK_007b8bb3,puVar30[-1]);
        fn_34f5a0(auStack_1d14 + lVar15,0x20,0x20,&UNK_007b8bb3,puVar30);
        if (param_1[0x160] != 0) {
          fn_34ed5c(auStack_1e68 + lVar15,param_1 + 0x160);
          fVar35 = *(float *)((long)afStack_1e34 + lVar15 + 4);
          if (fVar35 <= (float)uStack_1cf0) {
            fVar35 = (float)uStack_1cf0;
          }
          uStack_1cf0 = CONCAT44(uStack_1cf0._4_4_,fVar35);
        }
        fn_34ed5c((long)afStack_1d28 + lVar15,puVar30[-2]);
        if (*(char *)puVar30[-2] != '\0') {
          fVar35 = *(float *)((long)&uStack_1cf0 + lVar15);
          if (*(float *)((long)&uStack_1cf0 + lVar15) <= uStack_1cf0._4_4_) {
            fVar35 = uStack_1cf0._4_4_;
          }
          uStack_1cf0 = CONCAT44(fVar35,(float)uStack_1cf0);
        }
        fVar37 = *(float *)(lVar27 + 0x7875898);
        fVar35 = 1.0;
        if (fVar37 <= 1.0) {
          fVar35 = fVar37;
        }
        fVar63 = 0.0;
        if (0.0 <= fVar37) {
          fVar63 = fVar35;
        }
        fVar35 = (float)NEON_fmadd(fVar63,0xc0000000,0x40400000);
        fVar35 = fVar63 * fVar63 * fVar35;
        if (0.001 < fVar35) {
          fVar37 = *(float *)((long)&uStack_1cf8 + lVar15 + 4);
          if (((lVar15 == -0x40) && (param_1[0x2d8] != 0)) && (lStack_1d60 != 0)) {
            fn_45c63c(&fStack_2c70,lStack_1d60,auStack_1d54);
            if (cStack_2c60 == '\0') {
              fVar37 = fStack_1d30 * 0.7;
            }
            else {
              fVar37 = fStack_2c64 - fStack_2c6c;
            }
            fVar37 = (float)(int)(fVar37 * 0.5) + (float)(int)(fVar37 * 0.5);
            if (fVar37 <= 8.0) {
              fVar37 = 8.0;
            }
            uStack_1ce8 = CONCAT44((int)(fVar41 * 4.0),fVar37);
            fVar63 = fStack_1d34;
            if (cStack_2c60 != '\0') {
              fVar63 = (float)(int)fStack_2c68;
            }
            fVar39 = fStack_1d30;
            if (cStack_2c60 != '\0') {
              fVar39 = fStack_2c6c + fStack_2c64;
            }
            fVar37 = fVar37 + (float)(int)(fVar41 * 4.0) + fVar63;
            uStack_1ce0 = CONCAT44(fVar39 * 0.5,fVar63);
          }
          if (fVar37 <= *(float *)((long)afStack_1e34 + lVar15)) {
            fVar37 = *(float *)((long)afStack_1e34 + lVar15);
          }
          fVar37 = (float)NEON_fmadd(fVar41,0x40c00000,fVar37);
          if (fVar37 <= fVar41 * 42.0) {
            fVar37 = fVar41 * 42.0;
          }
          fVar63 = 0.0;
          if (!bVar10) {
            fVar63 = fVar41 * 10.0 * fVar35;
          }
          *(float *)((long)&uStack_1fb0 + lVar27) = fVar35 * fVar37;
          fVar42 = fVar42 + fVar63 + fVar35 * fVar37;
          bVar10 = false;
        }
        lVar15 = lVar15 + 0x40;
        lVar27 = lVar27 + 4;
        puVar30 = puVar30 + 6;
      } while (lVar15 != 0);
      fVar42 = (float)(int)fVar42;
      fVar35 = fVar41;
      if ((float)uStack_1cf0 <= 0.0) {
        fVar35 = 0.0;
      }
      fVar37 = uStack_1cf0._4_4_ + (float)uStack_1cf0 + fVar35;
      fVar35 = fVar36;
      if (fVar36 <= fVar37) {
        fVar35 = fVar37;
      }
      if (fVar35 <= fVar41 * 20.0) {
        fVar35 = fVar41 * 20.0;
      }
      fVar37 = 2.0;
      fVar35 = (float)NEON_fmadd(fVar41 * 8.0,0x40000000,fVar35);
      fVar35 = (float)(int)fVar35;
      uStack_1fb0._0_4_ = fVar42;
      uStack_1fb0._4_4_ = fVar35;
      if (bRam0000000007874e68 == 1) {
        lVar15 = fn_348680();
        fStack_2c70 = 0.0;
        fStack_2c6c = 0.0;
        uStack_2c80 = 0;
        fn_5ab268(&fStack_2c70,0,&uStack_2c80);
        fn_5a23b8(&uStack_2c88,0);
        fn_5afdc4();
        fStack_2c70 = 0.0;
        fStack_2c6c = 0.0;
        fn_58f980(2,&fStack_2c70);
        fn_58f7b8(ZEXT816(0),4);
        uVar22 = fn_5a23e4(&UNK_00793813,0,0x301bf);
        fn_58fa6c(2);
        if ((uVar22 & 1) != 0) {
          uVar29 = fn_5ab334();
          fStack_2c70 = 0.0;
          fStack_2c6c = 0.0;
          fn_5ba30c(ZEXT816(0),uVar29,&fStack_2c70,&uStack_2c88,0x6e000000,0);
          uStack_2c80 = CONCAT44((float)((ulong)uStack_2c88 >> 0x20) - fVar36,
                                 (float)uStack_2c88 - fVar36);
          fStack_2c70 = fVar36;
          fStack_2c6c = fVar36;
          fn_5ba23c(uVar29,&fStack_2c70,&uStack_2c80,0x28ffffff,0);
          lVar16 = fn_59b958();
          uVar56 = NEON_fmov(0x3f800000,4);
          uVar43 = *(undefined8 *)(param_1 + 300);
          uVar72 = NEON_fcmgt(uVar43,uVar56,4);
          uVar72 = NEON_bsl(uVar72,uVar56,uVar43,1);
          uVar59 = NEON_fcmlt(uVar43,0,4);
          uVar43 = NEON_fmaxnm(CONCAT44(((float)((ulong)uStack_2c88 >> 0x20) -
                                        SUB164(ZEXT816(0x4000000040000000),4) * fVar36) -
                                        uStack_1fb0._4_4_,
                                        ((float)uStack_2c88 -
                                        SUB164(ZEXT816(0x4000000040000000),0) * fVar36) -
                                        (float)uStack_1fb0),0,4);
          fVar35 = (float)CONCAT13((byte)((ulong)uVar72 >> 0x18) & ~(byte)((ulong)uVar59 >> 0x18),
                                   CONCAT12((byte)((ulong)uVar72 >> 0x10) &
                                            ~(byte)((ulong)uVar59 >> 0x10),
                                            CONCAT11((byte)((ulong)uVar72 >> 8) &
                                                     ~(byte)((ulong)uVar59 >> 8),
                                                     (byte)uVar72 & ~(byte)uVar59)));
          fStack_2c70 = (float)(int)(fVar36 + (float)uVar43 * fVar35);
          fStack_2c6c = (float)(int)(fVar36 + (float)((ulong)uVar43 >> 0x20) *
                                              (float)(CONCAT17((byte)((ulong)uVar72 >> 0x38) &
                                                               ~(byte)((ulong)uVar59 >> 0x38),
                                                               CONCAT16((byte)((ulong)uVar72 >> 0x30
                                                                              ) & ~(byte)((ulong)
                                                  uVar59 >> 0x30),
                                                  CONCAT15((byte)((ulong)uVar72 >> 0x28) &
                                                           ~(byte)((ulong)uVar59 >> 0x28),
                                                           CONCAT14((byte)((ulong)uVar72 >> 0x20) &
                                                                    ~(byte)((ulong)uVar59 >> 0x20),
                                                                    fVar35)))) >> 0x20));
          fn_5ae320(&fStack_2c70);
          fn_5d5068(&UNK_007a444c,&uStack_1fb0,0);
          uVar22 = fn_5a8120();
          if ((uVar22 & 1) != 0) {
            fRam0000000007874e6c = *(float *)(lVar16 + 0xd8) - fStack_2c70;
            fRam0000000007874e70 = *(float *)(lVar16 + 0xdc) - fStack_2c6c;
          }
          uVar22 = fn_5a80f8();
          if ((uVar22 & 1) == 0) {
            uVar72 = 0x3cffffff;
          }
          else {
            uVar72 = 0x78ffffff;
            uVar59 = CONCAT44(((float)((ulong)uStack_2c88 >> 0x20) +
                              SUB164(ZEXT816(0x4000000040000000),4) * -fVar36) - uStack_1fb0._4_4_,
                              ((float)uStack_2c88 + SUB164(ZEXT816(0x4000000040000000),0) * -fVar36)
                              - (float)uStack_1fb0);
            uVar43 = NEON_fmaxnm(uVar59,uVar56,4);
            uVar43 = CONCAT44((((float)((ulong)*(undefined8 *)(lVar16 + 0xd8) >> 0x20) -
                               fRam0000000007874e70) - fVar36) / (float)((ulong)uVar43 >> 0x20),
                              (((float)*(undefined8 *)(lVar16 + 0xd8) - fRam0000000007874e6c) -
                              fVar36) / (float)uVar43);
            uVar60 = NEON_fcmgt(uVar43,uVar56,4);
            uVar65 = NEON_fcmlt(uVar43,0,4);
            uVar43 = NEON_bit(uVar43,uVar56,uVar60,1);
            bVar11 = (byte)uVar43 & ~(byte)uVar65;
            bVar49 = (byte)((ulong)uVar43 >> 8) & ~(byte)((ulong)uVar65 >> 8);
            bVar50 = (byte)((ulong)uVar43 >> 0x10) & ~(byte)((ulong)uVar65 >> 0x10);
            bVar51 = (byte)((ulong)uVar43 >> 0x18) & ~(byte)((ulong)uVar65 >> 0x18);
            bVar52 = (byte)((ulong)uVar43 >> 0x20) & ~(byte)((ulong)uVar65 >> 0x20);
            bVar53 = (byte)((ulong)uVar43 >> 0x28) & ~(byte)((ulong)uVar65 >> 0x28);
            bVar54 = (byte)((ulong)uVar43 >> 0x30) & ~(byte)((ulong)uVar65 >> 0x30);
            bVar55 = (byte)((ulong)uVar43 >> 0x38) & ~(byte)((ulong)uVar65 >> 0x38);
            uVar43 = CONCAT17(bVar55,CONCAT16(bVar54,CONCAT15(bVar53,CONCAT14(bVar52,CONCAT13(bVar51
                                                  ,CONCAT12(bVar50,CONCAT11(bVar49,bVar11)))))));
            uVar59 = NEON_fmaxnm(uVar59,0,4);
            uVar56 = NEON_fcmlt(uVar43,0,4);
            *(undefined8 *)(lVar15 + 300) = uVar43;
            fVar35 = (float)CONCAT13(bVar51 & ~(byte)((ulong)uVar56 >> 0x18),
                                     CONCAT12(bVar50 & ~(byte)((ulong)uVar56 >> 0x10),
                                              CONCAT11(bVar49 & ~(byte)((ulong)uVar56 >> 8),
                                                       bVar11 & ~(byte)uVar56)));
            fStack_2c70 = (float)(int)(fVar36 + (float)uVar59 * fVar35);
            fStack_2c6c = (float)(int)(fVar36 + (float)((ulong)uVar59 >> 0x20) *
                                                (float)(CONCAT17(bVar55 & ~(byte)((ulong)uVar56 >>
                                                                                 0x38),
                                                                 CONCAT16(bVar54 & ~(byte)((ulong)
                                                  uVar56 >> 0x30),
                                                  CONCAT15(bVar53 & ~(byte)((ulong)uVar56 >> 0x28),
                                                           CONCAT14(bVar52 & ~(byte)((ulong)uVar56
                                                                                    >> 0x20),fVar35)
                                                          ))) >> 0x20));
          }
          fn_34f644(uVar29,param_1 + 0x128,&uStack_1b0,&uStack_1fb0,&fStack_2c70);
          uVar59 = NEON_fmov(0x40400000,4);
          uVar43 = NEON_fmov(0xc0400000,4);
          uStack_2c80 = CONCAT44(fStack_2c6c + (float)((ulong)uVar43 >> 0x20),
                                 fStack_2c70 + (float)uVar43);
          uStack_c0 = CONCAT44(fStack_2c6c + uStack_1fb0._4_4_ + (float)((ulong)uVar59 >> 0x20),
                               fStack_2c70 + (float)uStack_1fb0 + (float)uVar59);
          fn_5ba23c(uVar29,&uStack_2c80,&uStack_c0,uVar72,0);
          puVar21 = PTR_DAT_0654ad20;
          fVar35 = *(float *)PTR_DAT_0654ad20;
          fVar36 = 2.0;
          if (fVar35 <= 2.0) {
            fVar36 = fVar35;
          }
          fVar42 = 0.75;
          if (0.75 <= fVar35) {
            fVar42 = fVar36;
          }
          fVar36 = (float)uStack_2c88 * 0.5;
          fVar35 = (float)NEON_fmadd(fVar42,0xc2800000,uStack_2c88._4_4_);
          uStack_2c80 = CONCAT44(fVar35,fVar36 - fVar42 * 64.0);
          uVar22 = fn_34fd80(uVar29,&UNK_007bfb1a,&UNK_007d232e,&uStack_2c80);
          if ((uVar22 & 1) != 0) {
            *(undefined8 *)(lVar15 + 300) = 0x3f00000000000000;
          }
          uStack_2c80 = CONCAT44(fVar35 + 0.0,fVar36 + fVar42 * 64.0);
          uVar22 = fn_34fd80(uVar29,&UNK_00800e1a,&UNK_007f18dc,&uStack_2c80);
          if ((uVar22 & 1) != 0) {
            bRam0000000007874e68 = 0;
            puVar21[0x1c] = 1;
          }
        }
        fn_5a7280();
      }
      else {
        if ((byte)(bVar9 | param_1[0x12a] == 0 | (bVar11 ^ 0xff) & 1) == 0) {
          fStack_2c70 = 0.0;
          fStack_2c6c = 0.0;
          uVar22 = fn_34e7e8(0x7875ae8,&uStack_2c50,&uStack_2c88,&fStack_2c70);
          if ((uVar22 & 1) != 0) {
            fVar37 = (float)NEON_fmadd(fVar42,0xbf000000,fStack_2c70);
            fVar36 = (float)NEON_fmadd(fVar41,0xc1400000,fStack_2c6c - fVar35);
            uStack_2c80 = CONCAT44(fVar36,fVar37);
            if (((0.0 < fVar42 + fVar37) && (fVar37 < (float)uStack_2c88)) &&
               ((fVar37 = uStack_2c88._4_4_, fVar36 < uStack_2c88._4_4_ && (0.0 < fVar35 + fVar36)))
               ) {
              fVar37 = fRam0000000007875b38;
              fn_34f644(lVar16,param_1 + 0x128,&uStack_1b0,&uStack_1fb0,&uStack_2c80);
            }
          }
        }
        if (param_1[0x129] != 0) {
          fStack_2c70 = (float)fn_34fd30(param_1 + 0x128,&uStack_2c88,&uStack_1fb0);
          fStack_2c6c = fVar37;
          fn_34f644(lVar17,param_1 + 0x128,&uStack_1b0,&uStack_1fb0,&fStack_2c70);
        }
      }
    }
  }
  if (*(long *)(lVar4 + 0x28) == lStack_b8) {
    return;
  }
LAB_0044e7e4:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

