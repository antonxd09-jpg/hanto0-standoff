
// ================================================================================
// Источник: @imguisource_bot | ImGui Source: @ImGui_Source_FIXNEY | shit src 🧨: @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x382654 */

void fn_382654(ulong *param_1,char *param_2)

{
  undefined4 uVar1;
  long lVar2;
  undefined8 *puVar3;
  ulong uVar4;
  long lVar5;
  long lVar6;
  long lVar7;
  long lVar8;
  undefined8 *puVar9;
  ulong uVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined8 uVar14;
  long lVar15;
  ulong uVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined4 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  
  lVar2 = tpidr_el0;
  lVar5 = *(long *)(lVar2 + 0x28);
  if (*param_2 != '\0') {
    if (param_2[1] == '\0') {
      uVar21 = 0;
      uVar22 = 0;
      uVar23 = 0;
      uVar24 = 0;
    }
    else {
      uVar21 = *(undefined4 *)(param_2 + 0x14);
      uVar22 = *(undefined4 *)(param_2 + 0x18);
      uVar23 = *(undefined4 *)(param_2 + 0x1c);
      uVar24 = *(undefined4 *)(param_2 + 0x20);
    }
    lVar15 = 0x787e5c0;
    lVar6 = 0;
    do {
      if ((*(char *)(lVar15 + 0x888) != '\0') && (*(long *)(lVar15 + 0x600) != 0)) {
        uVar16 = 0;
        do {
          if (uVar16 == 0x40) {
            if (*(long *)(lVar2 + 0x28) == lVar5) {
                    /* WARNING: Subroutine does not return */
              fn_125954(&UNK_007cf662);
            }
            goto LAB_00482908;
          }
          puVar11 = (undefined8 *)(lVar15 + uVar16 * 0x18 + 8);
          uVar4 = fn_198128(*puVar11);
          if ((uVar4 & 1) != 0) {
            puVar12 = (undefined8 *)param_1[1];
            uVar18 = *(undefined8 *)(param_2 + 0xc);
            uVar17 = *(undefined8 *)(param_2 + 4);
            uVar14 = *puVar11;
            uVar1 = *(undefined4 *)(lVar15 + uVar16 * 0x18 + 0x10);
            if (puVar12 < (undefined8 *)param_1[2]) {
              *puVar12 = uVar14;
              *(undefined4 *)(puVar12 + 1) = 1;
              puVar11 = puVar12 + 6;
              *(undefined8 *)((long)puVar12 + 0x14) = uVar18;
              *(undefined8 *)((long)puVar12 + 0xc) = uVar17;
              *(undefined4 *)((long)puVar12 + 0x1c) = uVar21;
              *(undefined4 *)(puVar12 + 4) = uVar22;
              *(undefined4 *)((long)puVar12 + 0x24) = uVar23;
              *(undefined4 *)(puVar12 + 5) = uVar24;
              *(undefined4 *)((long)puVar12 + 0x2c) = uVar1;
            }
            else {
              puVar13 = (undefined8 *)*param_1;
              lVar8 = (long)puVar12 - (long)puVar13 >> 4;
              uVar4 = lVar8 * -0x5555555555555555 + 1;
              if (0x555555555555555 < uVar4) {
                if (*(long *)(lVar2 + 0x28) == lVar5) {
                  fn_34ba14(param_1);
LAB_004828f0:
                  if (*(long *)(lVar2 + 0x28) == lVar5) {
                    fn_13edb4();
                  }
                }
                goto LAB_00482908;
              }
              lVar7 = (long)(undefined8 *)param_1[2] - (long)puVar13 >> 4;
              uVar10 = lVar7 * 0x5555555555555556;
              if (uVar10 < uVar4 || uVar10 - uVar4 == 0) {
                uVar10 = uVar4;
              }
              if (0x2aaaaaaaaaaaaa9 < (ulong)(lVar7 * -0x5555555555555555)) {
                uVar10 = 0x555555555555555;
              }
              if (uVar10 == 0) {
                lVar7 = 0;
              }
              else {
                if (0x555555555555555 < uVar10) goto LAB_004828f0;
                lVar7 = fn_679020(uVar10 * 0x30);
              }
              uVar18 = *(undefined8 *)(param_2 + 0xc);
              uVar17 = *(undefined8 *)(param_2 + 4);
              puVar11 = (undefined8 *)(lVar7 + lVar8 * 0x10);
              *(undefined4 *)(puVar11 + 1) = 1;
              *puVar11 = uVar14;
              *(undefined8 *)((long)puVar11 + 0x14) = uVar18;
              *(undefined8 *)((long)puVar11 + 0xc) = uVar17;
              *(undefined4 *)((long)puVar11 + 0x1c) = uVar21;
              *(undefined4 *)(puVar11 + 4) = uVar22;
              *(undefined4 *)((long)puVar11 + 0x24) = uVar23;
              *(undefined4 *)(puVar11 + 5) = uVar24;
              *(undefined4 *)((long)puVar11 + 0x2c) = uVar1;
              puVar9 = puVar11;
              if (puVar12 != puVar13) {
                do {
                  uVar19 = puVar12[-3];
                  uVar18 = puVar12[-4];
                  uVar17 = puVar12[-1];
                  uVar14 = puVar12[-2];
                  puVar3 = puVar12 + -5;
                  uVar20 = puVar12[-6];
                  puVar12 = puVar12 + -6;
                  puVar9[-5] = *puVar3;
                  puVar9[-6] = uVar20;
                  puVar9[-3] = uVar19;
                  puVar9[-4] = uVar18;
                  puVar9[-1] = uVar17;
                  puVar9[-2] = uVar14;
                  puVar9 = puVar9 + -6;
                } while (puVar12 != puVar13);
                puVar12 = (undefined8 *)*param_1;
              }
              puVar11 = puVar11 + 6;
              *param_1 = (ulong)puVar9;
              param_1[1] = (ulong)puVar11;
              param_1[2] = lVar7 + uVar10 * 0x30;
              if (puVar12 != (undefined8 *)0x0) {
                fn_6790c8(puVar12);
              }
            }
            param_1[1] = (ulong)puVar11;
          }
          uVar16 = uVar16 + 1;
        } while (uVar16 < *(ulong *)(lVar15 + 0x600));
      }
      lVar8 = lVar6 + 0x890;
      lVar15 = lVar6 + 0x787ee50;
      lVar6 = lVar8;
    } while (lVar8 != 0x11200);
  }
  if (*(long *)(lVar2 + 0x28) == lVar5) {
    return;
  }
LAB_00482908:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

