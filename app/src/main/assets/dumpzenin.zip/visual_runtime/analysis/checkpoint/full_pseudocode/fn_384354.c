
// ================================================================================
// Uploaded to @imguisource_bot
// Sub: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Sub: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x384354 */

void fn_384354(ulong *param_1,char *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  long lVar3;
  undefined8 *puVar4;
  float fVar5;
  ulong uVar6;
  long lVar7;
  long lVar8;
  undefined8 *puVar9;
  undefined8 uVar10;
  long lVar11;
  undefined8 *puVar12;
  ulong uVar13;
  undefined8 *puVar14;
  long lVar15;
  undefined8 uVar16;
  undefined8 *puVar17;
  float fVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  float fVar21;
  undefined8 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  
  lVar3 = tpidr_el0;
  lVar7 = *(long *)(lVar3 + 0x28);
  if (*param_2 != '\0') {
    lVar11 = 0x788f7c8;
    lVar15 = 0;
    do {
      if ((*(char *)(lVar11 + 0x298) != '\0') &&
         (uVar6 = fn_198128(*(undefined8 *)(lVar11 + 0x10)), (uVar6 & 1) != 0)) {
        fVar5 = 1.0;
        if (0.0 <= *(float *)(lVar11 + 0x28c)) {
          fVar5 = *(float *)(lVar11 + 0x28c);
        }
        if (param_2[1] == '\0') {
          uVar23 = 0;
          uVar24 = 0;
          uVar25 = 0;
          fVar18 = 0.0;
        }
        else {
          uVar23 = *(undefined4 *)(param_2 + 0x14);
          uVar24 = *(undefined4 *)(param_2 + 0x18);
          uVar25 = *(undefined4 *)(param_2 + 0x1c);
          fVar18 = *(float *)(param_2 + 0x20);
        }
        fVar21 = *(float *)(param_2 + 0x10);
        puVar14 = (undefined8 *)param_1[1];
        uVar10 = *(undefined8 *)(param_2 + 4);
        uVar16 = *(undefined8 *)(lVar11 + 0x10);
        uVar2 = *(undefined4 *)(param_2 + 0xc);
        uVar1 = *(undefined4 *)(lVar11 + 0x290);
        if (puVar14 < (undefined8 *)param_1[2]) {
          *puVar14 = uVar16;
          *(undefined4 *)(puVar14 + 1) = 1;
          puVar9 = puVar14 + 6;
          *(undefined8 *)((long)puVar14 + 0xc) = uVar10;
          *(undefined4 *)((long)puVar14 + 0x14) = uVar2;
          *(float *)(puVar14 + 3) = fVar5 * fVar21;
          *(undefined4 *)((long)puVar14 + 0x1c) = uVar23;
          *(undefined4 *)(puVar14 + 4) = uVar24;
          *(undefined4 *)((long)puVar14 + 0x24) = uVar25;
          *(float *)(puVar14 + 5) = fVar5 * fVar18;
          *(undefined4 *)((long)puVar14 + 0x2c) = uVar1;
        }
        else {
          puVar17 = (undefined8 *)*param_1;
          lVar11 = (long)puVar14 - (long)puVar17 >> 4;
          uVar6 = lVar11 * -0x5555555555555555 + 1;
          if (0x555555555555555 < uVar6) {
            if (*(long *)(lVar3 + 0x28) == lVar7) {
              fn_34ba14(param_1);
LAB_004845e4:
              if (*(long *)(lVar3 + 0x28) == lVar7) {
                fn_13edb4();
              }
            }
            goto LAB_004845fc;
          }
          lVar8 = (long)(undefined8 *)param_1[2] - (long)puVar17 >> 4;
          uVar13 = lVar8 * 0x5555555555555556;
          if (uVar13 < uVar6 || uVar13 - uVar6 == 0) {
            uVar13 = uVar6;
          }
          if (0x2aaaaaaaaaaaaa9 < (ulong)(lVar8 * -0x5555555555555555)) {
            uVar13 = 0x555555555555555;
          }
          if (uVar13 == 0) {
            lVar8 = 0;
          }
          else {
            if (0x555555555555555 < uVar13) goto LAB_004845e4;
            lVar8 = fn_679020(uVar13 * 0x30);
          }
          uVar2 = *(undefined4 *)(param_2 + 0xc);
          puVar9 = (undefined8 *)(lVar8 + lVar11 * 0x10);
          *(undefined8 *)((long)puVar9 + 0xc) = *(undefined8 *)(param_2 + 4);
          *puVar9 = uVar16;
          *(undefined4 *)(puVar9 + 1) = 1;
          *(undefined4 *)((long)puVar9 + 0x14) = uVar2;
          *(float *)(puVar9 + 3) = fVar5 * fVar21;
          *(undefined4 *)((long)puVar9 + 0x1c) = uVar23;
          *(undefined4 *)(puVar9 + 4) = uVar24;
          *(undefined4 *)((long)puVar9 + 0x24) = uVar25;
          *(float *)(puVar9 + 5) = fVar5 * fVar18;
          *(undefined4 *)((long)puVar9 + 0x2c) = uVar1;
          puVar12 = puVar9;
          if (puVar14 != puVar17) {
            do {
              uVar20 = puVar14[-3];
              uVar19 = puVar14[-4];
              uVar16 = puVar14[-1];
              uVar10 = puVar14[-2];
              puVar4 = puVar14 + -5;
              uVar22 = puVar14[-6];
              puVar14 = puVar14 + -6;
              puVar12[-5] = *puVar4;
              puVar12[-6] = uVar22;
              puVar12[-3] = uVar20;
              puVar12[-4] = uVar19;
              puVar12[-1] = uVar16;
              puVar12[-2] = uVar10;
              puVar12 = puVar12 + -6;
            } while (puVar14 != puVar17);
            puVar14 = (undefined8 *)*param_1;
          }
          puVar9 = puVar9 + 6;
          *param_1 = (ulong)puVar12;
          param_1[1] = (ulong)puVar9;
          param_1[2] = lVar8 + uVar13 * 0x30;
          if (puVar14 != (undefined8 *)0x0) {
            fn_6790c8(puVar14);
          }
        }
        param_1[1] = (ulong)puVar9;
      }
      lVar8 = lVar15 + 0x2a0;
      lVar11 = lVar15 + 0x788fa68;
      lVar15 = lVar8;
    } while (lVar8 != 0x3f00);
  }
  if (*(long *)(lVar3 + 0x28) == lVar7) {
    return;
  }
LAB_004845fc:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

