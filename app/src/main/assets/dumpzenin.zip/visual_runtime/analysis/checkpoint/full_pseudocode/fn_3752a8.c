
// ================================================================================
// Telegram community:
// Bot: @imguisource_bot
// ImGui Source: @ImGui_Source_FIXNEY
// shit src 🧨: @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x3752a8 */

bool fn_3752a8(void)

{
  bool bVar1;
  undefined4 uVar2;
  int iVar3;
  
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar3 = fn_65eda8(0x787c6a0), iVar3 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    uRam000000000787c580 = 0;
    uRam000000000787c578 = 0;
    uRam000000000787c590 = 0;
    uRam000000000787c588 = 0;
    uRam000000000787c5a0 = 0;
    uRam000000000787c598 = 0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c688 = 0;
    uRam000000000787c68c = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  if (uRam000000000787c691._7_1_ == '\0') {
    uVar2 = fn_19e714(&UNK_007cb2b3);
    uRam000000000787c5d0 = CONCAT44(uRam000000000787c5d0._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007d235a);
    uRam000000000787c5d0 = CONCAT44(uVar2,(int)uRam000000000787c5d0);
    uVar2 = fn_19e714(&UNK_0078faef);
    uRam000000000787c5d8 = CONCAT44(uRam000000000787c5d8._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007e26de);
    uRam000000000787c5d8 = CONCAT44(uVar2,(int)uRam000000000787c5d8);
    uVar2 = fn_19e714(&UNK_007de710);
    uRam000000000787c5e0 = CONCAT44(uRam000000000787c5e0._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_00793841);
    uRam000000000787c5e0 = CONCAT44(uVar2,(undefined4)uRam000000000787c5e0);
    uVar2 = fn_19e714(&UNK_007f1926);
    uRam000000000787c5e8 = CONCAT44(uRam000000000787c5e8._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_00800e10);
    uRam000000000787c5e8 = CONCAT44(uVar2,(undefined4)uRam000000000787c5e8);
    uVar2 = fn_19e714(&UNK_0079c85e);
    uRam000000000787c5f0 = CONCAT44(uRam000000000787c5f0._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007987ba);
    uRam000000000787c5f0 = CONCAT44(uVar2,(undefined4)uRam000000000787c5f0);
    uVar2 = fn_19e714(&UNK_007a087b);
    uRam000000000787c5f8 = CONCAT44(uRam000000000787c5f8._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007d2367);
    uRam000000000787c5f8 = CONCAT44(uVar2,(undefined4)uRam000000000787c5f8);
    uVar2 = fn_19e714(&UNK_007bfb43);
    uRam000000000787c600 = CONCAT44(uRam000000000787c600._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007de719);
    uRam000000000787c600 = CONCAT44(uVar2,(undefined4)uRam000000000787c600);
    uVar2 = fn_19e714(&UNK_007b40da);
    uRam000000000787c608 = CONCAT44(uRam000000000787c608._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007cb33c);
    uRam000000000787c608 = CONCAT44(uVar2,(undefined4)uRam000000000787c608);
    uVar2 = fn_19e714(&UNK_00800e5a);
    uRam000000000787c610 = CONCAT44(uRam000000000787c610._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007b7e98);
    uRam000000000787c610 = CONCAT44(uVar2,(undefined4)uRam000000000787c610);
    uVar2 = fn_19e714(&UNK_007de724);
    uRam000000000787c618 = CONCAT44(uRam000000000787c618._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_00800e63);
    uRam000000000787c618 = CONCAT44(uVar2,(undefined4)uRam000000000787c618);
    uVar2 = fn_19e714(&UNK_007a7d69);
    uRam000000000787c620 = CONCAT44(uRam000000000787c620._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007ceb70);
    uRam000000000787c620 = CONCAT44(uVar2,(undefined4)uRam000000000787c620);
    uVar2 = fn_19e714(&UNK_007b40e1);
    uRam000000000787c628 = CONCAT44(uRam000000000787c628._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007f596b);
    uRam000000000787c628 = CONCAT44(uVar2,(undefined4)uRam000000000787c628);
    uVar2 = fn_19e714(&UNK_0078bd8d);
    uRam000000000787c630 = CONCAT44(uRam000000000787c630._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007b40e8);
    uRam000000000787c630 = CONCAT44(uVar2,(undefined4)uRam000000000787c630);
    uVar2 = fn_19e714(&UNK_007da57b);
    uRam000000000787c638 = CONCAT44(uRam000000000787c638._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_00800e69);
    uRam000000000787c638 = CONCAT44(uVar2,(undefined4)uRam000000000787c638);
    uVar2 = fn_19e714(&UNK_007c7bfe);
    uRam000000000787c640 = CONCAT44(uRam000000000787c640._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007b0163);
    uRam000000000787c640 = CONCAT44(uVar2,(undefined4)uRam000000000787c640);
    uVar2 = fn_19e714(&UNK_007b40f1);
    uRam000000000787c648 = CONCAT44(uRam000000000787c648._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007fd15a);
    uRam000000000787c648 = CONCAT44(uVar2,(undefined4)uRam000000000787c648);
    uVar2 = fn_19e714(&UNK_007e9fa0);
    uRam000000000787c650 = CONCAT44(uRam000000000787c650._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_0079384b);
    uRam000000000787c650 = CONCAT44(uVar2,(undefined4)uRam000000000787c650);
    uVar2 = fn_19e714(&UNK_007a0886);
    uRam000000000787c658 = CONCAT44(uRam000000000787c658._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007f1931);
    uRam000000000787c658 = CONCAT44(uVar2,(undefined4)uRam000000000787c658);
    uVar2 = fn_19e714(&UNK_007fd24f);
    uRam000000000787c660 = CONCAT44(uRam000000000787c660._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007de733);
    uRam000000000787c660 = CONCAT44(uVar2,(undefined4)uRam000000000787c660);
    uVar2 = fn_19e714(&UNK_007a0891);
    uRam000000000787c668 = CONCAT44(uRam000000000787c668._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007a7d7a);
    uRam000000000787c668 = CONCAT44(uVar2,(undefined4)uRam000000000787c668);
    uVar2 = fn_19e714(&UNK_00793853);
    uRam000000000787c670 = CONCAT44(uRam000000000787c670._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007bc207);
    uRam000000000787c670 = CONCAT44(uVar2,(undefined4)uRam000000000787c670);
    uVar2 = fn_19e714(&UNK_007c7c0c);
    uRam000000000787c678 = CONCAT44(uRam000000000787c678._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_00787de2);
    uRam000000000787c678 = CONCAT44(uVar2,(undefined4)uRam000000000787c678);
    uVar2 = fn_19e714(&UNK_007987cb);
    uRam000000000787c680 = CONCAT44(uRam000000000787c680._4_4_,uVar2);
    uVar2 = fn_19e714(&UNK_007ac393);
    uRam000000000787c680 = CONCAT44(uVar2,(undefined4)uRam000000000787c680);
    uRam000000000787c688 = fn_19e714(&UNK_007d69a9);
    bVar1 = false;
    if ((((int)uRam000000000787c5d0 != 0) && (uRam000000000787c5d0._4_4_ != 0)) &&
       ((int)uRam000000000787c5d8 != 0)) {
      bVar1 = uRam000000000787c5d8._4_4_ != 0;
    }
    uRam000000000787c691 = CONCAT17(bVar1,(undefined7)uRam000000000787c691);
  }
  else {
    bVar1 = true;
  }
  return bVar1;
}

