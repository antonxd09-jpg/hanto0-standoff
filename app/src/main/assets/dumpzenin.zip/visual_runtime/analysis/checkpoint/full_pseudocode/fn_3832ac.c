
// ================================================================================
// ##################################################
// # Bot: t.me/imguisource_bot
// # Main: t.me/ImGui_Source_FIXNEY (ImGui Source)
// # Two: t.me/il2cpp_src (shit src 🧨)
// ##################################################
// ================================================================================

/* ORIGINAL_RVA: 0x3832ac */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fn_3832ac(long param_1,long param_2,char param_3,long param_4,long param_5)

{
  uint *puVar1;
  bool bVar2;
  uint uVar3;
  char cVar4;
  long lVar5;
  int iVar6;
  int iVar7;
  long lVar8;
  long lVar9;
  ulong uVar10;
  ulong uVar11;
  long lVar12;
  long lVar13;
  long *plVar14;
  undefined8 *puVar15;
  long lVar16;
  char *pcVar17;
  undefined8 unaff_x26;
  char *pcVar18;
  long *plVar19;
  long *plVar20;
  undefined8 unaff_x27;
  undefined8 unaff_x28;
  undefined8 unaff_x30;
  ushort uVar21;
  float fVar22;
  float fVar23;
  float fVar25;
  undefined auVar24 [16];
  undefined4 uVar26;
  float fVar27;
  undefined auVar28 [16];
  float fVar29;
  float fVar30;
  float fVar31;
  undefined8 uStack_100;
  float fStack_f8;
  undefined8 uStack_f0;
  float fStack_e8;
  float fStack_e4;
  float fStack_e0;
  float fStack_dc;
  undefined8 uStack_d8;
  undefined uStack_d0;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  long lStack_b0;
  
  lVar5 = tpidr_el0;
  lStack_b0 = *(long *)(lVar5 + 0x28);
  lVar8 = fn_36ece4();
  lVar9 = fn_639800();
  if (lRam00000000078936c8 == 0) {
    fVar22 = 0.016;
  }
  else {
    fVar22 = (float)(lVar9 - lRam00000000078936c8) / 1e+09;
  }
  if (((fVar22 == -NAN || (int)((int)fVar22 + 1U) < 0 != SCARRY4((int)fVar22,1)) ||
      0x7e < ((uint)fVar22 & 0x7fffffff) - 0x800000 >> 0x18) && 0x7ffffe < (int)fVar22 - 1U) {
    fVar22 = 0.016;
  }
  fVar31 = 0.1;
  if (fVar22 <= 0.1) {
    fVar31 = fVar22;
  }
  lRam00000000078936c8 = lVar9;
  if (*(char *)(lVar8 + 0xe84) == '\0') {
    if (*(long *)(lVar5 + 0x28) == lStack_b0) {
      fn_383b30(0x788f7c8);
      fn_383b30(0x788fa68);
      fn_383b30(0x788fd08);
      fn_383b30(0x788ffa8);
      fn_383b30(0x7890248);
      fn_383b30(0x78904e8);
      fn_383b30(0x7890788);
      fn_383b30(0x7890a28);
      fn_383b30(0x7890cc8);
      fn_383b30(0x7890f68);
      fn_383b30(0x7891208);
      fn_383b30(0x78914a8);
      fn_383b30(0x7891748);
      fn_383b30(0x78919e8);
      fn_383b30(0x7891c88);
      fn_383b30(0x7891f28);
      fn_383b30(0x78921c8);
      fn_383b30(0x7892468);
      fn_383b30(0x7892708);
      fn_383b30(0x78929a8);
      fn_383b30(0x7892c48);
      fn_383b30(0x7892ee8);
      fn_383b30(0x7893188);
      lVar5 = tpidr_el0;
      lVar8 = *(long *)(lVar5 + 0x28);
      auVar28._8_8_ = uRam0000000007893450;
      auVar28._0_8_ = uRam0000000007893448;
      auVar24._8_5_ = uRam0000000007893460;
      auVar24._0_8_ = uRam0000000007893458;
      auVar24._13_3_ = uRam0000000007893465;
      auVar24 = NEON_cmeq(auVar24,0,8);
      auVar28 = NEON_cmeq(auVar28,0,8);
      uVar21 = NEON_umaxv(CONCAT26(CONCAT11(~auVar24[9],~auVar24[8]),
                                   CONCAT24(CONCAT11(~auVar24[1],~auVar24[0]),
                                            CONCAT22(CONCAT11(~auVar28[9],~auVar28[8]),
                                                     CONCAT11(~auVar28[1],~auVar28[0])))),2);
      if (((((uVar21 & 1) != 0) || (lRam0000000007893440 != 0)) || (lRam0000000007893428 != 0)) ||
         (CONCAT35(uRam000000000789346d,uRam0000000007893468) != 0)) {
        uVar10 = fn_198128(uRam0000000007893438);
        if ((uVar10 & 1) != 0) {
          fn_369ce0(uRam0000000007893438,0);
        }
        uVar10 = fn_198128(lRam0000000007893428);
        if ((uVar10 & 1) != 0) {
          fn_198eac(lRam0000000007893428);
        }
        uVar10 = fn_198128(lRam0000000007893440);
        if ((uVar10 & 1) != 0) {
          fn_198eac(lRam0000000007893440);
        }
        uVar10 = fn_198128(uRam0000000007893448);
        if ((uVar10 & 1) != 0) {
          fn_198eac(uRam0000000007893448);
        }
        uVar10 = fn_198128(uRam0000000007893450);
        if ((uVar10 & 1) != 0) {
          fn_198eac(uRam0000000007893450);
        }
        fn_439c54(uRam0000000007893458);
        fn_439c54(CONCAT35(uRam0000000007893465,uRam0000000007893460));
        fn_439c54(CONCAT35(uRam000000000789346d,uRam0000000007893468));
        uRam0000000007893480 = SUB168(_UNK_007822b0,8);
        uRam0000000007893478 = SUB168(_UNK_007822b0,0);
        uRam0000000007893490 = _UNK_00782e88;
        uRam0000000007893488 = _UNK_00782e80;
        uRam000000000789346d = 0;
        uRam0000000007893470 = 0;
        uRam0000000007893468 = 0;
        uRam0000000007893430 = 0;
        lRam0000000007893428 = 0;
        lRam0000000007893440 = 0;
        uRam0000000007893438 = 0;
        uRam0000000007893450 = 0;
        uRam0000000007893448 = 0;
        uRam0000000007893460 = 0;
        uRam0000000007893465 = 0;
        uRam0000000007893458 = 0;
        uRam00000000078934dc = 0x42a00000;
        uRam00000000078934d4 = _UNK_007839c8;
        uRam00000000078934a0 = 0x43480000;
        uRam0000000007893500 = SUB168(_UNK_007828b0,8);
        uRam00000000078934f8 = SUB168(_UNK_007828b0,0);
        uRam00000000078935c0 = 0x43480000;
        uRam000000000789358c = 0x100;
        uRam00000000078935e3 = (undefined)((ulong)unaff_x26 >> 0x30);
        uRam0000000007893590 = 2;
        uRam00000000078935e1 = (undefined2)((ulong)unaff_x26 >> 0x20);
        uRam0000000007893498 = 0;
        uRam00000000078935b8 = 0;
        uRam0000000007893617 = (undefined)((ulong)unaff_x26 >> 0x10);
        uRam00000000078935f4 = 0x41a00000;
        uRam0000000007893615 = (undefined2)unaff_x26;
        uRam00000000078935f8 = _UNK_00783658;
        uRam000000000789362f = (undefined)((ulong)unaff_x27 >> 0x30);
        uRam0000000007893508 = 0x42c80000;
        uRam0000000007893628 = 0x42c80000;
        uRam000000000789362d = (undefined2)((ulong)unaff_x27 >> 0x20);
        uRam000000000789364b = (undefined)((ulong)unaff_x27 >> 0x10);
        uRam000000000789352c = 0x43160000;
        uRam000000000789353c = 0x43160000;
        uRam0000000007893649 = (undefined2)unaff_x27;
        uRam000000000789364c = 0x43160000;
        uRam000000000789365c = 0x43160000;
        uRam000000000789366b = (undefined)((ulong)unaff_x28 >> 0x10);
        uRam000000000789365b = (undefined)((ulong)unaff_x28 >> 0x30);
        uRam0000000007893659 = (undefined2)((ulong)unaff_x28 >> 0x20);
        uRam000000000789367f = (undefined)((ulong)unaff_x30 >> 0x30);
        uRam0000000007893554 = SUB168(_UNK_00780c40,8);
        uRam000000000789354c = SUB168(_UNK_00780c40,0);
        auVar28 = NEON_fmov(0x3f800000,4);
        uRam0000000007893669 = (undefined2)unaff_x28;
        uRam000000000789368b = (undefined)((ulong)unaff_x30 >> 0x10);
        uRam0000000007893560 = _UNK_00783cd0;
        uRam000000000789367d = (undefined2)((ulong)unaff_x30 >> 0x20);
        uRam0000000007893680 = _UNK_00783cd0;
        uRam0000000007893620 = _UNK_00781098;
        uRam0000000007893618 = _UNK_00781090;
        uRam0000000007893574 = auVar28._8_8_;
        uRam000000000789356c = auVar28._0_8_;
        uRam0000000007893689 = (undefined2)unaff_x30;
        uRam00000000078934a4 = 0;
        uRam00000000078934b0 = _UNK_007808e8;
        uRam00000000078934a8 = _UNK_007808e0;
        uRam00000000078934b8 = _UNK_007833b8;
        uRam00000000078934c0 = 0;
        uRam00000000078934cc = _UNK_00782e98;
        uRam00000000078934c4 = _UNK_00782e90;
        uRam00000000078934e0 = 0;
        uRam00000000078934ec = _UNK_00782d58;
        uRam00000000078934e4 = _UNK_00782d50;
        uRam00000000078934f4 = 0;
        uRam000000000789350c = 0;
        uRam0000000007893518 = _UNK_00782178;
        uRam0000000007893510 = _UNK_00782170;
        uRam0000000007893520 = _UNK_00783850;
        uRam0000000007893528 = 0;
        uRam0000000007893530 = 0x4248000042480000;
        uRam0000000007893538 = 0;
        uRam0000000007893540 = _UNK_00783a58;
        uRam0000000007893548 = 0;
        uRam000000000789355c = 0;
        uRam0000000007893568 = 0;
        uRam000000000789358e = 0;
        uRam0000000007893594 = 0;
        uRam00000000078935a0 = _UNK_007828c8;
        uRam0000000007893598 = _UNK_007828c0;
        uRam00000000078935b0 = _UNK_00781088;
        uRam00000000078935a8 = _UNK_00781080;
        uRam00000000078935c4 = 0;
        uRam00000000078935d0 = _UNK_007808e8;
        uRam00000000078935c8 = _UNK_007808e0;
        uRam00000000078935d8 = _UNK_007833b8;
        uRam00000000078935e0 = 0;
        uRam00000000078935ec = _UNK_00782e98;
        uRam00000000078935e4 = _UNK_00782e90;
        uRam0000000007893600 = 0;
        uRam000000000789360c = _UNK_00782d58;
        uRam0000000007893604 = _UNK_00782d50;
        uRam0000000007893614 = 0;
        uRam000000000789362c = 0;
        uRam0000000007893638 = _UNK_00782178;
        uRam0000000007893630 = _UNK_00782170;
        uRam0000000007893640 = _UNK_00783850;
        uRam0000000007893648 = 0;
        uRam0000000007893650 = 0x4248000042480000;
        uRam0000000007893658 = 0;
        uRam0000000007893660 = _UNK_00783a58;
        uRam0000000007893668 = 0;
        uRam0000000007893674 = _UNK_00781dc8;
        uRam000000000789366c = _UNK_00781dc0;
        uRam000000000789367c = 0;
        uRam0000000007893688 = 0;
        uRam00000000078936ac = 0;
        uRam00000000078936b0 = _UNK_00783348;
        uRam00000000078936b8 = 0xffffffff;
        uRam00000000078936c0 = 0;
        uRam000000000789357c = uRam000000000789356c;
        uRam0000000007893584 = uRam0000000007893574;
        uRam000000000789368c = uRam000000000789356c;
        uRam0000000007893694 = uRam0000000007893574;
        uRam000000000789369c = uRam000000000789356c;
        uRam00000000078936a4 = uRam0000000007893574;
      }
      if (*(long *)(lVar5 + 0x28) == lVar8) {
        return;
      }
                    /* WARNING: Subroutine does not return */
      imp___stack_chk_fail();
    }
  }
  else {
    if (((param_1 != 0) && (param_2 != 0)) && ((param_4 != 0 && (param_5 != 0)))) {
      lVar9 = 0;
      puVar1 = (uint *)(lVar8 + 0xd68);
LAB_00483438:
      pcVar18 = (char *)(param_4 + lVar9 * 0x50 + 8);
      cVar4 = *pcVar18;
      lVar16 = param_2;
      pcVar17 = (char *)(param_1 + 0xd);
      do {
        if (((pcVar17[-5] == '\0') && (pcVar17[-4] == '\0')) &&
           ((*pcVar17 == cVar4 &&
            (uVar10 = fn_198128(*(undefined8 *)(pcVar17 + -0xd)), (uVar10 & 1) != 0)))) {
          if ((((param_3 != '\0') && (lVar16 = *(long *)(pcVar17 + -0xd), lVar16 != 0)) &&
              (pcVar17[-1] != '\0')) && (pcVar17[-1] != param_3)) {
            uStack_d0 = 0;
            fVar22 = *(float *)(lVar8 + 0xfa4);
            fStack_e8 = 0.0;
            fStack_e4 = 0.0;
            uStack_f0 = 0;
            uStack_d8 = 0;
            fStack_e0 = 0.0;
            fStack_dc = 0.0;
            uVar10 = fn_1c6d2c(*pcVar18,&uStack_f0);
            if ((uVar10 & 1) == 0) {
              uVar10 = 0;
              fVar29 = 0.0;
            }
            else {
              fVar23 = (float)uStack_f0 - fStack_e4;
              fVar25 = (float)((ulong)uStack_f0 >> 0x20) - fStack_e0;
              fVar29 = fStack_e8 - fStack_dc;
              uVar26 = NEON_fmadd(fVar23,fVar23,fVar25 * fVar25);
              fVar27 = (float)NEON_fmadd(fVar29,fVar29,uVar26);
              fVar27 = SQRT(fVar27);
              fVar30 = ABS(fVar27);
              bVar2 = fVar27 <= 6.0 && (INFINITY < fVar30 || fVar30 < INFINITY);
              if (fVar27 > 6.0 || INFINITY >= fVar30 && fVar30 >= INFINITY) {
                fVar29 = 0.0;
              }
              uVar10 = NEON_cmlt(CONCAT44((uint)bVar2 << 0x1f,(uint)bVar2 << 0x1f),0,4);
              uVar10 = CONCAT44(fVar25,fVar23) & uVar10;
            }
            uVar11 = fn_198128(lVar16);
            if (((uVar11 & 1) == 0) || (uVar11 = fn_367a3c(), (uVar11 & 1) == 0)) {
              if (((bRam00000000076ac3f8 & 1) == 0) && (iVar6 = fn_65eda8(0x76ac3f8), iVar6 != 0)) {
                fn_1269d0(0x76a9760);
                imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                fn_65eed8(0x76ac3f8);
              }
              fn_367a3c();
            }
            else {
              uVar3 = *puVar1;
              if (0xb < (int)uVar3) {
                uVar3 = 0xc;
              }
              lVar12 = fn_375098(uVar3 & ((int)uVar3 >> 0x1f ^ 0xffffffffU));
              if (lVar12 == 0) {
                if (((bRam00000000076ac3f8 & 1) == 0) && (iVar6 = fn_65eda8(0x76ac3f8), iVar6 != 0))
                {
                  fn_1269d0(0x76a9760);
                  goto LAB_00483914;
                }
              }
              else {
                lVar13 = fn_197da4(lVar16);
                fStack_f8 = 0.0;
                uStack_100 = 0;
                uStack_f0 = 0;
                fStack_e8 = 0.0;
                fStack_e4 = 0.0;
                if (((lVar13 != 0) && (uVar11 = fn_1967e0(lVar13,&uStack_100), (uVar11 & 1) != 0))
                   && (uVar11 = fn_196b44(lVar13,&uStack_f0), (uVar11 & 1) != 0)) {
                  plVar14 = (long *)0x788f7c8;
                  lVar13 = 0x3f00;
                  plVar19 = plVar14;
                  goto LAB_004835f0;
                }
                if (((bRam00000000076ac3f8 & 1) == 0) && (iVar6 = fn_65eda8(0x76ac3f8), iVar6 != 0))
                {
                  fn_1269d0(0x76a9760);
                  goto LAB_00483914;
                }
              }
            }
          }
          break;
        }
        lVar16 = lVar16 + -1;
        pcVar17 = pcVar17 + 0x10;
      } while (lVar16 != 0);
      goto LAB_0048342c;
    }
LAB_00483988:
    puVar15 = (undefined8 *)0x788f7c8;
    lVar8 = 0x3f00;
    do {
      if (*(char *)(puVar15 + 0x53) == '\0') goto LAB_004839c4;
      uVar10 = fn_198128(*puVar15);
      if (((((uVar10 & 1) == 0) || (uVar10 = fn_198128(puVar15[3]), (uVar10 & 1) == 0)) ||
          (uVar10 = fn_198128(puVar15[4]), (uVar10 & 1) == 0)) ||
         (*(float *)(puVar15 + 0x51) <= 0.0)) {
LAB_004839bc:
        fn_383b30(puVar15);
      }
      else {
        fVar29 = fVar31 + *(float *)((long)puVar15 + 0x284);
        fVar22 = fVar29 / *(float *)(puVar15 + 0x51);
        *(float *)((long)puVar15 + 0x284) = fVar29;
        if (1.0 <= fVar22) goto LAB_004839bc;
        fVar29 = (fVar22 + -0.7) / 0.3;
        fVar22 = 1.0;
        if (fVar29 <= 1.0) {
          fVar22 = fVar29;
        }
        fVar23 = 0.0;
        if (0.0 <= fVar29) {
          fVar23 = fVar22;
        }
        fVar22 = (float)NEON_fmadd(fVar23,0xc0000000,0x40400000);
        fVar22 = (float)(int)((1.0 - fVar23 * fVar23 * fVar22) * 255.0) / 255.0;
        if (fVar22 != *(float *)((long)puVar15 + 0x28c)) {
          *(float *)((long)puVar15 + 0x28c) = fVar22;
          uVar10 = fn_3751bc(puVar15[4],puVar15 + 9,1);
          if (((uVar10 & 1) == 0) ||
             ((puVar15[5] != 0 && (uVar10 = fn_375cc0(puVar15[5],puVar15 + 9,1), (uVar10 & 1) == 0))
             )) goto LAB_004839bc;
        }
      }
LAB_004839c4:
      lVar8 = lVar8 + -0x2a0;
      puVar15 = puVar15 + 0x54;
    } while (lVar8 != 0);
    if (*(long *)(lVar5 + 0x28) == lStack_b0) {
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
  while( true ) {
    fVar23 = 1.0;
    fVar25 = 1.0;
    if (0.0 < *(float *)(plVar14 + 0x51)) {
      fVar25 = *(float *)((long)plVar14 + 0x284) / *(float *)(plVar14 + 0x51);
    }
    if (0.0 < *(float *)(plVar19 + 0x51)) {
      fVar23 = *(float *)((long)plVar19 + 0x284) / *(float *)(plVar19 + 0x51);
    }
    if (fVar25 <= fVar23) {
      plVar20 = plVar19;
    }
    lVar13 = lVar13 + -0x2a0;
    plVar14 = plVar14 + 0x54;
    plVar19 = plVar20;
    if (lVar13 == 0) break;
LAB_004835f0:
    plVar20 = plVar14;
    if (*(char *)(plVar14 + 0x53) == '\0') break;
  }
  fn_383b30(plVar20);
  lVar13 = fn_36963c(&UNK_007f96a4);
  *plVar20 = lVar13;
  if (lVar13 == 0) {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar6 = fn_65eda8(0x76ac3f8), iVar6 != 0)) {
      fn_1269d0(0x76a9760);
LAB_00483914:
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    goto LAB_0048342c;
  }
  fn_1997d4(lVar16);
  iVar6 = fn_199ea0();
  if (iVar6 - 1U < 0x1f) {
    fn_199f6c(*plVar20,iVar6);
  }
  uVar26 = fn_199ea0(*plVar20);
  *(undefined4 *)(plVar20 + 0x52) = uVar26;
  fn_199704(*plVar20,0x3d);
  lVar13 = fn_3697f0(*plVar20);
  plVar20[1] = lVar13;
  lVar13 = fn_369978(*plVar20);
  plVar20[2] = lVar13;
  lVar13 = fn_367eb4();
  plVar20[3] = lVar13;
  if (((lVar13 == 0) || (plVar20[1] == 0)) || (plVar20[2] == 0)) {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar6 = fn_65eda8(0x76ac3f8), iVar6 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
  }
  else {
    fn_199704(lVar13,0x3d);
    lVar13 = fn_439970(plVar20[3]);
    plVar20[6] = lVar13;
    uVar11 = fn_36935c(lVar16,plVar20[3],1);
    if (((uVar11 & 1) != 0) && (lVar13 = fn_36998c(*plVar20), lVar13 != 0)) {
      uStack_c0 = CONCAT44((float)(uVar10 >> 0x20) + (float)((ulong)uStack_100 >> 0x20),
                           (float)uVar10 + (float)uStack_100);
      uStack_b8 = CONCAT44(uStack_b8._4_4_,fVar29 + fStack_f8);
      uVar10 = fn_196c78(lVar13,&uStack_c0,&uStack_f0);
      if ((uVar10 & 1) != 0) {
        lVar12 = fn_19ca80(lVar12);
        plVar20[4] = lVar12;
        if (lVar12 != 0) {
          lVar12 = fn_439970();
          plVar20[7] = lVar12;
          fn_199704(plVar20[4],0x3d);
          fn_384648(lVar16,plVar20[4]);
          uVar10 = fn_3751bc(plVar20[4],puVar1,1);
          if ((uVar10 & 1) != 0) {
            fn_369b28(plVar20[1],plVar20[3]);
            iVar7 = fn_36b0d8(plVar20[3]);
            iVar6 = iVar7;
            if (1 < iVar7) {
              iVar6 = 2;
            }
            iVar6 = iVar6 + -1;
            if (iVar7 < 1) {
              iVar6 = 0;
            }
            *(int *)((long)plVar20 + 0x294) = iVar6;
            if ((*(char *)(lVar8 + 0xe86) == '\0') ||
               (uVar10 = fn_38476c(plVar20,lVar16,puVar1), (uVar10 & 1) == 0)) {
              fn_369c04(plVar20[2],plVar20[4]);
            }
            else {
              uStack_b8 = SUB168(*(undefined (*) [16])(plVar20 + 4),8);
              uStack_c0 = SUB168(*(undefined (*) [16])(plVar20 + 4),0);
              uVar10 = fn_369258(plVar20[2],&uStack_c0,2);
              if ((uVar10 & 1) == 0) goto LAB_00483808;
            }
            imp_memcpy(plVar20 + 9,puVar1,0x23c);
            *(undefined4 *)((long)plVar20 + 0x284) = 0;
            fVar29 = 10.0;
            if (fVar22 <= 10.0) {
              fVar29 = fVar22;
            }
            *(undefined4 *)((long)plVar20 + 0x28c) = 0x3f800000;
            *(undefined *)(plVar20 + 0x53) = 1;
            fVar23 = 0.05;
            if (0.05 <= fVar22) {
              fVar23 = fVar29;
            }
            *(float *)(plVar20 + 0x51) = fVar23;
            goto LAB_0048342c;
          }
        }
      }
    }
LAB_00483808:
    fn_126488();
  }
  fn_383b30(plVar20);
LAB_0048342c:
  lVar9 = lVar9 + 1;
  if (lVar9 == param_5) goto LAB_00483988;
  goto LAB_00483438;
}

