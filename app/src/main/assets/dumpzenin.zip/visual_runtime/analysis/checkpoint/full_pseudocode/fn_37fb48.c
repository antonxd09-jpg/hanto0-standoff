
// ================================================================================
// TG Links: bot=t.me/imguisource_bot main=t.me/ImGui_Source_FIXNEY extra=t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x37fb48 */

void fn_37fb48(long *param_1,long param_2,long param_3,ulong param_4)

{
  int iVar1;
  long lVar2;
  ulong uVar3;
  long lVar4;
  
  lVar2 = param_1[2];
  lVar4 = *param_1;
  if (param_4 <= (ulong)((lVar2 - lVar4 >> 4) * -0x5555555555555555)) {
    lVar2 = param_1[1] - lVar4;
    if ((ulong)((lVar2 >> 4) * -0x5555555555555555) < param_4) {
      param_2 = param_2 + lVar2;
      if (param_1[1] != lVar4) {
        imp_memmove(lVar4);
        lVar4 = param_1[1];
      }
      lVar2 = -param_2;
    }
    else {
      lVar2 = -param_2;
    }
    param_3 = param_3 + lVar2;
    if (param_3 != 0) {
      imp_memmove(lVar4,param_2,param_3);
    }
LAB_0047fc88:
    param_1[1] = lVar4 + param_3;
    return;
  }
  if (lVar4 != 0) {
    param_1[1] = lVar4;
    fn_6790c8(lVar4);
    lVar2 = 0;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if (param_4 < 0x555555555555556) {
    uVar3 = (lVar2 >> 4) * 0x5555555555555556;
    if (uVar3 < param_4 || uVar3 - param_4 == 0) {
      uVar3 = param_4;
    }
    if (0x2aaaaaaaaaaaaa9 < (ulong)((lVar2 >> 4) * -0x5555555555555555)) {
      uVar3 = 0x555555555555555;
    }
    if (uVar3 < 0x555555555555556) {
      lVar4 = fn_679020(uVar3 * 0x30);
      param_3 = param_3 - param_2;
      *param_1 = lVar4;
      param_1[1] = lVar4;
      param_1[2] = lVar4 + uVar3 * 0x30;
      if (param_3 != 0) {
        imp_memcpy(lVar4,param_2,param_3);
      }
      goto LAB_0047fc88;
    }
  }
  fn_34ba14(param_1);
  if (((bRam000000000787de70 & 1) == 0) && (iVar1 = fn_65eda8(0x787de70), iVar1 != 0)) {
    uRam000000000787de68 = 0;
    uRam000000000787de50 = 0;
    uRam000000000787de48 = 0;
    uRam000000000787de60 = 0;
    uRam000000000787de66 = 0;
    uRam000000000787de58 = 0;
    uRam000000000787de40 = 0;
    uRam000000000787de38 = 0;
    fn_126978(&UNK_02f49914,0x787de38,0x36,0x49b4cde932fa7adc);
    fn_65eed8(0x787de70);
  }
  uRam000000000787de28 = 0x787de38;
  if (((bRam000000000787deb0 & 1) == 0) && (iVar1 = fn_65eda8(0x787deb0), iVar1 != 0)) {
    uRam000000000787dea8 = 0;
    uRam000000000787de90 = 0;
    uRam000000000787de88 = 0;
    uRam000000000787dea0 = 0;
    uRam000000000787dea5 = 0;
    uRam000000000787de98 = 0;
    uRam000000000787de80 = 0;
    uRam000000000787de78 = 0;
    fn_126978(&UNK_02f4994a,0x787de78,0x35,0x2064a9c70a6ba787);
    fn_65eed8(0x787deb0);
  }
  uRam000000000787de30 = 0x787de78;
  return;
}

