
// ================================================================================
// TG Links: bot=t.me/imguisource_bot main=t.me/ImGui_Source_FIXNEY extra=t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x31e838 */

bool fn_31e838(long param_1)

{
  int iVar1;
  
  if (param_1 == 0) {
    lRam00000000077616f8 = 0;
  }
  else {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    lRam00000000077616f8 = fn_43d5e4(0x76a9768,param_1,&UNK_007c5413,0);
    if (lRam00000000077616f8 != 0) goto LAB_0041e898;
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
LAB_0041e898:
  return lRam00000000077616f8 != 0;
}

