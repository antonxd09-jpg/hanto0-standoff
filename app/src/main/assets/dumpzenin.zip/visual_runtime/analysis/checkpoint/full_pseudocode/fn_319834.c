
// ================================================================================
// Telegram Hub: @imguisource_bot / ImGui Source @ImGui_Source_FIXNEY / shit src 🧨 @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x319834 */

void fn_319834(ulong param_1)

{
  int iVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  
  if (((bRam0000000007761618 & 1) == 0) && (iVar1 = fn_65eda8(0x7761618), iVar1 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  fn_31a518();
  if (lRam00000000077615b0 != 0) {
    fn_31c620(0,0);
  }
  if ((param_1 & 1) != 0) {
    if (((bRam0000000007761618 & 1) == 0) && (iVar1 = fn_65eda8(0x7761618), iVar1 != 0)) {
      fn_31ca58();
      imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
      fn_65eed8(0x7761618);
    }
    plVar4 = (long *)0x7760f00;
    do {
      lVar3 = *plVar4;
      if ((lVar3 != 0) && (uVar2 = fn_198128(lVar3), (uVar2 & 1) != 0)) {
        (*pcRam00000000077616c0)(lVar3,0);
        fn_198eac(lVar3);
      }
      if (plVar4[1] != 0) {
        fn_439c54();
      }
      plVar4[2] = 0;
      *(undefined4 *)(plVar4 + 4) = 0xffffffff;
      plVar4[1] = 0;
      *plVar4 = 0;
      plVar4[3] = -1;
      plVar4 = plVar4 + 5;
    } while (plVar4 != (long *)0x7761518);
    if (((bRam0000000007761618 & 1) == 0) && (iVar1 = fn_65eda8(0x7761618), iVar1 != 0)) {
      fn_31ca58();
      imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
      fn_65eed8(0x7761618);
    }
  }
  uRam0000000007761548 = 0;
  return;
}

