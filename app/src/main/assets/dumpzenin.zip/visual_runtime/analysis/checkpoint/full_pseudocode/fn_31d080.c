
// ================================================================================
// Get latest sources from @imguisource_bot
// Join ImGui Source: t.me/ImGui_Source_FIXNEY
// Join shit src 🧨: t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x31d080 */

void fn_31d080(long param_1)

{
  long lVar1;
  int iVar2;
  long lVar3;
  long lVar4;
  ulong uVar5;
  long lVar6;
  ulong uVar7;
  long *plVar8;
  undefined8 uStack_70;
  long lStack_68;
  
  lVar1 = tpidr_el0;
  lStack_68 = *(long *)(lVar1 + 0x28);
  lRam0000000007761648 = 0;
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  lVar3 = fn_43bc24(0x76a9768);
  uStack_70 = 0;
  if ((param_1 != 0) && (lVar4 = fn_43cd50(0x76a9768,param_1,&uStack_70), lVar4 != 0)) {
    do {
      uVar7 = (ulong)bRam00000000076aa0a5;
      uVar5 = fn_139354(0x76a97a8,uVar7 + lVar4,8);
      if (((((uVar5 & 1) != 0) && (plVar8 = *(long **)(uVar7 + lVar4), plVar8 != (long *)0x0)) &&
          (lVar6 = imp_strlen(plVar8), lVar6 == 0xf)) &&
         (*plVar8 == 0x61626f6c47746553 && *(long *)((long)plVar8 + 7) == 0x726f746365566c61)) {
        uVar7 = (ulong)bRam00000000076aa0a4;
        uVar5 = fn_139354(0x76a97a8,uVar7 + lVar4,1);
        if (((uVar5 & 1) != 0) && (*(char *)(uVar7 + lVar4) == '\x02')) {
          uVar7 = (ulong)bRam00000000076aa0a2;
          uVar5 = fn_139354(0x76a97a8,uVar7 + lVar4,8);
          if ((uVar5 & 1) == 0) {
            lVar4 = 0;
          }
          else {
            lVar4 = *(long *)(uVar7 + lVar4);
          }
          if (lVar3 + 0x72d2180 == lVar4) {
            lRam0000000007761648 = lVar4;
            if (lVar4 != 0) goto LAB_0041d210;
            goto LAB_0041d208;
          }
        }
      }
      lVar4 = fn_43cd50(0x76a9768,param_1,&uStack_70);
    } while (lVar4 != 0);
  }
  if (lRam0000000007761648 == 0) {
LAB_0041d208:
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
  }
LAB_0041d210:
  if (*(long *)(lVar1 + 0x28) == lStack_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(lRam0000000007761648 != 0);
}

