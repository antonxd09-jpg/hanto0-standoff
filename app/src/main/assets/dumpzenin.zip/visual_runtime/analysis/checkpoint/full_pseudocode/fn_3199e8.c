
// ================================================================================
// Телеграм экосистема:
// - Бот: t.me/imguisource_bot
// - Канал 1: t.me/ImGui_Source_FIXNEY (ImGui Source)
// - Канал 2: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x3199e8 */

void fn_3199e8(long *param_1,long param_2)

{
  long lVar1;
  
  if (param_1[1] != 0) {
    fn_439c54();
  }
  *param_1 = param_2;
  param_1[1] = 0;
  if (param_2 != 0) {
    lVar1 = fn_439970(param_2);
    param_1[1] = lVar1;
  }
  return;
}

