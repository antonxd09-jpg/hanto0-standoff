
// ================================================================================
// --------------------------------------------------
// * Telegram Bot: @imguisource_bot
// * ImGui Source: t.me/ImGui_Source_FIXNEY
// * shit src 🧨: t.me/il2cpp_src
// --------------------------------------------------
// ================================================================================

/* ORIGINAL_RVA: 0x37dcd8 */

bool fn_37dcd8(long param_1)

{
  int iVar1;
  
  if (param_1 == 0) {
    lRam000000000787def0 = 0;
  }
  else {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    lRam000000000787def0 = fn_43d5e4(0x76a9768,param_1,&UNK_007ac368,3);
    if (lRam000000000787def0 != 0) goto LAB_0047dd38;
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
LAB_0047dd38:
  return lRam000000000787def0 != 0;
}

