
// ================================================================================
// Bot: @imguisource_bot
// Channel #1: @ImGui_Source_FIXNEY | ImGui Source
// Channel #2: @il2cpp_src | shit src 🧨
// ================================================================================

/* ORIGINAL_RVA: 0x37cf9c */

void fn_37cf9c(void)

{
  int iVar1;
  ulong uVar2;
  
  if (((bRam000000000787e2f0 & 1) == 0) && (iVar1 = fn_65eda8(0x787e2f0), iVar1 != 0)) {
    fn_37d22c();
    imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
    fn_65eed8(0x787e2f0);
  }
  if (((lRam000000000787e2d0 != 0) && (uVar2 = fn_198128(), (uVar2 & 1) != 0)) &&
     (cRam000000000787e2e0 == '\0')) {
    fn_18faa8(lRam000000000787e2d0,0);
  }
  if (lRam000000000787e2d8 != 0) {
    fn_439c54();
  }
  lRam000000000787e2d0 = 0;
  lRam000000000787e2d8 = 0;
  cRam000000000787e2e0 = 0;
  return;
}

