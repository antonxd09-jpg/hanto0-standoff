
// ================================================================================
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Telegram Bot: t.me/imguisource_bot
// ImGui Source: t.me/ImGui_Source_FIXNEY
// shit src 🧨: t.me/il2cpp_src
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ================================================================================

/* ORIGINAL_RVA: 0x382290 */

void fn_382290(ulong *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined uVar6;
  uint uVar7;
  ulong uVar8;
  undefined *puVar9;
  long lVar10;
  ulong *puVar11;
  char *pcVar12;
  ulong uVar13;
  long lVar14;
  long lVar15;
  undefined8 *puVar16;
  undefined8 *puVar17;
  long lVar18;
  ulong uVar19;
  undefined8 uVar20;
  undefined8 *puVar21;
  undefined8 *puVar22;
  undefined8 *puVar23;
  undefined8 *puVar24;
  ulong uVar25;
  undefined8 *puVar26;
  long lVar27;
  undefined8 uVar28;
  long lVar29;
  undefined8 uVar30;
  undefined8 uVar31;
  undefined8 uVar32;
  undefined4 uVar33;
  undefined4 uVar34;
  undefined4 uVar35;
  undefined4 uVar36;
  undefined auVar37 [16];
  uint uStack_64;
  
  lVar27 = 0x787e5c0;
  lVar14 = 0;
  do {
    if (*(char *)(lVar27 + 0x888) != '\0') {
      if (*(char *)(lVar27 + 0x72c) == '\0') {
        uStack_64 = 0;
        if (*(char *)(lVar27 + 0x84c) != '\0') goto LAB_00482328;
LAB_0048233c:
        uVar7 = 0;
      }
      else {
        uStack_64 = fn_198128(*(undefined8 *)(lVar27 + 0x610));
        if (*(char *)(lVar27 + 0x84c) == '\0') goto LAB_0048233c;
LAB_00482328:
        if (*(long *)(lVar27 + 0x618) == 0) goto LAB_0048233c;
        uVar7 = fn_198128();
      }
      if (((uStack_64 | uVar7) & 1) != 0) {
        uVar4 = *(uint *)(lVar27 + 0x640);
        uVar1 = uVar4;
        if (0xb < uVar4) {
          uVar1 = 0xc;
        }
        uVar2 = 0;
        if (-1 < (int)uVar4) {
          uVar2 = uVar1;
        }
        if (*(long *)(lVar27 + 0x600) != 0) {
          uVar25 = 0;
          do {
            if (uVar25 == 0x40) {
                    /* WARNING: Subroutine does not return */
              fn_125954(&UNK_007cf662);
            }
            puVar26 = (undefined8 *)(lVar27 + uVar25 * 0x18 + 8);
            uVar8 = fn_198128(*puVar26);
            if ((uVar8 & 1) != 0) {
              if ((uStack_64 & 1) != 0) {
                puVar23 = (undefined8 *)param_1[1];
                uVar20 = *puVar26;
                uVar28 = *(undefined8 *)(lVar27 + 0x610);
                uVar6 = *(undefined *)(lVar27 + 0x75d);
                uVar33 = *(undefined4 *)(lVar27 + uVar25 * 0x18 + 0x10);
                if (puVar23 < (undefined8 *)param_1[2]) {
                  *(undefined4 *)((long)puVar23 + 0x1c) = uVar33;
                  puVar22 = puVar23 + 4;
                  *puVar23 = uVar20;
                  puVar23[1] = uVar28;
                  *(undefined4 *)(puVar23 + 2) = 0;
                  *(uint *)((long)puVar23 + 0x14) = uVar2;
                  *(undefined *)(puVar23 + 3) = uVar6;
LAB_004824d4:
                  param_1[1] = (ulong)puVar22;
                  goto LAB_004824d8;
                }
                puVar21 = (undefined8 *)*param_1;
                lVar29 = (long)puVar23 - (long)puVar21 >> 5;
                uVar8 = lVar29 + 1;
                if (uVar8 >> 0x3b == 0) {
                  uVar13 = (long)(undefined8 *)param_1[2] - (long)puVar21;
                  uVar19 = (long)uVar13 >> 4;
                  if (uVar19 <= uVar8) {
                    uVar19 = uVar8;
                  }
                  if (0x7fffffffffffffdf < uVar13) {
                    uVar19 = 0x7ffffffffffffff;
                  }
                  if (uVar19 == 0) {
                    lVar10 = 0;
LAB_0048246c:
                    puVar22 = (undefined8 *)(lVar10 + lVar29 * 0x20);
                    *(undefined4 *)(puVar22 + 2) = 0;
                    *(uint *)((long)puVar22 + 0x14) = uVar2;
                    *puVar22 = uVar20;
                    puVar22[1] = uVar28;
                    *(undefined *)(puVar22 + 3) = uVar6;
                    *(undefined4 *)((long)puVar22 + 0x1c) = uVar33;
                    puVar17 = puVar22;
                    puVar16 = puVar22;
                    if (puVar23 != puVar21) {
                      do {
                        puVar24 = puVar23 + -4;
                        uVar30 = *puVar24;
                        uVar28 = puVar23[-1];
                        uVar20 = puVar23[-2];
                        puVar16 = puVar17 + -4;
                        puVar17[-3] = puVar23[-3];
                        *puVar16 = uVar30;
                        puVar17[-1] = uVar28;
                        puVar17[-2] = uVar20;
                        puVar17 = puVar16;
                        puVar23 = puVar24;
                      } while (puVar24 != puVar21);
                      puVar23 = (undefined8 *)*param_1;
                    }
                    puVar22 = puVar22 + 4;
                    *param_1 = (ulong)puVar16;
                    param_1[1] = (ulong)puVar22;
                    param_1[2] = lVar10 + uVar19 * 0x20;
                    if (puVar23 != (undefined8 *)0x0) {
                      fn_6790c8(puVar23);
                    }
                    goto LAB_004824d4;
                  }
                  if (uVar19 >> 0x3b == 0) {
                    lVar10 = fn_679020(uVar19 << 5);
                    goto LAB_0048246c;
                  }
LAB_00482640:
                  fn_13edb4();
                }
                fn_378a90(param_1);
LAB_0048264c:
                auVar37 = fn_378a90(param_1);
                pcVar12 = auVar37._8_8_;
                puVar11 = auVar37._0_8_;
                lVar27 = tpidr_el0;
                lVar14 = *(long *)(lVar27 + 0x28);
                if (*pcVar12 == '\0') goto LAB_00482878;
                if (pcVar12[1] == '\0') {
                  uVar33 = 0;
                  uVar34 = 0;
                  uVar35 = 0;
                  uVar36 = 0;
                }
                else {
                  uVar33 = *(undefined4 *)(pcVar12 + 0x14);
                  uVar34 = *(undefined4 *)(pcVar12 + 0x18);
                  uVar35 = *(undefined4 *)(pcVar12 + 0x1c);
                  uVar36 = *(undefined4 *)(pcVar12 + 0x20);
                }
                lVar29 = 0x787e5c0;
                lVar10 = 0;
                goto LAB_004826f8;
              }
LAB_004824d8:
              if ((uVar7 & 1) != 0) {
                uVar28 = *puVar26;
                uVar20 = *(undefined8 *)(lVar27 + 0x618);
                uVar33 = *(undefined4 *)(lVar27 + 0x87c);
                puVar9 = (undefined *)imp_wmemchr(&UNK_00803ca8,*(undefined4 *)(lVar27 + 0x760),0xb)
                ;
                puVar3 = &UNK_00803cd4;
                if (puVar9 != (undefined *)0x0) {
                  puVar3 = puVar9;
                }
                puVar26 = (undefined8 *)param_1[1];
                uVar6 = *(undefined *)(lVar27 + 0x75d);
                uVar34 = 2;
                if (puVar3 != &UNK_00803cd4) {
                  uVar34 = *(undefined4 *)(lVar27 + 0x760);
                }
                uVar35 = *(undefined4 *)(lVar27 + uVar25 * 0x18 + 0x10);
                if (puVar26 < (undefined8 *)param_1[2]) {
                  *puVar26 = uVar28;
                  puVar26[1] = uVar20;
                  *(undefined4 *)(puVar26 + 2) = uVar33;
                  *(undefined4 *)((long)puVar26 + 0x14) = uVar34;
                  *(undefined *)(puVar26 + 3) = uVar6;
                  puVar23 = puVar26 + 4;
                  *(undefined4 *)((long)puVar26 + 0x1c) = uVar35;
                }
                else {
                  puVar22 = (undefined8 *)*param_1;
                  lVar29 = (long)puVar26 - (long)puVar22 >> 5;
                  uVar8 = lVar29 + 1;
                  if (uVar8 >> 0x3b != 0) goto LAB_0048264c;
                  uVar13 = (long)(undefined8 *)param_1[2] - (long)puVar22;
                  uVar19 = (long)uVar13 >> 4;
                  if (uVar19 <= uVar8) {
                    uVar19 = uVar8;
                  }
                  if (0x7fffffffffffffdf < uVar13) {
                    uVar19 = 0x7ffffffffffffff;
                  }
                  if (uVar19 == 0) {
                    lVar10 = 0;
                  }
                  else {
                    if (uVar19 >> 0x3b != 0) goto LAB_00482640;
                    lVar10 = fn_679020(uVar19 << 5);
                  }
                  puVar23 = (undefined8 *)(lVar10 + lVar29 * 0x20);
                  *puVar23 = uVar28;
                  puVar23[1] = uVar20;
                  *(undefined *)(puVar23 + 3) = uVar6;
                  *(undefined4 *)(puVar23 + 2) = uVar33;
                  *(undefined4 *)((long)puVar23 + 0x14) = uVar34;
                  *(undefined4 *)((long)puVar23 + 0x1c) = uVar35;
                  puVar21 = puVar23;
                  puVar17 = puVar23;
                  if (puVar26 != puVar22) {
                    do {
                      puVar16 = puVar26 + -4;
                      uVar30 = *puVar16;
                      uVar28 = puVar26[-1];
                      uVar20 = puVar26[-2];
                      puVar17 = puVar21 + -4;
                      puVar21[-3] = puVar26[-3];
                      *puVar17 = uVar30;
                      puVar21[-1] = uVar28;
                      puVar21[-2] = uVar20;
                      puVar21 = puVar17;
                      puVar26 = puVar16;
                    } while (puVar16 != puVar22);
                    puVar26 = (undefined8 *)*param_1;
                  }
                  puVar23 = puVar23 + 4;
                  *param_1 = (ulong)puVar17;
                  param_1[1] = (ulong)puVar23;
                  param_1[2] = lVar10 + uVar19 * 0x20;
                  if (puVar26 != (undefined8 *)0x0) {
                    fn_6790c8(puVar26);
                  }
                }
                param_1[1] = (ulong)puVar23;
              }
            }
            uVar25 = uVar25 + 1;
          } while (uVar25 < *(ulong *)(lVar27 + 0x600));
        }
      }
    }
    lVar29 = lVar14 + 0x890;
    lVar27 = lVar14 + 0x787ee50;
    lVar14 = lVar29;
    if (lVar29 == 0x11200) {
      return;
    }
  } while( true );
LAB_004826f8:
  do {
    if ((*(char *)(lVar29 + 0x888) != '\0') && (*(long *)(lVar29 + 0x600) != 0)) {
      uVar25 = 0;
      do {
        if (uVar25 == 0x40) {
          if (*(long *)(lVar27 + 0x28) == lVar14) {
                    /* WARNING: Subroutine does not return */
            fn_125954(&UNK_007cf662);
          }
          goto LAB_00482908;
        }
        puVar26 = (undefined8 *)(lVar29 + uVar25 * 0x18 + 8);
        uVar8 = fn_198128(*puVar26);
        if ((uVar8 & 1) != 0) {
          puVar23 = (undefined8 *)puVar11[1];
          uVar30 = *(undefined8 *)(pcVar12 + 0xc);
          uVar28 = *(undefined8 *)(pcVar12 + 4);
          uVar20 = *puVar26;
          uVar5 = *(undefined4 *)(lVar29 + uVar25 * 0x18 + 0x10);
          if (puVar23 < (undefined8 *)puVar11[2]) {
            *puVar23 = uVar20;
            *(undefined4 *)(puVar23 + 1) = 1;
            puVar26 = puVar23 + 6;
            *(undefined8 *)((long)puVar23 + 0x14) = uVar30;
            *(undefined8 *)((long)puVar23 + 0xc) = uVar28;
            *(undefined4 *)((long)puVar23 + 0x1c) = uVar33;
            *(undefined4 *)(puVar23 + 4) = uVar34;
            *(undefined4 *)((long)puVar23 + 0x24) = uVar35;
            *(undefined4 *)(puVar23 + 5) = uVar36;
            *(undefined4 *)((long)puVar23 + 0x2c) = uVar5;
          }
          else {
            puVar22 = (undefined8 *)*puVar11;
            lVar18 = (long)puVar23 - (long)puVar22 >> 4;
            uVar8 = lVar18 * -0x5555555555555555 + 1;
            if (0x555555555555555 < uVar8) {
              if (*(long *)(lVar27 + 0x28) == lVar14) {
                fn_34ba14(puVar11);
LAB_004828f0:
                if (*(long *)(lVar27 + 0x28) == lVar14) {
                  fn_13edb4();
                }
              }
              goto LAB_00482908;
            }
            lVar15 = (long)(undefined8 *)puVar11[2] - (long)puVar22 >> 4;
            uVar19 = lVar15 * 0x5555555555555556;
            if (uVar19 < uVar8 || uVar19 - uVar8 == 0) {
              uVar19 = uVar8;
            }
            if (0x2aaaaaaaaaaaaa9 < (ulong)(lVar15 * -0x5555555555555555)) {
              uVar19 = 0x555555555555555;
            }
            if (uVar19 == 0) {
              lVar15 = 0;
            }
            else {
              if (0x555555555555555 < uVar19) goto LAB_004828f0;
              lVar15 = fn_679020(uVar19 * 0x30);
            }
            uVar30 = *(undefined8 *)(pcVar12 + 0xc);
            uVar28 = *(undefined8 *)(pcVar12 + 4);
            puVar26 = (undefined8 *)(lVar15 + lVar18 * 0x10);
            *(undefined4 *)(puVar26 + 1) = 1;
            *puVar26 = uVar20;
            *(undefined8 *)((long)puVar26 + 0x14) = uVar30;
            *(undefined8 *)((long)puVar26 + 0xc) = uVar28;
            *(undefined4 *)((long)puVar26 + 0x1c) = uVar33;
            *(undefined4 *)(puVar26 + 4) = uVar34;
            *(undefined4 *)((long)puVar26 + 0x24) = uVar35;
            *(undefined4 *)(puVar26 + 5) = uVar36;
            *(undefined4 *)((long)puVar26 + 0x2c) = uVar5;
            puVar21 = puVar26;
            if (puVar23 != puVar22) {
              do {
                uVar31 = puVar23[-3];
                uVar30 = puVar23[-4];
                uVar28 = puVar23[-1];
                uVar20 = puVar23[-2];
                puVar17 = puVar23 + -5;
                uVar32 = puVar23[-6];
                puVar23 = puVar23 + -6;
                puVar21[-5] = *puVar17;
                puVar21[-6] = uVar32;
                puVar21[-3] = uVar31;
                puVar21[-4] = uVar30;
                puVar21[-1] = uVar28;
                puVar21[-2] = uVar20;
                puVar21 = puVar21 + -6;
              } while (puVar23 != puVar22);
              puVar23 = (undefined8 *)*puVar11;
            }
            puVar26 = puVar26 + 6;
            *puVar11 = (ulong)puVar21;
            puVar11[1] = (ulong)puVar26;
            puVar11[2] = lVar15 + uVar19 * 0x30;
            if (puVar23 != (undefined8 *)0x0) {
              fn_6790c8(puVar23);
            }
          }
          puVar11[1] = (ulong)puVar26;
        }
        uVar25 = uVar25 + 1;
      } while (uVar25 < *(ulong *)(lVar29 + 0x600));
    }
    lVar18 = lVar10 + 0x890;
    lVar29 = lVar10 + 0x787ee50;
    lVar10 = lVar18;
  } while (lVar18 != 0x11200);
LAB_00482878:
  if (*(long *)(lVar27 + 0x28) == lVar14) {
    return;
  }
LAB_00482908:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

