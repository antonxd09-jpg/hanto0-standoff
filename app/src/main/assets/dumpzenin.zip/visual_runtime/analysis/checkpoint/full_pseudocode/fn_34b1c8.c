
// ================================================================================
// Original upload at: @imguisource_bot
// Channels: @ImGui_Source_FIXNEY (ImGui Source), @il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x34b1c8 */

long fn_34b1c8(long param_1,undefined8 param_2)

{
  int iVar1;
  ulong uVar2;
  ulong uVar3;
  long lVar4;
  long lVar5;
  long *plVar6;
  
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  uVar2 = fn_139354(0x76a97a8,param_1 + 0x28,8);
  if (((((uVar2 & 1) != 0) && (lVar4 = *(long *)(param_1 + 0x28), lVar4 != 0)) &&
      (uVar2 = fn_139354(0x76a97a8,lVar4 + 0x10,8), (uVar2 & 1) != 0)) &&
     (lVar4 = *(long *)(lVar4 + 0x10), lVar4 != 0)) {
    uVar2 = fn_139354(0x76a97a8,lVar4 + 0x10,8);
    if ((uVar2 & 1) == 0) {
      lVar5 = 0;
    }
    else {
      lVar5 = *(long *)(lVar4 + 0x10);
    }
    uVar2 = fn_139354(0x76a97a8,lVar4 + 0x18,4);
    if ((uVar2 & 1) != 0) {
      if (lVar5 == 0) {
        return 0;
      }
      uVar2 = (ulong)*(uint *)(lVar4 + 0x18);
      if (0x1f < *(uint *)(lVar4 + 0x18) - 1) {
        return 0;
      }
      plVar6 = (long *)(lVar5 + 0x20);
      do {
        uVar3 = fn_139354(0x76a97a8,plVar6,8);
        if (((uVar3 & 1) != 0) && (lVar4 = *plVar6, lVar4 != 0)) {
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          uVar3 = fn_43da54(0x76a9768,lVar4,param_2);
          if ((uVar3 & 1) != 0) {
            return lVar4;
          }
        }
        uVar2 = uVar2 - 1;
        plVar6 = plVar6 + 1;
        if (uVar2 == 0) {
          return 0;
        }
      } while( true );
    }
  }
  return 0;
}

