
// ================================================================================
// Телеграм экосистема:
// - Бот: t.me/imguisource_bot
// - Канал 1: t.me/ImGui_Source_FIXNEY (ImGui Source)
// - Канал 2: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x381d80 */

bool fn_381d80(long param_1,undefined8 *param_2,undefined8 param_3,long param_4,ulong param_5)

{
  ulong *puVar1;
  ulong *puVar2;
  long lVar3;
  bool bVar4;
  int iVar5;
  undefined4 uVar6;
  ulong uVar7;
  long lVar8;
  ulong uVar9;
  char *pcVar10;
  float *pfVar11;
  ulong uVar12;
  long lVar13;
  undefined8 uStack_78;
  undefined8 uStack_70;
  long lStack_68;
  
  lVar3 = tpidr_el0;
  lStack_68 = *(long *)(lVar3 + 0x28);
  if (param_5 == 0) {
    bVar4 = true;
  }
  else {
    lVar13 = 0;
    bVar4 = false;
    uVar12 = 0;
    pfVar11 = (float *)(param_4 + 8);
    do {
      if (lVar13 == 0x600) goto LAB_004820bc;
      puVar1 = (ulong *)(param_1 + lVar13);
      uVar7 = fn_198128(*puVar1);
      if (((uVar7 & 1) == 0) || (uVar7 = fn_198128(puVar1[1]), (uVar7 & 1) == 0)) {
        if ((*puVar1 | puVar1[1]) != 0) {
          uVar7 = fn_198128();
          if ((uVar7 & 1) != 0) {
            fn_369ce0(puVar1[1],0);
          }
          uVar7 = fn_198128(*puVar1);
          if ((uVar7 & 1) != 0) {
            fn_198eac(*puVar1);
          }
          *puVar1 = 0;
          puVar1[1] = 0;
          *(undefined4 *)(param_1 + lVar13 + 0x10) = 0xffffffff;
          *(undefined *)(param_1 + lVar13 + 0x14) = 0;
        }
        uVar7 = fn_36963c(&UNK_007de73a);
        *puVar1 = uVar7;
        if (uVar7 == 0) goto LAB_00481ff0;
        fn_199704(uVar7,0x3d);
        fn_1997d4(*(undefined8 *)(param_1 + 0x638));
        iVar5 = fn_199ea0();
        if (iVar5 - 1U < 0x1f) {
          fn_199f6c(*puVar1,iVar5);
        }
        puVar2 = (ulong *)(param_1 + lVar13);
        uVar6 = fn_199ea0(*puVar2);
        *(undefined4 *)(puVar2 + 2) = uVar6;
        *(undefined *)((long)puVar2 + 0x14) = 1;
        lVar8 = fn_3697f0(*puVar2);
        uVar7 = fn_369978(*puVar2);
        puVar1[1] = uVar7;
        if ((lVar8 == 0) || (uVar7 == 0)) {
          if ((uVar7 | *puVar2) != 0) {
            uVar12 = fn_198128();
            if ((uVar12 & 1) != 0) {
              fn_369ce0(puVar2[1],0);
            }
            uVar12 = fn_198128(*puVar2);
            if ((uVar12 & 1) != 0) {
              fn_198eac(*puVar2);
            }
            *puVar2 = 0;
            puVar2[1] = 0;
            *(undefined4 *)(puVar2 + 2) = 0xffffffff;
            *(undefined *)((long)puVar2 + 0x14) = 0;
          }
          goto LAB_00481ff0;
        }
        fn_369b28(lVar8,*(undefined8 *)(param_1 + 0x608));
        if (*(long *)(param_1 + 0x618) == 0) {
          fn_369c04(puVar1[1],*(undefined8 *)(param_1 + 0x610));
        }
        else {
          uStack_78 = *(undefined8 *)(param_1 + 0x610);
          uStack_70 = *(long *)(param_1 + 0x618);
          uVar7 = fn_369258(puVar1[1],&uStack_78,2);
          if ((uVar7 & 1) == 0) {
            puVar1 = (ulong *)(param_1 + lVar13);
            if ((*puVar1 | puVar1[1]) != 0) {
              uVar12 = fn_198128();
              if ((uVar12 & 1) != 0) {
                fn_369ce0(puVar1[1],0);
              }
              uVar12 = fn_198128(*puVar1);
              if ((uVar12 & 1) != 0) {
                fn_198eac(*puVar1);
              }
              *puVar1 = 0;
              puVar1[1] = 0;
              *(undefined4 *)(puVar1 + 2) = 0xffffffff;
              *(undefined *)((long)puVar1 + 0x14) = 0;
            }
            goto LAB_00481ff0;
          }
        }
      }
      else if (*(char *)(param_1 + lVar13 + 0x14) == '\0') {
        fn_369ce0(puVar1[1],1);
        *(undefined *)(param_1 + lVar13 + 0x14) = 1;
      }
      lVar8 = fn_36998c(*puVar1);
      if (lVar8 == 0) goto LAB_00481ff0;
      uStack_78 = CONCAT44((float)((ulong)*param_2 >> 0x20) +
                           (float)((ulong)*(undefined8 *)(pfVar11 + -2) >> 0x20),
                           (float)*param_2 + (float)*(undefined8 *)(pfVar11 + -2));
      uStack_70 = CONCAT44(uStack_70._4_4_,*(float *)(param_2 + 1) + *pfVar11);
      uVar7 = fn_196c78(lVar8,&uStack_78,param_3);
      if ((uVar7 & 1) == 0) goto LAB_00481ff0;
      uVar12 = uVar12 + 1;
      lVar13 = lVar13 + 0x18;
      pfVar11 = pfVar11 + 3;
      bVar4 = param_5 <= uVar12;
    } while (param_5 != uVar12);
  }
  if (param_5 < *(ulong *)(param_1 + 0x600)) {
    uVar12 = param_5;
    if (param_5 < 0x41) {
      uVar12 = 0x40;
    }
    pcVar10 = (char *)(param_1 + param_5 * 0x18 + 0x14);
    uVar7 = param_5;
    do {
      if (uVar12 == uVar7) goto LAB_004820bc;
      if ((*pcVar10 != '\0') &&
         (uVar9 = fn_198128(*(undefined8 *)(pcVar10 + -0xc)), (uVar9 & 1) != 0)) {
        fn_369ce0(*(undefined8 *)(pcVar10 + -0xc),0);
      }
      *pcVar10 = '\0';
      uVar7 = uVar7 + 1;
      pcVar10 = pcVar10 + 0x18;
    } while (uVar7 < *(ulong *)(param_1 + 0x600));
  }
  *(ulong *)(param_1 + 0x600) = param_5;
LAB_00481ff0:
  if (*(long *)(lVar3 + 0x28) == lStack_68) {
    return bVar4;
  }
LAB_004820dc:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
LAB_004820bc:
  if (*(long *)(lVar3 + 0x28) == lStack_68) {
                    /* WARNING: Subroutine does not return */
    fn_125954(&UNK_007cf662);
  }
  goto LAB_004820dc;
}

