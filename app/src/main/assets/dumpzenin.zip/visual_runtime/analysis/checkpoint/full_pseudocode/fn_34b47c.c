
// ================================================================================
// --------------------------------------------------
// * Telegram Bot: @imguisource_bot
// * ImGui Source: t.me/ImGui_Source_FIXNEY
// * shit src 🧨: t.me/il2cpp_src
// --------------------------------------------------
// ================================================================================

/* ORIGINAL_RVA: 0x34b47c */

long fn_34b47c(long param_1)

{
  int iVar1;
  ulong uVar2;
  long lVar3;
  long lVar4;
  
  if (lRam0000000007871f98 == 0) {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    lRam0000000007871f98 =
         fn_43d298(0x76a9768,uRam00000000076ab270,uRam00000000076ab278,uRam00000000076ab280);
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  uVar2 = fn_139354(0x76a97a8,param_1 + 0x70,8);
  if ((uVar2 & 1) == 0) {
    lVar3 = 0;
  }
  else {
    lVar4 = *(long *)(param_1 + 0x70);
    lVar3 = 0;
    if ((lVar4 != 0) && (lRam0000000007871f98 != 0)) {
      if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
      }
      uVar2 = fn_43da54(0x76a9768,lVar4,lRam0000000007871f98);
      lVar3 = lVar4;
      if ((uVar2 & 1) == 0) {
        lVar3 = 0;
      }
    }
  }
  return lVar3;
}

