#!/usr/bin/env python3

# ================================================================================
# Проверенные сурсы в боте @imguisource_bot
# Официальный канал: t.me/ImGui_Source_FIXNEY (ImGui Source)
# Второй канал: t.me/il2cpp_src (shit src 🧨)
# ================================================================================

"""Снять фиксированную схему настроек исполнением исходного ARM64."""
import argparse,hashlib,json,struct
from pathlib import Path
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM,CS_OP_MEM
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_INVALID
from unicorn.arm64_const import *

CONFIG={'sha256':'b51edeec00f49cddf0731cc64803654533127cafcaed0d8b13cebf35387f895b',
 'entry':0x140ac8,'stack':0x100000000,'config':0x110000000,'serializer':0x120000000,
 'vtable':0x120001000,'callbacks':0x130000000,'tls':0x140000000,'return':0x150000000,
 'heap':0x160000000,'heap_size':0x4000000,'allocate':0x679020,'free':0x6790c8,
 'begin':0x13c968,'end':0x13cd74,'integer':0x13c84c,'float':0x13c864,'color':0x13c874,
 'limit':5000000,'page':0x1000}

def capture(image,imports_path,output):
    stream=image.open('rb');assert hashlib.file_digest(stream,'sha256').hexdigest()==CONFIG['sha256'];stream.seek(0)
    elf=ELFFile(stream);uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
    for segment in elf.iter_segments():
        if segment['p_type']!='PT_LOAD':continue
        start=segment['p_vaddr']&-CONFIG['page'];end=(segment['p_vaddr']+segment['p_memsz']+CONFIG['page']-1)&-CONFIG['page']
        uc.mem_map(start,end-start);uc.mem_write(segment['p_vaddr'],segment.data())
    for relocation in elf.get_section_by_name('.rela.dyn').iter_relocations():
        if relocation['r_info_type']==1027:uc.mem_write(relocation['r_offset'],struct.pack('<Q',relocation['r_addend']))
    for name,size in [('stack',0x200000),('config',0x200000),('serializer',0x2000),('callbacks',0x1000),('tls',0x1000),('return',0x1000),('heap',CONFIG['heap_size'])]:uc.mem_map(CONFIG[name],size)
    uc.mem_write(CONFIG['serializer'],struct.pack('<Q',CONFIG['vtable']))
    callbacks={}
    for offset in range(0,0x80,8):
        address=CONFIG['callbacks']+offset*8;callbacks[address]=offset;uc.mem_write(CONFIG['vtable']+offset,struct.pack('<Q',address))
    uc.reg_write(UC_ARM64_REG_TPIDR_EL0,CONFIG['tls']);uc.reg_write(UC_ARM64_REG_SP,CONFIG['stack']+0x1ff000)
    uc.reg_write(UC_ARM64_REG_LR,CONFIG['return']);uc.reg_write(UC_ARM64_REG_X0,CONFIG['serializer']);uc.reg_write(UC_ARM64_REG_X1,CONFIG['config'])
    # Необязательный callback предмета — nullptr, проверка 0x1479b0..0x1479cc.
    uc.reg_write(UC_ARM64_REG_X2,0)
    imports={int(line.split()[0],16):line.split()[1]for line in imports_path.read_text().splitlines()}
    md=Cs(CS_ARCH_ARM64,CS_MODE_ARM);md.detail=True
    paths=[];fields=[];gaps=[];category='';allocated=0;completed=False
    def reg(index):return uc.reg_read(UC_ARM64_REG_FP if index==29 else UC_ARM64_REG_LR if index==30 else UC_ARM64_REG_X0+index)
    def text(address):
        result=bytearray()
        while len(result)<2048:
            value=bytes(uc.mem_read(address+len(result),1))
            if value==b'\0':return result.decode('utf-8','replace')
            result+=value
        raise ValueError('Name exceeds limit')
    def ret(value=0):uc.reg_write(UC_ARM64_REG_X0,value);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
    def signed(value):return struct.unpack('<i',struct.pack('<I',value&0xffffffff))[0]
    def fp(register):return struct.unpack('<f',struct.pack('<I',uc.reg_read(register)))[0]
    def field(kind,count=1,minimum=None,maximum=None):
        address=reg(2);name=text(reg(1));row={'category':category,'path':'.'.join(paths+[name]),'name':name,'type':kind,'count':count,'caller_rva':uc.reg_read(UC_ARM64_REG_LR)-4}
        if CONFIG['config']<=address<CONFIG['config']+0x200000:row['offset_from_config']=address-CONFIG['config']
        else:row['temporary_storage']=True
        if minimum is not None:row['minimum']=minimum
        if maximum is not None:row['maximum']=maximum
        fields.append(row)
    def hook(uc,address,size,user):
        nonlocal category,allocated,completed
        if address==CONFIG['return']:completed=True;uc.emu_stop();return
        if address==CONFIG['allocate']:
            amount=max((reg(0)+15)&-16,16)
            if allocated+amount>CONFIG['heap_size']:raise ValueError('Emulator heap full')
            pointer=CONFIG['heap']+allocated;allocated+=amount;ret(pointer);return
        if address==CONFIG['free']:ret();return
        if address==CONFIG['begin']:paths.append(text(reg(1)));ret();return
        if address==CONFIG['end']:
            if paths:paths.pop()
            ret();return
        if address==CONFIG['integer']:field('int32',minimum=signed(reg(3)),maximum=signed(reg(4)));ret();return
        if address==CONFIG['float']:field('float32',minimum=fp(UC_ARM64_REG_S0),maximum=fp(UC_ARM64_REG_S1));ret();return
        if address==CONFIG['color']:field('float32',count=4,minimum=0.,maximum=1.);ret();return
        if address in imports:
            symbol=imports[address]
            if symbol=='strlen':ret(len(text(reg(0)).encode()));return
            if symbol in {'memcpy','memmove'}:
                destination=reg(0);uc.mem_write(destination,bytes(uc.mem_read(reg(1),reg(2))));ret(destination);return
            if symbol=='memset':
                destination=reg(0);uc.mem_write(destination,bytes([reg(1)&255])*reg(2));ret(destination);return
            if symbol=='memcmp':
                a,b=bytes(uc.mem_read(reg(0),reg(2))),bytes(uc.mem_read(reg(1),reg(2)));ret(((a>b)-(a<b))&0xffffffffffffffff);return
            if symbol in {'memchr','wmemchr'}:
                pointer,value,count=reg(0),reg(1),reg(2);stride=4 if symbol=='wmemchr'else 1;data=bytes(uc.mem_read(pointer,count*stride));found=0
                for i in range(count):
                    if int.from_bytes(data[i*stride:(i+1)*stride],'little')==value&((1<<(stride*8))-1):found=pointer+i*stride;break
                ret(found);return
            gaps.append({'pc':address,'import':symbol});uc.emu_stop();return
        if address not in callbacks:return
        offset=callbacks[address]
        if offset==0x10:ret(1);return
        if offset==0x38:category=text(reg(1));ret();return
        if offset==0x18:field('bool');ret();return
        if offset==0x20:field('int32',count=reg(3),minimum=signed(reg(4)),maximum=signed(reg(5)));ret();return
        if offset==0x28:field('float32',count=reg(3),minimum=fp(UC_ARM64_REG_S0),maximum=fp(UC_ARM64_REG_S1));ret();return
        if offset==0x40:
            field('unclassified_vtable_40');pc=uc.reg_read(UC_ARM64_REG_LR);instruction=next(md.disasm(bytes(uc.mem_read(pc,4)),pc));ops=instruction.operands
            if len(ops)==2 and ops[1].type==CS_OP_MEM and not ops[1].mem.index:
                base=instruction.reg_name(ops[1].mem.base);width=1 if instruction.mnemonic in {'ldrb','ldurb'}else 4 if instruction.mnemonic=='ldr'and instruction.reg_name(ops[0].reg).startswith('w')else None
                if base.startswith('x')and base[1:].isdigit()and width and reg(int(base[1:]))+ops[1].mem.disp==reg(2):fields[-1].update(storage_width_verified=width,storage_width_instruction_rva=pc,storage_width_instruction=instruction.mnemonic+' '+instruction.op_str)
            ret();return
        if offset in {0x30,0x48,0x50,0x58,0x60,0x68,0x70,0x78}:
            field(f'unclassified_vtable_{offset:x}');ret();return
        gaps.append({'pc':address,'virtual_offset':offset});uc.emu_stop()
    def invalid(uc,access,address,size,value,user):gaps.append({'pc':uc.reg_read(UC_ARM64_REG_PC),'address':address,'access':access});return False
    uc.hook_add(UC_HOOK_CODE,hook);uc.hook_add(UC_HOOK_MEM_INVALID,invalid);error=None
    try:uc.emu_start(CONFIG['entry'],CONFIG['return']+4,count=CONFIG['limit'])
    except Exception as exc:error=f'{type(exc).__name__}: {exc}'
    visual=[r for r in fields if r['category'].startswith('Visuals')];normalized=[]
    for i,row in enumerate(visual):
        if row.get('temporary_storage')and i and visual[i-1]['path']==row['path']and visual[i-1].get('storage_width_verified'):continue
        item=dict(row)
        if item.get('storage_width_verified')and i+1<len(visual):
            following=visual[i+1]
            if following['path']==item['path']and following.get('temporary_storage')and following['type']=='int32':item.update(type='enum8'if item['storage_width_verified']==1 else'enum32',minimum=following['minimum'],maximum=following['maximum'],range_caller_rva=following['caller_rva'])
        normalized.append(item)
    report={'input_sha256':CONFIG['sha256'],'native_capture_completed':completed,'capture_error':error,'gaps':gaps,'native_entry_rva':CONFIG['entry'],'profile':'zero initialized storage; vtable+0x10=true; optional callback=nullptr','scope_limit':'dynamic containers empty; defaults not recovered','address_kind':'offsets in serializer argument, not Unity object layout','raw_registration_count':len(visual),'total_registration_count':len(fields),'fields':normalized}
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(report,indent=2)+'\n')
    print('returned',completed,'fields',len(fields),'visual calls',len(visual),'unique',len(normalized),'gaps',gaps,'error',error,flush=True)
    assert completed and not gaps and not error and len(normalized)==1957
    assert len({r['path']for r in normalized})==1957 and not any(r['type'].startswith('unclassified')for r in normalized)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('image',type=Path);p.add_argument('imports',type=Path);p.add_argument('output',type=Path);a=p.parse_args();capture(a.image,a.imports,a.output)
