
// ================================================================================
// Do not re-upload without credits:
// Bot: @imguisource_bot
// ImGui Source: @ImGui_Source_FIXNEY
// shit src 🧨: @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x319fb0 */

void fn_319fb0(long param_1)

{
  bool bVar1;
  long lVar2;
  long lVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  undefined4 uVar12;
  float fVar13;
  undefined4 uVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  undefined4 uVar29;
  undefined4 uVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  undefined4 uVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  float fStack_128;
  float fStack_124;
  float fStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  float fStack_114;
  float fStack_110;
  undefined4 uStack_108;
  float fStack_104;
  float fStack_100;
  undefined4 uStack_f8;
  float fStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_bc;
  float fStack_b8;
  undefined4 uStack_b4;
  float fStack_ac;
  long lStack_98;
  
  lVar2 = tpidr_el0;
  lStack_98 = *(long *)(lVar2 + 0x28);
  if (((bRam0000000007761618 & 1) == 0) && (iVar6 = fn_65eda8(0x7761618), iVar6 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  if (((bRam0000000007761618 & 1) == 0) && (iVar6 = fn_65eda8(0x7761618), iVar6 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  lVar3 = lRam0000000007760e20;
  if (lRam0000000007760e20 != 0) {
    iVar6 = (*pcRam0000000007761678)(param_1,0);
    iVar7 = (*pcRam0000000007761680)(param_1,0);
    iVar8 = (*pcRam0000000007761700)(0);
    if ((iVar8 < iVar6 * 3) || (iVar6 = (*pcRam0000000007761708)(0), iVar6 < iVar7 * 3)) {
      fn_18e534(&uStack_d8,param_1);
      fn_18e3c8(&uStack_118,param_1);
      uVar12 = NEON_fmadd(uStack_d4,uStack_118,fStack_114 * fStack_c4);
      uVar14 = NEON_fmadd(uStack_cc,uStack_f8,fStack_f4 * fStack_bc);
      uVar29 = NEON_fmadd(uStack_d4,uStack_f8,fStack_f4 * fStack_c4);
      fVar10 = (float)NEON_fmadd(uStack_b4,fStack_110,uVar12);
      fVar9 = (float)NEON_fmadd(fStack_ac,uStack_f0,uVar14);
      uVar30 = NEON_fmadd(uStack_cc,uStack_108,fStack_104 * fStack_bc);
      uVar14 = NEON_fmadd(uStack_cc,uStack_118,fStack_114 * fStack_bc);
      fStack_114 = fStack_c8 * fStack_114;
      uVar34 = NEON_fmadd(uStack_d8,uStack_108,fStack_c8 * fStack_104);
      uVar12 = NEON_fmadd(uStack_d4,uStack_108,fStack_104 * fStack_c4);
      fVar13 = (float)NEON_fmadd(uStack_b4,uStack_f0,uVar29);
      fStack_c8 = fStack_c8 * fStack_f4;
      fVar11 = (float)NEON_fmadd(fStack_ac,fStack_100,uVar30);
      fVar15 = (float)NEON_fmadd(fStack_ac,fStack_110,uVar14);
      fVar31 = (float)NEON_fmadd(uStack_d8,uStack_118,fStack_114);
      fVar17 = (float)NEON_fmadd(fStack_b8,fStack_100,uVar34);
      fVar16 = (float)NEON_fmadd(uStack_b4,fStack_100,uVar12);
      uVar12 = NEON_fmadd(uStack_d8,uStack_f8,fStack_c8);
      fVar25 = (float)NEON_fmadd(fVar13,fVar15,-(fVar10 * fVar9));
      fVar18 = (float)NEON_fmadd(fStack_b8,fStack_110,fVar31);
      fVar22 = (float)NEON_fmadd(fStack_b8,uStack_f0,uVar12);
      fVar35 = (float)NEON_fmadd(fVar16,fVar9,-(fVar13 * fVar11));
      fVar33 = (float)NEON_fmadd(fVar10,fVar11,-(fVar16 * fVar15));
      uVar12 = NEON_fmadd(fVar18,fVar35,fVar17 * fVar25);
      fVar24 = 1e-12;
      fVar36 = (float)NEON_fmadd(fVar22,fVar33,uVar12);
      fVar23 = ABS(fVar36);
      bVar4 = fVar23 < INFINITY;
      bVar1 = INFINITY < fVar23;
      bVar5 = 1e-12 <= fVar23;
      if (bVar5 && (bVar1 || bVar4)) {
        fVar36 = 1.0 / fVar36;
        fStack_100 = (float)NEON_fmadd(fVar22,fVar11,-(fVar17 * fVar9));
        fVar24 = (float)NEON_fmadd(fVar17,fVar13,-(fVar22 * fVar16));
        fVar31 = (float)NEON_fmadd(fVar18,fVar9,-(fVar22 * fVar15));
        fStack_c8 = (float)NEON_fmadd(fVar22,fVar10,-(fVar18 * fVar13));
        fStack_b8 = (float)NEON_fmadd(fVar17,fVar15,-(fVar18 * fVar11));
        fVar23 = (float)NEON_fmadd(fVar18,fVar16,-(fVar17 * fVar10));
        fStack_110 = fVar35 * fVar36;
        fStack_100 = fStack_100 * fVar36;
        fVar24 = fVar24 * fVar36;
        fStack_ac = fVar25 * fVar36;
        fVar31 = fVar31 * fVar36;
        fStack_c8 = fStack_c8 * fVar36;
        fStack_114 = fVar33 * fVar36;
        fStack_b8 = fStack_b8 * fVar36;
        fVar23 = fVar23 * fVar36;
      }
      fVar25 = 0.0;
      fVar36 = 1.0;
      if ((cRam0000000007761614 != '\0' && (bVar5 && (bVar1 || bVar4))) &&
          lRam00000000077615e8 == param_1) {
        fVar35 = 0.0;
        fVar19 = 0.0;
        fVar20 = 0.0;
        fStack_120 = 0.0;
        fStack_124 = 0.0;
        fVar33 = 1.0;
        uVar12 = NEON_fmadd(fRam00000000077615f0,fStack_110,fStack_ac * fRam00000000077615f4);
        fVar26 = (float)NEON_fmadd(fRam00000000077615f8,fStack_114,uVar12);
        fStack_128 = 1.0;
        if (ABS(fVar26) != INFINITY) {
          uVar12 = NEON_fmadd(fRam00000000077615f0,fStack_100,fVar31 * fRam00000000077615f4);
          fVar27 = (float)NEON_fmadd(fRam00000000077615f8,fStack_b8,uVar12);
          fStack_128 = 1.0;
          if (ABS(fVar27) != INFINITY) {
            uVar12 = NEON_fmadd(fRam00000000077615f0,fVar24,fStack_c8 * fRam00000000077615f4);
            fVar28 = (float)NEON_fmadd(fRam00000000077615f8,fVar23,uVar12);
            fStack_128 = 1.0;
            if (ABS(fVar28) != INFINITY) {
              uVar12 = NEON_fmadd(fRam00000000077615fc,fStack_110,fStack_ac * fRam0000000007761600);
              fVar37 = (float)NEON_fmadd(fRam0000000007761604,fStack_114,uVar12);
              fStack_128 = 1.0;
              if (ABS(fVar37) != INFINITY) {
                uVar12 = NEON_fmadd(fRam00000000077615fc,fStack_100,fVar31 * fRam0000000007761600);
                fVar38 = (float)NEON_fmadd(fRam0000000007761604,fStack_b8,uVar12);
                fStack_120 = 0.0;
                fStack_128 = 1.0;
                if (ABS(fVar38) != INFINITY) {
                  uVar12 = NEON_fmadd(fRam00000000077615fc,fVar24,fStack_c8 * fRam0000000007761600);
                  fVar21 = (float)NEON_fmadd(fRam0000000007761604,fVar23,uVar12);
                  fStack_128 = 1.0;
                  if (ABS(fVar21) != INFINITY) {
                    uVar12 = NEON_fmadd(fRam0000000007761608,fStack_110,
                                        fStack_ac * fRam000000000776160c);
                    fVar32 = (float)NEON_fmadd(fRam0000000007761610,fStack_114,uVar12);
                    fStack_128 = 1.0;
                    if (ABS(fVar32) != INFINITY) {
                      uVar12 = NEON_fmadd(fRam0000000007761608,fStack_100,
                                          fVar31 * fRam000000000776160c);
                      fVar31 = (float)NEON_fmadd(fRam0000000007761610,fStack_b8,uVar12);
                      fStack_128 = 1.0;
                      if (ABS(fVar31) != INFINITY) {
                        uVar12 = NEON_fmadd(fRam0000000007761608,fVar24,
                                            fStack_c8 * fRam000000000776160c);
                        fVar24 = (float)NEON_fmadd(fRam0000000007761610,fVar23,uVar12);
                        if (ABS(fVar24) != INFINITY) {
                          fStack_128 = fVar26;
                          fVar36 = fVar24;
                          fVar33 = fVar38;
                          fVar25 = fVar31;
                          fVar35 = fVar32;
                          fVar19 = fVar21;
                          fVar20 = fVar37;
                          fStack_124 = fVar27;
                          fStack_120 = fVar28;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      else {
        fStack_128 = 1.0;
        fVar36 = 1.0;
        fVar33 = 1.0;
        fVar35 = 0.0;
        fVar19 = 0.0;
        fVar20 = 0.0;
        fStack_124 = 0.0;
        fStack_120 = 0.0;
      }
      if (bVar5 && (bVar1 || bVar4)) {
        fRam00000000077615f0 = fVar18;
        fRam00000000077615f4 = fVar17;
        fRam00000000077615f8 = fVar22;
        fRam00000000077615fc = fVar10;
        fRam0000000007761600 = fVar16;
        fRam0000000007761604 = fVar13;
        fRam0000000007761608 = fVar15;
        fRam000000000776160c = fVar11;
        fRam0000000007761610 = fVar9;
      }
      uStack_11c = 0;
      lRam00000000077615e8 = param_1;
      cRam0000000007761614 = bVar5 && (bVar1 || bVar4);
      fn_19d5a8(lVar3,uRam0000000007760ea4,&fStack_128);
      uStack_11c = 0;
      fStack_128 = fVar20;
      fStack_124 = fVar33;
      fStack_120 = fVar19;
      fn_19d5a8(lVar3,uRam0000000007760ea8,&fStack_128);
      uStack_11c = 0;
      fStack_128 = fVar35;
      fStack_124 = fVar25;
      fStack_120 = fVar36;
      fn_19d5a8(lVar3,uRam0000000007760eac,&fStack_128);
    }
  }
  if (*(long *)(lVar2 + 0x28) != lStack_98) {
                    /* WARNING: Subroutine does not return */
    imp___stack_chk_fail();
  }
  return;
}

