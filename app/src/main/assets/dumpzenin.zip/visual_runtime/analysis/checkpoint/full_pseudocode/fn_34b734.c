
// ================================================================================
// @project     ImGui Source
// @bot         t.me/imguisource_bot
// @channel_1   t.me/ImGui_Source_FIXNEY (ImGui Source)
// @channel_2   t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x34b734 */

undefined4 fn_34b734(void)

{
  undefined4 *puVar1;
  int iVar2;
  ulong uVar3;
  undefined4 uVar4;
  undefined auVar5 [16];
  
  fn_139930(&UNK_007df23f);
  auVar5 = fn_139930(&UNK_007df23f);
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  puVar1 = (undefined4 *)(auVar5._8_8_ + auVar5._0_8_);
  uVar3 = fn_139354(0x76a97a8,puVar1,4);
  uVar4 = 0;
  if ((uVar3 & 1) != 0) {
    uVar4 = *puVar1;
  }
  return uVar4;
}

