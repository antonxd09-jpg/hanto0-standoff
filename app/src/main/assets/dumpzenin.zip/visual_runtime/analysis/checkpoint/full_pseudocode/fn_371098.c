
// ================================================================================
// Exclusive release:
// TG Bot: t.me/imguisource_bot
// TG 1: t.me/ImGui_Source_FIXNEY (ImGui Source)
// TG 2: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x371098 */

void fn_371098(undefined8 *param_1,byte param_2)

{
  ulong uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  int iVar4;
  int iVar5;
  ulong uVar6;
  undefined8 uVar7;
  long lVar8;
  long lVar9;
  long lVar10;
  undefined8 *puVar11;
  ulong uVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  ulong uVar16;
  undefined8 *puVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  
  uVar1 = tpidr_el0;
  lVar8 = *(long *)(uVar1 + 0x28);
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar4 = fn_65eda8(0x787c6a0), iVar4 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    uRam000000000787c580 = 0;
    uRam000000000787c578 = 0;
    puRam000000000787c590 = (undefined8 *)0x0;
    uRam000000000787c588 = 0;
    uRam000000000787c5a0 = 0;
    puRam000000000787c598 = (undefined8 *)0x0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c688 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c689 = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  puVar3 = puRam000000000787c598;
  if (puRam000000000787c590 != puRam000000000787c598) {
    puVar15 = puRam000000000787c590;
    do {
      uVar16 = 0x555555555555555;
      uVar6 = fn_198128(*puVar15);
      if ((uVar6 & 1) != 0) {
        uVar7 = fn_1997d4(*puVar15);
        iVar4 = fn_199ea0();
        if (((((iVar4 != 8) != (bool)(param_2 & 1)) &&
             (uVar6 = func_0x0029a210(uVar7), (uVar6 & 1) != 0)) &&
            (uVar6 = func_0x0029ba64(*puVar15), (uVar6 & 1) != 0)) &&
           (iVar5 = func_0x0047143c(*puVar15), 0 < iVar5)) {
          uVar7 = *puVar15;
          lVar10 = puVar15[1];
          uVar22 = 0;
          uVar23 = 0;
          uVar25 = 0;
          uVar24 = 0;
          uVar19 = *(undefined8 *)(lVar10 + 0xc);
          uVar18 = *(undefined8 *)(lVar10 + 4);
          if ((*(char *)(puVar15 + 2) != '\0') && (*(char *)(lVar10 + 1) != '\0')) {
            uVar25 = *(undefined4 *)(lVar10 + 0x14);
            uVar23 = *(undefined4 *)(lVar10 + 0x18);
            uVar22 = *(undefined4 *)(lVar10 + 0x1c);
            uVar24 = *(undefined4 *)(lVar10 + 0x20);
          }
          puVar14 = (undefined8 *)param_1[1];
          if (puVar14 < (undefined8 *)param_1[2]) {
            *puVar14 = uVar7;
            puVar11 = puVar14 + 6;
            *(int *)(puVar14 + 1) = iVar5;
            *(undefined8 *)((long)puVar14 + 0x14) = uVar19;
            *(undefined8 *)((long)puVar14 + 0xc) = uVar18;
            *(undefined4 *)((long)puVar14 + 0x1c) = uVar25;
            *(undefined4 *)(puVar14 + 4) = uVar23;
            *(undefined4 *)((long)puVar14 + 0x24) = uVar22;
            *(undefined4 *)(puVar14 + 5) = uVar24;
            *(int *)((long)puVar14 + 0x2c) = iVar4;
          }
          else {
            puVar17 = (undefined8 *)*param_1;
            lVar10 = (long)puVar14 - (long)puVar17 >> 4;
            uVar6 = lVar10 * -0x5555555555555555 + 1;
            if (0x555555555555555 < uVar6) {
              if (*(long *)(uVar1 + 0x28) == lVar8) {
                fn_34ba14(param_1);
code_r0x004713f0:
                if ((*(long *)(uVar16 + 0x28) == lVar8) &&
                   (uVar7 = fn_13edb4(), *(long *)(uVar1 + 0x28) == lVar8)) {
                  fn_65ef80(0x787c6a0);
                    /* WARNING: Subroutine does not return */
                  fn_67b74c(uVar7);
                }
              }
              goto code_r0x0047142c;
            }
            lVar9 = (long)(undefined8 *)param_1[2] - (long)puVar17 >> 4;
            uVar12 = lVar9 * 0x5555555555555556;
            if (uVar12 < uVar6 || uVar12 - uVar6 == 0) {
              uVar12 = uVar6;
            }
            if (0x2aaaaaaaaaaaaa9 < (ulong)(lVar9 * -0x5555555555555555)) {
              uVar12 = uVar16;
            }
            if (uVar12 == 0) {
              lVar9 = 0;
            }
            else {
              uVar16 = uVar1;
              if (0x555555555555555 < uVar12) goto code_r0x004713f0;
              lVar9 = fn_679020(uVar12 * 0x30);
            }
            puVar11 = (undefined8 *)(lVar9 + lVar10 * 0x10);
            *puVar11 = uVar7;
            *(int *)(puVar11 + 1) = iVar5;
            *(undefined8 *)((long)puVar11 + 0x14) = uVar19;
            *(undefined8 *)((long)puVar11 + 0xc) = uVar18;
            *(undefined4 *)((long)puVar11 + 0x1c) = uVar25;
            *(undefined4 *)(puVar11 + 4) = uVar23;
            *(undefined4 *)((long)puVar11 + 0x24) = uVar22;
            *(undefined4 *)(puVar11 + 5) = uVar24;
            *(int *)((long)puVar11 + 0x2c) = iVar4;
            puVar13 = puVar11;
            if (puVar14 != puVar17) {
              do {
                uVar20 = puVar14[-3];
                uVar19 = puVar14[-4];
                uVar18 = puVar14[-1];
                uVar7 = puVar14[-2];
                puVar2 = puVar14 + -5;
                uVar21 = puVar14[-6];
                puVar14 = puVar14 + -6;
                puVar13[-5] = *puVar2;
                puVar13[-6] = uVar21;
                puVar13[-3] = uVar20;
                puVar13[-4] = uVar19;
                puVar13[-1] = uVar18;
                puVar13[-2] = uVar7;
                puVar13 = puVar13 + -6;
              } while (puVar14 != puVar17);
              puVar14 = (undefined8 *)*param_1;
            }
            puVar11 = puVar11 + 6;
            *param_1 = puVar13;
            param_1[1] = puVar11;
            param_1[2] = lVar9 + uVar12 * 0x30;
            if (puVar14 != (undefined8 *)0x0) {
              fn_6790c8(puVar14);
            }
          }
          param_1[1] = puVar11;
        }
      }
      puVar15 = puVar15 + 3;
    } while (puVar15 != puVar3);
  }
  if (*(long *)(uVar1 + 0x28) == lVar8) {
    return;
  }
code_r0x0047142c:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

