
// ================================================================================
// Package distributed via @imguisource_bot
// Channel ImGui Source: @ImGui_Source_FIXNEY
// Channel shit src 🧨: @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x34b8c0 */

void fn_34b8c0(undefined *param_1,float param_2,float param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  *param_1 = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  *(undefined8 *)(param_1 + 9) = 0;
  if (((0.0 < param_3) && (param_2 <= param_3)) && (*param_1 = 1, 0 < param_4)) {
    fVar5 = (float)fn_337520(param_2 / param_3,&UNK_02f48198,2);
    if (fVar5 <= 0.0) {
      fVar5 = 0.0;
    }
    fVar6 = (float)fn_337520(param_2 / param_3,&UNK_02f481b8,2);
    if (fVar6 <= 0.0) {
      fVar6 = 0.0;
    }
    uVar4 = (uint)(float)(int)(fVar5 * 1700.0);
    fVar6 = fVar6 * 100.0;
    fVar7 = 1.0;
    uVar1 = 0;
    if (ABS((float)(int)(fVar5 * 1700.0)) != INFINITY) {
      uVar1 = uVar4 & ((int)uVar4 >> 0x1f ^ 0xffffffffU);
    }
    if (0.0 <= fVar6) {
      fVar5 = 100.0;
      if (fVar6 <= 100.0) {
        fVar5 = fVar6;
      }
      fVar7 = (100.0 - fVar5) / 100.0;
    }
    uVar4 = 0x80000000;
    if (ABS(fVar7 * (float)uVar1) != INFINITY) {
      uVar4 = (int)(fVar7 * (float)uVar1);
    }
    uVar2 = uVar1;
    if ((int)uVar4 <= (int)uVar1) {
      uVar2 = uVar4;
    }
    if ((int)(uVar2 & ((int)uVar2 >> 0x1f ^ 0xffffffffU)) <= (int)param_5) {
      param_5 = uVar2;
    }
    param_5 = param_5 & ((int)param_5 >> 0x1f ^ 0xffffffffU);
    *(uint *)(param_1 + 0xc) = param_5;
    iVar3 = uVar1 - param_5;
    *(uint *)(param_1 + 4) = uVar1;
    *(int *)(param_1 + 8) = iVar3;
    param_1[0x10] = param_4 <= iVar3;
  }
  return;
}

