
// ================================================================================
// Release channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Second channel: t.me/il2cpp_src (shit src 🧨)
// Telegram bot: t.me/imguisource_bot
// ================================================================================

/* ORIGINAL_RVA: 0x31e710 */

bool fn_31e710(long param_1)

{
  int iVar1;
  
  if (param_1 == 0) {
    lRam00000000077616f0 = 0;
  }
  else {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    lRam00000000077616f0 = fn_43d5e4(0x76a9768,param_1,&UNK_007fd1a9,1);
    if (lRam00000000077616f0 != 0) goto LAB_0041e770;
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
LAB_0041e770:
  return lRam00000000077616f0 != 0;
}

