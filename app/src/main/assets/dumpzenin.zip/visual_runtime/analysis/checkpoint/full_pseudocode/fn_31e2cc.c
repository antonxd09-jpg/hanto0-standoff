
// ================================================================================
// Bot: @imguisource_bot
// Channel #1: @ImGui_Source_FIXNEY | ImGui Source
// Channel #2: @il2cpp_src | shit src 🧨
// ================================================================================

/* ORIGINAL_RVA: 0x31e2cc */

void fn_31e2cc(long param_1)

{
  long lVar1;
  int iVar2;
  long lVar3;
  long lVar4;
  ulong uVar5;
  long lVar6;
  ulong uVar7;
  int *piVar8;
  undefined8 uStack_70;
  long lStack_68;
  
  lVar1 = tpidr_el0;
  lStack_68 = *(long *)(lVar1 + 0x28);
  lRam00000000077616a8 = 0;
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  lVar3 = fn_43bc24(0x76a9768);
  uStack_70 = 0;
  if ((param_1 != 0) && (lVar4 = fn_43cd50(0x76a9768,param_1,&uStack_70), lVar4 != 0)) {
    do {
      uVar7 = (ulong)bRam00000000076aa0a5;
      uVar5 = fn_139354(0x76a97a8,uVar7 + lVar4,8);
      if (((((uVar5 & 1) != 0) && (piVar8 = *(int **)(uVar7 + lVar4), piVar8 != (int *)0x0)) &&
          (lVar6 = imp_strlen(piVar8), lVar6 == 5)) &&
         (*piVar8 == 0x6f74632e && *(char *)(piVar8 + 1) == 'r')) {
        uVar7 = (ulong)bRam00000000076aa0a4;
        uVar5 = fn_139354(0x76a97a8,uVar7 + lVar4,1);
        if (((uVar5 & 1) != 0) && (*(char *)(uVar7 + lVar4) == '\x04')) {
          uVar7 = (ulong)bRam00000000076aa0a2;
          uVar5 = fn_139354(0x76a97a8,uVar7 + lVar4,8);
          if ((uVar5 & 1) == 0) {
            lVar4 = 0;
          }
          else {
            lVar4 = *(long *)(uVar7 + lVar4);
          }
          if (lVar3 + 0x72aa270 == lVar4) {
            lRam00000000077616a8 = lVar4;
            if (lVar4 != 0) goto LAB_0041e448;
            goto LAB_0041e440;
          }
        }
      }
      lVar4 = fn_43cd50(0x76a9768,param_1,&uStack_70);
    } while (lVar4 != 0);
  }
  if (lRam00000000077616a8 == 0) {
LAB_0041e440:
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
  }
LAB_0041e448:
  if (*(long *)(lVar1 + 0x28) == lStack_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(lRam00000000077616a8 != 0);
}

