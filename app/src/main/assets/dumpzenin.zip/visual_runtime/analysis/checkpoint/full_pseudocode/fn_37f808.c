
// ================================================================================
// Powered by @imguisource_bot | Channels: @ImGui_Source_FIXNEY, @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x37f808 */

void fn_37f808(undefined8 param_1)

{
  long lVar1;
  undefined8 uStack_38;
  undefined4 uStack_30;
  long lStack_28;
  
  lVar1 = tpidr_el0;
  lStack_28 = *(long *)(lVar1 + 0x28);
  uStack_38 = 0;
  uStack_30 = 0;
  fn_126978(param_1,&uStack_38,0xc,0x795725ac11079e6f);
  if (*(long *)(lVar1 + 0x28) == lStack_28) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(uStack_38,uStack_30);
}

