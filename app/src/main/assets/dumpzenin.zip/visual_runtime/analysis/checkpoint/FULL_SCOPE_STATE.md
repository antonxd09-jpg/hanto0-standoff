# Full scope checkpoint

Latest user explicitly requires the WHOLE visual module in .hpp/.cpp, including chams, ESP, grenades, world, post FX and map processing. Individual function drops do not satisfy the current request. Do not repeat that mistake or claim full readiness.

Breakthrough this pass: TypedEsp.java applies 180 native ESP configuration fields as a 0x384-byte structure at original ELF RVA 0x6cb0040. Main function 0x43f24c has verified void(void) ABI (entry reads no incoming arguments). With these types and a 240-second decompile limit it completed successfully, producing 3918 lines. This is DIAGNOSTIC pseudocode, not a compilable restored CPP.

Main pseudo: analysis/typed_esp/fn_43f24c.txt. Ghidra script: analysis/TypedEsp.java. The parameterless main uses globals and a preview override block; native preview caller 0x449460 sets 0x6cb98c8 globals, invokes main, then restores them. Config anchor connection: 0x15edac first pointer field calls 0x43f0b8, and 0x15d3d8 copies this block into serialized snapshot start, size 900 bytes.

Current whole-module status is full_scope_status.json: still incomplete. Existing renderer_swap and trajectory_mesh are separate completed mechanisms, not the full visual subsystem. Do not generate unimplemented backend stubs, blind offsets, or use a wrapper into original library as if it were recovered standalone source.
