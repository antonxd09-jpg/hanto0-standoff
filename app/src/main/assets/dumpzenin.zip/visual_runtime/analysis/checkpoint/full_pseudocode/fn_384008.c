
// ================================================================================
// Get latest sources from @imguisource_bot
// Join ImGui Source: t.me/ImGui_Source_FIXNEY
// Join shit src 🧨: t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x384008 */

void fn_384008(ulong *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  float fVar8;
  ulong uVar9;
  long lVar10;
  undefined *puVar11;
  long lVar12;
  ulong *puVar13;
  char *pcVar14;
  ulong uVar15;
  long lVar16;
  long lVar17;
  undefined8 *puVar18;
  undefined8 *puVar19;
  undefined8 *puVar20;
  ulong uVar21;
  long lVar22;
  undefined8 *puVar23;
  undefined8 *puVar24;
  undefined8 *puVar25;
  undefined8 uVar26;
  undefined8 uVar27;
  float fVar28;
  undefined8 uVar29;
  undefined8 uVar30;
  float fVar31;
  undefined8 uVar32;
  undefined4 uVar33;
  undefined4 uVar34;
  undefined4 uVar35;
  undefined auVar36 [16];
  
  lVar22 = 0x788f7c8;
  lVar16 = 0;
  do {
    if ((*(char *)(lVar22 + 0x298) != '\0') &&
       (uVar9 = fn_198128(*(undefined8 *)(lVar22 + 0x10)), (uVar9 & 1) != 0)) {
      if ((*(char *)(lVar22 + 0x134) != '\0') &&
         (uVar9 = fn_198128(*(undefined8 *)(lVar22 + 0x20)), (uVar9 & 1) != 0)) {
        uVar4 = *(uint *)(lVar22 + 0x48);
        puVar24 = (undefined8 *)param_1[1];
        uVar27 = *(undefined8 *)(lVar22 + 0x10);
        uVar26 = *(undefined8 *)(lVar22 + 0x20);
        uVar7 = *(undefined *)(lVar22 + 0x165);
        uVar33 = *(undefined4 *)(lVar22 + 0x290);
        uVar1 = uVar4;
        if (0xb < uVar4) {
          uVar1 = 0xc;
        }
        uVar2 = 0;
        if (-1 < (int)uVar4) {
          uVar2 = uVar1;
        }
        if (puVar24 < (undefined8 *)param_1[2]) {
          *puVar24 = uVar27;
          puVar24[1] = uVar26;
          puVar18 = puVar24 + 4;
          *(undefined4 *)(puVar24 + 2) = 0;
          *(uint *)((long)puVar24 + 0x14) = uVar2;
          *(undefined *)(puVar24 + 3) = uVar7;
          *(undefined4 *)((long)puVar24 + 0x1c) = uVar33;
LAB_004841c0:
          param_1[1] = (ulong)puVar18;
          goto LAB_004841c4;
        }
        puVar25 = (undefined8 *)*param_1;
        lVar12 = (long)puVar24 - (long)puVar25 >> 5;
        uVar9 = lVar12 + 1;
        if (uVar9 >> 0x3b == 0) {
          uVar15 = (long)(undefined8 *)param_1[2] - (long)puVar25;
          uVar21 = (long)uVar15 >> 4;
          if (uVar21 <= uVar9) {
            uVar21 = uVar9;
          }
          if (0x7fffffffffffffdf < uVar15) {
            uVar21 = 0x7ffffffffffffff;
          }
          if (uVar21 == 0) {
            lVar10 = 0;
LAB_00484148:
            puVar18 = (undefined8 *)(lVar10 + lVar12 * 0x20);
            *puVar18 = uVar27;
            puVar18[1] = uVar26;
            *(undefined4 *)(puVar18 + 2) = 0;
            *(uint *)((long)puVar18 + 0x14) = uVar2;
            *(undefined *)(puVar18 + 3) = uVar7;
            *(undefined4 *)((long)puVar18 + 0x1c) = uVar33;
            puVar20 = puVar18;
            puVar19 = puVar18;
            if (puVar24 != puVar25) {
              do {
                puVar23 = puVar24 + -4;
                uVar29 = *puVar23;
                uVar27 = puVar24[-1];
                uVar26 = puVar24[-2];
                puVar19 = puVar20 + -4;
                puVar20[-3] = puVar24[-3];
                *puVar19 = uVar29;
                puVar20[-1] = uVar27;
                puVar20[-2] = uVar26;
                puVar20 = puVar19;
                puVar24 = puVar23;
              } while (puVar23 != puVar25);
              puVar24 = (undefined8 *)*param_1;
            }
            puVar18 = puVar18 + 4;
            *param_1 = (ulong)puVar19;
            param_1[1] = (ulong)puVar18;
            param_1[2] = lVar10 + uVar21 * 0x20;
            if (puVar24 != (undefined8 *)0x0) {
              fn_6790c8(puVar24);
            }
            goto LAB_004841c0;
          }
          if (uVar21 >> 0x3b == 0) {
            lVar10 = fn_679020(uVar21 << 5);
            goto LAB_00484148;
          }
        }
        else {
LAB_00484348:
          fn_378a90(param_1);
        }
LAB_00484350:
        auVar36 = fn_13edb4();
        pcVar14 = auVar36._8_8_;
        puVar13 = auVar36._0_8_;
        lVar22 = tpidr_el0;
        lVar16 = *(long *)(lVar22 + 0x28);
        if (*pcVar14 == '\0') goto LAB_00484588;
        lVar12 = 0x788f7c8;
        lVar10 = 0;
        break;
      }
LAB_004841c4:
      if (((*(char *)(lVar22 + 0x254) != '\0') && (*(long *)(lVar22 + 0x28) != 0)) &&
         (uVar9 = fn_198128(), (uVar9 & 1) != 0)) {
        uVar27 = *(undefined8 *)(lVar22 + 0x10);
        uVar26 = *(undefined8 *)(lVar22 + 0x28);
        uVar33 = *(undefined4 *)(lVar22 + 0x294);
        puVar11 = (undefined *)imp_wmemchr(&UNK_00803ca8,*(undefined4 *)(lVar22 + 0x168),0xb);
        puVar3 = &UNK_00803cd4;
        if (puVar11 != (undefined *)0x0) {
          puVar3 = puVar11;
        }
        uVar7 = *(undefined *)(lVar22 + 0x165);
        uVar35 = *(undefined4 *)(lVar22 + 0x290);
        puVar24 = (undefined8 *)param_1[1];
        uVar34 = 2;
        if (puVar3 != &UNK_00803cd4) {
          uVar34 = *(undefined4 *)(lVar22 + 0x168);
        }
        if (puVar24 < (undefined8 *)param_1[2]) {
          *puVar24 = uVar27;
          puVar24[1] = uVar26;
          puVar18 = puVar24 + 4;
          *(undefined4 *)(puVar24 + 2) = uVar33;
          *(undefined4 *)((long)puVar24 + 0x14) = uVar34;
          *(undefined *)(puVar24 + 3) = uVar7;
          *(undefined4 *)((long)puVar24 + 0x1c) = uVar35;
        }
        else {
          puVar25 = (undefined8 *)*param_1;
          lVar22 = (long)puVar24 - (long)puVar25 >> 5;
          uVar9 = lVar22 + 1;
          if (uVar9 >> 0x3b != 0) goto LAB_00484348;
          uVar15 = (long)(undefined8 *)param_1[2] - (long)puVar25;
          uVar21 = (long)uVar15 >> 4;
          if (uVar21 <= uVar9) {
            uVar21 = uVar9;
          }
          if (0x7fffffffffffffdf < uVar15) {
            uVar21 = 0x7ffffffffffffff;
          }
          if (uVar21 == 0) {
            lVar12 = 0;
          }
          else {
            if (uVar21 >> 0x3b != 0) goto LAB_00484350;
            lVar12 = fn_679020(uVar21 << 5);
          }
          puVar18 = (undefined8 *)(lVar12 + lVar22 * 0x20);
          *(undefined4 *)(puVar18 + 2) = uVar33;
          *(undefined4 *)((long)puVar18 + 0x14) = uVar34;
          *puVar18 = uVar27;
          puVar18[1] = uVar26;
          *(undefined *)(puVar18 + 3) = uVar7;
          *(undefined4 *)((long)puVar18 + 0x1c) = uVar35;
          puVar20 = puVar18;
          puVar19 = puVar18;
          if (puVar24 != puVar25) {
            do {
              puVar23 = puVar24 + -4;
              uVar29 = *puVar23;
              uVar27 = puVar24[-1];
              uVar26 = puVar24[-2];
              puVar19 = puVar20 + -4;
              puVar20[-3] = puVar24[-3];
              *puVar19 = uVar29;
              puVar20[-1] = uVar27;
              puVar20[-2] = uVar26;
              puVar20 = puVar19;
              puVar24 = puVar23;
            } while (puVar23 != puVar25);
            puVar24 = (undefined8 *)*param_1;
          }
          puVar18 = puVar18 + 4;
          *param_1 = (ulong)puVar19;
          param_1[1] = (ulong)puVar18;
          param_1[2] = lVar12 + uVar21 * 0x20;
          if (puVar24 != (undefined8 *)0x0) {
            fn_6790c8(puVar24);
          }
        }
        param_1[1] = (ulong)puVar18;
      }
    }
    lVar12 = lVar16 + 0x2a0;
    lVar22 = lVar16 + 0x788fa68;
    lVar16 = lVar12;
    if (lVar12 == 0x3f00) {
      return;
    }
  } while( true );
  do {
    if ((*(char *)(lVar12 + 0x298) != '\0') &&
       (uVar9 = fn_198128(*(undefined8 *)(lVar12 + 0x10)), (uVar9 & 1) != 0)) {
      fVar8 = 1.0;
      if (0.0 <= *(float *)(lVar12 + 0x28c)) {
        fVar8 = *(float *)(lVar12 + 0x28c);
      }
      if (pcVar14[1] == '\0') {
        uVar33 = 0;
        uVar34 = 0;
        uVar35 = 0;
        fVar28 = 0.0;
      }
      else {
        uVar33 = *(undefined4 *)(pcVar14 + 0x14);
        uVar34 = *(undefined4 *)(pcVar14 + 0x18);
        uVar35 = *(undefined4 *)(pcVar14 + 0x1c);
        fVar28 = *(float *)(pcVar14 + 0x20);
      }
      fVar31 = *(float *)(pcVar14 + 0x10);
      puVar24 = (undefined8 *)puVar13[1];
      uVar26 = *(undefined8 *)(pcVar14 + 4);
      uVar27 = *(undefined8 *)(lVar12 + 0x10);
      uVar6 = *(undefined4 *)(pcVar14 + 0xc);
      uVar5 = *(undefined4 *)(lVar12 + 0x290);
      if (puVar24 < (undefined8 *)puVar13[2]) {
        *puVar24 = uVar27;
        *(undefined4 *)(puVar24 + 1) = 1;
        puVar18 = puVar24 + 6;
        *(undefined8 *)((long)puVar24 + 0xc) = uVar26;
        *(undefined4 *)((long)puVar24 + 0x14) = uVar6;
        *(float *)(puVar24 + 3) = fVar8 * fVar31;
        *(undefined4 *)((long)puVar24 + 0x1c) = uVar33;
        *(undefined4 *)(puVar24 + 4) = uVar34;
        *(undefined4 *)((long)puVar24 + 0x24) = uVar35;
        *(float *)(puVar24 + 5) = fVar8 * fVar28;
        *(undefined4 *)((long)puVar24 + 0x2c) = uVar5;
      }
      else {
        puVar25 = (undefined8 *)*puVar13;
        lVar12 = (long)puVar24 - (long)puVar25 >> 4;
        uVar9 = lVar12 * -0x5555555555555555 + 1;
        if (0x555555555555555 < uVar9) {
          if (*(long *)(lVar22 + 0x28) == lVar16) {
            fn_34ba14(puVar13);
LAB_004845e4:
            if (*(long *)(lVar22 + 0x28) == lVar16) {
              fn_13edb4();
            }
          }
          goto LAB_004845fc;
        }
        lVar17 = (long)(undefined8 *)puVar13[2] - (long)puVar25 >> 4;
        uVar21 = lVar17 * 0x5555555555555556;
        if (uVar21 < uVar9 || uVar21 - uVar9 == 0) {
          uVar21 = uVar9;
        }
        if (0x2aaaaaaaaaaaaa9 < (ulong)(lVar17 * -0x5555555555555555)) {
          uVar21 = 0x555555555555555;
        }
        if (uVar21 == 0) {
          lVar17 = 0;
        }
        else {
          if (0x555555555555555 < uVar21) goto LAB_004845e4;
          lVar17 = fn_679020(uVar21 * 0x30);
        }
        uVar6 = *(undefined4 *)(pcVar14 + 0xc);
        puVar18 = (undefined8 *)(lVar17 + lVar12 * 0x10);
        *(undefined8 *)((long)puVar18 + 0xc) = *(undefined8 *)(pcVar14 + 4);
        *puVar18 = uVar27;
        *(undefined4 *)(puVar18 + 1) = 1;
        *(undefined4 *)((long)puVar18 + 0x14) = uVar6;
        *(float *)(puVar18 + 3) = fVar8 * fVar31;
        *(undefined4 *)((long)puVar18 + 0x1c) = uVar33;
        *(undefined4 *)(puVar18 + 4) = uVar34;
        *(undefined4 *)((long)puVar18 + 0x24) = uVar35;
        *(float *)(puVar18 + 5) = fVar8 * fVar28;
        *(undefined4 *)((long)puVar18 + 0x2c) = uVar5;
        puVar20 = puVar18;
        if (puVar24 != puVar25) {
          do {
            uVar30 = puVar24[-3];
            uVar29 = puVar24[-4];
            uVar27 = puVar24[-1];
            uVar26 = puVar24[-2];
            puVar19 = puVar24 + -5;
            uVar32 = puVar24[-6];
            puVar24 = puVar24 + -6;
            puVar20[-5] = *puVar19;
            puVar20[-6] = uVar32;
            puVar20[-3] = uVar30;
            puVar20[-4] = uVar29;
            puVar20[-1] = uVar27;
            puVar20[-2] = uVar26;
            puVar20 = puVar20 + -6;
          } while (puVar24 != puVar25);
          puVar24 = (undefined8 *)*puVar13;
        }
        puVar18 = puVar18 + 6;
        *puVar13 = (ulong)puVar20;
        puVar13[1] = (ulong)puVar18;
        puVar13[2] = lVar17 + uVar21 * 0x30;
        if (puVar24 != (undefined8 *)0x0) {
          fn_6790c8(puVar24);
        }
      }
      puVar13[1] = (ulong)puVar18;
    }
    lVar17 = lVar10 + 0x2a0;
    lVar12 = lVar10 + 0x788fa68;
    lVar10 = lVar17;
  } while (lVar17 != 0x3f00);
LAB_00484588:
  if (*(long *)(lVar22 + 0x28) == lVar16) {
    return;
  }
LAB_004845fc:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

