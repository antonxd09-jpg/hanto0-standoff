
// ================================================================================
// Telegram: @imguisource_bot | Join ImGui Source (t.me/ImGui_Source_FIXNEY) & shit src 🧨 (t.me/il2cpp_src)
// ================================================================================

/* ORIGINAL_RVA: 0x37fa10 */

void fn_37fa10(long *param_1,long param_2,long param_3,ulong param_4)

{
  ulong uVar1;
  int iVar2;
  long *plVar3;
  ulong uVar4;
  long lVar5;
  long lVar6;
  long lVar7;
  long lVar8;
  undefined auVar9 [16];
  
  uVar4 = param_1[2];
  lVar7 = *param_1;
  if (param_4 <= (ulong)((long)(uVar4 - lVar7) >> 4)) {
    lVar5 = param_1[1] - lVar7;
    if ((ulong)(lVar5 >> 4) < param_4) {
      lVar8 = param_2 + lVar5;
      if (param_1[1] != lVar7) {
        imp_memmove(lVar7,param_2,lVar5 + -4);
        lVar7 = param_1[1];
      }
      lVar5 = -lVar8;
    }
    else {
      lVar5 = -param_2;
      lVar8 = param_2;
    }
    param_3 = param_3 + lVar5;
    if (param_3 != 0) {
      imp_memmove(lVar7,lVar8,param_3 + -4);
    }
LAB_0047fb24:
    param_1[1] = lVar7 + param_3;
    return;
  }
  lVar5 = param_3;
  if (lVar7 != 0) {
    param_1[1] = lVar7;
    fn_6790c8(lVar7);
    uVar4 = 0;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if (param_4 >> 0x3c == 0) {
    uVar1 = (long)uVar4 >> 3;
    if ((ulong)((long)uVar4 >> 3) <= param_4) {
      uVar1 = param_4;
    }
    if (0x7fffffffffffffef < uVar4) {
      uVar1 = 0xfffffffffffffff;
    }
    if (uVar1 >> 0x3c == 0) {
      lVar7 = fn_679020(uVar1 * 0x10);
      param_3 = param_3 - param_2;
      *param_1 = lVar7;
      param_1[1] = lVar7;
      param_1[2] = lVar7 + uVar1 * 0x10;
      if (param_3 != 0) {
        imp_memcpy(lVar7,param_2,param_3 + -4);
      }
      goto LAB_0047fb24;
    }
  }
  auVar9 = fn_377560(param_1);
  lVar7 = auVar9._8_8_;
  plVar3 = auVar9._0_8_;
  lVar6 = plVar3[2];
  lVar8 = *plVar3;
  if ((ulong)((lVar6 - lVar8 >> 4) * -0x5555555555555555) < param_4) {
    if (lVar8 != 0) {
      plVar3[1] = lVar8;
      fn_6790c8(lVar8);
      lVar6 = 0;
      *plVar3 = 0;
      plVar3[1] = 0;
      plVar3[2] = 0;
    }
    if (param_4 < 0x555555555555556) {
      uVar4 = (lVar6 >> 4) * 0x5555555555555556;
      if (uVar4 < param_4 || uVar4 - param_4 == 0) {
        uVar4 = param_4;
      }
      if (0x2aaaaaaaaaaaaa9 < (ulong)((lVar6 >> 4) * -0x5555555555555555)) {
        uVar4 = 0x555555555555555;
      }
      if (uVar4 < 0x555555555555556) {
        lVar8 = fn_679020(uVar4 * 0x30);
        lVar5 = lVar5 - lVar7;
        *plVar3 = lVar8;
        plVar3[1] = lVar8;
        plVar3[2] = lVar8 + uVar4 * 0x30;
        if (lVar5 != 0) {
          imp_memcpy(lVar8,lVar7,lVar5);
        }
        goto LAB_0047fc88;
      }
    }
    fn_34ba14(plVar3);
    if (((bRam000000000787de70 & 1) == 0) && (iVar2 = fn_65eda8(0x787de70), iVar2 != 0)) {
      uRam000000000787de68 = 0;
      uRam000000000787de50 = 0;
      uRam000000000787de48 = 0;
      uRam000000000787de60 = 0;
      uRam000000000787de66 = 0;
      uRam000000000787de58 = 0;
      uRam000000000787de40 = 0;
      uRam000000000787de38 = 0;
      fn_126978(&UNK_02f49914,0x787de38,0x36,0x49b4cde932fa7adc);
      fn_65eed8(0x787de70);
    }
    uRam000000000787de28 = 0x787de38;
    if (((bRam000000000787deb0 & 1) == 0) && (iVar2 = fn_65eda8(0x787deb0), iVar2 != 0)) {
      uRam000000000787dea8 = 0;
      uRam000000000787de90 = 0;
      uRam000000000787de88 = 0;
      uRam000000000787dea0 = 0;
      uRam000000000787dea5 = 0;
      uRam000000000787de98 = 0;
      uRam000000000787de80 = 0;
      uRam000000000787de78 = 0;
      fn_126978(&UNK_02f4994a,0x787de78,0x35,0x2064a9c70a6ba787);
      fn_65eed8(0x787deb0);
    }
    uRam000000000787de30 = 0x787de78;
    return;
  }
  lVar6 = plVar3[1] - lVar8;
  if (((ulong)((lVar6 >> 4) * -0x5555555555555555) < param_4) &&
     (lVar7 = lVar7 + lVar6, plVar3[1] != lVar8)) {
    imp_memmove(lVar8);
    lVar8 = plVar3[1];
  }
  lVar5 = lVar5 - lVar7;
  if (lVar5 != 0) {
    imp_memmove(lVar8,lVar7,lVar5);
  }
LAB_0047fc88:
  plVar3[1] = lVar8 + lVar5;
  return;
}

