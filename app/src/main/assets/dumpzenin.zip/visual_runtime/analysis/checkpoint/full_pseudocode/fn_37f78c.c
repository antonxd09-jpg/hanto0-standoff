
// ================================================================================
// ##################################################
// # Bot: t.me/imguisource_bot
// # Main: t.me/ImGui_Source_FIXNEY (ImGui Source)
// # Two: t.me/il2cpp_src (shit src 🧨)
// ##################################################
// ================================================================================

/* ORIGINAL_RVA: 0x37f78c */

void fn_37f78c(undefined8 param_1)

{
  long lVar1;
  undefined7 uStack_38;
  undefined uStack_31;
  undefined4 uStack_30;
  uint uStack_2c;
  long lStack_28;
  
  lVar1 = tpidr_el0;
  lStack_28 = *(long *)(lVar1 + 0x28);
  uStack_38 = 0;
  uStack_31 = 0;
  uStack_30 = 0;
  uStack_2c = uStack_2c & 0xff000000;
  fn_126978(param_1,&uStack_38,0xf,0xe2cd80bce6f23a9);
  if (*(long *)(lVar1 + 0x28) == lStack_28) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(CONCAT17(uStack_31,uStack_38));
}

