
// ================================================================================
// Protected source: @imguisource_bot
// Official channels: t.me/ImGui_Source_FIXNEY & t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x37fe0c */

void fn_37fe0c(undefined8 param_1,undefined8 param_2,uint param_3)

{
  long lVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  ulong uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  long lVar9;
  ulong uVar10;
  code *pcVar11;
  undefined8 *puVar12;
  undefined auStack_c4 [16];
  undefined auStack_b4 [12];
  undefined auStack_a8 [64];
  long lStack_68;
  
  lVar1 = tpidr_el0;
  lStack_68 = *(long *)(lVar1 + 0x28);
  if ((pcRam000000000787e4c0 != (code *)0x0) && (lRam000000000787e470 != 0)) {
    (*pcRam000000000787e4c0)(0,lRam000000000787e470,0);
  }
  uVar6 = fn_198128(param_1);
  if (((uVar6 & 1) == 0) || (uVar6 = fn_198128(param_2), (uVar6 & 1) == 0)) goto LAB_00480454;
  if ((cRam000000000787e490 == '\0') && (uVar6 = fn_380834(), (uVar6 & 1) == 0)) {
    if (cRam000000000787e488 == '\0') {
      fn_126488();
    }
  }
  else {
    iVar2 = (*pcRam000000000787e4c8)(param_1,0);
    iVar3 = (*pcRam000000000787e4d0)(param_1,0);
    if (((0xffffdfff < iVar2 - 0x2001U) && (0xffffdfff < iVar3 - 0x2001U)) &&
       ((cRam000000000787e490 != '\0' || (uVar6 = fn_380834(), (uVar6 & 1) != 0)))) {
      lVar9 = lRam000000000787e460;
      if (lRam000000000787e460 == 0) {
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        if (((bRam000000000787e590 & 1) == 0) && (iVar5 = fn_65eda8(0x787e590), iVar5 != 0)) {
          uRam000000000787e578 = 0;
          uRam000000000787e580 = 0;
          uRam000000000787e585 = 0;
          uRam000000000787e588 = 0;
          fn_126978(&UNK_02f49a41,0x787e578,0x15,0x164cc11f93ba55ae);
          fn_65eed8(0x787e590);
        }
        lVar9 = fn_43cd88(0x76a9768,0x787e578);
        if (lRam000000000787e468 != 0) {
          fn_439c54(lRam000000000787e468);
        }
        if (lVar9 == 0) {
          lRam000000000787e460 = 0;
          lRam000000000787e468 = 0;
        }
        else {
          lRam000000000787e468 = fn_439970(lVar9);
          lRam000000000787e460 = 0;
          if (lRam000000000787e468 != 0) goto LAB_0047fefc;
        }
      }
      else {
LAB_0047fefc:
        lRam000000000787e460 = lVar9;
        lVar9 = lRam000000000787e470;
        if (lRam000000000787e470 == 0) {
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          if (((bRam000000000787e5b8 & 1) == 0) && (iVar5 = fn_65eda8(0x787e5b8), iVar5 != 0)) {
            uRam000000000787e598 = 0;
            uRam000000000787e5a0 = 0;
            uRam000000000787e5b0 = 0;
            uRam000000000787e5a8 = 0;
            fn_126978(&UNK_02f49a56,0x787e598,0x1a,0x151d73cc51182155);
            fn_65eed8(0x787e5b8);
          }
          lVar9 = fn_43cd88(0x76a9768,0x787e598);
          if (lRam000000000787e478 != 0) {
            fn_439c54(lRam000000000787e478);
          }
          puVar12 = (undefined8 *)0x787e470;
          if (lVar9 != 0) {
            lRam000000000787e478 = fn_439970(lVar9);
            lRam000000000787e470 = 0;
            if (lRam000000000787e478 == 0) goto LAB_00480430;
            goto LAB_0047ff08;
          }
LAB_00480408:
          *puVar12 = 0;
          puVar12[1] = 0;
        }
        else {
LAB_0047ff08:
          lRam000000000787e470 = lVar9;
          uVar6 = fn_198128(lRam000000000787e440);
          if ((uVar6 & 1) == 0) {
            uVar6 = fn_198128(lRam000000000787e430);
            if ((uVar6 & 1) != 0) {
              fn_198eac(lRam000000000787e430);
            }
            if (lRam000000000787e448 != 0) {
              fn_439c54();
            }
            cRam000000000787e489 = '\0';
            lRam000000000787e440 = 0;
            lRam000000000787e448 = 0;
            lVar9 = fn_36963c(&UNK_007bfb4f);
            if (lRam000000000787e438 != 0) {
              fn_439c54(lRam000000000787e438);
            }
            if (lVar9 == 0) {
              lRam000000000787e438 = 0;
            }
            else {
              lRam000000000787e438 = fn_439970(lVar9);
              if (lRam000000000787e438 != 0) {
                lRam000000000787e430 = lVar9;
                if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0))
                {
                  fn_1269d0(0x76a9760);
                  imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                  fn_65eed8(0x76ac3f8);
                }
                lVar9 = fn_43d1bc(0x76a9768,&UNK_007edd0d);
                if (lVar9 != 0) {
                  lVar9 = fn_199d38(lRam000000000787e430,lVar9);
                  if (lRam000000000787e448 != 0) {
                    fn_439c54(lRam000000000787e448);
                  }
                  puVar12 = (undefined8 *)0x787e440;
                  if (lVar9 == 0) goto LAB_00480408;
                  lRam000000000787e448 = fn_439970(lVar9);
                  lRam000000000787e440 = 0;
                  if (lRam000000000787e448 != 0) {
                    lRam000000000787e440 = lVar9;
                    fn_199be4(lVar9,0);
                    fn_199704(lRam000000000787e430,0x3d);
                    goto LAB_0047ff18;
                  }
                }
                goto LAB_00480430;
              }
            }
            lRam000000000787e430 = 0;
            uVar6 = fn_198128(lVar9);
            if ((uVar6 & 1) != 0) {
              fn_198eac(lVar9);
            }
          }
          else {
LAB_0047ff18:
            uVar6 = fn_198128(lRam000000000787e450);
            if ((((uVar6 & 1) != 0) && ((int)uRam000000000787e480 == iVar2)) &&
               (uRam000000000787e480._4_4_ == iVar3)) {
LAB_0047ff44:
              lVar9 = lRam000000000787e440;
              fn_199be4(lRam000000000787e440,0);
              uVar7 = fn_197da4(param_1);
              uVar8 = fn_197da4(lVar9);
              uVar6 = fn_1967e0(uVar7,auStack_b4);
              if ((((uVar6 & 1) != 0) && (uVar6 = fn_196b44(uVar7,auStack_c4), (uVar6 & 1) != 0)) &&
                 (uVar6 = fn_196c78(uVar8,auStack_b4,auStack_c4), (uVar6 & 1) != 0)) {
                (*pcRam000000000787e540)(lVar9,0,0);
                pcVar11 = pcRam000000000787e548;
                fn_18e80c(param_1);
                (*pcVar11)(lVar9,0);
                pcVar11 = pcRam000000000787e550;
                fn_18e5e8(param_1);
                (*pcVar11)(lVar9,0);
                pcVar11 = pcRam000000000787e558;
                fn_18ec98(param_1);
                (*pcVar11)(lVar9,0);
                uVar4 = (*pcRam000000000787e4d8)(param_1,0);
                if ((uVar4 & param_3) != 0) {
                  (*pcRam000000000787e508)(lVar9,uVar4 & param_3,0);
                  uVar6 = fn_18f858(param_1);
                  if ((uVar6 & 1) == 0) {
                    if (cRam000000000787e489 != '\0') {
                      fn_18ebdc(lVar9);
                      cRam000000000787e489 = '\0';
                    }
                  }
                  else {
                    fn_18e534(auStack_a8,param_1);
                    fn_18ead4(lVar9,auStack_a8);
                    cRam000000000787e489 = '\x01';
                  }
                  (*pcRam000000000787e4b0)(lVar9,lRam000000000787e450,0);
                  fn_18e978(param_1);
                  fn_18f08c(lVar9);
                  (*pcRam000000000787e4e0)(lVar9,2,0);
                  uVar6 = fn_18ed34(0x3f800000,0x3f800000,0x3f800000,0x3f800000,lVar9);
                  (*pcRam000000000787e510)(lVar9,0,0);
                  (*pcRam000000000787e518)(lVar9,0,0);
                  (*pcRam000000000787e520)(lVar9,0,0);
                  (*pcRam000000000787e4e8)(lVar9,0,0);
                  fn_18e3c8(auStack_a8,param_1);
                  uVar10 = fn_18f2b0(lVar9,auStack_a8);
                  if ((((uVar6 & 1) == 0) || ((uVar10 & 1) == 0)) ||
                     (uVar6 = fn_18fbd0(lVar9,param_2,&UNK_007da587), (uVar6 & 1) == 0)) {
                    if (cRam000000000787e488 == '\0') {
                      fn_126488();
                    }
                    pcVar11 = (code *)0x1;
                  }
                  else {
                    (*pcRam000000000787e4b8)(lRam000000000787e460,lRam000000000787e450,0);
                    pcVar11 = pcRam000000000787e4c0;
                    if (pcRam000000000787e4c0 != (code *)0x0) {
                      if (lRam000000000787e470 != 0) {
                        (*pcRam000000000787e4c0)(0x3f800000,lRam000000000787e470,0);
                      }
                      pcVar11 = (code *)0x0;
                    }
                  }
                  cRam000000000787e488 = (char)pcVar11;
                }
              }
              goto LAB_00480454;
            }
            (*pcRam000000000787e4b0)(lRam000000000787e440,0,0);
            uVar6 = fn_198128(lRam000000000787e450);
            if ((uVar6 & 1) != 0) {
              if (pcRam000000000787e560 != (code *)0x0) {
                (*pcRam000000000787e560)(lRam000000000787e450,0);
              }
              fn_198eac(lRam000000000787e450);
            }
            if (lRam000000000787e458 != 0) {
              fn_439c54();
            }
            uRam000000000787e480 = 0;
            lRam000000000787e450 = 0;
            lRam000000000787e458 = 0;
            if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
              fn_1269d0(0x76a9760);
              imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
              fn_65eed8(0x76ac3f8);
            }
            lVar9 = fn_43cd6c(0x76a9768,uRam000000000787e4a8);
            if (lVar9 != 0) {
              if (lRam000000000787e458 != 0) {
                fn_439c54();
              }
              lRam000000000787e458 = fn_439970(lVar9);
              lRam000000000787e450 = 0;
              if (lRam000000000787e458 != 0) {
                lRam000000000787e450 = lVar9;
                (*pcRam000000000787e568)(lVar9,iVar2,iVar3,0x18,0,0);
                uVar6 = fn_198128(lVar9);
                if ((uVar6 & 1) != 0) {
                  (*pcRam000000000787e4f0)(lVar9,8,0);
                  (*pcRam000000000787e528)(lVar9,0,0);
                  (*pcRam000000000787e530)(lVar9,0,0);
                  (*pcRam000000000787e538)(lVar9,0,0);
                  (*pcRam000000000787e4f8)(lVar9,0,0);
                  (*pcRam000000000787e500)(lVar9,1,0);
                  fn_199704(lVar9,0x3d);
                  uVar6 = (*pcRam000000000787e570)(lVar9,0);
                  if ((uVar6 & 1) != 0) {
                    uRam000000000787e480 = CONCAT44(iVar3,iVar2);
                    goto LAB_0047ff44;
                  }
                  fn_380d48();
                }
              }
            }
          }
        }
      }
    }
LAB_00480430:
    if (((cRam000000000787e488 == '\0') && ((bRam00000000076ac3f8 & 1) == 0)) &&
       (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
  }
  cRam000000000787e488 = '\x01';
LAB_00480454:
  if (*(long *)(lVar1 + 0x28) == lStack_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

