
// ================================================================================
// Official Telegram Bot: t.me/imguisource_bot
// Official Channels:
// 1. ImGui Source -> t.me/ImGui_Source_FIXNEY
// 2. shit src 🧨 -> t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x34b75c */

undefined4 fn_34b75c(long param_1,long param_2)

{
  int iVar1;
  ulong uVar2;
  undefined4 uVar3;
  
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  uVar2 = fn_139354(0x76a97a8,(undefined4 *)(param_2 + param_1),4);
  uVar3 = 0;
  if ((uVar2 & 1) != 0) {
    uVar3 = *(undefined4 *)(param_2 + param_1);
  }
  return uVar3;
}

