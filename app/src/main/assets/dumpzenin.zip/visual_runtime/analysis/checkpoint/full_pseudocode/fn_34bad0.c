
// ================================================================================
// [Telegram] Bot: @imguisource_bot | Channel: @ImGui_Source_FIXNEY (ImGui Source) | Second: @il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x34bad0 */

void fn_34bad0(void)

{
  long lVar1;
  long lVar2;
  long lVar3;
  undefined8 uStack_c98;
  undefined auStack_c90 [16];
  undefined auStack_c80 [28];
  undefined auStack_c64 [4];
  undefined8 auStack_c60 [377];
  undefined8 uStack_98;
  undefined uStack_90;
  undefined8 uStack_88;
  undefined5 uStack_80;
  undefined3 uStack_7b;
  undefined5 uStack_78;
  undefined8 uStack_70;
  undefined uStack_68;
  undefined8 uStack_64;
  undefined uStack_5c;
  undefined4 uStack_58;
  undefined uStack_54;
  undefined uStack_50;
  undefined8 uStack_4c;
  undefined8 uStack_44;
  long lStack_38;
  
  lVar2 = tpidr_el0;
  lStack_38 = *(long *)(lVar2 + 0x28);
  fn_63d380(0x7873040);
  imp_memset(&uStack_c98,0,0xc00);
  lVar3 = 0;
  do {
    lVar1 = lVar3 + 0x40;
    *(undefined8 *)((long)&uStack_c98 + lVar3) = 0;
    auStack_c90[lVar3] = 0;
    auStack_c80[lVar3] = 0;
    auStack_c64[lVar3] = 0;
    *(undefined8 *)((long)auStack_c60 + lVar3) = 0;
    lVar3 = lVar1;
  } while (lVar1 != 0xc00);
  uStack_98 = 0;
  uStack_90 = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_78 = 0;
  uStack_80 = 0;
  uStack_7b = 0;
  uStack_88 = 0;
  uStack_70 = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_5c = 0;
  uStack_44 = 0;
  uStack_4c = 0;
  imp_memcpy(0x7874e78,&uStack_c98,0xc5c);
  if (*(long *)(lVar2 + 0x28) == lStack_38) {
    imp_pthread_mutex_unlock(0x7873040);
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

