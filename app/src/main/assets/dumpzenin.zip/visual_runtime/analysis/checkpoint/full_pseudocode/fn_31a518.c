
// ================================================================================
// >> TG BOT: @imguisource_bot
// >> CHANNEL: @ImGui_Source_FIXNEY (ImGui Source)
// >> BACKUP: @il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x31a518 */

void fn_31a518(void)

{
  long lVar1;
  int iVar2;
  ulong uVar3;
  
  if (((bRam0000000007761618 & 1) == 0) && (iVar2 = fn_65eda8(0x7761618), iVar2 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  lVar1 = lRam0000000007760ee8;
  if ((((cRam0000000007760ef8 != '\0') && (lRam0000000007760ee8 != 0)) &&
      (uVar3 = fn_198128(lRam0000000007760ee8), (uVar3 & 1) != 0)) && (lRam0000000007760ed8 != 0)) {
    (*pcRam0000000007761670)(lVar1,0x12,lRam0000000007760ed8,0);
  }
  cRam0000000007760ef8 = 0;
  if (lRam0000000007760ef0 != 0) {
    fn_439c54();
  }
  lRam0000000007760ee8 = 0;
  lRam0000000007760ef0 = 0;
  return;
}

