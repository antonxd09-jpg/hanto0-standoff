
// ================================================================================
// Бот с сурсами: @imguisource_bot
// Основной канал (ImGui Source): @ImGui_Source_FIXNEY
// Дополнительный канал (shit src 🧨): @il2cpp_src
// ================================================================================

// @category Analysis
import ghidra.app.script.GhidraScript;
import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.*;
import ghidra.program.model.address.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.listing.Function.FunctionUpdateType;
import ghidra.program.model.data.*;
import ghidra.program.model.symbol.SourceType;
import java.nio.file.*;
import java.util.*;

public class TypedEsp extends GhidraScript {
 public void run() throws Exception {
  String[] args=getScriptArgs();long base=currentProgram.getImageBase().getOffset();
  Map<Long,Long> bounds=new HashMap<>();
  for(String line:Files.readAllLines(Paths.get(args[0]))){String[] p=line.split("\\t");bounds.put(Long.parseLong(p[0],16),Long.parseLong(p[1],16));}
  for(String line:Files.readAllLines(Paths.get(args[1]))){
   if(line.isBlank())continue;long rva=Long.parseLong(line,16);if(!bounds.containsKey(rva))continue;
   Address begin=toAddr(base+rva),end=toAddr(base+bounds.get(rva)-1);AddressSet body=new AddressSet(begin,end);
   new DisassembleCommand(begin,body,true).applyTo(currentProgram,monitor);
   Function f=getFunctionAt(begin);
   if(f==null)try{f=currentProgram.getFunctionManager().createFunction("fn_"+line,begin,body,SourceType.USER_DEFINED);}catch(Exception ignored){}
   if(f!=null)try{f.setBody(body);}catch(Exception ignored){}
  }
  StructureDataType cfg=new StructureDataType("PlayerVisualSettings",0x384);
  int count=0;
  for(String line:Files.readAllLines(Paths.get(args[2]))){
   String[] p=line.split("\\t");int offset=Integer.parseInt(p[0],16),n=Integer.parseInt(p[2]);
   DataType type=p[1].equals("float32")?FloatDataType.dataType:(p[1].equals("bool")||p[1].equals("enum8"))?UnsignedCharDataType.dataType:IntegerDataType.dataType;
   if(n>1)type=new ArrayDataType(type,n,type.getLength());
   cfg.replaceAtOffset(offset,type,type.getLength(),p[3],"Native serializer field");count++;
  }
  DataType resolved=currentProgram.getDataTypeManager().resolve(cfg,DataTypeConflictHandler.REPLACE_HANDLER);
  Address config=toAddr(base+0x6cb0040L);
  clearListing(config,config.add(0x383));createData(config,resolved);
  Function main=getFunctionAt(toAddr(base+0x43f24cL));
  main.setCallingConvention(currentProgram.getCompilerSpec().getDefaultCallingConvention().getName());
  main.setReturnType(VoidDataType.dataType,SourceType.USER_DEFINED);
  main.replaceParameters(FunctionUpdateType.DYNAMIC_STORAGE_ALL_PARAMS,true,SourceType.USER_DEFINED,new Parameter[0]);
  println("TYPED_ESP_FIELDS="+count+" SIGNATURE="+main.getSignature().getPrototypeString());
  DecompInterface d=new DecompInterface();d.toggleSyntaxTree(false);d.openProgram(currentProgram);
  DecompileResults r=d.decompileFunction(main,240,monitor);
  Path output=Paths.get(args[3]);Files.createDirectories(output);
  String text=r.decompileCompleted()&&r.getDecompiledFunction()!=null?r.getDecompiledFunction().getC():"/* DECOMPILE_ERROR: "+r.getErrorMessage()+" */\n";
  Files.writeString(output.resolve("fn_43f24c.c"),"/* ORIGINAL_ELF_RVA: 0x43f24c; diagnostic output */\n"+text);
  println("MAIN_ESP_COMPLETED="+r.decompileCompleted()+" ERROR="+r.getErrorMessage());d.dispose();
 }
}
