
// ================================================================================
// Origin: @imguisource_bot
// Community:
//  - ImGui Source: @ImGui_Source_FIXNEY
//  - shit src 🧨: @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x31a5ec */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fn_31a5ec(ulong param_1,byte param_2,undefined8 *param_3)

{
  bool bVar1;
  undefined uVar2;
  undefined uVar3;
  int iVar4;
  uint uVar5;
  char cVar6;
  byte bVar7;
  int iVar8;
  long lVar9;
  undefined auVar10 [16];
  undefined auVar11 [16];
  undefined auVar12 [16];
  bool bVar13;
  char cVar14;
  bool bVar15;
  bool bVar16;
  bool bVar17;
  byte bVar18;
  byte bVar19;
  uint uVar20;
  uint uVar21;
  int iVar22;
  ulong uVar23;
  long lVar24;
  ulong uVar25;
  uint uVar26;
  undefined4 uVar27;
  undefined4 uVar28;
  char cVar29;
  long lVar30;
  int iVar31;
  long lVar32;
  float fVar33;
  float fVar34;
  double dVar35;
  undefined8 uVar36;
  undefined8 uVar37;
  undefined auVar38 [16];
  undefined8 uVar39;
  float fVar40;
  undefined8 uVar41;
  float fVar42;
  undefined auVar43 [16];
  undefined auVar44 [16];
  float fStack_750;
  float fStack_74c;
  long lStack_738;
  float *pfStack_730;
  ulong *puStack_728;
  undefined8 uStack_720;
  undefined8 uStack_718;
  undefined8 uStack_710;
  undefined8 uStack_708;
  undefined8 uStack_700;
  undefined8 uStack_6f8;
  undefined8 uStack_6f0;
  undefined4 uStack_6e8;
  undefined8 uStack_6e4;
  undefined4 uStack_6dc;
  ulong uStack_6d8;
  uint uStack_6d0;
  uint uStack_6cc;
  undefined8 uStack_6c8;
  undefined8 uStack_6c0;
  ulong uStack_6b8;
  undefined8 uStack_6b0;
  undefined8 uStack_6a8;
  float fStack_6a0;
  float fStack_69c;
  undefined4 uStack_698;
  undefined4 uStack_694;
  undefined4 uStack_690;
  undefined8 uStack_68c;
  undefined4 auStack_684 [21];
  undefined auStack_630 [160];
  undefined auStack_590 [1280];
  long lStack_90;
  
  lVar9 = tpidr_el0;
  lStack_90 = *(long *)(lVar9 + 0x28);
  if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  uVar20 = (*pcRam0000000007761678)(param_1,0);
  uVar21 = (*pcRam0000000007761680)(param_1,0);
  if ((0xf < (int)uVar20) && (0xf < (int)uVar21)) {
    iVar22 = (*pcRam0000000007761700)(0);
    if ((iVar22 < (int)(uVar20 * 3)) ||
       (iVar22 = (*pcRam0000000007761708)(0), iVar22 < (int)(uVar21 * 3))) {
      if ((((uRam00000000077615d8 != param_1) || (uVar20 != (uint)uRam0000000007761520)) ||
          (uVar21 != uRam0000000007761520._4_4_)) ||
         (bVar15 = 0x1c < iRam00000000077615e0, iRam00000000077615e0 = iRam00000000077615e0 + 1,
         cVar6 = cRam00000000077615e5, bVar15)) {
        iRam00000000077615e0 = 0;
        uRam00000000077615d8 = param_1;
        lVar24 = (*pcRam0000000007761688)(param_1,0);
        cRam00000000077615e4 = lVar24 != 0;
        uVar25 = (*pcRam0000000007761690)(param_1,0);
        cVar6 = '\0';
        if ((uVar25 & 1) != 0) {
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar22 = fn_65eda8(0x76ac3f8), iVar22 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar22 = fn_65eda8(0x76ac3f8), iVar22 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          lVar24 = fn_43bc24(0x76a9768);
          uVar25 = fn_139354(0x76a97a8,lVar24 + 0xd0119c0,8);
          if ((uVar25 & 1) == 0) {
            lVar30 = 0;
          }
          else {
            lVar30 = *(long *)(lVar24 + 0xd0119c0);
          }
          lVar24 = (*(code *)(&UNK_05f1b128 + lVar24))();
          cVar6 = '\x01';
          if ((lVar30 != 0) && (lVar24 != 0)) {
            uVar25 = fn_139354(0x76a97a8,lVar30 + 0xd8,4);
            if ((uVar25 & 1) == 0) {
              uVar26 = 0;
            }
            else {
              uVar26 = *(uint *)(lVar30 + 0xd8);
              if (2 < uVar26) {
                cVar6 = '\x01';
                goto LAB_0041a888;
              }
            }
            lVar24 = lVar24 + (ulong)(uVar26 << 4);
            uVar25 = fn_139354(0x76a97a8,lVar24 + 0xbb,1);
            if ((uVar25 & 1) == 0) {
              cVar6 = '\0';
            }
            else {
              cVar6 = *(char *)(lVar24 + 0xbb) != '\0';
            }
          }
        }
      }
LAB_0041a888:
      cRam00000000077615e5 = cVar6;
      if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
        fn_31ca58();
        imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
        fn_65eed8(0x7761618);
      }
      bVar18 = 0;
      uStack_6b0 = 0;
      uStack_6b8 = 0;
      uStack_6c0 = 0;
      uStack_6c8 = 0;
      uStack_6d8 = param_1;
      uStack_6d0 = uVar20;
      uStack_6cc = uVar21;
      if (((cRam000000000776174e != '\0') && (cRam00000000077615e4 == '\0')) &&
         (cRam00000000077615e5 == '\0')) {
        bVar18 = fn_37d050(param_1);
        bVar18 = bVar18 ^ 1;
      }
      uVar37 = uStack_6c8;
      cVar14 = cRam00000000077615e5;
      cVar6 = *(char *)((long)param_3 + 2);
      uStack_6c8 = CONCAT71(CONCAT61(uStack_6c8._2_6_,cRam00000000077615e5),bVar18) &
                   0xffffffffffffff01;
      if (cVar6 == '\0') {
        uVar26 = 0;
        iVar31 = 0;
        iVar22 = 0;
        cVar29 = *(char *)((long)param_3 + 0x39);
        if (cVar29 != '\0') goto LAB_0041a9d4;
        cVar29 = '\0';
      }
      else {
        fVar40 = *(float *)(param_3 + 2);
        fVar33 = *(float *)((long)param_3 + 0x14);
        uStack_6c8._0_4_ = CONCAT13(*(undefined *)(param_3 + 5),CONCAT12(1,(undefined2)uStack_6c8));
        fVar42 = 1.0;
        if (fVar33 <= 1.0) {
          fVar42 = fVar33;
        }
        fVar34 = -1.0;
        if (-1.0 <= fVar33) {
          fVar34 = fVar42;
        }
        fVar42 = fVar34 + 2.0;
        bVar15 = 0.0 <= fVar34;
        if (fVar34 <= 0.0) {
          fVar34 = 0.0;
        }
        if (bVar15) {
          fVar42 = 2.0;
        }
        iVar22 = (int)((float)uVar20 / fVar42);
        iVar31 = (int)((float)uVar21 / (2.0 - fVar34));
        uStack_6b8 = CONCAT44(iVar31,iVar22);
        iVar4 = iVar22;
        if (iVar22 <= iVar31) {
          iVar4 = iVar31;
        }
        if (iVar4 < 2) {
          iVar4 = 1;
        }
        fVar42 = 10.0;
        if (fVar40 <= 10.0) {
          fVar42 = fVar40;
        }
        auVar44._0_8_ = (double)iVar4;
        auVar44._8_8_ = 0;
        fVar33 = 1.0;
        if (1.0 <= fVar40) {
          fVar33 = fVar42;
        }
        dVar35 = (double)imp_log2(auVar44);
        fVar42 = fVar33 + (float)dVar35 + -10.0;
        uVar26 = (uint)fVar42;
        if (0xf < (int)uVar26) {
          uVar26 = 0x10;
        }
        if ((int)uVar26 < 2) {
          uVar26 = 1;
        }
        uStack_6b0 = CONCAT44((fVar42 + 0.5) - (float)(int)(float)(int)fVar42,uVar26);
        cVar29 = *(char *)((long)param_3 + 0x39);
        if (cVar29 != '\0') {
LAB_0041a9d4:
          uVar25 = uStack_6c8;
          uStack_6c8._0_6_ =
               CONCAT15(*(undefined *)(param_3 + 9),CONCAT14(1,(undefined4)uStack_6c8));
        }
      }
      bVar18 = *(byte *)((long)param_3 + 0xa9);
      if (bVar18 != 0) {
        uVar5 = *(uint *)(param_3 + 0x17);
        if (2 < (int)uVar5) {
          uVar5 = 3;
        }
        uStack_6c8._0_7_ = CONCAT16(1,(undefined6)uStack_6c8);
        uStack_6c0 = CONCAT44(uVar5 & ((int)uVar5 >> 0x1f ^ 0xffffffffU),(undefined4)uStack_6c0);
      }
      bVar7 = *(byte *)((long)param_3 + 0x49);
      if (bVar7 != 0) {
        uStack_6c8 = CONCAT17(1,(undefined7)uStack_6c8);
        uStack_6c0 = CONCAT71(uStack_6c0._1_7_,param_2) & 0xffffffffffffff01;
      }
      if (cRam0000000007761548 == '\0') {
        bVar15 = true;
LAB_0041aae4:
        iVar8 = (uint)(bRam000000000776174a != 0) << 1;
        iVar4 = 0;
        if (cVar14 != '\0') {
          iVar4 = iVar8;
        }
        if (cRam000000000776174b != '\0') {
          iVar8 = 0x16;
        }
        bVar19 = fn_31f0c0(0x16,0,uVar20,uVar21,iVar4,1);
        bVar16 = bVar18 != 0 && bVar7 != 0;
        if (((bVar19 & 1) != 0) && ((bVar18 | bVar7) != 0)) {
          bVar19 = fn_31f0c0(1,uVar20,uVar21,iVar4,1);
        }
        if ((bVar19 & bVar16) == 1) {
          bVar19 = fn_31f0c0(2,uVar20,uVar21,iVar4,1);
        }
        fn_31f574(1,(bVar18 | bVar7) != 0);
        fn_31f574(2,bVar16);
        if (((bVar19 & 1) != 0) && (cVar29 != '\0')) {
          bVar19 = fn_31f0c0(3,0x80,0x80,(ulong)bRam000000000776174a << 1,0);
        }
        fn_31f574(3,cVar29 != '\0');
        if (bVar18 != 0) {
          uVar27 = 0;
          if (bRam000000000776174a != 0 && cVar14 != '\0') {
            uVar27 = 2;
          }
          bVar7 = bVar19 & 1;
          bVar19 = 0;
          if (bVar7 != 0) {
            uVar28 = 0;
            if (cRam000000000776174d != '\0') {
              uVar28 = 0xf;
            }
            if (cRam000000000776174c != '\0') {
              uVar28 = 0x10;
            }
            uVar25 = fn_31f0c0(4,uVar20,uVar21,uVar28,1);
            bVar19 = 0;
            if ((uVar25 & 1) != 0) {
              uVar25 = fn_31f0c0(5,uVar20 >> 1,uVar21 >> 1,uVar27,1);
              if ((uVar25 & 1) == 0) {
                bVar19 = 0;
              }
              else {
                bVar19 = fn_31f0c0(6,uVar20 >> 1,uVar21 >> 1,uVar27,1);
              }
            }
          }
        }
        bVar16 = bVar18 != 0;
        fn_31f574(4,bVar16);
        fn_31f574(5,bVar16);
        fn_31f574(6,bVar16);
        uVar20 = 0;
        do {
          bVar17 = cVar6 != '\0';
          bVar13 = uVar20 >= uVar26;
          bVar16 = (int)uVar20 < (int)(uVar26 - 1);
          bVar1 = bVar16 && bVar17;
          bVar18 = (bVar13 || !bVar17) & bVar19;
          if ((!bVar13 && bVar17) && ((bVar19 & 1) != 0)) {
            bVar18 = fn_31f0c0(uVar20 + 7,iVar22,iVar31,iVar8,1);
          }
          if ((bVar1 & bVar18) == 0) {
            bVar19 = (!bVar16 || !bVar17) & bVar18;
          }
          else {
            bVar19 = fn_31f0c0(uVar20 + 0x17,iVar22,iVar31,iVar8,1);
          }
          fn_31f574(uVar20 + 7,uVar20 < uVar26 && bVar17);
          fn_31f574(uVar20 + 0x17,bVar1);
          uVar20 = uVar20 + 1;
          if (iVar22 < 0) {
            iVar22 = iVar22 + 1;
          }
          iVar22 = iVar22 >> 1;
          if (iVar22 < 2) {
            iVar22 = 1;
          }
          if (iVar31 < 0) {
            iVar31 = iVar31 + 1;
          }
          iVar31 = iVar31 >> 1;
          if (iVar31 < 2) {
            iVar31 = 1;
          }
        } while (uVar20 != 0x10);
        if ((bVar19 & 1) != 0) goto LAB_0041adb4;
        lVar24 = 1;
LAB_0041af30:
        fn_319834(lVar24);
      }
      else {
        uVar25 = uStack_6d8 ^ uRam0000000007761518 |
                 CONCAT44(uStack_6cc,uStack_6d0) ^ uRam0000000007761520 |
                 uStack_6c8 ^ uRam0000000007761528 | uStack_6c0 ^ uRam0000000007761530 |
                 uStack_6b8 ^ uRam0000000007761538 | uStack_6b0 ^ uRam0000000007761540;
        bVar15 = uVar25 != 0;
        if ((uVar25 != 0) || (lRam0000000007760f00 == 0)) goto LAB_0041aae4;
        uVar25 = (*pcRam00000000077616b8)(lRam0000000007760f00,0);
        bVar15 = false;
        if ((uVar25 & 1) == 0) goto LAB_0041aae4;
LAB_0041adb4:
        if (((bVar15) || (cRam0000000007760d88 == '\0')) ||
           (iVar22 = imp_memcmp(0x7760ccc,param_3,0xbc), iVar22 != 0)) {
          if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
            fn_31ca58();
            imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
            fn_65eed8(0x7761618);
          }
          if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
            fn_31ca58();
            imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
            fn_65eed8(0x7761618);
          }
          uVar41 = uRam0000000007760da8;
          uVar37 = CONCAT44(uStack_6cc,uStack_6d0);
          fn_31f6d4(0,*(char *)(param_3 + 6) != '\0' && *(char *)(param_3 + 7) != '\0');
          fn_31f6d4(1,*(char *)(param_3 + 6) != '\0' && *(char *)(param_3 + 7) == '\0');
          if (*(char *)(param_3 + 6) != '\0') {
            fVar33 = *(float *)((long)param_3 + 0x34);
            fVar42 = 1.0;
            if (fVar33 <= 1.0) {
              fVar42 = fVar33;
            }
            fVar40 = 0.0;
            if (0.0 <= fVar33) {
              fVar40 = fVar42 * 0.05;
            }
            fn_19d360(fVar40,fVar33,0,uVar41,uRam0000000007760e88);
          }
          fn_31f6d4(2,*(char *)((long)param_3 + 2) != '\0' && *(char *)(param_3 + 5) != '\0');
          fn_31f6d4(3,*(char *)((long)param_3 + 2) != '\0' && *(char *)(param_3 + 5) == '\0');
          if (*(char *)((long)param_3 + 2) != '\0') {
            fVar33 = *(float *)(param_3 + 1);
            fVar42 = 5.0;
            if (fVar33 <= 5.0) {
              fVar42 = fVar33;
            }
            fVar40 = 0.0;
            if (0.0 <= fVar33) {
              fVar40 = fVar42;
            }
            if (fVar40 <= 0.04045) {
              fVar40 = fVar40 / 12.92;
            }
            else {
              if (1.0 <= fVar40) {
                uVar27 = 0x400ccccd;
              }
              else {
                uVar27 = 0x4019999a;
                fVar40 = (fVar40 + 0.055) / 1.055;
              }
              fVar40 = (float)imp_powf(fVar40,uVar27);
            }
            fVar33 = *(float *)((long)param_3 + 0xc);
            fVar42 = 1.0;
            if (fVar33 <= 1.0) {
              fVar42 = fVar33;
            }
            fVar34 = 0.0;
            if (0.0 <= fVar33) {
              fVar34 = fVar42;
            }
            fVar42 = (float)NEON_fmadd(fVar40,fVar34,0x3727c5ac);
            if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            uStack_6a8._4_4_ = fVar40 - fVar42;
            fStack_6a0 = fVar42 + fVar42;
            fStack_69c = 0.25 / fVar42;
            uStack_6a8._0_4_ = fVar40;
            fn_19d5a8(uRam0000000007760dd0,uRam0000000007760e74,&uStack_6a8);
            if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            fn_19d360(uRam0000000007760dd0,uRam0000000007760e78);
            fVar33 = *(float *)((long)param_3 + 4);
            fVar42 = 10.0;
            if (fVar33 <= 10.0) {
              fVar42 = fVar33;
            }
            fVar40 = 0.0;
            if (0.0 <= fVar33) {
              fVar40 = fVar42 / 10.0;
            }
            fVar33 = (float)imp_exp2f(fVar40,fVar33,0);
            uVar27 = uRam0000000007760e84;
            fVar42 = *(float *)(param_3 + 3);
            if (fVar42 <= 0.04045) {
              fVar42 = fVar42 / 12.92;
            }
            else {
              if (1.0 <= fVar42) {
                uVar28 = 0x400ccccd;
              }
              else {
                uVar28 = 0x4019999a;
                fVar42 = (fVar42 + 0.055) / 1.055;
              }
              fVar42 = (float)imp_powf(fVar42,uVar28);
            }
            fVar40 = *(float *)((long)param_3 + 0x1c);
            fVar33 = fVar33 + -1.0;
            if (fVar40 <= 0.04045) {
              fVar40 = fVar40 / 12.92;
            }
            else {
              if (1.0 <= fVar40) {
                uVar28 = 0x400ccccd;
              }
              else {
                uVar28 = 0x4019999a;
                fVar40 = (fVar40 + 0.055) / 1.055;
              }
              fVar40 = (float)imp_powf(fVar40,uVar28);
            }
            fVar34 = *(float *)(param_3 + 4);
            if (fVar34 <= 0.04045) {
              fStack_6a0 = fVar34 / 12.92;
            }
            else {
              if (1.0 <= fVar34) {
                uVar28 = 0x400ccccd;
              }
              else {
                uVar28 = 0x4019999a;
                fVar34 = (fVar34 + 0.055) / 1.055;
              }
              fStack_6a0 = (float)imp_powf(fVar34,uVar28);
            }
            fStack_6a0 = fVar33 * fStack_6a0;
            uStack_6a8._0_4_ = fVar33 * fVar42;
            uStack_6a8._4_4_ = fVar33 * fVar40;
            fStack_69c = fVar33;
            fn_19d5a8(uVar41,uVar27,&uStack_6a8);
            fStack_69c = 0.0;
            uVar36 = NEON_smax(uStack_6b8,0x100000001,4);
            uVar39 = NEON_fmov(0x3f800000,4);
            uVar36 = NEON_scvtf(uVar36,4);
            uStack_6a8._0_4_ = (float)uVar39 / (float)uVar36;
            uStack_6a8._4_4_ = (float)((ulong)uVar39 >> 0x20) / (float)((ulong)uVar36 >> 0x20);
            fStack_6a0 = uStack_6b0._4_4_;
            fn_19d5a8(uVar41,uRam0000000007760e80,&uStack_6a8);
          }
          uVar37 = NEON_scvtf(uVar37,4);
          fStack_750 = (float)uVar37;
          fStack_74c = (float)((ulong)uVar37 >> 0x20);
          fn_31f6d4(4,*(undefined *)((long)param_3 + 0x84));
          if (*(char *)((long)param_3 + 0x84) != '\0') {
            fVar33 = 1.0;
            fVar40 = *(float *)(param_3 + 0x13);
            fVar34 = *(float *)(param_3 + 0x14);
            fVar42 = fVar33;
            if (fVar40 <= 1.0) {
              fVar42 = fVar40;
            }
            uStack_6a8._4_4_ = 0.0;
            if (0.0 <= fVar40) {
              uStack_6a8._4_4_ = fVar42 * 3.0;
            }
            fVar42 = fVar33;
            if (fVar34 <= 1.0) {
              fVar42 = fVar34;
            }
            fVar40 = 0.0;
            if (0.0 <= fVar34) {
              fVar40 = fVar42;
            }
            uStack_6a8._0_4_ = 1.0;
            if (*(char *)(param_3 + 0x15) != '\0') {
              uStack_6a8._0_4_ = 1.0;
              if (1.0 <= fStack_74c) {
                uStack_6a8._0_4_ = fStack_74c;
              }
              uStack_6a8._0_4_ = fStack_750 / (float)uStack_6a8;
            }
            uStack_6a8._0_4_ = uStack_6a8._4_4_ * (float)uStack_6a8;
            fStack_6a0 = 0.5;
            fStack_69c = 0.5;
            fn_19d5a8(uVar41,uRam0000000007760e8c,&uStack_6a8);
            fStack_6a0 = *(float *)(param_3 + 0x12);
            fStack_69c = (float)NEON_fmadd(1.0 - fVar40,0x40c00000,fVar40);
            uStack_6a8._0_4_ = (float)param_3[0x11];
            uStack_6a8._4_4_ = (float)((ulong)param_3[0x11] >> 0x20);
            fn_19d5a8(uVar41,uRam0000000007760e90,&uStack_6a8);
            fVar42 = *(float *)((long)param_3 + 0x9c);
            if (fVar42 <= 1.0) {
              fVar33 = fVar42;
            }
            fVar40 = 0.05;
            if (0.01 <= fVar42) {
              fVar40 = fVar33 * 5.0;
            }
            fn_19d360(fVar40,fVar33 * 5.0,uVar41,uRam0000000007760e94);
          }
          fn_31f6d4(5,*(undefined *)((long)param_3 + 0x39));
          if (*(char *)((long)param_3 + 0x39) != '\0') {
            fVar40 = *(float *)((long)param_3 + 0x3c);
            fVar33 = *(float *)(param_3 + 8);
            fVar34 = *(float *)((long)param_3 + 0x44);
            fVar42 = 3.0;
            if (fVar33 <= 3.0) {
              fVar42 = fVar33;
            }
            uStack_6a8._4_4_ = 0.3;
            if (0.3 <= fVar33) {
              uStack_6a8._4_4_ = fVar42;
            }
            fVar42 = 1.0;
            if (fVar34 <= 1.0) {
              fVar42 = fVar34;
            }
            fStack_6a0 = 0.0;
            if (0.0 <= fVar34) {
              fStack_6a0 = fVar42;
            }
            uStack_6a8._0_4_ = (fStack_750 * 0.0078125) / uStack_6a8._4_4_;
            uStack_6a8._4_4_ = (fStack_74c * 0.0078125) / uStack_6a8._4_4_;
            fVar42 = 1.0;
            if (fVar40 <= 1.0) {
              fVar42 = fVar40;
            }
            fStack_69c = 0.0;
            if (0.0 <= fVar40) {
              fStack_69c = fVar42 * 20.0;
            }
            fn_19d5a8(uVar41,uRam0000000007760e9c,&uStack_6a8);
          }
          if (*(char *)((long)param_3 + 0x54) == '\0') {
LAB_0041b654:
            uVar37 = 0;
          }
          else {
            if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            auVar38._0_8_ = SUB168(*(undefined (*) [16])(param_3 + 0xe),0);
            auVar38._8_4_ = *(undefined4 *)(param_3 + 0xf);
            uVar41 = param_3[0xb];
            auVar38._12_4_ = *(undefined4 *)(param_3 + 0x10);
            uVar37 = NEON_fcmgt(uVar41,0x42c8000042c80000,4);
            auVar44 = NEON_fcmgt(auVar38,_UNK_00782930,4);
            uVar37 = NEON_bif(0x42c8000042c80000,uVar41,uVar37,1);
            auVar11._8_8_ = _UNK_00782d98;
            auVar11._0_8_ = _UNK_00782d90;
            auVar10._8_8_ = _UNK_00782d98;
            auVar10._0_8_ = _UNK_00782d90;
            uVar41 = NEON_fcmgt(0xc2c80000c2c80000,uVar41,4);
            auVar43 = NEON_bif(_UNK_00782930,auVar38,auVar44,1);
            auVar44 = NEON_fcmgt(auVar10,auVar38,4);
            uVar37 = NEON_bit(uVar37,0xc2c80000c2c80000,uVar41,1);
            uStack_698 = *(undefined4 *)(param_3 + 0xd);
            auVar44 = NEON_bsl(auVar44,auVar11,auVar43,1);
            uStack_6a8._0_4_ = (float)uVar37;
            uStack_6a8._4_4_ = (float)((ulong)uVar37 >> 0x20);
            fStack_6a0 = (float)param_3[0xc];
            fStack_69c = (float)((ulong)param_3[0xc] >> 0x20);
            uStack_68c._0_4_ = auVar44._8_4_;
            uStack_68c._4_4_ = auVar44._12_4_;
            uStack_694 = auVar44._0_4_;
            uStack_690 = auVar44._4_4_;
            if ((lRam0000000007761550 == 0) || (uVar25 = fn_198128(), (uVar25 & 1) == 0)) {
              if (lRam0000000007761558 != 0) {
                fn_439c54();
              }
              lRam0000000007761550 = 0;
              lRam0000000007761558 = 0;
              if (((bRam00000000076ac3f8 & 1) == 0) && (iVar22 = fn_65eda8(0x76ac3f8), iVar22 != 0))
              {
                fn_1269d0(0x76a9760);
                imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                fn_65eed8(0x76ac3f8);
              }
              uVar37 = fn_18de7c();
              lVar24 = fn_43cd6c(0x76a9768,uVar37);
              if (lVar24 != 0) {
                (*pcRam0000000007761730)(lVar24,0x400,0x20,4,0,1,0);
                uVar25 = fn_198128(lVar24);
                if ((uVar25 & 1) != 0) {
                  (*pcRam00000000077616e0)(lVar24,1,0);
                  (*pcRam00000000077616e8)(lVar24,1,0);
                  fn_199704(lVar24,0x3d);
                  if (lRam0000000007761558 != 0) {
                    fn_439c54();
                  }
                  lRam0000000007761558 = 0;
                  lRam0000000007761550 = lVar24;
                  lRam0000000007761558 = fn_439970(lVar24);
                  cRam00000000077615ac = '\0';
                  cRam0000000007761548 = '\0';
                  goto LAB_0041b4e8;
                }
              }
LAB_0041b624:
              uVar37 = 0;
              if ((*(char *)((long)param_3 + 0x54) != '\0') && (cRam0000000007761617 == '\0')) {
                cRam0000000007761617 = '\x01';
                if ((bRam00000000076ac3f8 & 1) != 0) goto LAB_0041b654;
                iVar22 = fn_65eda8(0x76ac3f8,0);
                if (iVar22 != 0) {
                  fn_1269d0(0x76a9760);
                  imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                  fn_65eed8(0x76ac3f8);
                }
                uVar37 = 0;
              }
            }
            else {
LAB_0041b4e8:
              if (lRam0000000007761560 == 0) {
                lVar24 = fn_18c3ec(0x8000);
                if (lRam0000000007761568 != 0) {
                  fn_439c54(lRam0000000007761568);
                }
                lRam0000000007761568 = 0;
                lRam0000000007761560 = lVar24;
                if ((lVar24 == 0) ||
                   (lRam0000000007761568 = fn_439970(lVar24), lRam0000000007761560 == 0))
                goto LAB_0041b624;
              }
              if ((cRam00000000077615ac == '\0') ||
                 ((((lRam0000000007761588 != CONCAT44(uStack_6a8._4_4_,(float)uStack_6a8) ||
                    lRam0000000007761590 != CONCAT44(fStack_69c,fStack_6a0)) ||
                   lRam0000000007761598 != CONCAT44(uStack_694,uStack_698)) ||
                  lRam00000000077615a0 != CONCAT44((undefined4)uStack_68c,uStack_690)) ||
                  iRam00000000077615a8 != uStack_68c._4_4_)) {
                uVar25 = lRam0000000007761578 - lRam0000000007761570 >> 2;
                if (uVar25 >> 0xf == 0) {
                  fn_15166c(0x7761570,0x8000 - uVar25);
                }
                else if (lRam0000000007761578 - lRam0000000007761570 != 0x20000) {
                  lRam0000000007761578 = lRam0000000007761570 + 0x20000;
                }
                fn_320118(&uStack_6a8,lRam0000000007761570);
                uVar25 = fn_18c418(lRam0000000007761550,lRam0000000007761560,lRam0000000007761570,
                                   lRam0000000007761578 - lRam0000000007761570 >> 2,0);
                if ((uVar25 & 1) == 0) goto LAB_0041b624;
                lRam0000000007761588 = CONCAT44(uStack_6a8._4_4_,(float)uStack_6a8);
                auVar43._8_4_ = fStack_6a0;
                auVar43._0_8_ = lRam0000000007761588;
                auVar43._12_4_ = fStack_69c;
                lRam00000000077615a0 = CONCAT44((undefined4)uStack_68c,uStack_690);
                lRam0000000007761598 = CONCAT44(uStack_694,uStack_698);
                cRam00000000077615ac = '\x01';
                lRam0000000007761590 = auVar43._8_8_;
                iRam00000000077615a8 = uStack_68c._4_4_;
              }
              uVar37 = 1;
            }
          }
          fn_31f6d4(6,uVar37);
          if (*(char *)((long)param_3 + 0xa9) != '\0') {
            if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            uVar37 = uRam0000000007760e48;
            fVar42 = (float)NEON_fmadd((float)uStack_6c0._4_4_,0x40800000,0x40c00000);
            NEON_fminnm(fVar42 / fStack_74c,0x3d4ccccd);
            fn_19d360(uRam0000000007760e48,uRam0000000007760ebc);
            fn_19d360(uVar37,uRam0000000007760ec0);
            fn_19d360(uVar37,uRam0000000007760ec4);
            fn_19d360(uVar37,uRam0000000007760ec8);
            fn_19d360(uVar37,uRam0000000007760ecc);
          }
          if (*(char *)((long)param_3 + 0x49) != '\0') {
            iVar22 = (int)((fStack_74c * 5.0) / 100.0);
            if (iVar22 < 2) {
              iVar22 = 1;
            }
            if (((bRam0000000007761618 & 1) == 0) && (iVar31 = fn_65eda8(0x7761618), iVar31 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            fVar33 = *(float *)((long)param_3 + 0x4c);
            uVar20 = *(uint *)(param_3 + 10);
            fStack_69c = 0.0;
            fVar42 = 360.0;
            if (fVar33 <= 360.0) {
              fVar42 = fVar33;
            }
            uStack_6a8._0_4_ = 0.0;
            if (0.0 <= fVar33) {
              uStack_6a8._0_4_ = (fVar42 / 360.0) * 0.5;
            }
            uStack_6a8._4_4_ = (float)iVar22;
            if (0x1f < (int)uVar20) {
              uVar20 = 0x20;
            }
            if ((int)uVar20 < 5) {
              uVar20 = 4;
            }
            fStack_6a0 = (float)(uVar20 >> 1);
            fn_19d5a8(uRam0000000007760e20,uRam0000000007760eb0,&uStack_6a8);
          }
          uRam0000000007760e67 = 1;
          uRam0000000007760cf4 = param_3[5];
          uRam0000000007760cec = param_3[4];
          uRam0000000007760cd4 = param_3[1];
          uRam0000000007760ccc = *param_3;
          uRam0000000007760ce4 = param_3[3];
          uRam0000000007760cdc = param_3[2];
          uRam0000000007760d04 = SUB168(*(undefined (*) [16])(param_3 + 6),8);
          uRam0000000007760cfc = SUB168(*(undefined (*) [16])(param_3 + 6),0);
          uRam0000000007760d34 = param_3[0xd];
          uRam0000000007760d2c = param_3[0xc];
          uRam0000000007760d14 = param_3[9];
          uRam0000000007760d0c = param_3[8];
          uRam0000000007760d24 = param_3[0xb];
          uRam0000000007760d1c = param_3[10];
          uRam0000000007760d44 = SUB168(*(undefined (*) [16])(param_3 + 0xe),8);
          uRam0000000007760d3c = SUB168(*(undefined (*) [16])(param_3 + 0xe),0);
          uRam0000000007760d64 = param_3[0x13];
          uRam0000000007760d5c = param_3[0x12];
          uRam0000000007760d6c = param_3[0x14];
          uRam0000000007760d54 = param_3[0x11];
          uRam0000000007760d4c = param_3[0x10];
          cRam0000000007760d88 = '\x01';
          uRam0000000007760d80 = SUB168(*(undefined (*) [16])((long)param_3 + 0xac),8);
          uRam0000000007760d7c = SUB164(*(undefined (*) [16])((long)param_3 + 0xac),4);
          uRam0000000007760d74 = (undefined4)param_3[0x15];
          uRam0000000007760d78 = (undefined4)((ulong)param_3[0x15] >> 0x20);
        }
        if (!(bool)(cRam0000000007761548 != '\0' & (bVar15 ^ 1U))) {
          if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
            fn_31ca58();
            imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
            fn_65eed8(0x7761618);
          }
          if (lRam0000000007760ed8 == 0) {
            if (((bRam00000000076ac3f8 & 1) == 0) && (iVar22 = fn_65eda8(0x76ac3f8), iVar22 != 0)) {
              fn_1269d0(0x76a9760);
              imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
              fn_65eed8(0x76ac3f8);
            }
            lVar24 = fn_43cd6c(0x76a9768,uRam0000000007761738);
            if (lVar24 == 0) goto LAB_0041af30;
            (*pcRam0000000007761620)(lVar24,0);
            if (lRam0000000007760ee0 != 0) {
              fn_439c54();
            }
            lRam0000000007760ee0 = 0;
            lRam0000000007760ed8 = lVar24;
            lRam0000000007760ee0 = fn_439970(lVar24);
            if (pcRam0000000007761630 != (code *)0x0) {
              if (((bRam00000000076ac3f8 & 1) == 0) && (iVar22 = fn_65eda8(0x76ac3f8), iVar22 != 0))
              {
                fn_1269d0(0x76a9760);
                imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                fn_65eed8(0x76ac3f8);
              }
              lVar30 = fn_43cd88(0x76a9768,&UNK_007fd1dc);
              if (lVar30 != 0) {
                (*pcRam0000000007761630)(lVar24,lVar30,0);
              }
            }
          }
          lVar24 = lRam0000000007760ed8;
          (*pcRam0000000007761628)(lRam0000000007760ed8,0);
          uStack_6f8 = 0;
          uStack_6f0 = 0;
          uStack_6e8 = 0;
          uStack_700 = 0xffffffff00000000;
          uStack_6e4 = 0xffffffff;
          uStack_6dc = 0;
          (*pcRam0000000007761658)(&uStack_700,2,0);
          imp_memset(&uStack_6a8,0,0x618);
          lVar30 = 0;
          do {
            lVar32 = lVar30 + 0x28;
            *(undefined8 *)((long)&uStack_6a8 + lVar30) = 0xffffffff00000000;
            *(undefined8 *)((long)&fStack_6a0 + lVar30) = 0;
            *(undefined8 *)((long)&uStack_698 + lVar30) = 0;
            *(undefined4 *)((long)&uStack_690 + lVar30) = 0;
            *(undefined8 *)((long)&uStack_68c + lVar30) = 0xffffffff;
            *(undefined4 *)((long)auStack_684 + lVar30) = 0;
            lVar30 = lVar32;
          } while (lVar32 != 0x618);
          lVar30 = 0;
          do {
            if (*(long *)(lVar30 + 0x7760f00) != 0) {
              (*pcRam0000000007761660)((long)&uStack_6a8 + lVar30,*(long *)(lVar30 + 0x7760f00),0);
            }
            lVar30 = lVar30 + 0x28;
          } while (lVar30 != 0x618);
          auVar44 = NEON_fmov(0xbf800000,4);
          puStack_728 = &uStack_6d8;
          pfStack_730 = (float *)&uStack_6a8;
          uStack_718 = auVar44._8_8_;
          uStack_720 = auVar44._0_8_;
          lStack_738 = lVar24;
          uStack_710 = 0;
          uStack_708 = 0;
          (*pcRam0000000007761640)
                    (ZEXT816(0x3f800000),0x3f800000,0,0,lVar24,&uStack_700,&uStack_6a8,0,0xffffffff,
                     0xffffffff,0,0);
          if (uStack_6c8._4_1_ != '\0') {
            fn_31f898(&lStack_738,0,auStack_630,2,uStack_6c8._5_1_ != '\0');
          }
          cVar6 = uStack_6c8._6_1_;
          if (uStack_6c8._6_1_ == '\0') {
            uVar20 = 0;
          }
          else {
            if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            uVar37 = uRam0000000007760e48;
            fn_19d788(uRam0000000007760e48,uRam0000000007760eb4,uRam0000000007760fa0);
            fn_19d788(uVar37,uRam0000000007760eb8,uRam0000000007760fc8);
            fn_31f898(&lStack_738,0,pfStack_730 + 0x28,4,0);
            uVar20 = 1;
            fn_31f898(&lStack_738,0,pfStack_730 + 0x32,4,1);
            fn_31f898(&lStack_738,5,pfStack_730 + 0x3c,4,uStack_6c0._4_4_ + 2);
            fn_31f898(&lStack_738,6,pfStack_730 + 0x32,4,6);
            fn_31f898(&lStack_738,0,pfStack_730 + 10,4,7);
          }
          uVar21 = uVar20;
          if (uStack_6c8._7_1_ != '\0') {
            uVar21 = 1;
            if (cVar6 != '\0') {
              uVar21 = 2;
            }
            fn_31f898(&lStack_738,uVar20,pfStack_730 + (ulong)uVar21 * 10,3,(char)uStack_6c0 != '\0'
                     );
          }
          if (uStack_6c8._2_1_ != '\0') {
            cVar6 = uStack_6c8._3_1_;
            bVar15 = uStack_6c8._3_1_ != '\0';
            if ((int)uStack_6b0 < 1) {
LAB_0041bd04:
              iVar22 = (int)uStack_6b0 + 6;
            }
            else {
              fn_31f898(&lStack_738,uVar21,pfStack_730 + 0x46,1,bVar15);
              if ((int)uStack_6b0 < 2) goto LAB_0041bd04;
              lVar30 = 1;
              lVar32 = 0x140;
              do {
                fn_31f898(&lStack_738,(int)lVar30 + 6,(long)pfStack_730 + lVar32,1,bVar15 | 2);
                lVar30 = lVar30 + 1;
                lVar32 = lVar32 + 0x28;
              } while (lVar30 < (int)uStack_6b0);
              iVar22 = (int)uStack_6b0 + 6;
              if (1 < (int)uStack_6b0) {
                lVar30 = (ulong)((int)uStack_6b0 - 2) * 0x28;
                uVar27 = 4;
                if (cVar6 != '\0') {
                  uVar27 = 5;
                }
                iVar31 = (int)uStack_6b0 + 0x15;
                do {
                  (*pcRam0000000007761650)(lVar24,uRam0000000007760e70,auStack_590 + lVar30,3,0);
                  fn_31f898(&lStack_738,iVar22,(long)pfStack_730 + lVar30 + 0x398,1,uVar27);
                  lVar30 = lVar30 + -0x28;
                  iVar22 = iVar31;
                  iVar31 = iVar31 + -1;
                } while (lVar30 != -0x28);
                iVar22 = 0x17;
              }
            }
            if (((bRam0000000007761618 & 1) == 0) && (iVar31 = fn_65eda8(0x7761618), iVar31 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            fn_19d788(uRam0000000007760da8,uRam0000000007760e7c,
                      *(undefined8 *)((long)iVar22 * 0x28 + 0x7760f00));
          }
          if (uStack_6c8._4_1_ != '\0') {
            if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            fn_19d788(uRam0000000007760da8,uRam0000000007760e98,uRam0000000007760f78);
          }
          if ((lRam0000000007761550 != 0) && (uVar25 = fn_198128(), (uVar25 & 1) != 0)) {
            if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
              fn_31ca58();
              imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
              fn_65eed8(0x7761618);
            }
            fn_19d788(uRam0000000007760da8,uRam0000000007760ea0,lRam0000000007761550);
          }
          fn_31f898(&lStack_738,uVar21,&uStack_700,0,0);
          auVar12._8_4_ = uStack_6d0;
          auVar12._0_8_ = uStack_6d8;
          auVar12._12_4_ = uStack_6cc;
          uRam0000000007761520 = auVar12._8_8_;
          uRam0000000007761518 = uStack_6d8;
          uRam0000000007761530 = uStack_6c0;
          uRam0000000007761528 = uStack_6c8;
          uRam0000000007761540 = uStack_6b0;
          uRam0000000007761538 = uStack_6b8;
          cRam0000000007761548 = '\x01';
        }
        if ((cRam0000000007760ef8 == '\0') ||
           (iVar22 = iRam0000000007760efc, uRam0000000007760ee8 != param_1)) {
          fn_31a518();
          (*pcRam0000000007761668)(param_1,0x12,lRam0000000007760ed8,0);
          cRam0000000007760ef8 = '\x01';
          if (lRam0000000007760ef0 != 0) {
            fn_439c54();
          }
          lRam0000000007760ef0 = 0;
          uRam0000000007760ee8 = param_1;
          if (param_1 != 0) {
            lRam0000000007760ef0 = fn_439970(param_1);
          }
          iVar22 = 1;
          if (1 < iRam0000000007760efc + 1U) {
            iVar22 = iRam0000000007760efc + 1;
          }
        }
        iRam0000000007760efc = iVar22;
        uVar3 = *(undefined *)((long)param_3 + 0xa9);
        if ((param_2 & 1) != 0) {
          uVar3 = 1;
        }
        uVar2 = *(undefined *)((long)param_3 + 0xa9);
        if (*(char *)((long)param_3 + 0x49) != '\0') {
          uVar2 = uVar3;
        }
        fn_31c620(param_1,uVar2);
      }
    }
    else if ((cRam0000000007760ef8 != '\0') && (uRam0000000007760ee8 == param_1)) {
      if (*(long *)(lVar9 + 0x28) == lStack_90) {
        if (((bRam0000000007761618 & 1) == 0) && (iVar22 = fn_65eda8(0x7761618), iVar22 != 0)) {
          fn_31ca58();
          imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
          fn_65eed8(0x7761618);
        }
        uVar25 = uRam0000000007760ee8;
        if ((((cRam0000000007760ef8 != '\0') && (uRam0000000007760ee8 != 0)) &&
            (uVar23 = fn_198128(uRam0000000007760ee8), (uVar23 & 1) != 0)) &&
           (lRam0000000007760ed8 != 0)) {
          (*pcRam0000000007761670)(uVar25,0x12,lRam0000000007760ed8,0);
        }
        cRam0000000007760ef8 = 0;
        if (lRam0000000007760ef0 != 0) {
          fn_439c54();
        }
        uRam0000000007760ee8 = 0;
        lRam0000000007760ef0 = 0;
        return;
      }
      goto LAB_0041c458;
    }
  }
  if (*(long *)(lVar9 + 0x28) == lStack_90) {
    return;
  }
LAB_0041c458:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

