
// ================================================================================
// Наш телеграм бот: t.me/imguisource_bot
// Наш канал ImGui Source: t.me/ImGui_Source_FIXNEY
// Второй канал shit src 🧨: t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x37cc10 */

undefined8 fn_37cc10(long param_1)

{
  if (*(char *)(param_1 + 0x11c) != '\0') {
    if (*(char *)(param_1 + 0xec) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0x11e) != '\0') && (*(char *)(param_1 + 0x20c) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 0x358) != '\0') {
    if (*(char *)(param_1 + 0x328) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0x35a) != '\0') && (*(char *)(param_1 + 0x448) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 0x594) != '\0') {
    if (*(char *)(param_1 + 0x564) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0x596) != '\0') && (*(char *)(param_1 + 0x684) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 2000) != '\0') {
    if (*(char *)(param_1 + 0x7a0) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0x7d2) != '\0') && (*(char *)(param_1 + 0x8c0) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 0xa0c) != '\0') {
    if (*(char *)(param_1 + 0x9dc) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0xa0e) != '\0') && (*(char *)(param_1 + 0xafc) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 0xc48) != '\0') {
    if (*(char *)(param_1 + 0xc18) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0xc4a) != '\0') && (*(char *)(param_1 + 0xd38) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 0xe84) != '\0') {
    if (*(char *)(param_1 + 0xe54) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0xe86) != '\0') && (*(char *)(param_1 + 0xf74) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 0x10c4) != '\0') {
    if (*(char *)(param_1 + 0x1094) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0x10c6) != '\0') && (*(char *)(param_1 + 0x11b4) != '\0')) {
      return 1;
    }
  }
  if (*(char *)(param_1 + 0x1304) != '\0') {
    if (*(char *)(param_1 + 0x12d4) != '\0') {
      return 1;
    }
    if ((*(char *)(param_1 + 0x1306) != '\0') && (*(char *)(param_1 + 0x13f4) != '\0')) {
      return 1;
    }
  }
  return 0;
}

