
// ================================================================================
// [METADATA]
// BOT=https://t.me/imguisource_bot
// MAIN_CHANNEL=https://t.me/ImGui_Source_FIXNEY
// EXTRA_CHANNEL=https://t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x37f8e0 */

void fn_37f8e0(long *param_1,long param_2,long param_3,ulong param_4)

{
  ulong uVar1;
  int iVar2;
  long *plVar3;
  long lVar4;
  ulong uVar5;
  long lVar6;
  long lVar7;
  long lVar8;
  long lVar9;
  undefined auVar10 [16];
  
  uVar5 = param_1[2];
  lVar8 = *param_1;
  if (param_4 <= (ulong)((long)(uVar5 - lVar8) >> 5)) {
    lVar9 = param_1[1] - lVar8;
    if ((ulong)(lVar9 >> 5) < param_4) {
      param_2 = param_2 + lVar9;
      if (param_1[1] != lVar8) {
        imp_memmove(lVar8);
        lVar8 = param_1[1];
      }
      lVar9 = -param_2;
    }
    else {
      lVar9 = -param_2;
    }
    param_3 = param_3 + lVar9;
    if (param_3 != 0) {
      imp_memmove(lVar8,param_2,param_3);
    }
LAB_0047f9ec:
    param_1[1] = lVar8 + param_3;
    return;
  }
  lVar9 = param_3;
  if (lVar8 != 0) {
    param_1[1] = lVar8;
    fn_6790c8(lVar8);
    uVar5 = 0;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if (param_4 >> 0x3b == 0) {
    uVar1 = (long)uVar5 >> 4;
    if ((ulong)((long)uVar5 >> 4) <= param_4) {
      uVar1 = param_4;
    }
    if (0x7fffffffffffffdf < uVar5) {
      uVar1 = 0x7ffffffffffffff;
    }
    if (uVar1 >> 0x3b == 0) {
      lVar8 = fn_679020(uVar1 * 0x20);
      param_3 = param_3 - param_2;
      *param_1 = lVar8;
      param_1[1] = lVar8;
      param_1[2] = lVar8 + uVar1 * 0x20;
      if (param_3 != 0) {
        imp_memcpy(lVar8,param_2,param_3);
      }
      goto LAB_0047f9ec;
    }
  }
  auVar10 = fn_378a90(param_1);
  lVar7 = auVar10._8_8_;
  plVar3 = auVar10._0_8_;
  uVar5 = plVar3[2];
  lVar8 = *plVar3;
  if (param_4 <= (ulong)((long)(uVar5 - lVar8) >> 4)) {
    lVar6 = plVar3[1] - lVar8;
    lVar4 = lVar7;
    if (((ulong)(lVar6 >> 4) < param_4) && (lVar4 = lVar7 + lVar6, plVar3[1] != lVar8)) {
      imp_memmove(lVar8,lVar7,lVar6 + -4);
      lVar8 = plVar3[1];
    }
    lVar9 = lVar9 - lVar4;
    if (lVar9 != 0) {
      imp_memmove(lVar8,lVar4,lVar9 + -4);
    }
LAB_0047fb24:
    plVar3[1] = lVar8 + lVar9;
    return;
  }
  lVar4 = lVar9;
  if (lVar8 != 0) {
    plVar3[1] = lVar8;
    fn_6790c8(lVar8);
    uVar5 = 0;
    *plVar3 = 0;
    plVar3[1] = 0;
    plVar3[2] = 0;
  }
  if (param_4 >> 0x3c == 0) {
    uVar1 = (long)uVar5 >> 3;
    if ((ulong)((long)uVar5 >> 3) <= param_4) {
      uVar1 = param_4;
    }
    if (0x7fffffffffffffef < uVar5) {
      uVar1 = 0xfffffffffffffff;
    }
    if (uVar1 >> 0x3c == 0) {
      lVar8 = fn_679020(uVar1 * 0x10);
      lVar9 = lVar9 - lVar7;
      *plVar3 = lVar8;
      plVar3[1] = lVar8;
      plVar3[2] = lVar8 + uVar1 * 0x10;
      if (lVar9 != 0) {
        imp_memcpy(lVar8,lVar7,lVar9 + -4);
      }
      goto LAB_0047fb24;
    }
  }
  auVar10 = fn_377560(plVar3);
  lVar8 = auVar10._8_8_;
  plVar3 = auVar10._0_8_;
  lVar7 = plVar3[2];
  lVar9 = *plVar3;
  if ((ulong)((lVar7 - lVar9 >> 4) * -0x5555555555555555) < param_4) {
    if (lVar9 != 0) {
      plVar3[1] = lVar9;
      fn_6790c8(lVar9);
      lVar7 = 0;
      *plVar3 = 0;
      plVar3[1] = 0;
      plVar3[2] = 0;
    }
    if (param_4 < 0x555555555555556) {
      uVar5 = (lVar7 >> 4) * 0x5555555555555556;
      if (uVar5 < param_4 || uVar5 - param_4 == 0) {
        uVar5 = param_4;
      }
      if (0x2aaaaaaaaaaaaa9 < (ulong)((lVar7 >> 4) * -0x5555555555555555)) {
        uVar5 = 0x555555555555555;
      }
      if (uVar5 < 0x555555555555556) {
        lVar9 = fn_679020(uVar5 * 0x30);
        lVar4 = lVar4 - lVar8;
        *plVar3 = lVar9;
        plVar3[1] = lVar9;
        plVar3[2] = lVar9 + uVar5 * 0x30;
        if (lVar4 != 0) {
          imp_memcpy(lVar9,lVar8,lVar4);
        }
        goto LAB_0047fc88;
      }
    }
    fn_34ba14(plVar3);
    if (((bRam000000000787de70 & 1) == 0) && (iVar2 = fn_65eda8(0x787de70), iVar2 != 0)) {
      uRam000000000787de68 = 0;
      uRam000000000787de50 = 0;
      uRam000000000787de48 = 0;
      uRam000000000787de60 = 0;
      uRam000000000787de66 = 0;
      uRam000000000787de58 = 0;
      uRam000000000787de40 = 0;
      uRam000000000787de38 = 0;
      fn_126978(&UNK_02f49914,0x787de38,0x36,0x49b4cde932fa7adc);
      fn_65eed8(0x787de70);
    }
    uRam000000000787de28 = 0x787de38;
    if (((bRam000000000787deb0 & 1) == 0) && (iVar2 = fn_65eda8(0x787deb0), iVar2 != 0)) {
      uRam000000000787dea8 = 0;
      uRam000000000787de90 = 0;
      uRam000000000787de88 = 0;
      uRam000000000787dea0 = 0;
      uRam000000000787dea5 = 0;
      uRam000000000787de98 = 0;
      uRam000000000787de80 = 0;
      uRam000000000787de78 = 0;
      fn_126978(&UNK_02f4994a,0x787de78,0x35,0x2064a9c70a6ba787);
      fn_65eed8(0x787deb0);
    }
    uRam000000000787de30 = 0x787de78;
    return;
  }
  lVar7 = plVar3[1] - lVar9;
  if (((ulong)((lVar7 >> 4) * -0x5555555555555555) < param_4) &&
     (lVar8 = lVar8 + lVar7, plVar3[1] != lVar9)) {
    imp_memmove(lVar9);
    lVar9 = plVar3[1];
  }
  lVar4 = lVar4 - lVar8;
  if (lVar4 != 0) {
    imp_memmove(lVar9,lVar8,lVar4);
  }
LAB_0047fc88:
  plVar3[1] = lVar9 + lVar4;
  return;
}

