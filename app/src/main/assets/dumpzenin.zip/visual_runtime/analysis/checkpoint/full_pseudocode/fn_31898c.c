
// ================================================================================
// [TG] @imguisource_bot -> @ImGui_Source_FIXNEY (ImGui Source) -> @il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x31898c */

void fn_31898c(long param_1)

{
  long lVar1;
  uint uVar2;
  long lVar3;
  char cVar4;
  int iVar5;
  ulong uVar6;
  long lVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  long lVar15;
  long lVar16;
  long lVar17;
  char *pcVar18;
  ulong uVar19;
  long *plVar20;
  undefined8 uStack_70;
  long lStack_68;
  
  lVar1 = tpidr_el0;
  lStack_68 = *(long *)(lVar1 + 0x28);
  if (((bRam0000000007761618 & 1) == 0) && (iVar5 = fn_65eda8(0x7761618), iVar5 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  if (((bRam0000000007761618 & 1) == 0) && (iVar5 = fn_65eda8(0x7761618), iVar5 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  pcVar18 = (char *)0x7760b48;
  if (puRam0000000007760c08 == (undefined8 *)0x0) {
LAB_00418bf4:
    if (*pcVar18 != '\0') goto LAB_00418bfc;
  }
  else {
    if ((cRam0000000007760b48 != '\0') &&
       ((((cRam0000000007760b4a != '\0' || (cRam0000000007760b78 != '\0')) ||
         (cRam0000000007760b81 != '\0')) ||
        (((cRam0000000007760b91 != '\0' || ((char)uRam0000000007760b9c != '\0')) ||
         (((char)uRam0000000007760bcc != '\0' || (cRam0000000007760bf1 != '\0')))))))) {
      _uRam0000000007760c90 = CONCAT44(uRam0000000007760bcc,uRam0000000007760bc8);
      uRam0000000007760cb8 =
           CONCAT22(uRam0000000007760bf2,CONCAT11(cRam0000000007760bf1,uRam0000000007760bf0));
      uRam0000000007760c98 = uRam0000000007760bd0;
      uRam0000000007760ca8 = uRam0000000007760be0;
      uRam0000000007760ca0 = uRam0000000007760bd8;
      uRam0000000007760cb0 = uRam0000000007760be8;
      uRam0000000007760cc4 = uRam0000000007760bfc;
      uRam0000000007760cbc = uRam0000000007760bf4;
      uRam0000000007760cc0 = uRam0000000007760bf8;
      uRam0000000007760c58 =
           CONCAT62(uRam0000000007760b92,CONCAT11(cRam0000000007760b91,uRam0000000007760b90));
      uRam0000000007760c60 = CONCAT44(uRam0000000007760b9c,uRam0000000007760b98);
      uRam0000000007760c50 = (undefined4)uRam0000000007760b88;
      uRam0000000007760c54 = (undefined4)((ulong)uRam0000000007760b88 >> 0x20);
      uRam0000000007760c68 = uRam0000000007760ba0;
      uRam0000000007760c78 = uRam0000000007760bb0;
      uRam0000000007760c70 = uRam0000000007760ba8;
      uRam0000000007760c88 = uRam0000000007760bc0;
      uRam0000000007760c80 = uRam0000000007760bb8;
      uRam0000000007760c18 = (undefined4)uRam0000000007760b50;
      uRam0000000007760c1c = (undefined4)((ulong)uRam0000000007760b50 >> 0x20);
      cRam0000000007760c10 = cRam0000000007760b48;
      uRam0000000007760c11 = uRam0000000007760b49;
      cRam0000000007760c12 = cRam0000000007760b4a;
      uRam0000000007760c13 = (undefined)uRam0000000007760b4b;
      uRam0000000007760c14 = (undefined4)((uint5)uRam0000000007760b4b >> 8);
      uRam0000000007760c28 = uRam0000000007760b60;
      uRam0000000007760c20 = (undefined4)uRam0000000007760b58;
      uRam0000000007760c24 = (undefined4)((ulong)uRam0000000007760b58 >> 0x20);
      uRam0000000007760c40 = CONCAT71(uRam0000000007760b79,cRam0000000007760b78);
      uRam0000000007760c38 = uRam0000000007760b70;
      uRam0000000007760c30 = uRam0000000007760b68;
      uRam0000000007760c48 = uRam0000000007760b80;
      cRam0000000007760c49 = cRam0000000007760b81;
      uRam0000000007760c4a = (undefined2)uRam0000000007760b82;
      uRam0000000007760c4c = (undefined4)((uint6)uRam0000000007760b82 >> 0x10);
      if ((cRam0000000007760b4a == '\0') && (*(char *)((long)puRam0000000007760c08 + 2) != '\0')) {
        uRam0000000007760c1c = (undefined4)*(undefined8 *)((long)puRam0000000007760c08 + 0xc);
        uRam0000000007760c20 =
             (undefined4)((ulong)*(undefined8 *)((long)puRam0000000007760c08 + 0xc) >> 0x20);
        uRam0000000007760c14 = (undefined4)*(undefined8 *)((long)puRam0000000007760c08 + 4);
        uRam0000000007760c18 =
             (undefined4)((ulong)*(undefined8 *)((long)puRam0000000007760c08 + 4) >> 0x20);
        uRam0000000007760c24 = *(undefined4 *)((long)puRam0000000007760c08 + 0x14);
        cRam0000000007760c12 = '\x01';
        uRam0000000007760c30 = puRam0000000007760c08[4];
        uRam0000000007760c28 = puRam0000000007760c08[3];
        uRam0000000007760c38 =
             CONCAT71((int7)((ulong)uRam0000000007760b70 >> 8),
                      *(undefined *)(puRam0000000007760c08 + 5));
        uRam0000000007760c38 =
             CONCAT44(*(undefined4 *)((long)puRam0000000007760c08 + 0x2c),
                      (undefined4)uRam0000000007760c38);
      }
      if ((cRam0000000007760b78 == '\0') && (*(char *)(puRam0000000007760c08 + 6) != '\0')) {
        uRam0000000007760c48 = *(undefined *)(puRam0000000007760c08 + 7);
        uRam0000000007760c40 = CONCAT71(uRam0000000007760b79,1);
        uRam0000000007760c40 =
             CONCAT44(*(undefined4 *)((long)puRam0000000007760c08 + 0x34),
                      (undefined4)uRam0000000007760c40);
      }
      if ((cRam0000000007760b81 == '\0') && (*(char *)((long)puRam0000000007760c08 + 0x39) != '\0'))
      {
        uRam0000000007760c4c = (undefined4)*(undefined8 *)((long)puRam0000000007760c08 + 0x3c);
        uRam0000000007760c50 =
             (undefined4)((ulong)*(undefined8 *)((long)puRam0000000007760c08 + 0x3c) >> 0x20);
        uRam0000000007760c54 = *(undefined4 *)((long)puRam0000000007760c08 + 0x44);
        cRam0000000007760c49 = '\x01';
        uVar6 = (ulong)uRam0000000007760c58 >> 8;
        uRam0000000007760c58 = CONCAT71((int7)uVar6,*(undefined *)(puRam0000000007760c08 + 9));
      }
      if (((char)uRam0000000007760b9c == '\0') &&
         (*(char *)((long)puRam0000000007760c08 + 0x54) != '\0')) {
        uRam0000000007760c68 = puRam0000000007760c08[0xb];
        uRam0000000007760c78 = puRam0000000007760c08[0xd];
        uRam0000000007760c70 = puRam0000000007760c08[0xc];
        uRam0000000007760c88 = puRam0000000007760c08[0xf];
        uRam0000000007760c80 = puRam0000000007760c08[0xe];
        _uRam0000000007760c90 =
             CONCAT44(uRam0000000007760bcc,*(undefined4 *)(puRam0000000007760c08 + 0x10));
      }
      pcVar18 = (char *)0x7760c10;
      if ((uRam0000000007760c90._4_1_ == '\0') &&
         (pcVar18 = (char *)0x7760c10, *(char *)((long)puRam0000000007760c08 + 0x84) != '\0')) {
        uRam0000000007760ca0 = puRam0000000007760c08[0x12];
        uRam0000000007760c98 = puRam0000000007760c08[0x11];
        uRam0000000007760cb0 = puRam0000000007760c08[0x14];
        uRam0000000007760ca8 = puRam0000000007760c08[0x13];
        uVar2 = (uint)uRam0000000007760cb8 >> 8;
        uRam0000000007760cb8 = CONCAT31((int3)uVar2,*(undefined *)(puRam0000000007760c08 + 0x15));
      }
      goto LAB_00418bf4;
    }
    uRam0000000007760c38 = puRam0000000007760c08[5];
    uRam0000000007760c30 = puRam0000000007760c08[4];
    uVar8 = puRam0000000007760c08[7];
    uRam0000000007760c40 = puRam0000000007760c08[6];
    pcVar18 = (char *)0x7760c10;
    uVar9 = *puRam0000000007760c08;
    uRam0000000007760c28 = puRam0000000007760c08[3];
    uRam0000000007760c48 = (undefined)uVar8;
    cRam0000000007760c49 = (char)((ulong)uVar8 >> 8);
    uRam0000000007760c4a = (undefined2)((ulong)uVar8 >> 0x10);
    uRam0000000007760c4c = (undefined4)((ulong)uVar8 >> 0x20);
    uRam0000000007760c18 = (undefined4)puRam0000000007760c08[1];
    uRam0000000007760c1c = (undefined4)((ulong)puRam0000000007760c08[1] >> 0x20);
    uRam0000000007760c11 = (undefined)((ulong)uVar9 >> 8);
    cRam0000000007760c12 = (char)((ulong)uVar9 >> 0x10);
    uRam0000000007760c13 = (undefined)((ulong)uVar9 >> 0x18);
    uRam0000000007760c14 = (undefined4)((ulong)uVar9 >> 0x20);
    uRam0000000007760c20 = (undefined4)puRam0000000007760c08[2];
    uRam0000000007760c24 = (undefined4)((ulong)puRam0000000007760c08[2] >> 0x20);
    uRam0000000007760c78 = puRam0000000007760c08[0xd];
    uRam0000000007760c70 = puRam0000000007760c08[0xc];
    uRam0000000007760c88 = puRam0000000007760c08[0xf];
    uRam0000000007760c80 = puRam0000000007760c08[0xe];
    uRam0000000007760c58 = puRam0000000007760c08[9];
    uRam0000000007760c68 = puRam0000000007760c08[0xb];
    uRam0000000007760c60 = puRam0000000007760c08[10];
    uRam0000000007760c50 = (undefined4)puRam0000000007760c08[8];
    uRam0000000007760c54 = (undefined4)((ulong)puRam0000000007760c08[8] >> 0x20);
    uRam0000000007760ca8 = puRam0000000007760c08[0x13];
    uRam0000000007760ca0 = puRam0000000007760c08[0x12];
    uRam0000000007760cb0 = puRam0000000007760c08[0x14];
    uRam0000000007760cc4 = *(undefined8 *)((long)puRam0000000007760c08 + 0xb4);
    uRam0000000007760c98 = puRam0000000007760c08[0x11];
    _uRam0000000007760c90 = puRam0000000007760c08[0x10];
    uRam0000000007760cc0 =
         (undefined4)((ulong)*(undefined8 *)((long)puRam0000000007760c08 + 0xac) >> 0x20);
    uRam0000000007760cb8 = (undefined4)puRam0000000007760c08[0x15];
    uRam0000000007760cbc = (undefined4)((ulong)puRam0000000007760c08[0x15] >> 0x20);
    cRam0000000007760c10 = '\x01';
LAB_00418bfc:
    if (((((((pcVar18[2] != '\0') || (pcVar18[0x30] != '\0')) || (pcVar18[0x39] != '\0')) ||
          ((pcVar18[0x49] != '\0' || (pcVar18[0x54] != '\0')))) || (pcVar18[0x84] != '\0')) ||
        (pcVar18[0xa9] != '\0')) && (uVar6 = fn_432fec(), (uVar6 & 1) != 0)) {
      uVar6 = fn_198128(param_1);
      if ((uVar6 & 1) == 0) goto LAB_00418cb0;
      lVar7 = fn_1cd154();
      if (lVar7 == 0) {
        lVar7 = fn_18e31c();
joined_r0x00418cec:
        if (lVar7 != param_1) {
LAB_00418d00:
          iVar5 = fn_18ea14(param_1);
          if (iVar5 != 0x100) goto LAB_00418cb0;
        }
      }
      else {
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        uVar19 = (ulong)uRam00000000076aa6b2;
        uVar6 = fn_139354(0x76a97a8,uVar19 + lVar7,8);
        if ((uVar6 & 1) != 0) {
          lVar7 = *(long *)(uVar19 + lVar7);
          goto joined_r0x00418cec;
        }
        lVar7 = 0;
        if (param_1 != 0) goto LAB_00418d00;
      }
      if (bRam0000000007761748 == 0) {
        if (cRam0000000007761749 != '\0') goto LAB_00418cb0;
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        lRam0000000007761738 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007b5d91,&UNK_007fed29);
        uVar8 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007b5d91,&UNK_007f33e3);
        uRam0000000007761740 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007a13d2,&UNK_007d821e);
        uVar9 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007a13d2,&UNK_007ee9a6);
        uVar10 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007a13d2,&UNK_007d4569);
        uVar11 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007a13d2,&UNK_007d450f);
        uVar12 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007a13d2,&UNK_007bfaeb);
        uVar13 = fn_18de44();
        uVar14 = fn_18e1d0();
        uVar6 = fn_31cf58(0x7761620,lRam0000000007761738,&UNK_007df39c);
        if (((uVar6 & 1) == 0) ||
           (uVar6 = fn_31cf58(0x7761628,lRam0000000007761738,&UNK_007eadea),
           lVar3 = lRam0000000007761738, (uVar6 & 1) == 0)) {
LAB_004193d0:
          bRam0000000007761748 = 0;
        }
        else {
          lRam0000000007761640 = 0;
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          lVar15 = fn_43bc24(0x76a9768);
          uStack_70 = 0;
          lVar17 = lRam0000000007761640;
          if ((lVar3 != 0) &&
             (lVar16 = fn_43cd50(0x76a9768,lVar3,&uStack_70), lVar17 = lRam0000000007761640,
             lVar16 != 0)) {
            do {
              uVar19 = (ulong)bRam00000000076aa0a5;
              uVar6 = fn_139354(0x76a97a8,uVar19 + lVar16,8);
              if (((((uVar6 & 1) != 0) &&
                   (plVar20 = *(long **)(uVar19 + lVar16), plVar20 != (long *)0x0)) &&
                  (lVar17 = imp_strlen(plVar20), lVar17 == 0xf)) &&
                 (*plVar20 == 0x6564495f74696c42 &&
                  *(long *)((long)plVar20 + 7) == 0x7265696669746e65)) {
                uVar19 = (ulong)bRam00000000076aa0a4;
                uVar6 = fn_139354(0x76a97a8,uVar19 + lVar16,1);
                if (((uVar6 & 1) != 0) && (*(char *)(uVar19 + lVar16) == '\b')) {
                  uVar19 = (ulong)bRam00000000076aa0a2;
                  uVar6 = fn_139354(0x76a97a8,uVar19 + lVar16,8);
                  if ((uVar6 & 1) == 0) {
                    lVar17 = 0;
                  }
                  else {
                    lVar17 = *(long *)(uVar19 + lVar16);
                  }
                  if (lVar15 + 0x72c69c8 == lVar17) break;
                }
              }
              lVar16 = fn_43cd50(0x76a9768,lVar3,&uStack_70);
              lVar17 = lRam0000000007761640;
            } while (lVar16 != 0);
          }
          lRam0000000007761640 = lVar17;
          if (((lRam0000000007761640 == 0) && ((bRam00000000076ac3f8 & 1) == 0)) &&
             (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          if ((((((((lRam0000000007761640 == 0) ||
                   (uVar6 = fn_31d080(lRam0000000007761738), (uVar6 & 1) == 0)) ||
                  (uVar6 = fn_31d3b0(lRam0000000007761738), (uVar6 & 1) == 0)) ||
                 ((uVar6 = fn_31d4d8(uVar8), (uVar6 & 1) == 0 ||
                  (uVar6 = fn_31d7f4(uVar8), (uVar6 & 1) == 0)))) ||
                (((uVar6 = fn_31db10(0x7761668,uVar13,&UNK_007a9ac3,0x6bda16c), (uVar6 & 1) == 0 ||
                  ((uVar6 = fn_31db10(0x7761670,uVar13,&UNK_007d4574,0x6bd8284), (uVar6 & 1) == 0 ||
                   (uVar6 = fn_31de2c(0x7761678,uVar13,&UNK_007a7cae), (uVar6 & 1) == 0)))) ||
                 (uVar6 = fn_31de2c(0x7761680,uVar13,&UNK_007e60e0), (uVar6 & 1) == 0)))) ||
               (((((uVar6 = fn_31df54(uVar13), (uVar6 & 1) == 0 ||
                   (uVar6 = fn_31e07c(0x7761690,uVar13,&UNK_007de6d2), (uVar6 & 1) == 0)) ||
                  (uVar6 = fn_31de2c(0x7761698,uVar13,&UNK_007b010f), (uVar6 & 1) == 0)) ||
                 ((uVar6 = fn_31e1a4(0x77616a0,uVar13,&UNK_0078fa09), (uVar6 & 1) == 0 ||
                  (uVar6 = fn_31e2cc(uRam0000000007761740), (uVar6 & 1) == 0)))) ||
                ((uVar6 = fn_31e07c(0x77616b0,uRam0000000007761740,&UNK_007eeaeb), (uVar6 & 1) == 0
                 || ((uVar6 = fn_31e07c(0x77616b8,uRam0000000007761740,&UNK_007fed46),
                     (uVar6 & 1) == 0 ||
                     (uVar6 = fn_31cf58(0x77616c0,uRam0000000007761740,&UNK_007e3ea5),
                     (uVar6 & 1) == 0)))))))) ||
              ((uVar6 = fn_31e5e8(0x77616c8,uRam0000000007761740,&UNK_007a1ea8), (uVar6 & 1) == 0 ||
               (((uVar6 = fn_31e5e8(0x77616d0,uRam0000000007761740,&UNK_007c53fe), (uVar6 & 1) == 0
                 || (uVar6 = fn_31e5e8(0x77616d8,uRam0000000007761740,&UNK_007d822c),
                    (uVar6 & 1) == 0)) ||
                (uVar6 = fn_31e1a4(0x77616e0,uVar9,&UNK_007fed50), (uVar6 & 1) == 0)))))) ||
             (((uVar6 = fn_31e1a4(0x77616e8,uVar9,&UNK_00785367), (uVar6 & 1) == 0 ||
               (uVar6 = fn_31e710(uVar10), (uVar6 & 1) == 0)) ||
              ((uVar6 = fn_31e838(uVar10), (uVar6 & 1) == 0 ||
               ((uVar6 = fn_31e960(0x7761700,uVar11,&UNK_007c87b7), (uVar6 & 1) == 0 ||
                (uVar6 = fn_31e960(0x7761708,uVar11,&UNK_007fa1e3), (uVar6 & 1) == 0))))))))
          goto LAB_004193d0;
          uVar8 = fn_18de0c();
          uVar6 = fn_31e07c(0x7761710,uVar8,&UNK_0078446b);
          if (((uVar6 & 1) == 0) ||
             (((uVar6 = fn_31e960(0x7761718,uVar12,&UNK_007a43f2), (uVar6 & 1) == 0 ||
               (uVar6 = fn_31ea88(0x7761720,uVar14,&UNK_007a7cbd,0x72dbf24), (uVar6 & 1) == 0)) ||
              (uVar6 = fn_31ea88(0x7761728,uVar14,&UNK_0079c7e5,0x72fbdf0), (uVar6 & 1) == 0))))
          goto LAB_004193d0;
          fn_18de7c();
          bRam0000000007761748 = fn_31eda4();
        }
        bRam0000000007761748 = bRam0000000007761748 & 1;
        if (lRam0000000007761738 == 0) {
          uRam0000000007761638 = 0;
          uRam0000000007761630 = 0;
        }
        else {
          uRam0000000007761630 = fn_43d5e4(0x76a9768,lRam0000000007761738,&UNK_007faeda,1);
          if (lRam0000000007761738 == 0) {
            uRam0000000007761638 = 0;
          }
          else {
            uRam0000000007761638 = fn_43d5e4(0x76a9768,lRam0000000007761738,&UNK_007e3ea5,0);
          }
        }
        if (bRam0000000007761748 == 0) {
          cRam0000000007761749 = '\x01';
          goto LAB_00418cb0;
        }
        bRam000000000776174a = (*pcRam00000000077616f0)(2,0);
        bRam000000000776174a = bRam000000000776174a & 1;
        bRam000000000776174b = (*pcRam00000000077616f0)(0x16,0);
        bRam000000000776174b = bRam000000000776174b & 1;
        bRam000000000776174c = (*pcRam00000000077616f0)(0x10,0);
        bRam000000000776174c = bRam000000000776174c & 1;
        bRam000000000776174d = (*pcRam00000000077616f0)(0xf,0);
        bRam000000000776174d = bRam000000000776174d & 1;
        bRam000000000776174e = (*pcRam00000000077616f8)(0);
        bRam000000000776174e = bRam000000000776174e & 1;
        iVar5 = (*pcRam0000000007761718)(0);
        cRam000000000776174f = iVar5 == 0;
        if (iVar5 != 0) {
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar5 = fn_65eda8(0x76ac3f8), iVar5 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          goto LAB_00418d24;
        }
      }
      else {
LAB_00418d24:
        if (cRam000000000776174f == '\0') goto LAB_00418cb0;
      }
      if ((lVar7 != param_1) && (lRam00000000077615c0 != param_1)) {
        fn_3199e8(0x77615c0,param_1);
      }
      fn_319a28();
      uVar6 = fn_319c00();
      if ((uVar6 & 1) != 0) {
        if ((lVar7 == param_1) && (pcVar18[0x49] != '\0')) {
          fn_319fb0(param_1);
        }
        lVar3 = lRam00000000077615c0;
        cVar4 = pcVar18[1];
        if (cVar4 != '\0') {
          if (((lRam00000000077615c0 == 0) ||
              (uVar6 = fn_198128(lRam00000000077615c0), (uVar6 & 1) == 0)) ||
             (uVar6 = (*pcRam0000000007761710)(lVar3,0), (uVar6 & 1) == 0)) {
            cVar4 = '\0';
          }
          else {
            iVar5 = fn_18ea14(lVar3);
            cVar4 = iVar5 == 0x100;
          }
        }
        if ((bool)cVar4 == (lVar7 != param_1)) {
          cRam0000000007761615 = '\x01';
          fn_31a5ec(param_1,lVar7 != param_1,pcVar18);
        }
        else if ((cRam0000000007760ef8 != '\0') && (lRam0000000007760ee8 == param_1)) {
          fn_31a518();
        }
      }
      goto LAB_00418cb0;
    }
  }
  if (cRam0000000007761615 != '\0') {
    fn_319834(1);
    cRam0000000007761615 = '\0';
  }
LAB_00418cb0:
  if (*(long *)(lVar1 + 0x28) != lStack_68) {
                    /* WARNING: Subroutine does not return */
    imp___stack_chk_fail();
  }
  return;
}

