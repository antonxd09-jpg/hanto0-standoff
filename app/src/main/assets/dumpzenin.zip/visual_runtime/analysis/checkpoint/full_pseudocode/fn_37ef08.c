
// ================================================================================
// Source provider: @imguisource_bot
// Channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Channel: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x37ef08 */

void fn_37ef08(long *param_1,long param_2,undefined8 param_3,long param_4)

{
  long lVar1;
  int iVar2;
  long lVar3;
  long lVar4;
  ulong uVar5;
  long lVar6;
  long lVar7;
  ulong uVar8;
  long lVar9;
  undefined8 uStack_70;
  long lStack_68;
  
  lVar1 = tpidr_el0;
  lStack_68 = *(long *)(lVar1 + 0x28);
  *param_1 = 0;
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  lVar3 = fn_43bc24(0x76a9768);
  uStack_70 = 0;
  if ((param_2 != 0) && (lVar4 = fn_43cd50(0x76a9768,param_2,&uStack_70), lVar4 != 0)) {
    do {
      uVar8 = (ulong)bRam00000000076aa0a5;
      uVar5 = fn_139354(0x76a97a8,uVar8 + lVar4,8);
      if (((uVar5 & 1) != 0) && (lVar9 = *(long *)(uVar8 + lVar4), lVar9 != 0)) {
        lVar6 = imp_strlen(lVar9);
        lVar7 = imp_strlen(param_3);
        if ((lVar6 == lVar7) && (iVar2 = imp_memcmp(lVar9,param_3,lVar6), iVar2 == 0)) {
          uVar8 = (ulong)bRam00000000076aa0a4;
          uVar5 = fn_139354(0x76a97a8,uVar8 + lVar4,1);
          if (((uVar5 & 1) != 0) && (*(char *)(uVar8 + lVar4) == '\x02')) {
            uVar8 = (ulong)bRam00000000076aa0a2;
            uVar5 = fn_139354(0x76a97a8,uVar8 + lVar4,8);
            if ((uVar5 & 1) == 0) {
              lVar4 = 0;
            }
            else {
              lVar4 = *(long *)(uVar8 + lVar4);
            }
            if (lVar3 + param_4 == lVar4) {
              *param_1 = lVar4;
              goto joined_r0x0047f0c4;
            }
          }
        }
      }
      lVar4 = fn_43cd50(0x76a9768,param_2,&uStack_70);
    } while (lVar4 != 0);
  }
  lVar4 = *param_1;
joined_r0x0047f0c4:
  if (((lVar4 == 0) && ((bRam00000000076ac3f8 & 1) == 0)) &&
     (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  if (*(long *)(lVar1 + 0x28) == lStack_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(*param_1 != 0);
}

