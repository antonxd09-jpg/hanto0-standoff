
// ================================================================================
// Watermark:
// t.me/imguisource_bot
// t.me/ImGui_Source_FIXNEY (ImGui Source)
// t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x370e50 */

void fn_370e50(ulong *param_1)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  int iVar4;
  ulong uVar5;
  undefined8 uVar6;
  long lVar7;
  ulong uVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  ulong uVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  long lVar16;
  
  puVar2 = puRam000000000787c578;
  puVar13 = puRam000000000787c580;
  if (((bRam000000000787c6a0 & 1) == 0) &&
     (iVar4 = fn_65eda8(0x787c6a0), puVar2 = puRam000000000787c578, puVar13 = puRam000000000787c580,
     iVar4 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    puRam000000000787c580 = (undefined8 *)0x0;
    puRam000000000787c578 = (undefined8 *)0x0;
    uRam000000000787c590 = 0;
    uRam000000000787c588 = 0;
    uRam000000000787c5a0 = 0;
    uRam000000000787c598 = 0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c688 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c689 = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
    puVar2 = puRam000000000787c578;
    puVar13 = puRam000000000787c580;
  }
  do {
    puVar3 = puRam000000000787c580;
    if (puVar2 == puRam000000000787c580) {
      puRam000000000787c580 = puVar13;
      return;
    }
    puRam000000000787c580 = puVar13;
    if ((0 < *(int *)(puVar2 + 1)) && (uVar5 = fn_198128(*puVar2), (uVar5 & 1) != 0)) {
      uVar6 = fn_1997d4(*puVar2);
      uVar5 = func_0x0029a210();
      if (((uVar5 & 1) != 0) &&
         ((uVar5 = func_0x0029ba64(*puVar2), (uVar5 & 1) != 0 &&
          (iVar4 = fn_199ea0(uVar6), iVar4 == 8)))) {
        puVar13 = (undefined8 *)param_1[1];
        if (puVar13 < (undefined8 *)param_1[2]) {
          uVar6 = *puVar2;
          puVar14 = puVar13 + 2;
          puVar13[1] = puVar2[1];
          *puVar13 = uVar6;
        }
        else {
          puVar15 = (undefined8 *)*param_1;
          lVar16 = (long)puVar13 - (long)puVar15 >> 4;
          uVar5 = lVar16 + 1;
          if (uVar5 >> 0x3c != 0) {
            fn_377560(param_1);
code_r0x0047107c:
            uVar6 = fn_13edb4();
            fn_65ef80(0x787c6a0);
                    /* WARNING: Subroutine does not return */
            fn_67b74c(uVar6);
          }
          uVar8 = (long)(undefined8 *)param_1[2] - (long)puVar15;
          uVar11 = (long)uVar8 >> 3;
          if (uVar11 <= uVar5) {
            uVar11 = uVar5;
          }
          if (0x7fffffffffffffef < uVar8) {
            uVar11 = 0xfffffffffffffff;
          }
          if (uVar11 == 0) {
            lVar7 = 0;
          }
          else {
            if (uVar11 >> 0x3c != 0) goto code_r0x0047107c;
            lVar7 = fn_679020(uVar11 << 4);
          }
          puVar14 = (undefined8 *)(lVar7 + lVar16 * 0x10);
          uVar6 = *puVar2;
          puVar14[1] = puVar2[1];
          *puVar14 = uVar6;
          puVar9 = puVar14;
          puVar10 = puVar14;
          if (puVar13 != puVar15) {
            do {
              puVar12 = puVar13 + -2;
              uVar1 = *(undefined4 *)(puVar13 + -1);
              puVar10 = puVar9 + -2;
              *puVar10 = *puVar12;
              *(undefined4 *)(puVar9 + -1) = uVar1;
              puVar9 = puVar10;
              puVar13 = puVar12;
            } while (puVar12 != puVar15);
            puVar13 = (undefined8 *)*param_1;
          }
          puVar14 = puVar14 + 2;
          *param_1 = (ulong)puVar10;
          param_1[1] = (ulong)puVar14;
          param_1[2] = lVar7 + uVar11 * 0x10;
          if (puVar13 != (undefined8 *)0x0) {
            fn_6790c8(puVar13);
          }
        }
        param_1[1] = (ulong)puVar14;
      }
    }
    puVar2 = puVar2 + 2;
    puVar13 = puRam000000000787c580;
    puRam000000000787c580 = puVar3;
  } while( true );
}

