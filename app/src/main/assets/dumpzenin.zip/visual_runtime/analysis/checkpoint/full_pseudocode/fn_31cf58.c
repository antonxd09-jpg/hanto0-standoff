
// ================================================================================
// Uploaded to @imguisource_bot
// Sub: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Sub: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x31cf58 */

bool fn_31cf58(long *param_1,long param_2,undefined8 param_3)

{
  int iVar1;
  long lVar2;
  
  if (param_2 == 0) {
    *param_1 = 0;
  }
  else {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    lVar2 = fn_43d5e4(0x76a9768,param_2,param_3,0);
    *param_1 = lVar2;
    if (lVar2 != 0) goto LAB_0041cfb8;
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
LAB_0041cfb8:
  return *param_1 != 0;
}

