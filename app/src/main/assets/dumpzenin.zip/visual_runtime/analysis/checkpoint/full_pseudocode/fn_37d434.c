
// ================================================================================
// Release channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Second channel: t.me/il2cpp_src (shit src 🧨)
// Telegram bot: t.me/imguisource_bot
// ================================================================================

/* ORIGINAL_RVA: 0x37d434 */

void fn_37d434(long param_1)

{
  int iVar1;
  long lVar2;
  
  fn_37cee0();
  if (((bRam000000000787e2f0 & 1) == 0) && (iVar1 = fn_65eda8(0x787e2f0), iVar1 != 0)) {
    fn_37d22c();
    imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
    fn_65eed8(0x787e2f0);
  }
  lVar2 = *(long *)(param_1 + 8);
  if (lVar2 != 0) {
    (*pcRam000000000787dec0)(lVar2,0);
    if (pcRam000000000787ded0 != (code *)0x0) {
      (*pcRam000000000787ded0)(lVar2,0);
    }
  }
  if (*(long *)(param_1 + 0x10) != 0) {
    fn_439c54();
  }
  *(long *)(param_1 + 8) = 0;
  *(undefined8 *)(param_1 + 0x10) = 0;
  lVar2 = *(long *)(param_1 + 0x38);
  if (lVar2 != 0) {
    *(long *)(param_1 + 0x40) = lVar2;
    fn_6790c8();
  }
  *(long *)(param_1 + 0x38) = 0;
  *(undefined8 *)(param_1 + 0x40) = 0;
  lVar2 = *(long *)(param_1 + 0x50);
  *(undefined8 *)(param_1 + 0x48) = 0;
  if (lVar2 != 0) {
    *(long *)(param_1 + 0x58) = lVar2;
    fn_6790c8();
  }
  *(long *)(param_1 + 0x50) = 0;
  *(undefined8 *)(param_1 + 0x58) = 0;
  lVar2 = *(long *)(param_1 + 0x68);
  *(undefined8 *)(param_1 + 0x60) = 0;
  if (lVar2 != 0) {
    *(long *)(param_1 + 0x70) = lVar2;
    fn_6790c8();
  }
  *(undefined *)(param_1 + 0x90) = 0;
  *(undefined8 *)(param_1 + 0x70) = 0;
  *(long *)(param_1 + 0x68) = 0;
  *(undefined8 *)(param_1 + 0x80) = 0;
  *(undefined8 *)(param_1 + 0x78) = 0;
  *(undefined8 *)(param_1 + 0x85) = 0;
  return;
}

