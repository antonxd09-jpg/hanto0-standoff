
// ================================================================================
// Exclusive release:
// TG Bot: t.me/imguisource_bot
// TG 1: t.me/ImGui_Source_FIXNEY (ImGui Source)
// TG 2: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x319c00 */

undefined8 fn_319c00(void)

{
  int iVar1;
  ulong uVar2;
  long lVar3;
  long lVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  
  if (((bRam0000000007761618 & 1) == 0) && (iVar1 = fn_65eda8(0x7761618), iVar1 != 0)) {
    fn_31ca58();
    imp___cxa_atexit(&UNK_0041cf40,0x7760b48,&DAT_064e5160);
    fn_65eed8(0x7761618);
  }
  if (cRam0000000007760e58 != '\0') {
    if (((((((lRam0000000007760da8 == 0) || (uVar2 = fn_198128(), (uVar2 & 1) == 0)) ||
           (lRam0000000007760dd0 == 0)) ||
          ((uVar2 = fn_198128(), (uVar2 & 1) == 0 || (lRam0000000007760df8 == 0)))) ||
         ((uVar2 = fn_198128(), (uVar2 & 1) == 0 ||
          ((lRam0000000007760e20 == 0 || (uVar2 = fn_198128(), (uVar2 & 1) == 0)))))) ||
        (lRam0000000007760e48 == 0)) || (uVar2 = fn_198128(), (uVar2 & 1) == 0)) {
      cRam0000000007760e58 = '\0';
    }
    else if (cRam0000000007760e58 != '\0') {
      return 1;
    }
  }
  if (0 < iRam0000000007760e5c) {
    iRam0000000007760e5c = iRam0000000007760e5c + -1;
    return 0;
  }
  if ((lRam0000000007760da8 == 0) || (uVar2 = fn_198128(), (uVar2 & 1) == 0)) {
    lVar4 = 0x7760d90;
    if ((lRam0000000007760d98 == 0) || (uVar2 = fn_198128(), (uVar2 & 1) == 0)) {
      lVar3 = fn_374f80(uRam0000000007760d90);
      if (lRam0000000007760da0 != 0) {
        fn_439c54(lRam0000000007760da0);
      }
      lRam0000000007760da0 = 0;
      puVar6 = (undefined8 *)0x7760d98;
      lRam0000000007760d98 = lVar3;
      if (lVar3 != 0) {
        lRam0000000007760da0 = fn_439970(lVar3);
        goto LAB_00419d34;
      }
    }
    else {
LAB_00419d34:
      puVar6 = (undefined8 *)0x7760d98;
      if (lRam0000000007760d98 != 0) {
        uVar2 = fn_198128();
        if ((uVar2 & 1) == 0) {
          puVar6 = (undefined8 *)0x7760d98;
          lVar4 = lRam0000000007760da0;
          goto joined_r0x00419e80;
        }
        lVar4 = fn_19ca80(lRam0000000007760d98);
        uVar2 = fn_198128();
        if ((uVar2 & 1) == 0) {
          iRam0000000007760e5c = 0x3c;
          return 0;
        }
        fn_199704(lVar4,0x3d);
        if (lRam0000000007760db0 != 0) {
          fn_439c54();
        }
        lRam0000000007760db0 = 0;
        lRam0000000007760da8 = lVar4;
        if (lVar4 != 0) {
          lRam0000000007760db0 = fn_439970(lVar4);
        }
        uRam0000000007760e67 = 0;
        goto LAB_00419d9c;
      }
    }
  }
  else {
LAB_00419d9c:
    lVar3 = 0;
    while ((*(long *)(lVar3 + 0x7760dd0) != 0 && (uVar2 = fn_198128(), (uVar2 & 1) != 0))) {
LAB_00419dac:
      lVar3 = lVar3 + 0x28;
      if (lVar3 == 0xa0) {
        uRam0000000007760d88 = 0;
        cRam0000000007760e58 = 1;
        uRam0000000007761548 = 0;
        return 1;
      }
    }
    if ((*(long *)(lVar3 + 0x7760dc0) == 0) || (uVar2 = fn_198128(), (uVar2 & 1) == 0)) {
      lVar4 = fn_374f80(*(undefined8 *)(lVar3 + 0x7760db8));
      if (*(long *)(lVar3 + 0x7760dc8) != 0) {
        fn_439c54(*(long *)(lVar3 + 0x7760dc8));
      }
      *(undefined8 *)(lVar3 + 0x7760dc8) = 0;
      *(long *)(lVar3 + 0x7760dc0) = lVar4;
      if (lVar4 != 0) {
        uVar5 = fn_439970();
        *(undefined8 *)(lVar3 + 0x7760dc8) = uVar5;
        goto LAB_00419e14;
      }
    }
    else {
LAB_00419e14:
      if ((*(long *)(lVar3 + 0x7760dc0) != 0) && (uVar2 = fn_198128(), (uVar2 & 1) != 0)) {
        lVar4 = fn_19ca80(*(undefined8 *)(lVar3 + 0x7760dc0));
        uVar2 = fn_198128();
        if ((uVar2 & 1) == 0) {
          iRam0000000007760e5c = 0x3c;
          return 0;
        }
        fn_199704(lVar4,0x3d);
        if (*(long *)(lVar3 + 0x7760dd8) != 0) {
          fn_439c54();
        }
        *(undefined8 *)(lVar3 + 0x7760dd8) = 0;
        *(long *)(lVar3 + 0x7760dd0) = lVar4;
        if (lVar4 != 0) {
          uVar5 = fn_439970(lVar4);
          *(undefined8 *)(lVar3 + 0x7760dd8) = uVar5;
        }
        goto LAB_00419dac;
      }
    }
    lVar4 = lVar3 + 0x7760db8;
    puVar6 = (undefined8 *)(lVar3 + 0x7760dc0);
  }
  lVar4 = *(long *)(lVar4 + 0x10);
joined_r0x00419e80:
  if (lVar4 != 0) {
    fn_439c54();
  }
  *puVar6 = 0;
  puVar6[1] = 0;
  iRam0000000007760e5c = 0x3c;
  if ((cRam0000000007761616 == '\0') &&
     (cRam0000000007761616 = '\x01', (bRam00000000076ac3f8 & 1) == 0)) {
    uVar5 = fn_65eda8(0x76ac3f8);
    if ((int)uVar5 != 0) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
      uVar5 = 0;
    }
  }
  else {
    uVar5 = 0;
  }
  return uVar5;
}

