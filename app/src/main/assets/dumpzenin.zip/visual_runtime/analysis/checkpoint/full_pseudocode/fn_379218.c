
// ================================================================================
// Telegram Hub: @imguisource_bot / ImGui Source @ImGui_Source_FIXNEY / shit src 🧨 @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x379218 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fn_379218(long *param_1,byte param_2)

{
  byte *pbVar1;
  long **pplVar2;
  int *piVar3;
  byte bVar4;
  uint uVar5;
  long *plVar6;
  int *piVar7;
  int iVar8;
  bool bVar9;
  int iVar10;
  undefined4 uVar11;
  uint uVar12;
  int iVar13;
  ulong uVar14;
  undefined8 uVar15;
  ulong *puVar16;
  long lVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  long lVar21;
  uint uVar22;
  long *plVar23;
  code *pcVar24;
  long lVar25;
  long *plVar26;
  long *plVar27;
  ulong uVar28;
  byte *pbVar29;
  long *plVar30;
  ulong uVar31;
  ulong uVar32;
  long *plVar33;
  long *plVar34;
  char *pcVar35;
  long *plVar36;
  undefined4 *puVar37;
  undefined *puVar38;
  long *plVar39;
  undefined8 *puVar40;
  undefined8 *puVar41;
  long lVar42;
  long *plVar43;
  undefined *puVar44;
  undefined8 *puVar45;
  int iVar46;
  int iVar47;
  long lVar48;
  long *plVar49;
  long lVar50;
  float fVar51;
  float fVar52;
  float fVar53;
  long lVar54;
  float fVar55;
  float fVar56;
  float fVar57;
  long lVar58;
  float fVar59;
  float fVar60;
  undefined4 uVar61;
  float fVar62;
  float fVar63;
  float fVar64;
  float fVar65;
  float fVar66;
  float fVar67;
  float fVar68;
  undefined4 uVar69;
  float fVar70;
  float fVar71;
  float fVar72;
  float fVar73;
  float fVar74;
  float fVar75;
  float fVar76;
  float fVar77;
  float fVar78;
  float fVar79;
  float fVar80;
  float fVar81;
  float fVar82;
  float fVar83;
  float fVar84;
  undefined auVar85 [16];
  undefined auVar86 [12];
  undefined8 uStack_388;
  undefined8 uStack_380;
  undefined8 uStack_378;
  undefined4 uStack_370;
  undefined8 uStack_36c;
  undefined4 uStack_364;
  undefined8 uStack_360;
  ulong uStack_358;
  undefined8 uStack_350;
  undefined4 uStack_348;
  undefined8 uStack_344;
  undefined4 uStack_33c;
  undefined5 uStack_338;
  undefined3 uStack_333;
  undefined auStack_330 [8];
  undefined8 uStack_328;
  undefined8 uStack_320;
  undefined8 uStack_318;
  undefined4 uStack_310;
  undefined auStack_30c [4];
  undefined8 uStack_308;
  undefined8 uStack_300;
  undefined8 uStack_2f8;
  undefined4 uStack_2f0;
  undefined8 uStack_2e8;
  ulong uStack_2e0;
  undefined8 uStack_2d8;
  undefined4 uStack_2d0;
  undefined8 uStack_2cc;
  ulong uStack_2c4;
  undefined4 uStack_2bc;
  undefined8 uStack_2b8;
  undefined8 uStack_2b0;
  undefined4 uStack_2a8;
  undefined8 uStack_2a4;
  ulong uStack_29c;
  undefined4 uStack_294;
  undefined8 uStack_290;
  undefined8 uStack_288;
  undefined4 uStack_280;
  undefined8 uStack_27c;
  ulong uStack_274;
  undefined4 uStack_26c;
  undefined8 uStack_268;
  undefined8 uStack_260;
  undefined4 uStack_258;
  undefined8 uStack_254;
  ulong uStack_24c;
  undefined4 uStack_244;
  undefined8 uStack_240;
  undefined8 uStack_238;
  undefined4 uStack_230;
  undefined8 uStack_22c;
  ulong uStack_224;
  undefined4 uStack_21c;
  undefined8 uStack_218;
  undefined8 uStack_210;
  undefined4 uStack_208;
  undefined8 uStack_204;
  undefined8 uStack_1fc;
  undefined4 uStack_1f4;
  undefined8 uStack_1f0;
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  undefined8 uStack_1d8;
  undefined8 uStack_1d0;
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  float fStack_1b8;
  float fStack_1b4;
  float fStack_1b0;
  float fStack_1ac;
  float fStack_1a8;
  float fStack_1a4;
  undefined8 uStack_1a0;
  undefined8 uStack_198;
  undefined4 uStack_190;
  undefined8 uStack_18c;
  ulong uStack_184;
  undefined4 uStack_17c;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined4 uStack_168;
  undefined8 uStack_164;
  ulong uStack_15c;
  undefined4 uStack_154;
  undefined8 uStack_150;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined8 uStack_13c;
  ulong uStack_134;
  undefined4 uStack_12c;
  undefined8 uStack_128;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined8 uStack_114;
  ulong uStack_10c;
  undefined4 uStack_104;
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined8 uStack_ec;
  ulong uStack_e4;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  long lStack_b8;
  
  plVar30 = (long *)tpidr_el0;
  plVar49 = (long *)0x787e2f0;
  lStack_b8 = plVar30[5];
  plVar39 = plVar30;
  if ((bRam000000000787e2f0 & 1) == 0) goto LAB_0047c4d0;
LAB_0047926c:
  fn_36ece4();
  uVar14 = fn_37cc10();
  if ((uVar14 & 1) == 0) {
    lVar17 = fn_36ece4();
    if ((((((*(char *)(lVar17 + 0x1424) == '\0') && (*(char *)(lVar17 + 0x1448) == '\0')) &&
          (*(char *)(lVar17 + 0x146c) == '\0')) &&
         ((*(char *)(lVar17 + 0x1490) == '\0' && (*(char *)(lVar17 + 0x14b4) == '\0')))) &&
        (*(char *)(lVar17 + 0x14d8) == '\0')) &&
       (((*(char *)(lVar17 + 0x14fc) == '\0' && (*(char *)(lVar17 + 0x1520) == '\0')) &&
        ((*(char *)(lVar17 + 0x1544) == '\0' &&
         ((*(char *)(lVar17 + 0x1568) == '\0' && (*(char *)(lVar17 + 0x158c) == '\0')))))))) {
      if (cRam000000000787e2e8 == '\0') goto LAB_0047c440;
      if (plVar39[5] == lStack_b8) {
        if ((bRam000000000787e2f0 & 1) == 0) {
          iVar10 = fn_65eda8(0x787e2f0);
          if (iVar10 != 0) {
            fn_37d22c();
            imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
            fn_65eed8(0x787e2f0);
          }
        }
        fn_37d434(0x787dff8);
        fn_37d434(0x787e090);
        fn_37cf9c();
        cRam000000000787e2e8 = 0;
        return;
      }
      goto LAB_0047cc0c;
    }
  }
  uVar14 = fn_198128(param_1);
  if ((uVar14 & 1) != 0) {
    if ((param_2 & 1) == 0) {
      iVar10 = fn_18ea14(param_1);
      if (iVar10 != 0x100) goto LAB_0047c440;
    }
    if (bRam000000000787df80 != 0) goto LAB_004792ac;
    if (cRam000000000787df81 == '\0') {
      if ((bRam00000000076ac3f8 & 1) == 0) {
        iVar10 = fn_65eda8(0x76ac3f8);
        if (iVar10 != 0) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
      }
      lRam000000000787df78 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007b5d91,&UNK_007fed29);
      uVar15 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007b5d91,&UNK_007f33e3);
      uVar18 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007a13d2,&UNK_007d4569);
      uVar19 = fn_43d298(0x76a9768,&UNK_0079d413,&UNK_007a13d2,&UNK_007d450f);
      uVar20 = fn_18de44();
      uVar14 = fn_37d550(0x787deb8,lRam000000000787df78,&UNK_007df39c);
      if ((uVar14 & 1) == 0) {
LAB_00479908:
        bRam000000000787df80 = 0;
      }
      else {
        uVar14 = fn_37d550(0x787dec0,lRam000000000787df78,&UNK_007eadea);
        lVar17 = lRam000000000787df78;
        if ((uVar14 & 1) == 0) goto LAB_00479908;
        pcRam000000000787ded8 = (code *)0x0;
        if ((bRam00000000076ac3f8 & 1) == 0) {
          iVar10 = fn_65eda8(0x76ac3f8);
          if (iVar10 != 0) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
        }
        if ((bRam00000000076ac3f8 & 1) == 0) {
          iVar10 = fn_65eda8(0x76ac3f8);
          if (iVar10 != 0) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
        }
        if ((bRam00000000076ac3f8 & 1) == 0) {
          iVar10 = fn_65eda8(0x76ac3f8);
          if (iVar10 != 0) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
        }
        lVar21 = fn_43bc24(0x76a9768);
        uStack_1d0 = 0;
        pcVar24 = pcRam000000000787ded8;
        if (lVar17 != 0) {
          lVar48 = fn_43cd50(0x76a9768,lVar17,&uStack_1d0);
          pcVar24 = pcRam000000000787ded8;
          if (lVar48 != 0) {
            do {
              uVar28 = (ulong)bRam00000000076aa0a5;
              uVar14 = fn_139354(0x76a97a8,uVar28 + lVar48,8);
              if (((uVar14 & 1) != 0) &&
                 (plVar49 = *(long **)(uVar28 + lVar48), plVar49 != (long *)0x0)) {
                lVar25 = imp_strlen(plVar49);
                if ((lVar25 == 0xf) &&
                   (*plVar49 == 0x6564495f74696c42 &&
                    *(long *)((long)plVar49 + 7) == 0x7265696669746e65)) {
                  uVar28 = (ulong)bRam00000000076aa0a4;
                  uVar14 = fn_139354(0x76a97a8,uVar28 + lVar48,1);
                  if (((uVar14 & 1) != 0) && (*(char *)(uVar28 + lVar48) == '\b')) {
                    uVar28 = (ulong)bRam00000000076aa0a2;
                    uVar14 = fn_139354(0x76a97a8,uVar28 + lVar48,8);
                    if ((uVar14 & 1) == 0) {
                      pcVar24 = (code *)0x0;
                    }
                    else {
                      pcVar24 = *(code **)(uVar28 + lVar48);
                    }
                    if ((code *)(lVar21 + 0x72c69c8) == pcVar24) break;
                  }
                }
              }
              lVar48 = fn_43cd50(0x76a9768,lVar17,&uStack_1d0);
              pcVar24 = pcRam000000000787ded8;
            } while (lVar48 != 0);
          }
        }
        pcRam000000000787ded8 = pcVar24;
        plVar49 = (long *)0x787e2f0;
        if ((pcRam000000000787ded8 == (code *)0x0) && ((bRam00000000076ac3f8 & 1) == 0)) {
          iVar10 = fn_65eda8(0x76ac3f8);
          if (iVar10 != 0) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
        }
        if (pcRam000000000787ded8 == (code *)0x0) {
LAB_0047b1bc:
          bRam000000000787df80 = 0;
        }
        else {
          uVar14 = fn_37d678(lRam000000000787df78);
          if ((uVar14 & 1) == 0) goto LAB_0047b1bc;
          uVar14 = fn_37d9a8(lRam000000000787df78);
          if ((uVar14 & 1) == 0) goto LAB_0047b1bc;
          uVar14 = fn_37dcd8(lRam000000000787df78);
          if ((uVar14 & 1) == 0) goto LAB_0047b1bc;
          uVar14 = fn_37de00(lRam000000000787df78);
          if ((uVar14 & 1) == 0) goto LAB_0047b1bc;
          uVar14 = fn_37e130(lRam000000000787df78);
          if ((uVar14 & 1) == 0) goto LAB_0047b1bc;
          uVar14 = fn_37e258(lRam000000000787df78);
          if ((uVar14 & 1) == 0) goto LAB_0047b1bc;
          uVar14 = fn_37e588(lRam000000000787df78);
          if ((uVar14 & 1) == 0) goto LAB_0047b1bc;
          uVar14 = fn_37e8c8(lRam000000000787df78);
          if ((uVar14 & 1) == 0) {
LAB_0047c48c:
            bRam000000000787df80 = 0;
          }
          else {
            uVar14 = fn_37ebf0(0x787df20,uVar15,0x72c8988);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37ebf0(0x787df28,uVar15,0x72c0da0);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37ef08(0x787df30,uVar20,&UNK_007a9ac3,0x6bda16c);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37ef08(0x787df38,uVar20,&UNK_007d4574,0x6bd8284);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37f224(0x787df40,uVar20,&UNK_00785381);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37f224(0x787df48,uVar20,&UNK_007a9ad4);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37f34c(uVar20);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar15 = fn_18e208();
            uVar14 = fn_37f224(0x787df58,uVar15,&UNK_007c7c1a);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37f474(uVar18);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            uVar14 = fn_37f59c(0x787df68,uVar19,&UNK_007c87b7);
            if ((uVar14 & 1) == 0) goto LAB_0047c48c;
            bRam000000000787df80 = fn_37f59c(0x787df70,uVar19,&UNK_007fa1e3);
          }
        }
      }
      bRam000000000787df80 = bRam000000000787df80 & 1;
      if (lRam000000000787df78 == 0) {
        uRam000000000787ded0 = 0;
        pcRam000000000787dec8 = (code *)0x0;
      }
      else {
        pcRam000000000787dec8 = (code *)fn_43d5e4(0x76a9768,lRam000000000787df78,&UNK_007faeda,1);
        if (lRam000000000787df78 == 0) {
          uRam000000000787ded0 = 0;
        }
        else {
          uRam000000000787ded0 = fn_43d5e4(0x76a9768,lRam000000000787df78,&UNK_007e3ea5,0);
        }
      }
      if (bRam000000000787df80 != 0) {
        bRam000000000787df82 = (*pcRam000000000787df60)(2,0);
        bRam000000000787df82 = bRam000000000787df82 & 1;
LAB_004792ac:
        if (cRam000000000787dff0 == '\0') {
          if ((bRam000000000787e310 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e310);
            if (iVar10 != 0) {
              uRam000000000787e2f8 = 0;
              uRam000000000787e300 = 0;
              uRam000000000787e305 = 0;
              uRam000000000787e308 = 0;
              fn_126978(&UNK_02f4997f,0x787e2f8,0x15,0x333a3b2a69d21f77);
              fn_65eed8(0x787e310);
            }
          }
          uRam000000000787df88 = fn_19e714(0x787e2f8);
          if ((bRam000000000787e330 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e330);
            if (iVar10 != 0) {
              uRam000000000787e318 = 0;
              uRam000000000787e320 = 0;
              uRam000000000787e326 = 0;
              uRam000000000787e328 = 0;
              fn_126978(&UNK_02f49994,0x787e318,0x16,0x9fe62e497b2b6383);
              fn_65eed8(0x787e330);
            }
          }
          uRam000000000787df8c = fn_19e714(0x787e318);
          uRam000000000787df90 = fn_19e714(&UNK_007b40fb);
          uRam000000000787df94 = fn_19e714(&UNK_007e9fae);
          uRam000000000787df98 = fn_19e714(&UNK_007e26ea);
          if ((bRam000000000787e350 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e350);
            if (iVar10 != 0) {
              uRam000000000787e338 = 0;
              uRam000000000787e340 = 0;
              uRam000000000787e347 = 0;
              uRam000000000787e348 = 0;
              fn_126978(&UNK_02f499aa,0x787e338,0x17,0x98e0f5ff1e9e73fb);
              fn_65eed8(0x787e350);
            }
          }
          uRam000000000787df9c = fn_19e714(0x787e338);
          if ((bRam000000000787e368 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e368);
            if (iVar10 != 0) {
              auVar85 = fn_37f6c4(&UNK_02f499c1);
              auRam000000000787e358 = auVar85;
              fn_65eed8(0x787e368);
            }
          }
          uRam000000000787dfa0 = fn_19e714(0x787e358);
          if ((bRam000000000787e388 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e388);
            if (iVar10 != 0) {
              uRam000000000787e370 = 0;
              uRam000000000787e378 = 0;
              uRam000000000787e380 = 0;
              fn_126978(&UNK_02f499d1,0x787e370,0x11,0x7e390085f512e0ae);
              fn_65eed8(0x787e388);
            }
          }
          uRam000000000787dfa4 = fn_19e714(0x787e370);
          if ((bRam000000000787e3a0 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e3a0);
            if (iVar10 != 0) {
              auVar85 = fn_37f728(&UNK_02f499e2);
              auRam000000000787e390 = auVar85;
              fn_65eed8(0x787e3a0);
            }
          }
          uRam000000000787dfa8 = fn_19e714(0x787e390);
          if ((bRam000000000787e3b8 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e3b8);
            if (iVar10 != 0) {
              auVar85 = fn_37f78c(&UNK_02f499f2);
              uRam000000000787e3a8 = auVar85._0_8_;
              uRam000000000787e3b0 = auVar85._8_4_;
              uRam000000000787e3b6 = auVar85[14];
              uRam000000000787e3b4 = auVar85._12_2_;
              fn_65eed8(0x787e3b8);
            }
          }
          uRam000000000787dfac = fn_19e714(0x787e3a8);
          if ((bRam000000000787e3d0 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e3d0);
            if (iVar10 != 0) {
              auVar86 = fn_37f808(&UNK_02f49a01);
              auRam000000000787e3c0 = auVar86;
              fn_65eed8(0x787e3d0);
            }
          }
          uRam000000000787dfb0 = fn_19e714(0x787e3c0);
          if ((bRam000000000787e3e8 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e3e8);
            if (iVar10 != 0) {
              auVar86 = fn_37f874(&UNK_02f49a0d);
              auRam000000000787e3d8 = auVar86;
              fn_65eed8(0x787e3e8);
            }
          }
          uRam000000000787dfb4 = fn_19e714(0x787e3d8);
          uVar14 = 0;
          do {
            if ((bRam000000000787e408 & 1) == 0) {
              iVar10 = fn_65eda8(0x787e408);
              if (iVar10 != 0) {
                uRam000000000787e3f0 = 0;
                uRam000000000787e3f8 = 0;
                uRam000000000787e3fd = 0;
                uRam000000000787e400 = 0;
                fn_126978(&UNK_02f49a19,0x787e3f0,0x15,0x861be0f7124cc2e2);
                fn_65eed8(0x787e408);
              }
            }
            fn_63b560(&uStack_2e8,uVar14 & 0xffffffff);
            uVar15 = imp_strlen(0x787e3f0);
            puVar16 = (ulong *)fn_63a5e0(&uStack_2e8,0,0x787e3f0,uVar15);
            uStack_1c0 = puVar16[2];
            uStack_1c8 = puVar16[1];
            uStack_1d0 = *puVar16;
            puVar16[1] = 0;
            puVar16[2] = 0;
            *puVar16 = 0;
            uVar28 = (ulong)&uStack_1d0 | 1;
            if ((uStack_1d0 & 1) != 0) {
              uVar28 = uStack_1c0;
            }
            uVar11 = fn_19e714(uVar28);
            *(undefined4 *)(uVar14 * 4 + 0x787dfb8) = uVar11;
            if ((uStack_1d0 & 1) != 0) {
              fn_6790c8(uStack_1c0);
            }
            if ((uStack_2e8 & 1) != 0) {
              fn_6790c8(uStack_2d8);
            }
            if ((bRam000000000787e428 & 1) == 0) {
              iVar10 = fn_65eda8(0x787e428);
              if (iVar10 != 0) {
                uRam000000000787e410 = 0;
                uRam000000000787e418 = 0;
                uRam000000000787e41f = 0;
                fn_126978(&UNK_02f49a2e,0x787e410,0x13,0x3fbe89c94d934232);
                fn_65eed8(0x787e428);
              }
            }
            fn_63b560(&uStack_2e8,uVar14 & 0xffffffff);
            uVar15 = imp_strlen(0x787e410);
            puVar16 = (ulong *)fn_63a5e0(&uStack_2e8,0,0x787e410,uVar15);
            uStack_1c0 = puVar16[2];
            uStack_1c8 = puVar16[1];
            uStack_1d0 = *puVar16;
            puVar16[1] = 0;
            puVar16[2] = 0;
            *puVar16 = 0;
            uVar28 = (ulong)&uStack_1d0 | 1;
            if ((uStack_1d0 & 1) != 0) {
              uVar28 = uStack_1c0;
            }
            uVar11 = fn_19e714(uVar28);
            *(undefined4 *)(uVar14 * 4 + 0x787dfd4) = uVar11;
            if ((uStack_1d0 & 1) != 0) {
              fn_6790c8(uStack_1c0);
            }
            if ((uStack_2e8 & 1) != 0) {
              fn_6790c8(uStack_2d8);
            }
            uVar14 = uVar14 + 1;
          } while (uVar14 != 7);
          plVar49 = (long *)0x787e2f0;
          cRam000000000787dff0 = '\x01';
        }
        cRam000000000787e2e8 = '\x01';
        lVar17 = 0x140;
        if ((param_2 & 1) == 0) {
          lVar17 = 0x1d8;
        }
        plVar43 = param_1;
        if ((*(byte *)plVar49 & 1) == 0) goto LAB_0047c530;
LAB_004798b8:
        plRam000000000787e250 = plRam000000000787e248;
        fn_36ece4();
        uVar14 = fn_37cc10();
        iVar10 = iRam000000000787e148;
        if ((uVar14 & 1) != 0) {
          if ((*(byte *)plVar49 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e2f0);
            if (iVar10 != 0) {
              fn_37d22c();
              imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
              fn_65eed8(0x787e2f0);
            }
          }
          if (lRam000000000787e138 == 0) {
LAB_004798f0:
            iVar10 = iRam000000000787e148 + -1;
            if (0 < iRam000000000787e148) goto LAB_00479a50;
            if (lRam000000000787e140 != 0) {
              fn_439c54();
            }
            lRam000000000787e138 = 0;
            lRam000000000787e140 = 0;
            if (lRam000000000787e128 == 0) {
LAB_00479948:
              lVar21 = fn_374f80(uRam000000000787de28);
              if (lRam000000000787e130 != 0) {
                fn_439c54(lRam000000000787e130);
              }
              lRam000000000787e130 = 0;
              lRam000000000787e128 = lVar21;
              if (lVar21 != 0) {
                lRam000000000787e130 = fn_439970(lVar21);
                goto LAB_0047997c;
              }
            }
            else {
              uVar14 = fn_198128();
              if ((uVar14 & 1) == 0) goto LAB_00479948;
LAB_0047997c:
              if (lRam000000000787e128 != 0) {
                uVar14 = fn_198128();
                if ((uVar14 & 1) != 0) {
                  lVar21 = fn_19ca80(lRam000000000787e128);
                  goto LAB_004799a4;
                }
              }
              lVar21 = 0;
            }
LAB_004799a4:
            uVar14 = fn_198128(lVar21);
            if ((uVar14 & 1) == 0) {
              if (lRam000000000787e130 != 0) {
                fn_439c54();
              }
              lRam000000000787e128 = 0;
              lRam000000000787e130 = 0;
              iRam000000000787e148 = 0x3c;
              iVar10 = iRam000000000787e148;
              goto LAB_00479a50;
            }
            fn_199704(lVar21,0x3d);
            if (lRam000000000787e140 != 0) {
              fn_439c54();
            }
            lRam000000000787e140 = 0;
            lRam000000000787e138 = lVar21;
            if (lVar21 != 0) {
              lRam000000000787e140 = fn_439970(lVar21);
            }
            uRam000000000787e120 = 0;
            uRam000000000787e088 = 0;
          }
          else {
            uVar14 = fn_198128();
            if ((uVar14 & 1) == 0) goto LAB_004798f0;
          }
          fn_3708f0(0x787e248,(param_2 ^ 0xff) & 1);
          iVar10 = iRam000000000787e148;
          if ((~param_2 & 1) == 0) {
            fn_384008(0x787e248);
            fn_382290(0x787e248);
            iVar10 = iRam000000000787e148;
          }
        }
LAB_00479a50:
        iRam000000000787e148 = iVar10;
        lVar21 = fn_36ece4();
        plRam000000000787e180 = plRam000000000787e178;
        if (((((*(char *)(lVar21 + 0x1424) != '\0') || (*(char *)(lVar21 + 0x1448) != '\0')) ||
             (*(char *)(lVar21 + 0x146c) != '\0')) ||
            ((((*(char *)(lVar21 + 0x1490) != '\0' || (*(char *)(lVar21 + 0x14b4) != '\0')) ||
              ((*(char *)(lVar21 + 0x14d8) != '\0' ||
               ((*(char *)(lVar21 + 0x14fc) != '\0' || (*(char *)(lVar21 + 0x1520) != '\0')))))) ||
             (*(char *)(lVar21 + 0x1544) != '\0')))) ||
           ((*(char *)(lVar21 + 0x1568) != '\0' ||
            (iVar10 = iRam000000000787e170, *(char *)(lVar21 + 0x158c) != '\0')))) {
          if ((*(byte *)plVar49 & 1) == 0) {
            iVar10 = fn_65eda8(0x787e2f0);
            if (iVar10 != 0) {
              fn_37d22c();
              imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
              fn_65eed8(0x787e2f0);
            }
          }
          if (lRam000000000787e160 == 0) {
LAB_00479af4:
            iVar10 = iRam000000000787e170 + -1;
            if (0 < iRam000000000787e170) goto LAB_00479c58;
            if (lRam000000000787e168 != 0) {
              fn_439c54();
            }
            lRam000000000787e160 = 0;
            lRam000000000787e168 = 0;
            if (lRam000000000787e150 == 0) {
LAB_00479b40:
              lVar48 = fn_374f80(uRam000000000787de30);
              if (lRam000000000787e158 != 0) {
                fn_439c54(lRam000000000787e158);
              }
              lRam000000000787e158 = 0;
              lRam000000000787e150 = lVar48;
              if (lVar48 != 0) {
                lRam000000000787e158 = fn_439970(lVar48);
                goto LAB_00479b74;
              }
            }
            else {
              uVar14 = fn_198128();
              if ((uVar14 & 1) == 0) goto LAB_00479b40;
LAB_00479b74:
              if (lRam000000000787e150 != 0) {
                uVar14 = fn_198128();
                if ((uVar14 & 1) != 0) {
                  lVar48 = fn_19ca80(lRam000000000787e150);
                  goto LAB_00479b9c;
                }
              }
              lVar48 = 0;
            }
LAB_00479b9c:
            uVar14 = fn_198128(lVar48);
            if ((uVar14 & 1) == 0) {
              if (lRam000000000787e158 != 0) {
                fn_439c54();
              }
              lRam000000000787e150 = 0;
              lRam000000000787e158 = 0;
              iRam000000000787e170 = 0x3c;
              iVar10 = iRam000000000787e170;
              goto LAB_00479c58;
            }
            fn_199704(lVar48,0x3d);
            if (lRam000000000787e168 != 0) {
              fn_439c54();
            }
            lRam000000000787e168 = 0;
            lRam000000000787e160 = lVar48;
            if (lVar48 != 0) {
              lRam000000000787e168 = fn_439970(lVar48);
            }
            uRam000000000787e120 = 0;
            uRam000000000787e088 = 0;
          }
          else {
            uVar14 = fn_198128();
            if ((uVar14 & 1) == 0) goto LAB_00479af4;
          }
          fn_371098(0x787e178,(param_2 ^ 0xff) & 1);
          iVar10 = iRam000000000787e170;
          if ((~param_2 & 1) == 0) {
            fn_384354(0x787e178,(char *)(lVar21 + 0x1520));
            fn_382654(0x787e178,(char *)(lVar21 + 0x14fc));
            fn_34ad8c(0x787e178);
            iVar10 = iRam000000000787e170;
          }
        }
LAB_00479c58:
        iRam000000000787e170 = iVar10;
        plRam000000000787e280 = plRam000000000787e278;
        plRam000000000787e2b0 = plRam000000000787e2a8;
        uVar12 = fn_18ea14(plVar43);
        plVar36 = plRam000000000787e250;
        auStack_330._0_5_ = 0;
        uStack_338 = 0;
        uStack_333 = 0;
        for (param_1 = plRam000000000787e248; param_1 != plVar36; param_1 = param_1 + 4) {
          uVar14 = (ulong)*(uint *)((long)param_1 + 0x14);
          if (*(uint *)((long)param_1 + 0x14) < 0xd) {
            if ((param_2 & 1) != 0) {
              uVar22 = 1 << (ulong)(*(uint *)((long)param_1 + 0x1c) & 0x1f);
              if (0x1f < *(uint *)((long)param_1 + 0x1c)) {
                uVar22 = 0xffffffff;
              }
              if ((uVar22 & uVar12) == 0) goto LAB_00479cb4;
            }
            if (*(char *)((long)&uStack_338 + uVar14) == '\0') {
              if ((*(byte *)plVar49 & 1) == 0) {
                iVar10 = fn_65eda8(plVar49);
                if (iVar10 != 0) {
                  fn_37d22c();
                  imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
                  fn_65eed8(plVar49);
                }
              }
              lVar48 = fn_375098(uVar14);
              if (lVar48 == 0) {
                *(undefined *)((long)&uStack_338 + uVar14) = 0xff;
              }
              else {
                if (*(long *)(uVar14 * 8 + 0x787e1e0) != lVar48) {
                  uVar15 = *(undefined8 *)(&UNK_06532578 + uVar14 * 8);
                  *(long *)(uVar14 * 8 + 0x787e1e0) = lVar48;
                  iVar10 = imp_strlen(uVar15);
                  iVar13 = (*pcRam000000000787df58)(lVar48,0);
                  uVar22 = 0xffffffff;
                  if (iVar13 == iVar10) {
                    uVar22 = 1;
                  }
                  *(uint *)(uVar14 * 4 + 0x787e1a8) = uVar22;
                  plVar49 = (long *)0x787e2f0;
                  if ((iVar13 != iVar10) && ((bRam00000000076ac3f8 & 1) == 0)) {
                    iVar10 = fn_65eda8(0x76ac3f8);
                    plVar49 = (long *)0x787e2f0;
                    if (iVar10 != 0) {
                      fn_1269d0(0x76a9760);
                      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                      fn_65eed8(0x76ac3f8);
                    }
                  }
                }
                uVar22 = 0xffffffff;
                if (0 < *(int *)(uVar14 * 4 + 0x787e1a8)) {
                  uVar22 = 1;
                }
                *(char *)((long)&uStack_338 + uVar14) = (char)uVar22;
                if ((uVar22 >> 7 & 1) == 0) goto LAB_00479db8;
              }
            }
            else if (-1 < *(char *)((long)&uStack_338 + uVar14)) {
LAB_00479db8:
              plVar26 = plRam000000000787e280;
              plVar27 = plRam000000000787e278;
              plVar30 = (long *)((long)plRam000000000787e280 - (long)plRam000000000787e278);
              uVar14 = (long)plVar30 >> 5;
              if (0x2f < uVar14) break;
              if (plRam000000000787e280 < plRam000000000787e288) {
                lVar42 = *param_1;
                lVar25 = param_1[3];
                lVar48 = param_1[2];
                plRam000000000787e280[1] = param_1[1];
                *plRam000000000787e280 = lVar42;
                plRam000000000787e280[3] = lVar25;
                plRam000000000787e280[2] = lVar48;
                plRam000000000787e280 = plRam000000000787e280 + 4;
              }
              else {
                uVar28 = (long)plRam000000000787e288 - (long)plRam000000000787e278 >> 4;
                if (uVar28 <= uVar14 + 1) {
                  uVar28 = uVar14 + 1;
                }
                if (0x7fffffffffffffdf <
                    (ulong)((long)plRam000000000787e288 - (long)plRam000000000787e278)) {
                  uVar28 = 0x7ffffffffffffff;
                }
                if (uVar28 >> 0x3b != 0) goto LAB_0047c4b8;
                lVar48 = fn_679020(uVar28 * 0x20);
                lVar25 = *param_1;
                lVar50 = param_1[3];
                lVar42 = param_1[2];
                plVar30 = (long *)(lVar48 + (long)plVar30);
                plVar30[1] = param_1[1];
                *plVar30 = lVar25;
                plVar30[3] = lVar50;
                plVar30[2] = lVar42;
                plRam000000000787e278 = plVar30;
                plVar49 = plVar26;
                while (plVar26 != plVar27) {
                  lVar50 = plVar26[-4];
                  lVar42 = plVar26[-1];
                  lVar25 = plVar26[-2];
                  plRam000000000787e278[-3] = plVar26[-3];
                  plRam000000000787e278[-4] = lVar50;
                  plRam000000000787e278[-1] = lVar42;
                  plRam000000000787e278[-2] = lVar25;
                  plRam000000000787e278 = plRam000000000787e278 + -4;
                  plVar26 = plVar26 + -4;
                  plVar49 = plVar27;
                }
                plRam000000000787e288 = (long *)(lVar48 + uVar28 * 0x20);
                if (plVar49 != (long *)0x0) {
                  plRam000000000787e280 = plVar30 + 4;
                  fn_6790c8(plVar49);
                }
                plVar49 = (long *)0x787e2f0;
                plRam000000000787e280 = plVar30 + 4;
              }
            }
          }
LAB_00479cb4:
        }
        plVar30 = plRam000000000787e180;
        if (plRam000000000787e178 != plRam000000000787e180) {
          param_1 = (long *)0x787e000;
          plVar36 = plRam000000000787e178;
          do {
            plVar26 = plRam000000000787e2b0;
            plVar27 = plRam000000000787e2a8;
            if ((param_2 & 1) == 0) {
LAB_00479f58:
              if ((0.0 < *(float *)(plVar36 + 3)) || (0.0 < *(float *)(plVar36 + 5))) {
                lVar48 = (long)plRam000000000787e2b0 - (long)plRam000000000787e2a8;
                uVar14 = (lVar48 >> 4) * -0x5555555555555555;
                if (0x3f < uVar14) break;
                if (plRam000000000787e2b0 < plRam000000000787e2b8) {
                  lVar42 = plVar36[2];
                  lVar25 = plVar36[5];
                  lVar48 = plVar36[4];
                  lVar54 = plVar36[1];
                  lVar50 = *plVar36;
                  plRam000000000787e2b0[3] = plVar36[3];
                  plRam000000000787e2b0[2] = lVar42;
                  plRam000000000787e2b0[5] = lVar25;
                  plRam000000000787e2b0[4] = lVar48;
                  plRam000000000787e2b0[1] = lVar54;
                  *plRam000000000787e2b0 = lVar50;
                  plRam000000000787e2b0 = plRam000000000787e2b0 + 6;
                }
                else {
                  lVar25 = (long)plRam000000000787e2b8 - (long)plRam000000000787e2a8 >> 4;
                  uVar28 = lVar25 * 0x5555555555555556;
                  if (uVar28 < uVar14 + 1 || uVar28 - (uVar14 + 1) == 0) {
                    uVar28 = uVar14 + 1;
                  }
                  if (0x2aaaaaaaaaaaaa9 < (ulong)(lVar25 * -0x5555555555555555)) {
                    uVar28 = 0x555555555555555;
                  }
                  plVar49 = (long *)0x787e000;
                  if (0x555555555555555 < uVar28) goto LAB_0047c4b8;
                  lVar25 = fn_679020(uVar28 * 0x30);
                  lVar42 = *plVar36;
                  lVar54 = plVar36[3];
                  lVar50 = plVar36[2];
                  plVar49 = (long *)(lVar25 + lVar48);
                  lVar58 = plVar36[5];
                  lVar48 = plVar36[4];
                  plVar49[1] = plVar36[1];
                  *plVar49 = lVar42;
                  plVar49[3] = lVar54;
                  plVar49[2] = lVar50;
                  plVar49[5] = lVar58;
                  plVar49[4] = lVar48;
                  plRam000000000787e2a8 = plVar49;
                  plVar23 = plVar26;
                  for (; plVar26 != plVar27; plVar26 = plVar26 + -6) {
                    lVar54 = plVar26[-3];
                    lVar50 = plVar26[-4];
                    lVar42 = plVar26[-1];
                    lVar48 = plVar26[-2];
                    lVar58 = plVar26[-6];
                    plRam000000000787e2a8[-5] = plVar26[-5];
                    plRam000000000787e2a8[-6] = lVar58;
                    plRam000000000787e2a8[-3] = lVar54;
                    plRam000000000787e2a8[-4] = lVar50;
                    plRam000000000787e2a8[-1] = lVar42;
                    plRam000000000787e2a8[-2] = lVar48;
                    plRam000000000787e2a8 = plRam000000000787e2a8 + -6;
                    plVar23 = plVar27;
                  }
                  plVar49 = plVar49 + 6;
                  plRam000000000787e2b8 = (long *)(lVar25 + uVar28 * 0x30);
                  plRam000000000787e2b0 = plVar49;
                  if (plVar23 != (long *)0x0) {
                    fn_6790c8(plVar23);
                    plRam000000000787e2b0 = plVar49;
                  }
                }
              }
            }
            else {
              uVar22 = 1 << (ulong)(*(uint *)((long)plVar36 + 0x2c) & 0x1f);
              if (0x1f < *(uint *)((long)plVar36 + 0x2c)) {
                uVar22 = 0xffffffff;
              }
              if ((uVar22 & uVar12) != 0) goto LAB_00479f58;
            }
            plVar36 = plVar36 + 6;
          } while (plVar36 != plVar30);
        }
        plVar36 = plRam000000000787e280;
        fVar51 = *(float *)(lVar21 + 0x15b0);
        fVar52 = 100.0;
        if (fVar51 <= 100.0) {
          fVar52 = fVar51;
        }
        fVar55 = 0.0;
        if (0.0 <= fVar51) {
          fVar55 = fVar52 * 10.0;
        }
        iRam000000000787e2c0 = (int)(long)fVar55;
        plRam000000000787e198 = plRam000000000787e190;
        if (plRam000000000787e278 != plRam000000000787e280) {
          param_1 = (long *)0x787e000;
          plVar30 = plRam000000000787e278;
          plVar26 = plRam000000000787e190;
          do {
            plVar49 = plRam000000000787e190;
            if (plVar26 < plRam000000000787e1a0) {
              plVar27 = plVar26 + 1;
              *plVar26 = *plVar30;
            }
            else {
              lVar21 = (long)plVar26 - (long)plRam000000000787e190;
              uVar14 = (lVar21 >> 3) + 1;
              plRam000000000787e198 = plVar26;
              if (uVar14 >> 0x3d != 0) goto LAB_0047c498;
              uVar28 = (long)plRam000000000787e1a0 - (long)plRam000000000787e190 >> 2;
              if (uVar28 <= uVar14) {
                uVar28 = uVar14;
              }
              if (0x7ffffffffffffff7 <
                  (ulong)((long)plRam000000000787e1a0 - (long)plRam000000000787e190)) {
                uVar28 = 0x1fffffffffffffff;
              }
              if (uVar28 == 0) {
                lVar48 = 0;
              }
              else {
                if (uVar28 >> 0x3d != 0) goto LAB_0047c4b8;
                lVar48 = fn_679020(uVar28 << 3);
              }
              plVar23 = (long *)(lVar48 + (lVar21 >> 3) * 8);
              plVar27 = plVar23 + 1;
              *plVar23 = *plVar30;
              plVar33 = plVar26;
              if ((long)plVar26 - (long)plVar49 != 0) {
                uVar14 = ((long)plVar26 - (long)plVar49) - 8;
                if (0x147 < uVar14) {
                  plVar33 = plVar26 + -1;
                  uVar31 = (lVar48 + lVar21) - 8;
                  uVar32 = (long)plVar33 - (long)plVar49 & 0xfffffffffffffff8;
                  if (((uVar31 - uVar32 <= uVar31) && ((long *)((long)plVar33 - uVar32) <= plVar33))
                     && ((byte *)0x1f < (byte *)((long)plVar26 + (-lVar21 - lVar48)))) {
                    uVar14 = (uVar14 >> 3) + 1;
                    uVar31 = uVar14 & 0x3ffffffffffffffc;
                    plVar23 = plVar23 + -uVar31;
                    plVar33 = (long *)(lVar48 + lVar21 + -0x10);
                    plVar26 = plVar26 + -2;
                    uVar32 = uVar31;
                    do {
                      plVar34 = plVar26 + -1;
                      lVar42 = plVar26[-2];
                      lVar25 = plVar26[1];
                      lVar21 = *plVar26;
                      uVar32 = uVar32 - 4;
                      plVar26 = plVar26 + -4;
                      plVar33[-1] = *plVar34;
                      plVar33[-2] = lVar42;
                      plVar33[1] = lVar25;
                      *plVar33 = lVar21;
                      plVar33 = plVar33 + -4;
                    } while (uVar32 != 0);
                    plVar26 = plVar26 + -uVar31;
                    plVar33 = plRam000000000787e190;
                    if (uVar14 == uVar31) goto LAB_0047a178;
                  }
                }
                do {
                  plVar26 = plVar26 + -1;
                  plVar23 = plVar23 + -1;
                  *plVar23 = *plVar26;
                  plVar33 = plRam000000000787e190;
                } while (plVar26 != plVar49);
              }
LAB_0047a178:
              plRam000000000787e1a0 = (long *)(lVar48 + uVar28 * 8);
              plRam000000000787e190 = plVar23;
              if (plVar33 != (long *)0x0) {
                plRam000000000787e198 = plVar27;
                fn_6790c8(plVar33);
              }
            }
            plVar30 = plVar30 + 4;
            plRam000000000787e198 = plVar27;
            plVar26 = plVar27;
          } while (plVar30 != plVar36);
        }
        plVar36 = plRam000000000787e2b0;
        if (plRam000000000787e2a8 != plRam000000000787e2b0) {
          param_1 = (long *)0x787e000;
          plVar30 = plRam000000000787e2a8;
          do {
            plVar27 = plRam000000000787e198;
            plVar26 = plRam000000000787e190;
            if (plRam000000000787e198 < plRam000000000787e1a0) {
              plVar49 = plRam000000000787e198 + 1;
              *plRam000000000787e198 = *plVar30;
            }
            else {
              lVar21 = (long)plRam000000000787e198 - (long)plRam000000000787e190;
              plVar49 = (long *)(lVar21 >> 3);
              pbVar1 = (byte *)((long)plVar49 + 1);
              if ((ulong)pbVar1 >> 0x3d != 0) goto LAB_0047c498;
              pbVar29 = (byte *)((long)plRam000000000787e1a0 - (long)plRam000000000787e190 >> 2);
              if (pbVar29 <= pbVar1) {
                pbVar29 = pbVar1;
              }
              if (0x7ffffffffffffff7 <
                  (ulong)((long)plRam000000000787e1a0 - (long)plRam000000000787e190)) {
                pbVar29 = (byte *)0x1fffffffffffffff;
              }
              if (pbVar29 == (byte *)0x0) {
                lVar48 = 0;
              }
              else {
                if ((ulong)pbVar29 >> 0x3d != 0) goto LAB_0047c4b8;
                lVar48 = fn_679020((long)pbVar29 << 3);
              }
              plVar23 = (long *)(lVar48 + (long)plVar49 * 8);
              plVar49 = plVar23 + 1;
              *plVar23 = *plVar30;
              plVar33 = plVar27;
              if ((long)plVar27 - (long)plVar26 != 0) {
                uVar14 = ((long)plVar27 - (long)plVar26) - 8;
                if (0x147 < uVar14) {
                  plVar33 = plVar27 + -1;
                  uVar32 = (lVar48 + lVar21) - 8;
                  uVar28 = (long)plVar33 - (long)plVar26 & 0xfffffffffffffff8;
                  if (((uVar32 - uVar28 <= uVar32) && ((long *)((long)plVar33 - uVar28) <= plVar33))
                     && ((byte *)0x1f < (byte *)((long)plVar27 + (-lVar21 - lVar48)))) {
                    uVar14 = (uVar14 >> 3) + 1;
                    uVar32 = uVar14 & 0x3ffffffffffffffc;
                    plVar23 = plVar23 + -uVar32;
                    plVar33 = (long *)(lVar48 + lVar21 + -0x10);
                    plVar34 = plVar27 + -2;
                    uVar28 = uVar32;
                    do {
                      plVar6 = plVar34 + -1;
                      lVar42 = plVar34[-2];
                      lVar25 = plVar34[1];
                      lVar21 = *plVar34;
                      uVar28 = uVar28 - 4;
                      plVar34 = plVar34 + -4;
                      plVar33[-1] = *plVar6;
                      plVar33[-2] = lVar42;
                      plVar33[1] = lVar25;
                      *plVar33 = lVar21;
                      plVar33 = plVar33 + -4;
                    } while (uVar28 != 0);
                    plVar27 = plVar27 + -uVar32;
                    plVar33 = plRam000000000787e190;
                    if (uVar14 == uVar32) goto LAB_0047a31c;
                  }
                }
                do {
                  plVar27 = plVar27 + -1;
                  plVar23 = plVar23 + -1;
                  *plVar23 = *plVar27;
                  plVar33 = plRam000000000787e190;
                } while (plVar27 != plVar26);
              }
LAB_0047a31c:
              plRam000000000787e1a0 = (long *)(lVar48 + (long)pbVar29 * 8);
              plRam000000000787e190 = plVar23;
              if (plVar33 != (long *)0x0) {
                plRam000000000787e198 = plVar49;
                fn_6790c8(plVar33);
              }
            }
            plVar30 = plVar30 + 6;
            plRam000000000787e198 = plVar49;
          } while (plVar30 != plVar36);
        }
        if (plRam000000000787e190 == plRam000000000787e198) goto LAB_0047a6b0;
        if ((param_2 & 1) == 0) {
          plRam000000000787e298 = plRam000000000787e290;
          plRam000000000787e268 = plRam000000000787e260;
          fn_370e50(0x787e260);
          plVar30 = plRam000000000787e268;
          if (plRam000000000787e260 != plRam000000000787e268) {
            param_1 = (long *)0x787e298;
            plVar49 = (long *)0x787e290;
            plVar36 = plRam000000000787e260;
            do {
              plVar26 = plRam000000000787e298;
              plVar27 = plRam000000000787e290;
              if (plRam000000000787e278 != plRam000000000787e280) {
                plVar23 = plRam000000000787e278;
                do {
                  if (*plVar23 == *plVar36) goto LAB_0047a748;
                  plVar23 = plVar23 + 4;
                } while (plVar23 != plRam000000000787e280);
              }
              if (plRam000000000787e298 < plRam000000000787e2a0) {
                lVar21 = *plVar36;
                plRam000000000787e298[1] = plVar36[1];
                *plRam000000000787e298 = lVar21;
                plRam000000000787e298 = plRam000000000787e298 + 2;
              }
              else {
                lVar21 = (long)plRam000000000787e298 - (long)plRam000000000787e290 >> 4;
                uVar14 = lVar21 + 1;
                if (uVar14 >> 0x3c != 0) goto LAB_0047c510;
                uVar28 = (long)plRam000000000787e2a0 - (long)plRam000000000787e290 >> 3;
                if (uVar28 <= uVar14) {
                  uVar28 = uVar14;
                }
                if (0x7fffffffffffffef <
                    (ulong)((long)plRam000000000787e2a0 - (long)plRam000000000787e290)) {
                  uVar28 = 0xfffffffffffffff;
                }
                if (uVar28 == 0) {
                  lVar48 = 0;
                }
                else {
                  if (uVar28 >> 0x3c != 0) goto LAB_0047c4b8;
                  lVar48 = fn_679020(uVar28 << 4);
                }
                plVar23 = (long *)(lVar48 + lVar21 * 0x10);
                lVar21 = *plVar36;
                plVar23[1] = plVar36[1];
                *plVar23 = lVar21;
                plVar33 = plVar23;
                plVar34 = plVar26;
                while (plVar26 != plVar27) {
                  uVar11 = *(undefined4 *)(plVar26 + -1);
                  plVar33[-2] = plVar26[-2];
                  *(undefined4 *)(plVar33 + -1) = uVar11;
                  plVar33 = plVar33 + -2;
                  plVar26 = plVar26 + -2;
                  plVar34 = plRam000000000787e290;
                }
                plRam000000000787e2a0 = (long *)(lVar48 + uVar28 * 0x10);
                plVar23 = plVar23 + 2;
                plRam000000000787e290 = plVar33;
                plRam000000000787e298 = plVar23;
                if (plVar34 != (long *)0x0) {
                  fn_6790c8(plVar34);
                  plRam000000000787e298 = plVar23;
                }
              }
LAB_0047a748:
              plVar36 = plVar36 + 2;
              if (plVar36 == plVar30) break;
            } while( true );
          }
          goto LAB_0047a848;
        }
        uStack_1c8 = 0;
        uStack_1d0 = 0;
        fStack_1b8 = 0.0;
        fStack_1b4 = 0.0;
        uStack_1c0 = 0;
        fStack_1a8 = 0.0;
        fStack_1a4 = 0.0;
        fStack_1b0 = 0.0;
        fStack_1ac = 0.0;
        uStack_198 = 0;
        uStack_1a0 = 0;
        uVar14 = fn_190198(plVar43,&uStack_1d0);
        plVar49 = plRam000000000787e198;
        if ((uVar14 & 1) == 0) goto LAB_0047a838;
        if (plRam000000000787e190 == plRam000000000787e198) goto LAB_0047a6b0;
        lVar21 = 0;
        fVar68 = (float)uStack_1d0 + uStack_1c8._4_4_;
        fVar71 = uStack_1c8._4_4_ - (float)uStack_1d0;
        fVar74 = uStack_1d0._4_4_ + uStack_1c8._4_4_;
        fVar75 = uStack_1c8._4_4_ - uStack_1d0._4_4_;
        fVar76 = (float)uStack_1c8 + uStack_1c8._4_4_;
        fVar78 = (float)uStack_1c0 + fStack_1b4;
        fVar79 = fStack_1b4 - (float)uStack_1c0;
        fVar82 = fStack_1b0 + fStack_1a4;
        fVar83 = fStack_1a4 - fStack_1b0;
        fVar52 = fStack_1a8 + fStack_1a4;
        fVar84 = fStack_1ac + fStack_1a4;
        fVar59 = fStack_1a4 - fStack_1ac;
        fVar80 = uStack_1c0._4_4_ + fStack_1b4;
        fVar66 = (float)uStack_1a0 + uStack_198._4_4_;
        fVar51 = uStack_198._4_4_ - (float)uStack_1a0;
        fVar81 = fStack_1b4 - uStack_1c0._4_4_;
        fVar65 = fStack_1b8 + fStack_1b4;
        fVar67 = uStack_1a0._4_4_ + uStack_198._4_4_;
        fVar55 = uStack_198._4_4_ - uStack_1a0._4_4_;
        fVar56 = (float)uStack_198 + uStack_198._4_4_;
        plVar30 = plRam000000000787e190;
        goto LAB_0047a55c;
      }
      cRam000000000787df81 = '\x01';
    }
  }
  goto LAB_0047c440;
LAB_0047c498:
  param_1 = (long *)0x787e000;
  if (plVar39[5] != lStack_b8) goto LAB_0047cc0c;
  fn_19e854(0x787e190);
LAB_0047c4b8:
  if (plVar39[5] != lStack_b8) goto LAB_0047cc0c;
  fn_13edb4();
LAB_0047c4d0:
  iVar10 = fn_65eda8(0x787e2f0);
  plVar39 = plVar30;
  if (iVar10 != 0) {
    fn_37d22c();
    imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
    fn_65eed8(0x787e2f0);
  }
  goto LAB_0047926c;
LAB_0047c510:
  if (plVar39[5] != lStack_b8) goto LAB_0047cc0c;
  fn_377560(0x787e290);
LAB_0047c530:
  iVar10 = fn_65eda8(0x787e2f0);
  plVar43 = param_1;
  if (iVar10 != 0) {
    fn_37d22c();
    imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
    fn_65eed8(0x787e2f0);
  }
  goto LAB_004798b8;
  while (plVar30 = plVar30 + 1, plVar30 != plVar49) {
LAB_0047a55c:
    lVar48 = *plVar30;
    if (lVar48 != lVar21) {
      uStack_2e0 = uStack_2e0 & 0xffffffff00000000;
      uStack_2e8 = 0;
      uStack_358 = uStack_358 & 0xffffffff00000000;
      uStack_360 = 0;
      uVar14 = fn_19bb30(lVar48,&uStack_2e8,&uStack_360);
      if ((uVar14 & 1) == 0) goto LAB_0047a838;
      uVar11 = NEON_fmadd(fVar68,(undefined4)uStack_2e8,fVar78 * uStack_2e8._4_4_);
      uVar61 = NEON_fmadd(fVar71,(undefined4)uStack_2e8,fVar79 * uStack_2e8._4_4_);
      uVar69 = NEON_fmadd(fVar74,(undefined4)uStack_2e8,fVar80 * uStack_2e8._4_4_);
      fVar63 = (float)NEON_fmadd(ABS(fVar68),(undefined4)uStack_360,ABS(fVar78) * uStack_360._4_4_);
      fVar72 = (float)NEON_fmadd(ABS(fVar71),(undefined4)uStack_360,ABS(fVar79) * uStack_360._4_4_);
      fVar53 = (float)NEON_fmadd(fVar82,(undefined4)uStack_2e0,uVar11);
      fVar62 = (float)NEON_fmadd(fVar83,(undefined4)uStack_2e0,uVar61);
      uVar61 = NEON_fmadd(fVar75,(undefined4)uStack_2e8,fVar81 * uStack_2e8._4_4_);
      fVar77 = (float)NEON_fmadd(ABS(fVar74),(undefined4)uStack_360,ABS(fVar80) * uStack_360._4_4_);
      uVar11 = NEON_fmadd(fVar76,(undefined4)uStack_2e8,fVar65 * uStack_2e8._4_4_);
      fVar64 = (float)NEON_fnmadd(ABS(fVar82),(undefined4)uStack_358,-fVar63);
      fVar70 = (float)NEON_fmadd(fVar84,(undefined4)uStack_2e0,uVar69);
      fVar63 = (float)NEON_fmadd(fVar52,(undefined4)uStack_2e0,uVar11);
      fVar73 = (float)NEON_fnmadd(ABS(fVar83),(undefined4)uStack_358,-fVar72);
      fVar60 = (float)NEON_fmadd(fVar59,(undefined4)uStack_2e0,uVar61);
      fVar57 = (float)NEON_fmadd(ABS(fVar75),(undefined4)uStack_360,ABS(fVar81) * uStack_360._4_4_);
      fVar77 = (float)NEON_fnmadd(ABS(fVar84),(undefined4)uStack_358,-fVar77);
      fVar72 = (float)NEON_fmadd(ABS(fVar76),(undefined4)uStack_360,ABS(fVar65) * uStack_360._4_4_);
      fVar72 = (float)NEON_fnmadd(ABS(fVar52),(undefined4)uStack_358,-fVar72);
      fVar57 = (float)NEON_fnmadd(ABS(fVar59),(undefined4)uStack_358,-fVar57);
      lVar21 = lVar48;
      if ((((fVar64 <= fVar66 + fVar53 && fVar73 <= fVar51 + fVar62) && fVar77 <= fVar67 + fVar70)
          && fVar57 <= fVar55 + fVar60) && fVar72 <= fVar56 + fVar63) goto LAB_0047a838;
    }
  }
LAB_0047a6b0:
  fn_37cee0(lVar17 + 0x787deb8);
  if (((param_2 & 1) != 0) &&
     (iVar10 = iRam000000000787e2e4 + 1, bVar9 = 0x77 < iRam000000000787e2e4,
     iRam000000000787e2e4 = iVar10, bVar9)) {
    uVar14 = fn_432fec();
    if ((uVar14 & 1) == 0) {
      fn_37cf9c();
    }
  }
  goto LAB_0047c440;
code_r0x0047b6a8:
  plVar49 = plVar49 + 4;
  if (plVar49 == plVar30) goto LAB_0047b6b4;
  goto LAB_0047b658;
LAB_0047b6e4:
  plVar49 = plVar49 + 4;
  if (plVar49 == plVar30) goto LAB_0047b75c;
  goto LAB_0047b6f0;
LAB_0047a838:
  plRam000000000787e298 = plRam000000000787e290;
LAB_0047a848:
  iRam000000000787e2c4 = (*pcRam000000000787df40)(plVar43,0);
  iRam000000000787e2c8 = (*pcRam000000000787df48)(plVar43,0);
  bRam000000000787e2cc = (param_2 ^ 0xff) & 1;
  if ((iRam000000000787e2c8 < 0x10) || (iRam000000000787e2c4 < 0x10)) goto LAB_0047c440;
  if ((param_2 & 1) != 0) {
    iVar10 = iRam000000000787e2c4 * 3;
    iVar13 = (*pcRam000000000787df68)(0);
    if (iVar13 < iVar10) {
LAB_0047a8f8:
      iRam000000000787e2e4 = 0;
      if ((bRam000000000787e2f0 & 1) == 0) {
        iVar10 = fn_65eda8(0x787e2f0);
        if (iVar10 != 0) {
          fn_37d22c();
          imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
          fn_65eed8(0x787e2f0);
        }
      }
      lVar21 = (*pcRam000000000787df50)(plVar43,0);
      if (lVar21 != 0) {
        pcVar35 = (char *)0x787e088;
        goto LAB_0047a944;
      }
      if (plRam000000000787e2d0 == plVar43) {
        uStack_1d0 = uStack_1d0 & 0xffffffffffffff00;
        uVar14 = fn_18f978(plVar43,&uStack_1d0);
        if ((uVar14 & 1) != 0) {
          if ((char)uStack_1d0 != '\0') {
            pcVar35 = (char *)0x787e088;
            goto LAB_0047a944;
          }
          fn_18faa8(plVar43,1);
        }
      }
      else {
        fn_37cf9c();
        uStack_1d0 = uStack_1d0 & 0xffffffffffffff00;
        uVar14 = fn_18f978(plVar43,&uStack_1d0);
        if ((uVar14 & 1) == 0) {
LAB_0047aed8:
          if ((cRam000000000787e2e9 == '\0') &&
             (cRam000000000787e2e9 = '\x01', (bRam00000000076ac3f8 & 1) == 0)) {
            iVar10 = fn_65eda8(0x76ac3f8);
            if (iVar10 != 0) {
              fn_1269d0(0x76a9760);
              imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
              fn_65eed8(0x76ac3f8);
            }
          }
        }
        else {
          if ((char)uStack_1d0 == '\0') {
            uVar14 = fn_18faa8(plVar43,1);
            if ((uVar14 & 1) == 0) goto LAB_0047aed8;
          }
          if (lRam000000000787e2d8 != 0) {
            fn_439c54();
          }
          lRam000000000787e2d8 = 0;
          plRam000000000787e2d0 = plVar43;
          if (plVar43 != (long *)0x0) {
            lRam000000000787e2d8 = fn_439970(plVar43);
          }
          cRam000000000787e2e0 = (char)uStack_1d0;
          pcVar35 = (char *)0x787e088;
          if ((char)uStack_1d0 != '\0') goto LAB_0047a944;
        }
      }
    }
    else {
      iVar10 = iRam000000000787e2c8 * 3;
      iVar13 = (*pcRam000000000787df70)(0);
      if (iVar13 < iVar10) goto LAB_0047a8f8;
      if ((cRam000000000787e020 == '\0') || (plRam000000000787e010 != plVar43)) goto LAB_0047c440;
    }
    fn_37cee0(0x787dff8);
    goto LAB_0047c440;
  }
  pcVar35 = (char *)0x787e120;
LAB_0047a944:
  if (*pcVar35 == '\0') {
LAB_0047ac30:
    if ((bRam000000000787e2f0 & 1) == 0) {
      iVar10 = fn_65eda8(0x787e2f0);
      if (iVar10 != 0) {
        fn_37d22c();
        imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
        fn_65eed8(0x787e2f0);
      }
    }
    lVar21 = 0x148;
    if ((param_2 & 1) == 0) {
      lVar21 = 0x1e0;
    }
    if (*(long *)(lVar21 + 0x787deb8) == 0) {
      if ((bRam00000000076ac3f8 & 1) == 0) {
        iVar10 = fn_65eda8(0x76ac3f8);
        if (iVar10 != 0) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
      }
      lVar48 = fn_43cd6c(0x76a9768,lRam000000000787df78);
      if (lVar48 == 0) {
        fn_37d434(lVar17 + 0x787deb8);
        goto LAB_0047c440;
      }
      (*pcRam000000000787deb8)(lVar48,0);
      lVar25 = 0x150;
      if ((param_2 & 1) == 0) {
        lVar25 = 0x1e8;
      }
      if (*(long *)(lVar25 + 0x787deb8) != 0) {
        fn_439c54();
      }
      *(undefined8 *)(lVar25 + 0x787deb8) = 0;
      *(long *)(lVar21 + 0x787deb8) = lVar48;
      uVar15 = fn_439970(lVar48);
      pcVar24 = pcRam000000000787dec8;
      *(undefined8 *)(lVar25 + 0x787deb8) = uVar15;
      if (pcVar24 != (code *)0x0) {
        if ((bRam00000000076ac3f8 & 1) == 0) {
          iVar10 = fn_65eda8(0x76ac3f8);
          if (iVar10 != 0) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
        }
        lVar25 = fn_43cd88(0x76a9768,&UNK_00800e75);
        if (lVar25 != 0) {
          (*pcRam000000000787dec8)(lVar48,lVar25,0);
        }
      }
    }
    uVar15 = *(undefined8 *)(lVar21 + 0x787deb8);
    (*pcRam000000000787dec0)(uVar15,0);
    uStack_380 = 0;
    uStack_378 = 0;
    uStack_370 = 0;
    uStack_388 = 0xffffffff00000000;
    uStack_36c = 0xffffffff;
    uStack_364 = 0;
    (*pcRam000000000787df20)(&uStack_388,2,0);
    if (plRam000000000787e278 != plRam000000000787e280) {
      if ((bRam000000000787e2f0 & 1) == 0) {
        iVar10 = fn_65eda8(0x787e2f0);
        if (iVar10 != 0) {
          fn_37d22c();
          imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
          fn_65eed8(0x787e2f0);
        }
      }
      iVar8 = iRam000000000787e2c8;
      iVar13 = iRam000000000787e2c4;
      lVar21 = lRam000000000787e138;
      bVar4 = bRam000000000787df82;
      iVar10 = iRam000000000787e2c8;
      if (iRam000000000787e2c4 <= iRam000000000787e2c8) {
        iVar10 = iRam000000000787e2c4;
      }
      if (iVar10 < 0) {
        iVar10 = iVar10 + 1;
      }
      uVar12 = iVar10 >> 1;
      if ((int)uVar12 < 2) {
        uVar12 = 1;
      }
      if (uVar12 < 0x20) {
        uVar22 = 1;
      }
      else if (uVar12 < 0x40) {
        uVar22 = 2;
      }
      else if (uVar12 < 0x80) {
        uVar22 = 3;
      }
      else if (uVar12 < 0x100) {
        uVar22 = 4;
      }
      else if (uVar12 < 0x200) {
        uVar22 = 5;
      }
      else {
        uVar22 = 6;
        if (0x3ff < uVar12) {
          uVar22 = 7;
        }
      }
      uStack_358 = 0;
      uStack_350 = 0;
      uStack_348 = 0;
      uStack_360 = 0xffffffff00000000;
      uStack_344 = 0xffffffff;
      uStack_33c = 0;
      (*pcRam000000000787df28)(&uStack_360,uRam000000000787df9c,0);
      uStack_1d0 = 0xffffffff00000000;
      uStack_c8 = 0xffffffff00000000;
      uStack_2e8 = 0xffffffff00000000;
      uStack_1e0 = 0xffffffff00000000;
      uStack_2c4 = _UNK_00781de8;
      uStack_2cc = _UNK_00781de0;
      uStack_29c = _UNK_00781de8;
      uStack_2a4 = _UNK_00781de0;
      uStack_274 = _UNK_00781de8;
      uStack_27c = _UNK_00781de0;
      uStack_24c = _UNK_00781de8;
      uStack_254 = _UNK_00781de0;
      uStack_224 = _UNK_00781de8;
      uStack_22c = _UNK_00781de0;
      uStack_1fc = _UNK_00781de8;
      uStack_204 = _UNK_00781de0;
      uVar12 = uVar22;
      if (uVar22 < 3) {
        uVar12 = 2;
      }
      uVar14 = (ulong)uVar12;
      fStack_1a4 = -NAN;
      uStack_17c = 0xffffffff;
      uStack_154 = 0xffffffff;
      uVar11 = 0;
      if (bRam000000000787e2cc != 0) {
        uVar11 = 0x18;
      }
      uStack_12c = 0xffffffff;
      uStack_104 = 0xffffffff;
      uStack_dc = 0xffffffff;
      uStack_2bc = 0xffffffff;
      uStack_294 = 0xffffffff;
      uStack_26c = 0xffffffff;
      uStack_244 = 0xffffffff;
      uStack_21c = 0xffffffff;
      uStack_1f4 = 0xffffffff;
      uStack_1c0 = 0;
      uStack_1c8 = 0;
      fStack_1ac = (float)_UNK_00781de8;
      fStack_1a8 = (float)(_UNK_00781de8 >> 0x20);
      fStack_1b4 = (float)_UNK_00781de0;
      fStack_1b0 = (float)((ulong)_UNK_00781de0 >> 0x20);
      fStack_1b8 = 0.0;
      uStack_198 = 0;
      uStack_1a0 = 0;
      uStack_184 = _UNK_00781de8;
      uStack_18c = _UNK_00781de0;
      uStack_190 = 0;
      uStack_170 = 0;
      uStack_178 = 0;
      uStack_15c = _UNK_00781de8;
      uStack_164 = _UNK_00781de0;
      uStack_168 = 0;
      uStack_148 = 0;
      uStack_150 = 0;
      uStack_134 = _UNK_00781de8;
      uStack_13c = _UNK_00781de0;
      uStack_140 = 0;
      uStack_128 = 0;
      uStack_120 = 0;
      uStack_10c = _UNK_00781de8;
      uStack_114 = _UNK_00781de0;
      uStack_118 = 0;
      uStack_100 = 0;
      uStack_f8 = 0;
      uStack_e4 = _UNK_00781de8;
      uStack_ec = _UNK_00781de0;
      uStack_f0 = 0;
      uStack_d8 = 0;
      uStack_d0 = 0;
      uStack_c0 = 0;
      uStack_2e0 = 0;
      uStack_2d8 = 0;
      uStack_2d0 = 0;
      uStack_2b8 = 0;
      uStack_2b0 = 0;
      uStack_2a8 = 0;
      uStack_290 = 0;
      uStack_288 = 0;
      uStack_280 = 0;
      uStack_268 = 0;
      uStack_260 = 0;
      uStack_258 = 0;
      uStack_240 = 0;
      uStack_238 = 0;
      uStack_230 = 0;
      uStack_218 = 0;
      uStack_210 = 0;
      uStack_208 = 0;
      uStack_1f0 = 0;
      uStack_1e8 = 0;
      uStack_1d8 = 0;
      uStack_308 = 0;
      uStack_300 = 0;
      uStack_2f0 = 0;
      uStack_2f8 = 0;
      uStack_328 = 0;
      uStack_320 = 0;
      uStack_310 = 0;
      uStack_318 = 0;
      (*pcRam000000000787def8)(uVar15,uRam000000000787df9c,0xffffffff,0xffffffff,uVar11,0,0,0);
      lVar48 = 0;
      uVar28 = 0;
      puVar37 = (undefined4 *)0x787dfb8;
      iVar10 = iVar13;
      iVar47 = iVar8;
      do {
        if (iVar10 < 0) {
          iVar10 = iVar10 + 1;
        }
        uVar11 = *puVar37;
        iVar10 = iVar10 >> 1;
        if (iVar10 < 2) {
          iVar10 = 1;
        }
        *(int *)((long)&uStack_308 + uVar28 * 4) = iVar10;
        if (iVar47 < 0) {
          iVar47 = iVar47 + 1;
        }
        iVar47 = iVar47 >> 1;
        if (iVar47 < 2) {
          iVar47 = 1;
        }
        *(int *)((long)&uStack_328 + uVar28 * 4) = iVar47;
        (*pcRam000000000787df28)((long)&uStack_1d0 + lVar48,uVar11,0);
        (*pcRam000000000787def8)(uVar15,*puVar37,iVar10,iVar47,0,1,(ulong)bVar4 << 1,0);
        uVar28 = uVar28 + 1;
        if (uVar28 < uVar14) {
          (*pcRam000000000787df28)((long)&uStack_2e8 + lVar48,puVar37[7],0);
          (*pcRam000000000787def8)(uVar15,puVar37[7],iVar10,iVar47,0,1,(ulong)bVar4 << 1,0);
        }
        lVar48 = lVar48 + 0x28;
        puVar37 = puVar37 + 1;
      } while (uVar14 * 0x28 - lVar48 != 0);
      puVar40 = &uStack_388;
      if (bRam000000000787e2cc != 0) {
        puVar40 = &uStack_360;
      }
      (*pcRam000000000787df08)(uVar15,&uStack_360,puVar40,0);
      (*pcRam000000000787df10)(0,0,0,0,uVar15,bRam000000000787e2cc,1,0);
      (*pcRam000000000787dee8)(0x3f800000,uVar15,uRam000000000787df88,0);
      (*pcRam000000000787dee8)(0x3e800000,uVar15,uRam000000000787df8c,0);
      plVar26 = plRam000000000787e298;
      plVar49 = plRam000000000787e278;
      plVar30 = plRam000000000787e280;
      plVar36 = plRam000000000787e290;
      if (bRam000000000787e2cc != 0) {
        for (; plRam000000000787e278 = plVar49, plRam000000000787e280 = plVar30, plVar36 != plVar26;
            plVar36 = plVar36 + 2) {
          if (0 < *(int *)(plVar36 + 1)) {
            iVar10 = 0;
            do {
              (*pcRam000000000787df18)(uVar15,*plVar36,lVar21,iVar10,4,0);
              iVar10 = iVar10 + 1;
            } while (iVar10 < *(int *)(plVar36 + 1));
          }
          plVar49 = plRam000000000787e278;
          plVar30 = plRam000000000787e280;
        }
        if (plVar49 != plVar30) {
LAB_0047b658:
          uVar28 = 0;
          lVar48 = *(long *)(&UNK_06532578 + (long)*(int *)((long)plVar49 + 0x14) * 8);
          do {
            uVar5 = *(byte *)(lVar48 + uVar28) - 0x43;
            if (uVar5 < 0x14 && (1 << (ulong)(uVar5 & 0x1f) & 0x82003U) != 0) {
              (*pcRam000000000787df18)
                        (uVar15,*plVar49,plVar49[1],*(undefined4 *)(plVar49 + 2),uVar28 & 0xffffffff
                         ,0);
            }
            else if (*(byte *)(lVar48 + uVar28) == 0) goto code_r0x0047b6a8;
            uVar28 = uVar28 + 1;
          } while( true );
        }
      }
LAB_0047b6b4:
      plVar30 = plRam000000000787e280;
      plVar49 = plRam000000000787e278;
      if (plRam000000000787e278 != plRam000000000787e280) {
LAB_0047b6f0:
        uVar28 = 0;
        lVar48 = *(long *)(&UNK_06532578 + (long)*(int *)((long)plVar49 + 0x14) * 8);
        do {
          bVar4 = *(byte *)(lVar48 + uVar28);
          if ((bVar4 != 0x44) && (bVar4 != 0x47)) {
            if (bVar4 == 0) goto LAB_0047b6e4;
            if (((*(char *)(plVar49 + 3) != '\0') || (uVar5 = bVar4 - 0x48, 0x29 < uVar5)) ||
               ((1L << ((ulong)uVar5 & 0x3f) & 0x20100000001U) == 0)) {
              (*pcRam000000000787df18)
                        (uVar15,*plVar49,plVar49[1],*(undefined4 *)(plVar49 + 2),uVar28 & 0xffffffff
                         ,0);
            }
          }
          uVar28 = uVar28 + 1;
        } while( true );
      }
LAB_0047b75c:
      (*pcRam000000000787dee8)(0,uVar15,uRam000000000787df88,0);
      uVar11 = 0x41200000;
      uVar61 = 0x3f800000;
      if (bRam000000000787df82 != 0) {
        uVar11 = 0x40200000;
        uVar61 = 0x40800000;
      }
      (*pcRam000000000787dee0)(uVar61,0x3f000000,0x3f7851ec,uVar11,uVar15,uRam000000000787df98,0);
      (*pcRam000000000787dee0)(1.0 / (float)iVar13,1.0 / (float)iVar8,uVar15,uRam000000000787df90,0)
      ;
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,&uStack_360,&uStack_1d0,lVar21,0,0xffffffff,0,0);
      if (uVar12 < 2) {
        lVar48 = (long)(int)uVar12 + -1;
        puVar40 = &uStack_1d0 + lVar48 * 5;
      }
      else {
        lVar48 = uVar14 - 1;
        puVar40 = &uStack_328;
        puVar41 = &uStack_308;
        puVar45 = &uStack_1d0;
        do {
          (*pcRam000000000787dee0)
                    (1.0 / (float)*(int *)puVar41,1.0 / (float)*(int *)puVar40,uVar15,
                     uRam000000000787df90,0);
          (*pcRam000000000787ded8)
                    (0x3f800000,0x3f800000,0,0,uVar15,puVar45,puVar45 + 5,lVar21,1,0xffffffff,0,0);
          lVar48 = lVar48 + -1;
          puVar40 = (undefined8 *)((long)puVar40 + 4);
          puVar41 = (undefined8 *)((long)puVar41 + 4);
          puVar45 = puVar45 + 5;
        } while (lVar48 != 0);
        lVar42 = uVar14 * 4;
        puVar38 = auStack_330 + 4;
        puVar44 = auStack_30c;
        lVar48 = 4;
        lVar50 = uVar14 * 0x28 + -0x50;
        lVar25 = (long)&uStack_1fc + (long)(int)uVar12 * 0x28 + 4;
        do {
          (*pcRam000000000787def0)(uVar15,uRam000000000787df94,(long)&uStack_1d0 + lVar50,3,0);
          puVar40 = &uStack_2e8;
          lVar54 = (long)puVar40 + lVar50;
          (*pcRam000000000787dee0)
                    (1.0 / (float)*(int *)(puVar44 + lVar42),1.0 / (float)*(int *)(puVar38 + lVar42)
                     ,uVar15,uRam000000000787df90,0);
          (*pcRam000000000787ded8)
                    (0x3f800000,0x3f800000,0,0,uVar15,lVar25,lVar54,lVar21,2,0xffffffff,0,0);
          lVar48 = lVar48 + 4;
          puVar38 = puVar38 + -4;
          puVar44 = puVar44 + -4;
          lVar50 = lVar50 + -0x28;
          lVar25 = lVar54;
        } while (lVar42 - lVar48 != 0);
        lVar48 = 0;
      }
      (*pcRam000000000787dee0)
                (1.0 / (float)*(int *)((long)&uStack_308 + lVar48 * 4),
                 1.0 / (float)*(int *)((long)&uStack_328 + lVar48 * 4),uVar15,uRam000000000787df90,0
                );
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,puVar40,&uStack_388,lVar21,3,0xffffffff,0,0);
      (*pcRam000000000787df00)(uVar15,uRam000000000787df9c,0);
      (*pcRam000000000787df00)(uVar15,uRam000000000787dfb8,0);
      (*pcRam000000000787df00)(uVar15,uRam000000000787dfd4,0);
      (*pcRam000000000787df00)(uVar15,uRam000000000787dfbc,0);
      if (2 < uVar22) {
        (*pcRam000000000787df00)(uVar15,uRam000000000787dfd8,0);
        (*pcRam000000000787df00)(uVar15,uRam000000000787dfc0,0);
        if (uVar22 != 3) {
          (*pcRam000000000787df00)(uVar15,uRam000000000787dfdc,0);
          (*pcRam000000000787df00)(uVar15,uRam000000000787dfc4,0);
          if (4 < uVar22) {
            (*pcRam000000000787df00)(uVar15,uRam000000000787dfe0,0);
          }
          if (uVar22 != 4) {
            (*pcRam000000000787df00)(uVar15,uRam000000000787dfc8,0);
            if (5 < uVar22) {
              (*pcRam000000000787df00)(uVar15,uRam000000000787dfe4,0);
            }
            if (uVar22 != 5) {
              (*pcRam000000000787df00)(uVar15,uRam000000000787dfcc,0);
              if (6 < uVar22) {
                (*pcRam000000000787df00)(uVar15,uRam000000000787dfe8,0);
              }
              if (uVar22 != 6) {
                (*pcRam000000000787df00)(uVar15,uRam000000000787dfd0,0);
              }
            }
          }
        }
      }
    }
    if (plRam000000000787e2a8 != plRam000000000787e2b0) {
      if ((bRam000000000787e2f0 & 1) == 0) {
        iVar10 = fn_65eda8(0x787e2f0);
        if (iVar10 != 0) {
          fn_37d22c();
          imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
          fn_65eed8(0x787e2f0);
        }
      }
      iVar8 = iRam000000000787e2c8;
      iVar13 = iRam000000000787e2c4;
      lVar21 = lRam000000000787e160;
      uStack_1c0 = 0;
      fStack_1b4 = -NAN;
      fStack_1b0 = 0.0;
      uStack_1c8 = 0;
      iVar10 = iRam000000000787e2c4;
      if (iRam000000000787e2c4 < 0) {
        iVar10 = iRam000000000787e2c4 + 1;
      }
      uStack_1d0 = 0xffffffff00000000;
      iVar10 = iVar10 >> 1;
      fStack_1b8 = 0.0;
      fStack_1ac = 0.0;
      uStack_2e8 = 0xffffffff00000000;
      if (iVar10 < 2) {
        iVar10 = 1;
      }
      uStack_2e0 = 0;
      uStack_2d8 = 0;
      iVar47 = iRam000000000787e2c8;
      if (iRam000000000787e2c8 < 0) {
        iVar47 = iRam000000000787e2c8 + 1;
      }
      uStack_2cc = 0xffffffff;
      iVar47 = iVar47 >> 1;
      uStack_2d0 = 0;
      uStack_2c4 = uStack_2c4 & 0xffffffff00000000;
      uStack_360 = 0xffffffff00000000;
      uStack_358 = 0;
      uStack_350 = 0;
      if (iVar47 < 2) {
        iVar47 = 1;
      }
      uStack_348 = 0;
      uStack_344 = 0xffffffff;
      uStack_33c = 0;
      (*pcRam000000000787df28)(&uStack_1d0,uRam000000000787dfac,0);
      (*pcRam000000000787df28)(&uStack_2e8,uRam000000000787dfb0,0);
      (*pcRam000000000787df28)(&uStack_360,uRam000000000787dfb4,0);
      (*pcRam000000000787def8)(uVar15,uRam000000000787dfac,0xffffffff,0xffffffff,0,1,0,0);
      (*pcRam000000000787def8)(uVar15,uRam000000000787dfb0,iVar10,iVar47,0,1,0,0);
      (*pcRam000000000787def8)(uVar15,uRam000000000787dfb4,iVar10,iVar47,0,1,0,0);
      puVar40 = &uStack_388;
      if (bRam000000000787e2cc != 0) {
        puVar40 = &uStack_1d0;
      }
      (*pcRam000000000787df08)(uVar15,&uStack_1d0,puVar40,0);
      (*pcRam000000000787df10)(0,0,0,0,uVar15,0,1,0);
      plVar49 = plRam000000000787e2b0;
      if (plRam000000000787e2a8 != plRam000000000787e2b0) {
        plVar30 = plRam000000000787e2a8;
        do {
          if ((bRam000000000787e2cc == 0) && (fVar52 = *(float *)(plVar30 + 5), 0.0 < fVar52)) {
            fVar51 = 1.0;
            if (fVar52 <= 1.0) {
              fVar51 = fVar52;
            }
            fVar55 = 0.0;
            if (0.0 <= fVar52) {
              fVar55 = fVar51;
            }
            (*pcRam000000000787dee0)
                      (fVar55 * *(float *)((long)plVar30 + 0x1c),fVar55 * *(float *)(plVar30 + 4),
                       fVar55 * *(float *)((long)plVar30 + 0x24),uVar15,uRam000000000787dfa0,0);
            if (0 < *(int *)(plVar30 + 1)) {
              iVar46 = 0;
              do {
                (*pcRam000000000787df18)(uVar15,*plVar30,lVar21,iVar46,0,0);
                iVar46 = iVar46 + 1;
              } while (iVar46 < *(int *)(plVar30 + 1));
            }
          }
          bVar4 = bRam000000000787e2cc;
          fVar52 = *(float *)(plVar30 + 3);
          if (0.0 < fVar52) {
            fVar51 = 1.0;
            if (fVar52 <= 1.0) {
              fVar51 = fVar52;
            }
            fVar55 = 0.0;
            if (0.0 <= fVar52) {
              fVar55 = fVar51;
            }
            (*pcRam000000000787dee0)
                      (fVar55 * *(float *)((long)plVar30 + 0xc),fVar55 * *(float *)(plVar30 + 2),
                       fVar55 * *(float *)((long)plVar30 + 0x14),uVar15,uRam000000000787dfa0,0);
            if (0 < *(int *)(plVar30 + 1)) {
              iVar46 = 0;
              do {
                (*pcRam000000000787df18)(uVar15,*plVar30,lVar21,iVar46,bVar4 ^ 1,0);
                iVar46 = iVar46 + 1;
              } while (iVar46 < *(int *)(plVar30 + 1));
            }
          }
          plVar30 = plVar30 + 6;
        } while (plVar30 != plVar49);
      }
      (*pcRam000000000787dee0)(1.0 / (float)iVar13,1.0 / (float)iVar8,uVar15,uRam000000000787dfa8,0)
      ;
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,&uStack_1d0,&uStack_2e8,lVar21,2,0xffffffff,0,0);
      fVar51 = (float)iRam000000000787e2c0 / 10.0;
      fVar55 = (float)iVar10;
      fVar56 = (float)iVar47;
      fVar59 = 1.0 / fVar55;
      fVar52 = 100.0;
      if (fVar51 <= 100.0) {
        fVar52 = fVar51;
      }
      fVar66 = 1.0 / fVar56;
      fVar65 = 0.0;
      if (0.0 <= fVar51) {
        fVar65 = fVar52 / 100.0;
      }
      uVar11 = NEON_fmadd(fVar65,0x3fffffff,0x3f19999a);
      (*pcRam000000000787dee0)(uVar11,0,0x40200000,0,uVar15,uRam000000000787dfa4,0);
      (*pcRam000000000787dee0)(fVar59,fVar66,fVar55,fVar56,uVar15,uRam000000000787dfa8,0);
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,&uStack_2e8,&uStack_360,lVar21,3,0xffffffff,0,0);
      (*pcRam000000000787dee0)(0,uVar11,0x40200000,0,uVar15,uRam000000000787dfa4,0);
      (*pcRam000000000787dee0)(fVar59,fVar66,fVar55,fVar56,uVar15,uRam000000000787dfa8,0);
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,&uStack_360,&uStack_2e8,lVar21,3,0xffffffff,0,0);
      (*pcRam000000000787dee0)(uVar11,0,0x40200000,0,uVar15,uRam000000000787dfa4,0);
      (*pcRam000000000787dee0)(fVar59,fVar66,fVar55,fVar56,uVar15,uRam000000000787dfa8,0);
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,&uStack_2e8,&uStack_360,lVar21,3,0xffffffff,0,0);
      (*pcRam000000000787dee0)(0,uVar11,0x40200000,0,uVar15,uRam000000000787dfa4,0);
      (*pcRam000000000787dee0)(fVar59,fVar66,fVar55,fVar56,uVar15,uRam000000000787dfa8,0);
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,&uStack_360,&uStack_2e8,lVar21,3,0xffffffff,0,0);
      (*pcRam000000000787def0)(uVar15,uRam000000000787dfac,&uStack_1d0,3,0);
      (*pcRam000000000787dee0)(fVar59,fVar66,fVar55,fVar56,uVar15,uRam000000000787dfa8,0);
      (*pcRam000000000787ded8)
                (0x3f800000,0x3f800000,0,0,uVar15,&uStack_2e8,&uStack_388,lVar21,4,0xffffffff,0,0);
      (*pcRam000000000787df00)(uVar15,uRam000000000787dfac,0);
      (*pcRam000000000787df00)(uVar15,uRam000000000787dfb0,0);
      (*pcRam000000000787df00)(uVar15,uRam000000000787dfb4,0);
    }
    bVar9 = (param_2 & 1) == 0;
    uVar15 = 0x787e030;
    if (bVar9) {
      uVar15 = 0x787e0c8;
    }
    puVar40 = (undefined8 *)0x787e078;
    uVar18 = 0x787e048;
    uVar19 = 0x787e060;
    if (bVar9) {
      puVar40 = (undefined8 *)0x787e110;
      uVar18 = 0x787e0e0;
      uVar19 = 0x787e0f8;
    }
    fn_37f8e0(uVar15,plRam000000000787e278,plRam000000000787e280,
              (long)plRam000000000787e280 - (long)plRam000000000787e278 >> 5);
    fn_37fa10(uVar18,plRam000000000787e290,plRam000000000787e298,
              (long)plRam000000000787e298 - (long)plRam000000000787e290 >> 4);
    fn_37fb48(uVar19,plRam000000000787e2a8,plRam000000000787e2b0,
              ((long)plRam000000000787e2b0 - (long)plRam000000000787e2a8 >> 4) * -0x5555555555555555
             );
    uVar15 = CONCAT17(bRam000000000787e2cc,CONCAT43(iRam000000000787e2c8,iRam000000000787e2c4._1_3_)
                     );
    *puVar40 = CONCAT44(iRam000000000787e2c4,iRam000000000787e2c0);
    *(undefined8 *)((long)puVar40 + 5) = uVar15;
    *pcVar35 = '\x01';
  }
  else {
    lVar21 = 0x140;
    if ((param_2 & 1) == 0) {
      lVar21 = 0x1d8;
    }
    if (iRam000000000787e2c4 != *(int *)(lVar21 + 0x787df3c)) goto LAB_0047ac30;
    lVar21 = 0x140;
    if ((param_2 & 1) == 0) {
      lVar21 = 0x1d8;
    }
    if (iRam000000000787e2c8 != *(int *)(lVar21 + 0x787df40)) goto LAB_0047ac30;
    lVar21 = 0x140;
    if ((param_2 & 1) == 0) {
      lVar21 = 0x1d8;
    }
    if (bRam000000000787e2cc != *(byte *)(lVar21 + 0x787df44)) goto LAB_0047ac30;
    pplVar2 = (long **)0x787e030;
    plVar49 = (long *)0x787e038;
    if ((param_2 & 1) == 0) {
      pplVar2 = (long **)0x787e0c8;
      plVar49 = (long *)0x787e0d0;
    }
    plVar30 = *pplVar2;
    plVar36 = plRam000000000787e278;
    if ((long)plRam000000000787e280 - (long)plRam000000000787e278 != *plVar49 - (long)plVar30)
    goto LAB_0047ac30;
    for (; plVar36 != plRam000000000787e280; plVar36 = plVar36 + 4) {
      if (((((*plVar36 != *plVar30) || (plVar36[1] != plVar30[1])) ||
           (*(int *)(plVar36 + 2) != *(int *)(plVar30 + 2))) ||
          ((*(int *)((long)plVar36 + 0x14) != *(int *)((long)plVar30 + 0x14) ||
           (*(char *)(plVar36 + 3) != *(char *)(plVar30 + 3))))) ||
         (*(int *)((long)plVar36 + 0x1c) != *(int *)((long)plVar30 + 0x1c))) goto LAB_0047ac30;
      plVar30 = plVar30 + 4;
    }
    pplVar2 = (long **)0x787e048;
    plVar49 = (long *)0x787e050;
    if ((param_2 & 1) == 0) {
      pplVar2 = (long **)0x787e0e0;
      plVar49 = (long *)0x787e0e8;
    }
    plVar30 = *pplVar2;
    plVar36 = plRam000000000787e290;
    if ((long)plRam000000000787e298 - (long)plRam000000000787e290 != *plVar49 - (long)plVar30)
    goto LAB_0047ac30;
    for (; plVar36 != plRam000000000787e298; plVar36 = plVar36 + 2) {
      if ((*plVar36 != *plVar30) || (*(int *)(plVar36 + 1) != *(int *)(plVar30 + 1)))
      goto LAB_0047ac30;
      plVar30 = plVar30 + 2;
    }
    pplVar2 = (long **)0x787e060;
    plVar49 = (long *)0x787e068;
    if ((param_2 & 1) == 0) {
      pplVar2 = (long **)0x787e0f8;
      plVar49 = (long *)0x787e100;
    }
    plVar30 = *pplVar2;
    plVar36 = plRam000000000787e2a8;
    if ((long)plRam000000000787e2b0 - (long)plRam000000000787e2a8 != *plVar49 - (long)plVar30)
    goto LAB_0047ac30;
    for (; plVar36 != plRam000000000787e2b0; plVar36 = plVar36 + 6) {
      if ((((((*plVar36 != *plVar30) || (*(int *)(plVar36 + 1) != *(int *)(plVar30 + 1))) ||
            (*(float *)((long)plVar36 + 0xc) != *(float *)((long)plVar30 + 0xc))) ||
           (((*(float *)(plVar36 + 2) != *(float *)(plVar30 + 2) ||
             (*(float *)((long)plVar36 + 0x14) != *(float *)((long)plVar30 + 0x14))) ||
            ((*(float *)(plVar36 + 3) != *(float *)(plVar30 + 3) ||
             ((*(float *)((long)plVar36 + 0x1c) != *(float *)((long)plVar30 + 0x1c) ||
              (*(float *)(plVar36 + 4) != *(float *)(plVar30 + 4))))))))) ||
          (*(float *)((long)plVar36 + 0x24) != *(float *)((long)plVar30 + 0x24))) ||
         ((*(float *)(plVar36 + 5) != *(float *)(plVar30 + 5) ||
          (*(int *)((long)plVar36 + 0x2c) != *(int *)((long)plVar30 + 0x2c))))) goto LAB_0047ac30;
      plVar30 = plVar30 + 6;
    }
    lVar21 = 0x140;
    if ((param_2 & 1) == 0) {
      lVar21 = 0x1d8;
    }
    if (iRam000000000787e2c0 != *(int *)(lVar21 + 0x787df38)) goto LAB_0047ac30;
  }
  iVar13 = fn_31c4e0(plVar43);
  iVar10 = 0x11;
  if (iVar13 != 0) {
    iVar10 = 0x12;
  }
  lVar21 = 0x168;
  if ((param_2 & 1) == 0) {
    lVar21 = 0x200;
  }
  if (*(char *)(lVar21 + 0x787deb8) != '\0') {
    bVar9 = (param_2 & 1) == 0;
    pplVar2 = (long **)0x787e010;
    if (bVar9) {
      pplVar2 = (long **)0x787e0a8;
    }
    piVar3 = (int *)0x787e028;
    piVar7 = (int *)0x787e024;
    if (bVar9) {
      piVar3 = (int *)0x787e0c0;
      piVar7 = (int *)0x787e0bc;
    }
    if (((*pplVar2 == plVar43) && (*piVar7 == iVar10)) && (*piVar3 == iVar13)) goto LAB_0047c440;
  }
  fn_37cee0(lVar17 + 0x787deb8);
  bVar9 = (param_2 & 1) == 0;
  puVar40 = (undefined8 *)0x787e000;
  if (bVar9) {
    puVar40 = (undefined8 *)0x787e098;
  }
  lVar17 = 0x16c;
  if (bVar9) {
    lVar17 = 0x204;
  }
  lVar48 = 0x170;
  if (bVar9) {
    lVar48 = 0x208;
  }
  lVar25 = 0x158;
  if (bVar9) {
    lVar25 = 0x1f0;
  }
  lVar42 = 0x160;
  if (bVar9) {
    lVar42 = 0x1f8;
  }
  (*pcRam000000000787df30)(plVar43,iVar10,*puVar40,0);
  lVar50 = *(long *)(lVar42 + 0x787deb8);
  *(undefined *)(lVar21 + 0x787deb8) = 1;
  *(int *)(lVar17 + 0x787deb8) = iVar10;
  *(int *)(lVar48 + 0x787deb8) = iVar13;
  if (lVar50 != 0) {
    fn_439c54();
  }
  *(undefined8 *)(lVar42 + 0x787deb8) = 0;
  *(long **)(lVar25 + 0x787deb8) = plVar43;
  if (plVar43 != (long *)0x0) {
    uVar15 = fn_439970();
    *(undefined8 *)(lVar42 + 0x787deb8) = uVar15;
  }
LAB_0047c440:
  if (plVar39[5] == lStack_b8) {
    return;
  }
LAB_0047cc0c:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

