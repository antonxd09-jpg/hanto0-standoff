
// ================================================================================
// t.me/imguisource_bot | t.me/ImGui_Source_FIXNEY (ImGui Source) | t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x3708f0 */

void fn_3708f0(long **param_1,byte param_2)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  char cVar7;
  bool bVar8;
  uint uVar9;
  int iVar10;
  ulong uVar11;
  undefined *puVar12;
  long lVar13;
  undefined8 uVar14;
  ulong uVar15;
  ulong uVar16;
  long *plVar17;
  long *plVar18;
  ulong uVar19;
  long *plVar20;
  long lVar21;
  int iVar22;
  long *plVar23;
  long *plVar24;
  long lVar25;
  long *plVar26;
  long *plVar27;
  long **pplVar28;
  long lVar29;
  uint *puVar30;
  
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar10 = fn_65eda8(0x787c6a0), iVar10 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    uRam000000000787c580 = 0;
    uRam000000000787c578 = 0;
    uRam000000000787c590 = 0;
    uRam000000000787c588 = 0;
    uRam000000000787c5a0 = 0;
    uRam000000000787c598 = 0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c688 = 0;
    iRam000000000787c68c = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  if (plRam000000000787c560 != (long *)0x0) {
    plVar27 = plRam000000000787c560;
    do {
      puVar30 = (uint *)plVar27[0x13];
      if ((((puVar30 != (uint *)0x0) && (*(char *)((long)plVar27 + 0xa2) == '\0')) &&
          (plVar27[3] != plVar27[4])) &&
         ((*(int *)((long)plVar27 + 0x84) == iRam000000000787c68c &&
          ((*(int *)(plVar27 + 0x12) != 8) != (bool)(param_2 & 1))))) {
        if ((*(char *)((long)puVar30 + 0x11e) == '\0') || (*(char *)(puVar30 + 0x83) == '\0')) {
          uVar9 = 0;
code_r0x004709f4:
          if (*(char *)(puVar30 + 0x3b) == '\0') goto code_r0x0047097c;
        }
        else {
          uVar9 = fn_198128(plVar27[7]);
          if ((uVar9 & 1) == 0) goto code_r0x004709f4;
        }
        fn_1997d4(plVar27[2]);
        uVar11 = func_0x0029a210();
        if (((uVar11 & 1) != 0) && (uVar11 = func_0x0029ba64(plVar27[2]), (uVar11 & 1) != 0)) {
          if (*(char *)(plVar27 + 0x14) == '\0') {
            bVar8 = false;
            cVar7 = *(char *)(puVar30 + 0x3b);
          }
          else {
            bVar8 = *(char *)((long)puVar30 + 0x11d) != '\0';
            cVar7 = *(char *)(puVar30 + 0x3b);
          }
          if (cVar7 != '\0') {
            uVar4 = *puVar30;
            lVar25 = plVar27[3];
            uVar1 = uVar4;
            if (0xb < uVar4) {
              uVar1 = 0xc;
            }
            uVar2 = 0;
            if (-1 < (int)uVar4) {
              uVar2 = uVar1;
            }
            if (plVar27[4] != lVar25) {
              uVar11 = 0;
              do {
                lVar25 = *(long *)(lVar25 + uVar11 * 0x18 + 8);
                uVar19 = fn_198128(lVar25);
                if ((uVar19 & 1) != 0) {
                  uVar6 = *(undefined4 *)(plVar27 + 0x12);
                  iVar5 = *(int *)((long)plVar27 + 0x94);
                  plVar23 = param_1[1];
                  lVar29 = plVar27[2];
                  iVar22 = (int)uVar11;
                  iVar10 = iVar22;
                  if (iVar5 <= iVar22) {
                    iVar10 = iVar5 + -1;
                  }
                  if (iVar5 < 1) {
                    iVar10 = iVar22;
                  }
                  if (plVar23 < param_1[2]) {
                    *plVar23 = lVar29;
                    plVar23[1] = lVar25;
                    plVar20 = plVar23 + 4;
                    *(undefined4 *)((long)plVar23 + 0x1c) = uVar6;
                    *(int *)(plVar23 + 2) = iVar10;
                    *(uint *)((long)plVar23 + 0x14) = uVar2;
                    *(bool *)(plVar23 + 3) = bVar8;
                  }
                  else {
                    plVar26 = *param_1;
                    pplVar28 = (long **)((long)plVar23 - (long)plVar26 >> 5);
                    uVar19 = (long)pplVar28 + 1;
                    if (uVar19 >> 0x3b != 0) {
                      fn_378a90(param_1);
                      goto code_r0x00470e2c;
                    }
                    uVar15 = (long)param_1[2] - (long)plVar26;
                    uVar16 = (long)uVar15 >> 4;
                    if (uVar16 <= uVar19) {
                      uVar16 = uVar19;
                    }
                    if (0x7fffffffffffffdf < uVar15) {
                      uVar16 = 0x7ffffffffffffff;
                    }
                    if (uVar16 == 0) {
                      lVar21 = 0;
                    }
                    else {
                      if (uVar16 >> 0x3b != 0) goto code_r0x00470e2c;
                      lVar21 = fn_679020(uVar16 << 5);
                    }
                    plVar20 = (long *)(lVar21 + (long)pplVar28 * 0x20);
                    *(bool *)(plVar20 + 3) = bVar8;
                    *plVar20 = lVar29;
                    plVar20[1] = lVar25;
                    *(int *)(plVar20 + 2) = iVar10;
                    *(uint *)((long)plVar20 + 0x14) = uVar2;
                    *(undefined4 *)((long)plVar20 + 0x1c) = uVar6;
                    plVar17 = plVar20;
                    plVar18 = plVar20;
                    if (plVar23 != plVar26) {
                      do {
                        plVar24 = plVar23 + -4;
                        lVar13 = *plVar24;
                        lVar29 = plVar23[-1];
                        lVar25 = plVar23[-2];
                        plVar18 = plVar17 + -4;
                        plVar17[-3] = plVar23[-3];
                        *plVar18 = lVar13;
                        plVar17[-1] = lVar29;
                        plVar17[-2] = lVar25;
                        plVar17 = plVar18;
                        plVar23 = plVar24;
                      } while (plVar24 != plVar26);
                      plVar23 = *param_1;
                    }
                    plVar20 = plVar20 + 4;
                    *param_1 = plVar18;
                    param_1[1] = plVar20;
                    param_1[2] = (long *)(lVar21 + uVar16 * 0x20);
                    if (plVar23 != (long *)0x0) {
                      fn_6790c8(plVar23);
                    }
                  }
                  param_1[1] = plVar20;
                }
                lVar25 = plVar27[3];
                uVar11 = uVar11 + 1;
              } while (uVar11 < (ulong)((plVar27[4] - lVar25 >> 3) * -0x5555555555555555));
            }
          }
          if ((uVar9 & 1) != 0) {
            lVar29 = plVar27[2];
            lVar25 = plVar27[7];
            iVar22 = (int)((ulong)(plVar27[4] - plVar27[3]) >> 3) * -0x55555555;
            iVar5 = *(int *)((long)plVar27 + 0x94);
            iVar10 = iVar22;
            if (iVar5 <= iVar22) {
              iVar10 = iVar5 + -1;
            }
            if (iVar5 < 1) {
              iVar10 = iVar22;
            }
            puVar12 = (undefined *)imp_wmemchr(&UNK_00803ca8,puVar30[0x48],0xb);
            puVar3 = &UNK_00803cd4;
            if (puVar12 != (undefined *)0x0) {
              puVar3 = puVar12;
            }
            uVar6 = *(undefined4 *)(plVar27 + 0x12);
            plVar23 = param_1[1];
            uVar9 = 2;
            if (puVar3 != &UNK_00803cd4) {
              uVar9 = puVar30[0x48];
            }
            if (plVar23 < param_1[2]) {
              *plVar23 = lVar29;
              plVar23[1] = lVar25;
              *(int *)(plVar23 + 2) = iVar10;
              *(uint *)((long)plVar23 + 0x14) = uVar9;
              plVar20 = plVar23 + 4;
              *(bool *)(plVar23 + 3) = bVar8;
              *(undefined4 *)((long)plVar23 + 0x1c) = uVar6;
            }
            else {
              plVar26 = *param_1;
              lVar21 = (long)plVar23 - (long)plVar26 >> 5;
              uVar11 = lVar21 + 1;
              pplVar28 = param_1;
              if (uVar11 >> 0x3b != 0) {
code_r0x00470e30:
                uVar14 = fn_378a90(pplVar28);
                fn_65ef80(0x787c6a0);
                    /* WARNING: Subroutine does not return */
                fn_67b74c(uVar14);
              }
              uVar16 = (long)param_1[2] - (long)plVar26;
              uVar19 = (long)uVar16 >> 4;
              if (uVar19 <= uVar11) {
                uVar19 = uVar11;
              }
              if (0x7fffffffffffffdf < uVar16) {
                uVar19 = 0x7ffffffffffffff;
              }
              if (uVar19 == 0) {
                lVar13 = 0;
              }
              else {
                if (uVar19 >> 0x3b != 0) {
code_r0x00470e2c:
                  fn_13edb4();
                  goto code_r0x00470e30;
                }
                lVar13 = fn_679020(uVar19 << 5);
              }
              plVar20 = (long *)(lVar13 + lVar21 * 0x20);
              *plVar20 = lVar29;
              plVar20[1] = lVar25;
              *(int *)(plVar20 + 2) = iVar10;
              *(uint *)((long)plVar20 + 0x14) = uVar9;
              *(bool *)(plVar20 + 3) = bVar8;
              *(undefined4 *)((long)plVar20 + 0x1c) = uVar6;
              plVar17 = plVar20;
              plVar18 = plVar20;
              if (plVar23 != plVar26) {
                do {
                  plVar24 = plVar23 + -4;
                  lVar21 = *plVar24;
                  lVar29 = plVar23[-1];
                  lVar25 = plVar23[-2];
                  plVar18 = plVar17 + -4;
                  plVar17[-3] = plVar23[-3];
                  *plVar18 = lVar21;
                  plVar17[-1] = lVar29;
                  plVar17[-2] = lVar25;
                  plVar17 = plVar18;
                  plVar23 = plVar24;
                } while (plVar24 != plVar26);
                plVar23 = *param_1;
              }
              plVar20 = plVar20 + 4;
              *param_1 = plVar18;
              param_1[1] = plVar20;
              param_1[2] = (long *)(lVar13 + uVar19 * 0x20);
              if (plVar23 != (long *)0x0) {
                fn_6790c8(plVar23);
              }
            }
            param_1[1] = plVar20;
          }
        }
      }
code_r0x0047097c:
      plVar27 = (long *)*plVar27;
    } while (plVar27 != (long *)0x0);
  }
  return;
}

