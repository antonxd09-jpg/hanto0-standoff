
// ================================================================================
// /// ========================================= ///
// /// Bot: @imguisource_bot
// /// ImGui Source: @ImGui_Source_FIXNEY
// /// shit src 🧨: @il2cpp_src
// /// ========================================= ///
// ================================================================================

/* ORIGINAL_RVA: 0x374f80 */

undefined8 fn_374f80(char *param_1)

{
  undefined8 uVar1;
  uint uVar2;
  int iVar3;
  long lVar4;
  long lVar5;
  undefined8 uVar6;
  ulong uVar7;
  undefined8 uVar8;
  
  if (((param_1 != (char *)0x0) && (*param_1 != '\0')) && (uVar7 = fn_371bd4(), (uVar7 & 1) != 0)) {
    if (((bRam000000000787c6a0 & 1) == 0) && (iVar3 = fn_65eda8(0x787c6a0), iVar3 != 0)) {
      fn_15adac(0x787aa08);
      imp_memset(0x787bfc0,0,0x5b0);
      uRam000000000787c570 = 0x3f800000;
      uRam000000000787c5c8 = 0x3f800000;
      uRam000000000787c580 = 0;
      uRam000000000787c578 = 0;
      uRam000000000787c590 = 0;
      uRam000000000787c588 = 0;
      uRam000000000787c5a0 = 0;
      uRam000000000787c598 = 0;
      uRam000000000787c5b0 = 0;
      uRam000000000787c5a8 = 0;
      uRam000000000787c5c0 = 0;
      uRam000000000787c5b8 = 0;
      uRam000000000787c5d8 = 0;
      uRam000000000787c5d0 = 0;
      uRam000000000787c5e8 = 0;
      uRam000000000787c5e0 = 0;
      uRam000000000787c5f8 = 0;
      uRam000000000787c5f0 = 0;
      uRam000000000787c608 = 0;
      uRam000000000787c600 = 0;
      uRam000000000787c618 = 0;
      uRam000000000787c610 = 0;
      uRam000000000787c628 = 0;
      uRam000000000787c620 = 0;
      uRam000000000787c638 = 0;
      uRam000000000787c630 = 0;
      uRam000000000787c648 = 0;
      uRam000000000787c640 = 0;
      uRam000000000787c658 = 0;
      uRam000000000787c650 = 0;
      uRam000000000787c668 = 0;
      uRam000000000787c660 = 0;
      uRam000000000787c678 = 0;
      uRam000000000787c670 = 0;
      uRam000000000787c688 = 0;
      uRam000000000787c680 = 0;
      uRam000000000787c691 = 0;
      uRam000000000787c689 = 0;
      uRam000000000787c690 = 0;
      imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
      fn_65eed8(0x787c6a0);
    }
    uVar1 = uRam000000000787bfc0;
    if (lRam00000000076e0c38 == 0) {
      if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
      }
      if (((bRam00000000076e0d58 & 1) == 0) && (iVar3 = fn_65eda8(0x76e0d58), iVar3 != 0)) {
        uRam00000000076e0d4b = 0;
        uRam00000000076e0d48 = 0;
        uRam00000000076e0d30 = 0;
        uRam00000000076e0d28 = 0;
        uRam00000000076e0d40 = 0;
        uRam00000000076e0d43 = 0;
        uRam00000000076e0d38 = 0;
        fn_126978(&UNK_00809e28,0x76e0d28,0x2b,0xa2028833c9a39f68);
        fn_65eed8(0x76e0d58);
      }
      lRam00000000076e0c38 = fn_43d1bc(0x76a9768,0x76e0d28);
    }
    lVar5 = lRam00000000076e0c38;
    uVar7 = fn_198128();
    uVar8 = 0;
    if ((((param_1 != (char *)0x0) && ((uVar7 & 1) != 0)) && (uVar8 = 0, lVar5 != 0)) &&
       (*param_1 != '\0')) {
      if (((bRam00000000076e0cc0 & 1) == 0) && (iVar3 = fn_65eda8(0x76e0cc0), iVar3 != 0)) {
        lVar4 = fn_126488();
        uVar8 = func_0x0028e240();
        uVar6 = func_0x0029f828();
        pcRam00000000076e0cb8 = (code *)fn_43d5e4(lVar4 + 8,uVar8,uVar6,2);
        fn_65eed8(0x76e0cc0);
      }
      if (((bRam00000000076e0cd0 & 1) == 0) && (iVar3 = fn_65eda8(0x76e0cd0), iVar3 != 0)) {
        lVar4 = fn_126488();
        uVar8 = func_0x0028e278();
        uVar6 = func_0x0029f8a0();
        pcRam00000000076e0cc8 = (code *)fn_43d5e4(lVar4 + 8,uVar8,uVar6,0);
        fn_65eed8(0x76e0cd0);
      }
      if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
      }
      lVar4 = fn_43cd88(0x76a9768,param_1);
      uVar8 = 0;
      if ((lVar4 != 0) && (pcRam00000000076e0cb8 != (code *)0x0)) {
        lVar5 = (*pcRam00000000076e0cb8)(uVar1,lVar4,lVar5,0);
        uVar8 = 0;
        if ((lVar5 != 0) && (pcRam00000000076e0cc8 != (code *)0x0)) {
          uVar8 = (*pcRam00000000076e0cc8)(lVar5,0);
        }
      }
      uVar7 = fn_198128(uVar8);
      if ((uVar7 & 1) != 0) {
        uVar2 = func_0x00298de0(uVar8);
        fn_199704(uVar8,uVar2 | 0x20);
      }
    }
    return uVar8;
  }
  return 0;
}

