
// ================================================================================
// Телеграм экосистема:
// - Бот: t.me/imguisource_bot
// - Канал 1: t.me/ImGui_Source_FIXNEY (ImGui Source)
// - Канал 2: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x37e130 */

bool fn_37e130(long param_1)

{
  int iVar1;
  
  if (param_1 == 0) {
    lRam000000000787df00 = 0;
  }
  else {
    if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
    }
    lRam000000000787df00 = fn_43d5e4(0x76a9768,param_1,&UNK_007987dd,1);
    if (lRam000000000787df00 != 0) goto LAB_0047e190;
  }
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar1 = fn_65eda8(0x76ac3f8), iVar1 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
LAB_0047e190:
  return lRam000000000787df00 != 0;
}

