
// ================================================================================
// [METADATA]
// BOT=https://t.me/imguisource_bot
// MAIN_CHANNEL=https://t.me/ImGui_Source_FIXNEY
// EXTRA_CHANNEL=https://t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x37cee0 */

void fn_37cee0(long param_1)

{
  int iVar1;
  ulong uVar2;
  long lVar3;
  
  if (((bRam000000000787e2f0 & 1) == 0) && (iVar1 = fn_65eda8(0x787e2f0), iVar1 != 0)) {
    fn_37d22c();
    imp___cxa_atexit(&UNK_0047d340,0x787deb8,&DAT_064e5160);
    fn_65eed8(0x787e2f0);
  }
  if ((((*(char *)(param_1 + 0x28) != '\0') && (lVar3 = *(long *)(param_1 + 0x18), lVar3 != 0)) &&
      (uVar2 = fn_198128(lVar3), (uVar2 & 1) != 0)) && (*(long *)(param_1 + 8) != 0)) {
    (*pcRam000000000787df38)(lVar3,*(undefined4 *)(param_1 + 0x2c),*(long *)(param_1 + 8),0);
  }
  *(undefined *)(param_1 + 0x28) = 0;
  if (*(long *)(param_1 + 0x20) != 0) {
    fn_439c54();
  }
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  return;
}

