
// ================================================================================
// Telegram Hub: @imguisource_bot / ImGui Source @ImGui_Source_FIXNEY / shit src 🧨 @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x37f6c4 */

void fn_37f6c4(undefined8 param_1)

{
  long lVar1;
  undefined8 uStack_38;
  undefined8 uStack_30;
  long lStack_28;
  
  lVar1 = tpidr_el0;
  lStack_28 = *(long *)(lVar1 + 0x28);
  uStack_38 = 0;
  uStack_30 = 0;
  fn_126978(param_1,&uStack_38,0x10,0x1e03bf9c7edf8949);
  if (*(long *)(lVar1 + 0x28) == lStack_28) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(uStack_38,uStack_30);
}

