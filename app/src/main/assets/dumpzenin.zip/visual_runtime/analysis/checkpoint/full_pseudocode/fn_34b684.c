
// ================================================================================
// Bot: @imguisource_bot | TG: @ImGui_Source_FIXNEY & @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x34b684 */

undefined2 fn_34b684(long param_1)

{
  undefined2 uVar1;
  int iVar2;
  ulong uVar3;
  
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  uVar3 = fn_139354(0x76a97a8,param_1 + 0x52,2);
  if ((uVar3 & 1) == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = *(undefined2 *)(param_1 + 0x52);
  }
  return uVar1;
}

