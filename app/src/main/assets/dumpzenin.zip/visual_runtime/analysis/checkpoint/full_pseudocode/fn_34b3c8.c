
// ================================================================================
// Powered by @imguisource_bot | Channels: @ImGui_Source_FIXNEY, @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x34b3c8 */

undefined fn_34b3c8(long param_1,long param_2)

{
  undefined uVar1;
  int iVar2;
  ulong uVar3;
  
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  uVar3 = fn_139354(0x76a97a8,param_2 + param_1,1);
  if ((uVar3 & 1) == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = *(undefined *)(param_2 + param_1);
  }
  return uVar1;
}

