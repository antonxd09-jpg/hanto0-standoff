
// ================================================================================
// Official Telegram Bot: t.me/imguisource_bot
// Official Channels:
// 1. ImGui Source -> t.me/ImGui_Source_FIXNEY
// 2. shit src 🧨 -> t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x34868c */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fn_34868c(long param_1)

{
  long *plVar1;
  long *plVar2;
  ulong **ppuVar3;
  uint uVar4;
  float *pfVar5;
  undefined8 *puVar6;
  byte *pbVar7;
  bool bVar8;
  long lVar9;
  undefined8 *puVar10;
  long lVar11;
  ulong **ppuVar12;
  undefined uVar13;
  byte bVar14;
  bool bVar15;
  bool bVar16;
  char cVar17;
  char cVar18;
  ushort uVar19;
  uint uVar20;
  int iVar21;
  long lVar22;
  ulong uVar23;
  long lVar24;
  long lVar25;
  undefined8 uVar26;
  ulong **ppuVar27;
  ulong *puVar28;
  undefined uVar29;
  long *plVar30;
  ulong **ppuVar31;
  float *pfVar32;
  ulong **ppuVar33;
  uint uVar34;
  ulong *puVar35;
  float *pfVar36;
  ulong uVar37;
  ulong **ppuVar38;
  ulong uVar39;
  ulong *puVar40;
  ulong *puVar41;
  long lVar42;
  long lVar43;
  char *pcVar44;
  undefined uVar45;
  long lVar46;
  ulong **ppuVar47;
  ulong *puVar48;
  byte bVar49;
  long *plVar50;
  long *plVar51;
  long lVar52;
  undefined4 uVar53;
  float fVar54;
  float fVar55;
  float fVar56;
  float fVar57;
  float fVar58;
  ulong *puVar59;
  float fVar60;
  float fVar61;
  float fVar62;
  float fVar63;
  undefined8 uVar64;
  undefined8 uVar65;
  undefined4 uVar66;
  float fVar67;
  float fVar68;
  float fVar69;
  undefined auVar70 [16];
  float fVar71;
  undefined auVar72 [16];
  float fVar73;
  float fVar74;
  float fVar75;
  float fVar76;
  float fVar77;
  float fVar78;
  float fVar79;
  float fVar80;
  float fVar81;
  float fVar82;
  undefined8 uStack_fc8;
  undefined8 uStack_fa0;
  undefined8 uStack_f98;
  undefined8 *puStack_f90;
  ulong *puStack_f50;
  long lStack_f48;
  undefined8 uStack_f40;
  float afStack_f38 [2];
  undefined2 uStack_f30;
  undefined2 uStack_f2e;
  float fStack_f2c;
  float fStack_f28;
  byte bStack_f20;
  undefined uStack_f1f;
  undefined2 uStack_f1e;
  float fStack_f1c;
  float fStack_f18;
  undefined4 uStack_f14;
  long *plStack_f10;
  long lStack_f08;
  int iStack_f00;
  undefined8 uStack_ef8;
  undefined8 uStack_ef0;
  undefined8 uStack_ee8;
  char cStack_ee0;
  undefined8 uStack_ed8;
  undefined8 uStack_ed0;
  undefined8 uStack_ec8;
  undefined8 uStack_ec0;
  undefined uStack_eb8;
  undefined5 uStack_eb4;
  undefined3 uStack_eaf;
  undefined4 uStack_eac;
  char cStack_ea8;
  undefined8 uStack_ea0;
  undefined8 auStack_e98 [2];
  undefined8 auStack_e88 [3];
  undefined auStack_e6c [4];
  undefined8 auStack_e68 [377];
  long lStack_2a0;
  undefined uStack_298;
  long lStack_290;
  float fStack_288;
  float fStack_284;
  float fStack_280;
  undefined uStack_27c;
  undefined8 uStack_278;
  undefined uStack_270;
  undefined8 uStack_26c;
  undefined uStack_264;
  int iStack_260;
  undefined uStack_25c;
  undefined uStack_258;
  undefined8 uStack_254;
  float fStack_24c;
  undefined4 uStack_248;
  undefined8 uStack_240;
  ulong *puStack_238;
  undefined8 uStack_230;
  undefined8 uStack_228;
  undefined8 uStack_220;
  undefined8 uStack_218;
  undefined8 uStack_210;
  undefined8 uStack_208;
  undefined8 uStack_200;
  undefined8 uStack_1f8;
  undefined8 uStack_1f0;
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  undefined8 uStack_1d8;
  undefined8 uStack_1d0;
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined8 uStack_198;
  undefined8 uStack_190;
  undefined8 uStack_188;
  undefined8 uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined8 uStack_158;
  undefined8 uStack_150;
  undefined8 uStack_148;
  undefined8 uStack_140;
  undefined8 uStack_138;
  undefined8 uStack_130;
  undefined8 uStack_128;
  undefined8 uStack_120;
  undefined8 uStack_118;
  undefined8 uStack_110;
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined8 uStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  long lStack_b8;
  
  lVar9 = tpidr_el0;
  lStack_b8 = *(long *)(lVar9 + 0x28);
  if (((bRam0000000006d35970 | bRam0000000006d35a98) == 0) &&
     (lVar22 = fn_36ece4(), *(char *)(lVar22 + 0x1304) == '\0')) {
    bVar15 = bRam0000000006d35c8c != 0;
  }
  else {
    bVar15 = true;
  }
  lVar22 = fn_36ece4();
  if ((*(char *)(lVar22 + 0x1544) == '\0') && (*(char *)(lVar22 + 0x1568) == '\0')) {
    bVar16 = *(char *)(lVar22 + 0x158c) != '\0';
    bVar8 = bVar15;
    if (bVar16) {
      bVar8 = true;
    }
    plRam0000000007871da0 = plRam0000000007871d98;
    if (!bVar8) {
      if (puRam0000000007871db0 == puRam0000000007871db8) {
        fn_34bad0();
        puRam0000000007871db8 = puRam0000000007871db0;
        lRam0000000007871de0 = 0;
        plRam0000000007871da0 = plRam0000000007871d98;
        uRam0000000007871df0 = 0;
        uRam0000000007871de8 = 0;
        uRam0000000007871e00 = 0;
        uRam0000000007871df8 = 0;
        uRam0000000007871e10 = 0;
        uRam0000000007871e08 = 0;
        uRam0000000007871e20 = 0;
        uRam0000000007871e18 = 0;
        uRam0000000007871e30 = 0;
        uRam0000000007871e28 = 0;
        uRam0000000007871e40 = 0;
        uRam0000000007871e38 = 0;
        uRam0000000007871e50 = 0;
        uRam0000000007871e48 = 0;
        uRam0000000007871e60 = 0;
        uRam0000000007871e58 = 0;
        uRam0000000007871e70 = 0;
        uRam0000000007871e68 = 0;
        uRam0000000007871e80 = 0;
        uRam0000000007871e78 = 0;
        uRam0000000007871e90 = 0;
        uRam0000000007871e88 = 0;
        uRam0000000007871ea0 = 0;
        uRam0000000007871e98 = 0;
        uRam0000000007871eb0 = 0;
        uRam0000000007871ea8 = 0;
        uRam0000000007871ec0 = 0;
        uRam0000000007871eb8 = 0;
        uRam0000000007871ed0 = 0;
        uRam0000000007871ec8 = 0;
        uRam0000000007871ee0 = 0;
        uRam0000000007871ed8 = 0;
        uRam0000000007871ef0 = 0;
        uRam0000000007871ee8 = 0;
        uRam0000000007871f00 = 0;
        uRam0000000007871ef8 = 0;
        uRam0000000007871f10 = 0;
        uRam0000000007871f08 = 0;
        uRam0000000007871f20 = 0;
        uRam0000000007871f18 = 0;
        uRam0000000007871f30 = 0;
        uRam0000000007871f28 = 0;
        uRam0000000007871f40 = 0;
        uRam0000000007871f38 = 0;
        uRam0000000007871f50 = 0;
        uRam0000000007871f48 = 0;
        uRam0000000007871f60 = 0;
        uRam0000000007871f58 = 0;
        lRam0000000006d35ca0 = 0;
        uRam0000000006d35cb8 = 0;
        if (*(long *)(lVar9 + 0x28) == lStack_b8) {
          uRam000000000776b1f3 = 0;
          if (plRam000000000776b1c8 != plRam000000000776b1c0) {
            uVar23 = 0;
            plVar30 = plRam000000000776b1c0;
            plVar50 = plRam000000000776b1c8;
            do {
              if ((8U >> (ulong)(*(uint *)(plVar30 + uVar23 * 6 + 1) & 0x1f) & 1) == 0) {
                uVar23 = uVar23 + 1;
                plVar2 = plRam000000000776b1c8;
              }
              else {
                puVar10 = (undefined8 *)plVar30[uVar23 * 6 + 3];
                puVar6 = (undefined8 *)plVar30[uVar23 * 6 + 2];
                plVar2 = plVar50;
                for (; puVar6 != puVar10; puVar6 = puVar6 + 3) {
                  if (((puVar6[2] != 0) && (uVar39 = fn_198128(*puVar6), (uVar39 & 1) != 0)) &&
                     (uVar39 = fn_198128(puVar6[1]), (uVar39 & 1) != 0)) {
                    fn_369c04(*puVar6,puVar6[1]);
                  }
                  puVar6[2] = 0;
                  plVar30 = plRam000000000776b1c0;
                  plVar2 = plRam000000000776b1c8;
                }
                plVar50 = plVar30 + uVar23 * 6;
                plVar51 = plVar2;
                if (plVar50 + 6 != plVar2) {
                  plVar30 = plVar30 + uVar23 * 6 + 3;
                  do {
                    plVar30[-3] = plVar30[3];
                    *(undefined4 *)(plVar30 + -2) = *(undefined4 *)(plVar30 + 4);
                    if (plVar30[-1] != 0) {
                      *plVar30 = plVar30[-1];
                      fn_6790c8();
                      *plVar30 = 0;
                      plVar30[1] = 0;
                    }
                    lVar9 = plVar30[7];
                    plVar50 = plVar50 + 6;
                    lVar24 = plVar30[6];
                    lVar22 = plVar30[5];
                    plVar30[6] = 0;
                    plVar30[7] = 0;
                    plVar30[5] = 0;
                    plVar30[1] = lVar9;
                    plVar30[2] = plVar30[8];
                    plVar1 = plVar30 + 9;
                    *plVar30 = lVar24;
                    plVar30[-1] = lVar22;
                    plVar30 = plVar30 + 6;
                    plVar51 = plRam000000000776b1c8;
                  } while (plVar1 != plVar2);
                }
                for (; plVar30 = plRam000000000776b1c0, plVar2 = plVar50, plVar51 != plVar50;
                    plVar51 = plVar51 + -6) {
                  if (plVar51[-4] != 0) {
                    plVar51[-3] = plVar51[-4];
                    fn_6790c8();
                  }
                }
              }
              plRam000000000776b1c8 = plVar2;
            } while (uVar23 < (ulong)(((long)plVar50 - (long)plVar30 >> 4) * -0x5555555555555555));
          }
          return;
        }
        goto LAB_0044ac40;
      }
      bVar16 = false;
    }
  }
  else {
    bVar16 = true;
  }
  plRam0000000007871da0 = plRam0000000007871d98;
  uStack_ef8 = 0;
  uStack_ef0 = 0;
  cStack_ee0 = '\0';
  uStack_ee8 = 0;
  uStack_eb8 = 0;
  uStack_ec0 = 0;
  uStack_ec8 = 0;
  uStack_ed0 = 0;
  uStack_ed8 = 0;
  uStack_eb4 = 0;
  uStack_eaf = 0;
  uStack_eac = 0;
  cStack_ea8 = '\0';
  lStack_f08 = 0;
  iStack_f00 = 0;
  if (((((param_1 == 0) || (uVar23 = fn_186838(param_1,&uStack_ef8), (uVar23 & 1) == 0)) ||
       ((cStack_ea8 == '\0' ||
        ((uVar23 = fn_4326cc(param_1,&lStack_f08), (uVar23 & 1) == 0 ||
         (lVar22 = fn_34b100(&UNK_0078fa7d,&UNK_00798795,0x7871f68), lVar22 == 0)))))) ||
      (lVar22 = fn_34b100(&UNK_0078fa7d,&UNK_007da56c,0x7871f70), lVar22 == 0)) ||
     (((lVar22 = fn_34b100(&UNK_0078fa7d,&UNK_007e9f86,0x7871f78), lVar22 == 0 ||
       (lVar22 = fn_34b100(&UNK_007f967c,&UNK_007a0859,0x7871f80), lVar22 == 0)) ||
      (lVar22 = fn_34b100(&UNK_007f967c,&UNK_007a085d,0x7871f88), lVar22 == 0)))) {
    fn_34bad0();
    lRam0000000007871de0 = 0;
    puRam0000000007871db8 = puRam0000000007871db0;
    uRam0000000007871df0 = 0;
    uRam0000000007871de8 = 0;
    uRam0000000007871e00 = 0;
    uRam0000000007871df8 = 0;
    uRam0000000007871e10 = 0;
    uRam0000000007871e08 = 0;
    uRam0000000007871e20 = 0;
    uRam0000000007871e18 = 0;
    uRam0000000007871e30 = 0;
    uRam0000000007871e28 = 0;
    uRam0000000007871e40 = 0;
    uRam0000000007871e38 = 0;
    uRam0000000007871e50 = 0;
    uRam0000000007871e48 = 0;
    uRam0000000007871e60 = 0;
    uRam0000000007871e58 = 0;
    uRam0000000007871e70 = 0;
    uRam0000000007871e68 = 0;
    uRam0000000007871e80 = 0;
    uRam0000000007871e78 = 0;
    uRam0000000007871e90 = 0;
    uRam0000000007871e88 = 0;
    uRam0000000007871ea0 = 0;
    uRam0000000007871e98 = 0;
    uRam0000000007871eb0 = 0;
    uRam0000000007871ea8 = 0;
    uRam0000000007871ec0 = 0;
    uRam0000000007871eb8 = 0;
    uRam0000000007871ed0 = 0;
    uRam0000000007871ec8 = 0;
    uRam0000000007871ee0 = 0;
    uRam0000000007871ed8 = 0;
    uRam0000000007871ef0 = 0;
    uRam0000000007871ee8 = 0;
    uRam0000000007871f00 = 0;
    uRam0000000007871ef8 = 0;
    uRam0000000007871f10 = 0;
    uRam0000000007871f08 = 0;
    uRam0000000007871f20 = 0;
    uRam0000000007871f18 = 0;
    uRam0000000007871f30 = 0;
    uRam0000000007871f28 = 0;
    uRam0000000007871f40 = 0;
    uRam0000000007871f38 = 0;
    uRam0000000007871f50 = 0;
    uRam0000000007871f48 = 0;
    uRam0000000007871f60 = 0;
    uRam0000000007871f58 = 0;
    plRam0000000007871da0 = plRam0000000007871d98;
    lRam0000000006d35ca0 = 0;
    uRam0000000006d35cb8 = 0;
    fn_33b6d0();
  }
  else {
    fn_18ae9c();
    imp_memset(&uStack_ea0,0,0xc00);
    lVar22 = 0;
    do {
      lVar24 = lVar22 + 0x40;
      *(undefined8 *)((long)&uStack_ea0 + lVar22) = 0;
      *(undefined *)((long)auStack_e98 + lVar22) = 0;
      *(undefined *)((long)auStack_e88 + lVar22) = 0;
      auStack_e6c[lVar22] = 0;
      *(undefined8 *)((long)auStack_e68 + lVar22) = 0;
      lVar22 = lVar24;
    } while (lVar24 != 0xc00);
    lStack_2a0 = 0;
    uStack_298 = 0;
    iStack_260 = 0;
    uStack_25c = 0;
    fStack_280 = 0.0;
    uStack_27c = 0;
    fStack_288 = 0.0;
    fStack_284 = 0.0;
    lStack_290 = 0;
    uStack_278 = 0;
    uStack_270 = 0;
    uStack_26c = 0;
    uStack_264 = 0;
    uStack_254 = 0;
    fStack_24c = 0.0;
    uStack_248 = fn_42c7f0();
    afStack_f38[0] = 0.0;
    uStack_f40 = 0;
    uVar23 = fn_42edc4(&uStack_f40);
    if (((uVar23 & 1) == 0) || (ABS((float)uStack_f40) == INFINITY)) {
LAB_004488f8:
      puStack_f90 = (undefined8 *)0x0;
      uStack_258 = false;
    }
    else {
      if ((INFINITY <= ABS(uStack_f40._4_4_)) && (ABS(uStack_f40._4_4_) <= INFINITY))
      goto LAB_004488f8;
      fVar54 = ABS(afStack_f38[0]);
      puVar6 = &uStack_f40;
      if (fVar54 >= INFINITY) {
        puVar6 = (undefined8 *)0x0;
      }
      uStack_258 = INFINITY < fVar54 || fVar54 < INFINITY;
      puStack_f90 = &uStack_f40;
      if (fVar54 <= INFINITY) {
        puStack_f90 = puVar6;
      }
    }
    bVar8 = (bool)uStack_258;
    fStack_24c = afStack_f38[0];
    uStack_254 = uStack_f40;
    lVar22 = fn_36ece4();
    lVar24 = fn_36ece4();
    bVar14 = bRam0000000006d35970;
    bVar49 = *(byte *)(lVar22 + 0x1304);
    lRam0000000007871de0 = 0;
    ppuRam0000000007871dd0 = ppuRam0000000007871dc8;
    if ((((byte)(bRam0000000006d35970 | *(byte *)(lVar24 + 0x1544) | bVar49) != 0) ||
        (*(byte *)(lVar24 + 0x158c) != 0)) || (puRam0000000007871db0 != puRam0000000007871db8)) {
      if (((bRam00000000076ac3f8 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
      }
      if (((bRam00000000076ac3f8 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
      }
      if (((bRam00000000076ac3f8 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
      }
      fVar54 = 150.0;
      if (fRam0000000006d35974 <= 150.0) {
        fVar54 = fRam0000000006d35974;
      }
      fVar60 = 5.0;
      if (5.0 <= fRam0000000006d35974) {
        fVar60 = fVar54;
      }
      if (iStack_f00 < 1) {
        ppuVar27 = (ulong **)0x0;
        uStack_c8 = 0;
        uStack_d0 = 0;
        uStack_d8 = 0;
        uStack_e0 = 0;
        uStack_e8 = 0;
        uStack_f0 = 0;
        uStack_f8 = 0;
        uStack_100 = 0;
        uStack_108 = 0;
        uStack_110 = 0;
        uStack_118 = 0;
        uStack_120 = 0;
        uStack_128 = 0;
        uStack_130 = 0;
        uStack_138 = 0;
        uStack_140 = 0;
        uStack_148 = 0;
        uStack_150 = 0;
        uStack_158 = 0;
        uStack_160 = 0;
        uStack_168 = 0;
        uStack_170 = 0;
        uStack_178 = 0;
        uStack_180 = 0;
        uStack_188 = 0;
        uStack_190 = 0;
        uStack_198 = 0;
        uStack_1a0 = 0;
        uStack_1a8 = 0;
        uStack_1b0 = 0;
        uStack_1b8 = 0;
        uStack_1c0 = 0;
        uStack_1c8 = 0;
        uStack_1d0 = 0;
        uStack_1d8 = 0;
        uStack_1e0 = 0;
        uStack_1e8 = 0;
        uStack_1f0 = 0;
        uStack_1f8 = 0;
        uStack_200 = 0;
        uStack_208 = 0;
        uStack_210 = 0;
        uStack_218 = 0;
        uStack_220 = 0;
        uStack_228 = 0;
        uStack_230 = 0;
        puStack_238 = (ulong *)0x0;
        uStack_240 = (ulong *)0x0;
      }
      else {
        pfVar36 = (float *)((ulong)&uStack_f40 | 4);
        pfVar5 = afStack_f38;
        lVar42 = 0;
        if (!bVar8) {
          pfVar36 = (float *)0x4;
          pfVar5 = (float *)0x8;
        }
        puStack_f50 = (ulong *)0x0;
        do {
          lVar52 = 0x76a97a8;
          plVar30 = (long *)(lStack_f08 + lVar42 * 8);
          uVar23 = fn_139354(0x76a97a8,plVar30,8);
          if (((uVar23 & 1) != 0) && (lVar46 = *plVar30, lVar46 != 0)) {
            uVar39 = (ulong)uRam00000000076aa95c;
            uVar23 = fn_139354(0x76a97a8,uVar39 + lVar46,1);
            if (((uVar23 & 1) != 0) &&
               ((*(char *)(uVar39 + lVar46) == '\n' &&
                (uVar23 = fn_43da54(0x76a9768,lVar46,uRam0000000007871f68), (uVar23 & 1) != 0)))) {
              uVar23 = fn_139354(0x76a97a8,lVar46 + 0x60,8);
              if ((uVar23 & 1) == 0) {
                lVar43 = 0;
              }
              else {
                lVar43 = *(long *)(lVar46 + 0x60);
              }
              lVar25 = fn_34b1c8(lVar46,uRam0000000007871f78);
              if ((((lVar43 != 0) && (lVar25 != 0)) &&
                  (uVar23 = fn_43da54(0x76a9768,lVar43,uRam0000000007871f70), (uVar23 & 1) != 0)) &&
                 (uVar20 = fn_34b3c8(lVar25,0x10), (uVar20 & 0xff) != 0)) {
                uVar23 = fn_139354(0x76a97a8,lVar43 + 0x48,8);
                if ((uVar23 & 1) == 0) {
                  uVar26 = 0;
                }
                else {
                  uVar26 = *(undefined8 *)(lVar43 + 0x48);
                }
                puStack_238 = (ulong *)((ulong)puStack_238 & 0xffffffff00000000);
                uStack_240 = (ulong *)0x0;
                uVar23 = fn_198128();
                if ((((uVar23 & 1) != 0) &&
                    (uVar23 = fn_1967e0(uVar26,&uStack_240), (uVar23 & 1) != 0)) &&
                   ((ABS((float)uStack_240) != INFINITY &&
                    ((ABS(uStack_240._4_4_) != INFINITY && (ABS(puStack_238._0_4_) != INFINITY))))))
                {
                  if (puStack_f90 != (undefined8 *)0x0) {
                    uVar53 = NEON_fmadd((float)uStack_240 - *(float *)puStack_f90,
                                        (float)uStack_240 - *(float *)puStack_f90,
                                        (uStack_240._4_4_ - *pfVar36) *
                                        (uStack_240._4_4_ - *pfVar36));
                    fVar54 = (float)NEON_fmadd(puStack_238._0_4_ - *pfVar5,
                                               puStack_238._0_4_ - *pfVar5,uVar53);
                    fVar54 = SQRT(fVar54);
                    if (fVar54 <= fVar60) goto LAB_00448e88;
                    ppuVar27 = (ulong **)fn_34b47c(lVar46);
                    ppuVar31 = ppuRam0000000007871dd0;
                    ppuVar3 = ppuRam0000000007871dc8;
                    if (ppuVar27 == (ulong **)0x0) goto LAB_00448c8c;
                    if (ppuRam0000000007871dd0 < ppuRam0000000007871dd8) {
                      *ppuRam0000000007871dd0 = (ulong *)ppuVar27;
                      ppuRam0000000007871dd0 = ppuRam0000000007871dd0 + 1;
                      goto LAB_00448c8c;
                    }
                    lVar46 = (long)ppuRam0000000007871dd0 - (long)ppuRam0000000007871dc8;
                    puVar48 = (ulong *)((lVar46 >> 3) + 1);
                    if ((ulong)puVar48 >> 0x3d == 0) {
                      puVar41 = (ulong *)((long)ppuRam0000000007871dd8 -
                                          (long)ppuRam0000000007871dc8 >> 2);
                      if (puVar41 <= puVar48) {
                        puVar41 = puVar48;
                      }
                      if (0x7ffffffffffffff7 <
                          (ulong)((long)ppuRam0000000007871dd8 - (long)ppuRam0000000007871dc8)) {
                        puVar41 = (ulong *)0x1fffffffffffffff;
                      }
                      if (puVar41 == (ulong *)0x0) {
                        lVar52 = 0;
                      }
                      else {
                        if ((ulong)puVar41 >> 0x3d != 0) goto LAB_0044a6dc;
                        lVar52 = fn_679020((long)puVar41 << 3);
                      }
                      ppuVar33 = (ulong **)(lVar52 + (lVar46 >> 3) * 8);
                      lVar43 = (long)ppuVar31 - (long)ppuVar3;
                      ppuVar47 = ppuVar33 + 1;
                      *ppuVar33 = (ulong *)ppuVar27;
                      if (lVar43 != 0) {
                        uVar23 = lVar43 - 8;
                        ppuVar27 = ppuVar31;
                        if ((0x37 < uVar23) && (0x1f < (ulong)((long)ppuVar31 + (-lVar46 - lVar52)))
                           ) {
                          uVar23 = (uVar23 >> 3) + 1;
                          uVar37 = uVar23 & 0x3ffffffffffffffc;
                          ppuVar27 = ppuVar31 + -uVar37;
                          ppuVar33 = ppuVar33 + -uVar37;
                          ppuVar38 = (ulong **)(lVar52 + lVar46 + -0x10);
                          ppuVar31 = ppuVar31 + -2;
                          uVar39 = uVar37;
                          do {
                            ppuVar12 = ppuVar31 + -1;
                            puVar28 = ppuVar31[-2];
                            puVar35 = ppuVar31[1];
                            puVar48 = *ppuVar31;
                            uVar39 = uVar39 - 4;
                            ppuVar31 = ppuVar31 + -4;
                            ppuVar38[-1] = *ppuVar12;
                            ppuVar38[-2] = puVar28;
                            ppuVar38[1] = puVar35;
                            *ppuVar38 = puVar48;
                            ppuVar38 = ppuVar38 + -4;
                          } while (uVar39 != 0);
                          ppuVar31 = ppuRam0000000007871dc8;
                          if (uVar23 == uVar37) goto LAB_0044933c;
                        }
                        do {
                          ppuVar27 = ppuVar27 + -1;
                          ppuVar33 = ppuVar33 + -1;
                          *ppuVar33 = *ppuVar27;
                          ppuVar31 = ppuRam0000000007871dc8;
                        } while (ppuVar27 != ppuVar3);
                      }
LAB_0044933c:
                      ppuRam0000000007871dd8 = (ulong **)(lVar52 + (long)puVar41 * 8);
                      ppuRam0000000007871dc8 = ppuVar33;
                      ppuRam0000000007871dd0 = ppuVar47;
                      if (ppuVar31 != (ulong **)0x0) {
                        fn_6790c8(ppuVar31);
                        ppuRam0000000007871dd0 = ppuVar47;
                      }
                      goto LAB_00448c8c;
                    }
LAB_0044aa60:
                    if (*(long *)(lVar9 + 0x28) != lStack_b8) goto LAB_0044ac40;
                    fn_19e854(0x7871dc8);
                    goto LAB_0044aa80;
                  }
                  fVar54 = 0.0;
LAB_00448e88:
                  uVar39 = (ulong)uRam00000000076aa958;
                  uVar23 = fn_139354(0x76a97a8,uVar39 + lVar46,8);
                  puVar48 = uStack_240;
                  if ((uVar23 & 1) == 0) {
                    uStack_fc8 = 0;
                  }
                  else {
                    uStack_fc8 = *(undefined8 *)(uVar39 + lVar46);
                  }
                  uVar53 = puStack_238._0_4_;
                  uVar23 = fn_139354(0x76a97a8,lVar43 + 0x18,8);
                  if ((uVar23 & 1) == 0) {
                    lVar43 = 0;
                  }
                  else {
                    lVar43 = *(long *)(lVar43 + 0x18);
                  }
                  puVar28 = (ulong *)fn_34b47c(lVar46);
                  ppuVar27 = ppuRam0000000007871dd0;
                  ppuVar3 = ppuRam0000000007871dc8;
                  if (puVar28 != (ulong *)0x0) {
                    if (ppuRam0000000007871dd0 < ppuRam0000000007871dd8) {
                      *ppuRam0000000007871dd0 = puVar28;
                      ppuRam0000000007871dd0 = ppuRam0000000007871dd0 + 1;
                    }
                    else {
                      lVar46 = (long)ppuRam0000000007871dd0 - (long)ppuRam0000000007871dc8;
                      puVar35 = (ulong *)((lVar46 >> 3) + 1);
                      if ((ulong)puVar35 >> 0x3d != 0) goto LAB_0044aa60;
                      puVar41 = (ulong *)((long)ppuRam0000000007871dd8 -
                                          (long)ppuRam0000000007871dc8 >> 2);
                      if (puVar41 <= puVar35) {
                        puVar41 = puVar35;
                      }
                      if (0x7ffffffffffffff7 <
                          (ulong)((long)ppuRam0000000007871dd8 - (long)ppuRam0000000007871dc8)) {
                        puVar41 = (ulong *)0x1fffffffffffffff;
                      }
                      if (puVar41 == (ulong *)0x0) {
                        lVar52 = 0;
                      }
                      else {
                        if ((ulong)puVar41 >> 0x3d != 0) goto LAB_0044a6dc;
                        lVar52 = fn_679020((long)puVar41 << 3);
                      }
                      ppuVar31 = (ulong **)(lVar52 + (lVar46 >> 3) * 8);
                      lVar11 = (long)ppuVar27 - (long)ppuVar3;
                      ppuVar33 = ppuVar31 + 1;
                      *ppuVar31 = puVar28;
                      if (lVar11 != 0) {
                        uVar23 = lVar11 - 8;
                        ppuVar47 = ppuVar27;
                        if ((0x37 < uVar23) && (0x1f < (ulong)((long)ppuVar27 + (-lVar46 - lVar52)))
                           ) {
                          uVar23 = (uVar23 >> 3) + 1;
                          uVar37 = uVar23 & 0x3ffffffffffffffc;
                          ppuVar47 = ppuVar27 + -uVar37;
                          ppuVar31 = ppuVar31 + -uVar37;
                          ppuVar38 = (ulong **)(lVar52 + lVar46 + -0x10);
                          ppuVar27 = ppuVar27 + -2;
                          uVar39 = uVar37;
                          do {
                            ppuVar12 = ppuVar27 + -1;
                            puVar40 = ppuVar27[-2];
                            puVar59 = ppuVar27[1];
                            puVar35 = *ppuVar27;
                            uVar39 = uVar39 - 4;
                            ppuVar27 = ppuVar27 + -4;
                            ppuVar38[-1] = *ppuVar12;
                            ppuVar38[-2] = puVar40;
                            ppuVar38[1] = puVar59;
                            *ppuVar38 = puVar35;
                            ppuVar38 = ppuVar38 + -4;
                          } while (uVar39 != 0);
                          ppuVar27 = ppuRam0000000007871dc8;
                          if (uVar23 == uVar37) goto LAB_0044905c;
                        }
                        do {
                          ppuVar47 = ppuVar47 + -1;
                          ppuVar31 = ppuVar31 + -1;
                          *ppuVar31 = *ppuVar47;
                          ppuVar27 = ppuRam0000000007871dc8;
                        } while (ppuVar47 != ppuVar3);
                      }
LAB_0044905c:
                      ppuRam0000000007871dd8 = (ulong **)(lVar52 + (long)puVar41 * 8);
                      ppuRam0000000007871dc8 = ppuVar31;
                      ppuRam0000000007871dd0 = ppuVar33;
                      if (ppuVar27 != (ulong **)0x0) {
                        fn_6790c8(ppuVar27);
                        ppuRam0000000007871dd0 = ppuVar33;
                      }
                    }
                  }
                  uVar23 = fn_198128(lVar43);
                  if ((uVar23 & 1) == 0) {
                    lVar43 = 0;
                  }
                  if (puStack_f50 == (ulong *)0x30) {
                    puVar35 = (ulong *)0x1;
                    pfVar32 = (float *)0x7872060;
                    puVar40 = (ulong *)0x0;
                    do {
                      puVar41 = puVar35;
                      if (*pfVar32 <= *(float *)((long)puVar40 * 0x58 + 0x7872008)) {
                        puVar41 = puVar40;
                      }
                      puVar35 = (ulong *)((long)puVar35 + 1);
                      pfVar32 = pfVar32 + 0x16;
                      puVar40 = puVar41;
                    } while (puVar35 != (ulong *)0x30);
                    puStack_f50 = (ulong *)0x30;
                    if (*(float *)((long)puVar41 * 0x58 + 0x7872008) <= fVar54) goto LAB_00448c8c;
                  }
                  else {
                    puVar41 = puStack_f50;
                    puStack_f50 = (ulong *)((long)puStack_f50 + 1);
                  }
                  if (bVar14 == 0) {
                    uVar45 = 0;
                    uVar26 = 0;
                    iVar21 = 0;
                    uStack_f98 = 0;
                    uStack_fa0 = 0;
                    uVar29 = 0;
                    uVar34 = 0;
                  }
                  else {
                    uVar26 = 0;
                    fStack_f18 = 0.0;
                    bStack_f20 = 0;
                    uStack_f1f = 0;
                    uStack_f1e = 0;
                    fStack_f1c = 0.0;
                    fStack_f28 = 0.0;
                    uStack_f30 = 0;
                    uStack_f2e = 0;
                    fStack_f2c = 0.0;
                    uStack_f98 = 0;
                    uStack_fa0 = 0;
                    if ((lVar43 == 0) ||
                       (uVar23 = fn_19bb30(lVar43,&bStack_f20,&uStack_f30), (uVar23 & 1) == 0)) {
LAB_004491c8:
                      uVar45 = 0;
                    }
                    else {
                      auVar70._4_4_ = fStack_f28;
                      auVar70._0_4_ = fStack_f2c;
                      fVar62 = (float)CONCAT22(uStack_f2e,uStack_f30);
                      fVar55 = (float)NEON_fmadd(fVar62,fVar62,fStack_f2c * fStack_f2c);
                      if (4.0 <= SQRT(fVar55 + fStack_f28 * fStack_f28)) goto LAB_004491c8;
                      fVar55 = (float)CONCAT22(uStack_f1e,CONCAT11(uStack_f1f,bStack_f20));
                      auVar72 = NEON_ext(ZEXT416((uint)fVar62),ZEXT416((uint)fVar62),4,1);
                      uVar45 = 1;
                      uVar26 = CONCAT44(fStack_f28 + fStack_f18,fStack_f2c + fStack_f1c);
                      auVar70._8_8_ = 0;
                      auVar70 = NEON_ext(auVar72,auVar70,0xc,1);
                      uStack_f98 = CONCAT44(fVar55 + fVar62,fStack_f18 - auVar70._8_4_);
                      uStack_fa0 = CONCAT44(fStack_f1c - auVar70._4_4_,fVar55 - auVar70._0_4_);
                    }
                    iVar21 = fn_18b394(uVar20);
                    if (iVar21 < 1) {
                      uVar29 = 0;
                      iVar21 = 0;
                      uVar34 = 0;
                    }
                    else {
                      uVar19 = fn_34b684(lVar25);
                      uVar4 = (uint)uVar19;
                      uVar29 = 1;
                      if (0x3e6 < uVar4) {
                        uVar4 = 999;
                      }
                      uVar34 = 0;
                      if (-1 < (short)uVar19) {
                        uVar34 = uVar4;
                      }
                    }
                  }
                  lVar52 = (long)puVar41 * 0x58;
                  *(undefined8 *)(lVar52 + 0x7871fb8) = uStack_fc8;
                  *(undefined *)(lVar52 + 0x7871fec) = uVar29;
                  *(undefined *)(lVar52 + 0x7871fd0) = uVar45;
                  *(char *)(lVar52 + 0x7871fc0) = (char)uVar20;
                  *(ulong **)(lVar52 + 0x7871fc4) = puVar48;
                  *(undefined4 *)(lVar52 + 0x7871fcc) = uVar53;
                  *(undefined8 *)(lVar52 + 0x7871fdc) = uStack_f98;
                  *(undefined8 *)(lVar52 + 0x7871fd4) = uStack_fa0;
                  *(undefined8 *)(lVar52 + 0x7871fe4) = uVar26;
                  *(uint *)(lVar52 + 0x7871ff0) = uVar34;
                  *(int *)(lVar52 + 0x7871ff4) = iVar21;
                  *(long *)(lVar52 + 0x7871ff8) = lVar43;
                  *(ulong **)(lVar52 + 0x7872000) = puVar28;
                  *(float *)(lVar52 + 0x7872008) = fVar54;
                }
              }
            }
          }
LAB_00448c8c:
          lVar52 = 0x76a97a8;
          lVar42 = lVar42 + 1;
        } while (lVar42 < iStack_f00);
        uStack_c8 = 0;
        uStack_d0 = 0;
        uStack_d8 = 0;
        uStack_e0 = 0;
        uStack_e8 = 0;
        uStack_f0 = 0;
        uStack_f8 = 0;
        uStack_100 = 0;
        uStack_108 = 0;
        uStack_110 = 0;
        uStack_118 = 0;
        uStack_120 = 0;
        uStack_128 = 0;
        uStack_130 = 0;
        uStack_138 = 0;
        uStack_140 = 0;
        uStack_148 = 0;
        uStack_150 = 0;
        uStack_158 = 0;
        uStack_160 = 0;
        uStack_168 = 0;
        uStack_170 = 0;
        uStack_178 = 0;
        uStack_180 = 0;
        uStack_188 = 0;
        uStack_190 = 0;
        uStack_198 = 0;
        uStack_1a0 = 0;
        uStack_1a8 = 0;
        uStack_1b0 = 0;
        uStack_1b8 = 0;
        uStack_1c0 = 0;
        uStack_1c8 = 0;
        uStack_1d0 = 0;
        uStack_1d8 = 0;
        uStack_1e0 = 0;
        uStack_1e8 = 0;
        uStack_1f0 = 0;
        uStack_1f8 = 0;
        uStack_200 = 0;
        uStack_208 = 0;
        uStack_210 = 0;
        uStack_218 = 0;
        uStack_220 = 0;
        uStack_228 = 0;
        uStack_230 = 0;
        puStack_238 = (ulong *)0x0;
        uStack_240 = (ulong *)0x0;
        if (puStack_f50 == (ulong *)0x0) {
          ppuVar27 = (ulong **)0x0;
        }
        else {
          puVar41 = (ulong *)0x0;
          puVar48 = (ulong *)0x0;
          do {
            lVar46 = lStack_2a0;
            lVar42 = (long)puVar41 * 0x58;
            pbVar7 = (byte *)(lVar24 + 0x158c);
            if (*(char *)(lVar42 + 0x7871fc0) != 'd') {
              pbVar7 = (byte *)(lVar24 + 0x1544);
            }
            ppuVar27 = (ulong **)puVar48;
            if ((*(long *)(lVar42 + 0x7872000) != 0) &&
               (((bVar49 != 0 && (*(char *)(lVar22 + 0x1305) != '\0')) ||
                ((*pbVar7 != 0 && (pbVar7[1] != 0)))))) {
              ppuVar27 = (ulong **)((long)puVar48 + 1);
              (&uStack_240)[(long)puVar48] = *(long *)(lVar42 + 0x7872000);
            }
            if (bVar14 != 0) {
              uVar26 = *(undefined8 *)(lVar42 + 0x7871fb8);
              uVar65 = *(undefined8 *)(lVar42 + 0x7871fd0);
              uVar64 = *(undefined8 *)(lVar42 + 0x7871fc8);
              lVar43 = lStack_2a0 * 0x40;
              lVar25 = lStack_2a0 * 8;
              lStack_2a0 = lStack_2a0 + 1;
              auStack_e98[lVar46 * 8] = *(undefined8 *)(lVar42 + 0x7871fc0);
              (&uStack_ea0)[lVar25] = uVar26;
              auStack_e88[lVar46 * 8] = uVar65;
              auStack_e98[lVar46 * 8 + 1] = uVar64;
              uVar26 = *(undefined8 *)(lVar42 + 0x7871fd8);
              uVar65 = *(undefined8 *)(lVar42 + 0x7871ff0);
              uVar64 = *(undefined8 *)(lVar42 + 0x7871fe8);
              auStack_e88[lVar46 * 8 + 2] = *(undefined8 *)(lVar42 + 0x7871fe0);
              auStack_e88[lVar46 * 8 + 1] = uVar26;
              auStack_e68[lVar46 * 8] = uVar65;
              *(undefined8 *)(&stack0xfffffffffffff190 + lVar43) = uVar64;
            }
            if ((bVar49 != 0) && (lVar42 = *(long *)((long)puVar41 * 0x58 + 0x7871ff8), lVar42 != 0)
               ) {
              lVar46 = lRam0000000007871de0 * 8;
              lRam0000000007871de0 = lRam0000000007871de0 + 1;
              *(long *)(lVar46 + 0x7871de8) = lVar42;
            }
            plVar30 = plRam0000000007871da0;
            plVar50 = plRam0000000007871d98;
            if ((*pbVar7 != 0) &&
               (lVar42 = *(long *)((long)puVar41 * 0x58 + 0x7871ff8), lVar42 != 0)) {
              if (plRam0000000007871da0 < plRam0000000007871da8) {
                *plRam0000000007871da0 = lVar42;
                plRam0000000007871da0[1] = (long)pbVar7;
                plRam0000000007871da0 = plRam0000000007871da0 + 2;
              }
              else {
                lVar46 = (long)plRam0000000007871da0 - (long)plRam0000000007871d98 >> 4;
                uVar23 = lVar46 + 1;
                if (uVar23 >> 0x3c != 0) goto LAB_0044a6f4;
                uVar39 = (long)plRam0000000007871da8 - (long)plRam0000000007871d98 >> 3;
                if (uVar39 <= uVar23) {
                  uVar39 = uVar23;
                }
                if (0x7fffffffffffffef <
                    (ulong)((long)plRam0000000007871da8 - (long)plRam0000000007871d98)) {
                  uVar39 = 0xfffffffffffffff;
                }
                if (uVar39 == 0) {
                  lVar43 = 0;
                }
                else {
                  if (uVar39 >> 0x3c != 0) goto LAB_0044a6dc;
                  lVar43 = fn_679020(uVar39 << 4);
                }
                plVar2 = (long *)(lVar43 + lVar46 * 0x10);
                *plVar2 = lVar42;
                plVar2[1] = (long)pbVar7;
                plVar51 = plVar2;
                plVar1 = plVar30;
                for (; plVar30 != plVar50; plVar30 = plVar30 + -2) {
                  lVar42 = plVar30[-2];
                  plVar51[-1] = plVar30[-1];
                  plVar51[-2] = lVar42;
                  plVar51 = plVar51 + -2;
                  plVar1 = plRam0000000007871d98;
                }
                plRam0000000007871da8 = (long *)(lVar43 + uVar39 * 0x10);
                plVar2 = plVar2 + 2;
                plRam0000000007871d98 = plVar51;
                plRam0000000007871da0 = plVar2;
                if (plVar1 != (long *)0x0) {
                  fn_6790c8(plVar1);
                  plRam0000000007871da0 = plVar2;
                }
              }
            }
            puVar41 = (ulong *)((long)puVar41 + 1);
            puVar48 = (ulong *)ppuVar27;
          } while (puVar41 != puStack_f50);
        }
      }
      if (((bRam00000000076ac3f8 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
      }
      if (ppuVar27 != (ulong **)0x0) {
        puVar48 = (ulong *)0x0;
        do {
          uVar23 = (&uStack_240)[(long)puVar48];
          for (puVar41 = puRam0000000007871db0; puVar41 != puRam0000000007871db8;
              puVar41 = puVar41 + 2) {
            if (*puVar41 == uVar23) goto LAB_00449768;
          }
          uVar39 = fn_139354(0x76a97a8,(byte *)(uVar23 + 0x12),1);
          puVar28 = puRam0000000007871db8;
          puVar41 = puRam0000000007871db0;
          if ((uVar39 & 1) == 0) {
            bVar49 = 0;
          }
          else {
            bVar49 = *(byte *)(uVar23 + 0x12);
          }
          if (puRam0000000007871db8 < puRam0000000007871dc0) {
            *puRam0000000007871db8 = uVar23;
            *(byte *)(puRam0000000007871db8 + 1) = bVar49;
            puRam0000000007871db8 = puRam0000000007871db8 + 2;
          }
          else {
            lVar52 = (long)puRam0000000007871db8 - (long)puRam0000000007871db0 >> 4;
            uVar39 = lVar52 + 1;
            if (uVar39 >> 0x3c != 0) {
              if (*(long *)(lVar9 + 0x28) == lStack_b8) {
                fn_34b748();
                goto LAB_0044a6dc;
              }
              goto LAB_0044ac40;
            }
            uVar37 = (long)puRam0000000007871dc0 - (long)puRam0000000007871db0 >> 3;
            if (uVar37 <= uVar39) {
              uVar37 = uVar39;
            }
            if (0x7fffffffffffffef <
                (ulong)((long)puRam0000000007871dc0 - (long)puRam0000000007871db0)) {
              uVar37 = 0xfffffffffffffff;
            }
            if (uVar37 == 0) {
              lVar22 = 0;
            }
            else {
              if (uVar37 >> 0x3c != 0) goto LAB_0044a6dc;
              lVar22 = fn_679020(uVar37 << 4);
            }
            puVar35 = (ulong *)(lVar22 + lVar52 * 0x10);
            *puVar35 = uVar23;
            *(byte *)(puVar35 + 1) = bVar49;
            puVar40 = puVar35;
            puVar59 = puVar28;
            while (puVar28 != puVar41) {
              bVar49 = *(byte *)(puVar28 + -1);
              puVar40[-2] = puVar28[-2];
              *(byte *)(puVar40 + -1) = bVar49;
              puVar40 = puVar40 + -2;
              puVar28 = puVar28 + -2;
              puVar59 = puRam0000000007871db0;
            }
            puRam0000000007871dc0 = (ulong *)(lVar22 + uVar37 * 0x10);
            puVar35 = puVar35 + 2;
            puRam0000000007871db0 = puVar40;
            puRam0000000007871db8 = puVar35;
            if (puVar59 != (ulong *)0x0) {
              fn_6790c8(puVar59);
              puRam0000000007871db8 = puVar35;
            }
          }
LAB_00449768:
          pcVar44 = (char *)(uVar23 + 0x12);
          uVar23 = fn_139354(0x76a97a8,pcVar44,1);
          if ((((uVar23 & 1) == 0) || (*pcVar44 != '\x01')) &&
             (uVar23 = fn_13955c(0x76a97a8,pcVar44,1), (uVar23 & 1) != 0)) {
            *pcVar44 = '\x01';
          }
          puVar48 = (ulong *)((long)puVar48 + 1);
        } while ((ulong **)puVar48 != ppuVar27);
      }
      if (puRam0000000007871db8 != puRam0000000007871db0) {
        uVar23 = 0;
        puVar41 = puRam0000000007871db0;
        puVar48 = puRam0000000007871db8;
        do {
          ppuVar3 = (ulong **)(puVar41 + uVar23 * 2);
          if (ppuVar27 == (ulong **)0x0) {
            ppuVar31 = (ulong **)&uStack_240;
          }
          else {
            ppuVar33 = (ulong **)&uStack_240;
            lVar22 = (long)ppuVar27 * 8;
            do {
              ppuVar31 = ppuVar33;
              if (*ppuVar33 == *ppuVar3) break;
              lVar22 = lVar22 + -8;
              ppuVar33 = ppuVar33 + 1;
              ppuVar31 = (ulong **)(&uStack_240 + (long)ppuVar27);
            } while (lVar22 != 0);
          }
          ppuVar33 = ppuRam0000000007871dc8;
          if (ppuRam0000000007871dc8 != ppuRam0000000007871dd0) {
            ppuVar47 = ppuRam0000000007871dc8;
            do {
              ppuVar33 = ppuVar47;
              if (*ppuVar33 == *ppuVar3) break;
              ppuVar47 = ppuVar33 + 1;
              ppuVar33 = ppuRam0000000007871dd0;
            } while (ppuVar47 != ppuRam0000000007871dd0);
          }
          if ((ppuVar31 == (ulong **)(&uStack_240 + (long)ppuVar27)) &&
             (ppuVar33 != ppuRam0000000007871dd0)) {
            puVar48 = *ppuVar3;
            uVar39 = fn_13955c(0x76a97a8,(long)puVar48 + 0x12,1);
            if ((uVar39 & 1) != 0) {
              *(undefined *)((long)puVar48 + 0x12) = *(undefined *)(ppuVar3 + 1);
            }
            puVar48 = puRam0000000007871db0 + uVar23 * 2;
            lVar22 = (long)puRam0000000007871db8 - (long)(puVar48 + 2);
            if (lVar22 != 0) {
              imp_memmove(puVar48,puVar48 + 2,lVar22 + -7);
            }
            puVar48 = (ulong *)((long)puVar48 + lVar22);
            puVar41 = puRam0000000007871db0;
            puRam0000000007871db8 = puVar48;
          }
          else {
            uVar23 = uVar23 + 1;
          }
        } while (uVar23 < (ulong)((long)puVar48 - (long)puVar41 >> 4));
      }
    }
    lVar52 = 0x76a97a8;
    lVar22 = fn_36ece4();
    ppuVar27 = (ulong **)(lVar22 + 0x1568);
    if ((*(byte *)ppuVar27 != 0) || (*(char *)(lVar22 + 0x158c) != '\0')) {
      puVar41 = (ulong *)0x76ac3f8;
      if ((bRam00000000076ac3f8 & 1) == 0) goto LAB_0044a70c;
LAB_004498e0:
      if (((*(byte *)puVar41 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
        lVar52 = 0x76a97a8;
      }
      if (((*(byte *)puVar41 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
        lVar52 = 0x76a97a8;
      }
      if (((*(byte *)puVar41 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
        fn_1269d0(0x76a9760);
        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
        fn_65eed8(0x76ac3f8);
        lVar52 = 0x76a97a8;
      }
      if ((*(byte *)ppuVar27 != 0) && ((lRam0000000007871fa8 == 0 || (lRam0000000007871fb0 == 0))))
      {
        lRam0000000007871fa8 =
             fn_43d298(0x76a9768,uRam00000000076ac150,uRam00000000076ac158,uRam00000000076ac160);
        lRam0000000007871fb0 = fn_43d298(0x76a9768,uRam00000000076ac150,&UNK_007a122b,&UNK_007d697d)
        ;
      }
      puVar41 = (ulong *)((long)ppuVar27 + 0x24);
      if ((*(byte *)puVar41 != 0) && (lRam0000000007871fa0 == 0)) {
        lRam0000000007871fa0 = fn_43d298(0x76a9768,&UNK_007f967c,&UNK_007a122b,&UNK_007de6e8);
      }
      if (0 < iStack_f00) {
        lVar22 = 0;
        do {
          plVar30 = (long *)(lStack_f08 + lVar22 * 8);
          uVar23 = fn_139354(lVar52,plVar30,8);
          if (((uVar23 & 1) != 0) && (lVar24 = *plVar30, lVar24 != 0)) {
            uVar19 = *(ushort *)(lVar52 + 0x11b4);
            uVar23 = fn_139354(lVar52,(ulong)uVar19 + lVar24,1);
            if ((uVar23 & 1) == 0) {
              bVar49 = 0;
            }
            else {
              bVar49 = *(byte *)((ulong)uVar19 + lVar24);
            }
            if ((((*(byte *)ppuVar27 == 0) || (bVar49 < bRam00000000076ac148)) ||
                (bRam00000000076ac149 < bVar49)) ||
               (((lRam0000000007871fa8 == 0 || (lRam0000000007871fb0 == 0)) ||
                (uVar23 = fn_43da54(0x76a9768,lVar24), (uVar23 & 1) == 0)))) {
              if (((bVar49 == 4) && (*(byte *)puVar41 != 0)) &&
                 ((lRam0000000007871fa0 != 0 &&
                  (((((uVar23 = fn_43da54(0x76a9768,lVar24,uRam0000000007871f80), (uVar23 & 1) != 0
                      && (uVar23 = fn_139354(lVar52,lVar24 + 0x58,8), (uVar23 & 1) != 0)) &&
                     (lVar42 = *(long *)(lVar24 + 0x58), lVar42 != 0)) &&
                    ((uVar23 = fn_43da54(0x76a9768,lVar42,uRam0000000007871f88), (uVar23 & 1) != 0
                     && (cVar17 = fn_34b3c8(lVar42,0x25), cVar17 == '\0')))) &&
                   (lVar24 = fn_34b1c8(lVar24,lRam0000000007871fa0), lVar24 != 0)))))) {
                plVar30 = (long *)(lVar24 + 0x28);
                uVar23 = fn_139354(lVar52,plVar30,8);
                puVar48 = puVar41;
                goto joined_r0x00449b60;
              }
            }
            else {
              uVar23 = fn_139354(lVar52,lVar24 + 0x60,8);
              if ((((uVar23 & 1) != 0) && (lVar24 = *(long *)(lVar24 + 0x60), lVar24 != 0)) &&
                 (uVar23 = fn_43da54(0x76a9768,lVar24,lRam0000000007871fb0), (uVar23 & 1) != 0)) {
                plVar30 = (long *)(lVar24 + 0x18);
                uVar23 = fn_139354(lVar52,plVar30,8);
                puVar48 = (ulong *)ppuVar27;
joined_r0x00449b60:
                if ((((uVar23 & 1) != 0) && (lVar24 = *plVar30, lVar24 != 0)) &&
                   (uVar23 = fn_198128(lVar24), plVar30 = plRam0000000007871da0,
                   plVar50 = plRam0000000007871d98, (uVar23 & 1) != 0)) {
                  if (plRam0000000007871da0 < plRam0000000007871da8) {
                    *plRam0000000007871da0 = lVar24;
                    plRam0000000007871da0[1] = (long)puVar48;
                    plRam0000000007871da0 = plRam0000000007871da0 + 2;
                  }
                  else {
                    lVar52 = (long)plRam0000000007871da0 - (long)plRam0000000007871d98 >> 4;
                    uVar23 = lVar52 + 1;
                    if (uVar23 >> 0x3c != 0) goto LAB_0044a6f4;
                    uVar39 = (long)plRam0000000007871da8 - (long)plRam0000000007871d98 >> 3;
                    if (uVar39 <= uVar23) {
                      uVar39 = uVar23;
                    }
                    if (0x7fffffffffffffef <
                        (ulong)((long)plRam0000000007871da8 - (long)plRam0000000007871d98)) {
                      uVar39 = 0xfffffffffffffff;
                    }
                    if (uVar39 == 0) {
                      lVar42 = 0;
                    }
                    else {
                      if (uVar39 >> 0x3c != 0) goto LAB_0044a6dc;
                      lVar42 = fn_679020(uVar39 << 4);
                    }
                    plVar2 = (long *)(lVar42 + lVar52 * 0x10);
                    *plVar2 = lVar24;
                    plVar2[1] = (long)puVar48;
                    plVar51 = plVar2;
                    plVar1 = plVar30;
                    for (; plVar30 != plVar50; plVar30 = plVar30 + -2) {
                      lVar24 = plVar30[-2];
                      plVar51[-1] = plVar30[-1];
                      plVar51[-2] = lVar24;
                      plVar51 = plVar51 + -2;
                      plVar1 = plRam0000000007871d98;
                    }
                    plRam0000000007871da8 = (long *)(lVar42 + uVar39 * 0x10);
                    lVar52 = 0x76a97a8;
                    plVar2 = plVar2 + 2;
                    plRam0000000007871d98 = plVar51;
                    plRam0000000007871da0 = plVar2;
                    if (plVar1 != (long *)0x0) {
                      fn_6790c8(plVar1);
                      plRam0000000007871da0 = plVar2;
                    }
                  }
                }
              }
            }
          }
          lVar22 = lVar22 + 1;
          if (iStack_f00 <= lVar22) break;
        } while( true );
      }
    }
    bVar14 = bRam0000000006d35c8c;
    bVar49 = bRam0000000006d35a98;
    if (bVar15) {
      fn_33b658(0x6d35c8c);
      if ((bVar14 | bVar49) != 0) {
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        if (0 < iStack_f00) {
          lVar24 = 0;
          lVar22 = 0;
          bVar15 = false;
          do {
            lVar42 = lStack_f08;
            uVar23 = fn_139354(0x76a97a8,lVar24 + lStack_f08,8);
            if (((uVar23 & 1) != 0) && (lVar42 = *(long *)(lVar24 + lVar42), lVar42 != 0)) {
              uVar39 = (ulong)uRam00000000076aa95c;
              uVar23 = fn_139354(0x76a97a8,uVar39 + lVar42,1);
              if ((((uVar23 & 1) != 0) &&
                  (((*(char *)(uVar39 + lVar42) == '\x04' &&
                    (uVar23 = fn_43da54(0x76a9768,lVar42,uRam0000000007871f80), (uVar23 & 1) != 0))
                   && (uVar23 = fn_139354(0x76a97a8,lVar42 + 0x58,8), (uVar23 & 1) != 0)))) &&
                 ((lVar52 = *(long *)(lVar42 + 0x58), lVar52 != 0 &&
                  (uVar23 = fn_43da54(0x76a9768,lVar52,uRam0000000007871f88), (uVar23 & 1) != 0))))
              {
                uVar23 = fn_139354(0x76a97a8,(float *)(lVar52 + 0x30),0xc);
                if ((uVar23 & 1) == 0) {
                  bVar15 = true;
                }
                else {
                  fVar54 = *(float *)(lVar52 + 0x30);
                  bVar15 = true;
                  if (((ABS(fVar54) != INFINITY) &&
                      (fVar60 = *(float *)(lVar52 + 0x34), ABS(fVar60) != INFINITY)) &&
                     (fVar62 = *(float *)(lVar52 + 0x38), ABS(fVar62) != INFINITY)) {
                    uVar39 = (ulong)uRam00000000076aa958;
                    uVar23 = fn_139354(0x76a97a8,uVar39 + lVar42,8);
                    if ((uVar23 & 1) == 0) {
                      lStack_f48 = 0;
                    }
                    else {
                      lStack_f48 = *(long *)(uVar39 + lVar42);
                    }
                    uVar29 = uRam0000000006d35ca8;
                    if (lStack_f48 == lRam0000000006d35ca0) goto LAB_0044a468;
                    lRam0000000006d35ca0 = lStack_f48;
                    uRam0000000006d35cac = _UNK_00783d90;
                    iRam0000000006d35cc8 = 0;
                    lVar22 = fn_34b100(&UNK_007f967c,&UNK_007d6981,0x7871f90);
                    if ((lVar22 != 0) &&
                       (lVar22 = fn_42a66c(lVar42,uRam0000000007871f90), lVar22 != 0)) {
                      if (((bRam00000000076ac3f8 & 1) == 0) &&
                         (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
                        fn_1269d0(0x76a9760);
                        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                        fn_65eed8(0x76ac3f8);
                      }
                      uVar23 = fn_139354(0x76a97a8,lVar22 + 0x38,8);
                      if (((uVar23 & 1) != 0) && (lVar22 = *(long *)(lVar22 + 0x38), lVar22 != 0)) {
                        fVar55 = (float)fn_34b75c(lVar22,0x3c);
                        fVar56 = (float)fn_34b75c(lVar22,0x50);
                        if ((fVar55 < 600.0) && ((1.0 < fVar55 && (ABS(fVar55) != INFINITY)))) {
                          uRam0000000006d35cac = CONCAT44(uRam0000000006d35cac._4_4_,fVar55);
                        }
                        if (((fVar56 < 200.0) && (1.0 < fVar56)) && (ABS(fVar56) != INFINITY)) {
                          uRam0000000006d35cac = CONCAT44(fVar56,(float)uRam0000000006d35cac);
                        }
                      }
                    }
                    if (lRam0000000007873038 == 0) {
                      if (((bRam00000000076ac3f8 & 1) == 0) &&
                         (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
                        fn_1269d0(0x76a9760);
                        imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                        fn_65eed8(0x76ac3f8);
                      }
                      lRam0000000007873038 = fn_43d1bc(0x76a9768,&UNK_0078fa9d);
                      if (lRam0000000007873038 == 0) {
                        uVar29 = 0;
                        goto LAB_0044a468;
                      }
                    }
                    if (((bRam00000000076ac3f8 & 1) == 0) &&
                       (iVar21 = fn_65eda8(0x76ac3f8), iVar21 != 0)) {
                      fn_1269d0(0x76a9760);
                      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                      fn_65eed8(0x76ac3f8);
                    }
                    fn_198538(&uStack_240,lRam0000000007873038,0,0x10);
                    puVar48 = puStack_238;
                    if (uStack_240 != puStack_238) {
                      fVar55 = 1e+09;
                      puVar41 = uStack_240;
                      uVar45 = 0;
                      goto LAB_0044a1bc;
                    }
                    uVar29 = 0;
                    goto LAB_0044a444;
                  }
                }
              }
            }
            lVar22 = lVar22 + 1;
            lVar24 = lVar24 + 8;
          } while (lVar22 < iStack_f00);
          if (bVar15) goto LAB_00449e28;
        }
        lRam0000000006d35ca0 = 0;
        if (bVar14 != 0) goto LAB_00449f6c;
      }
      goto LAB_00449f88;
    }
    fn_34bad0();
    if (!bVar16) {
      fn_34ac44();
    }
  }
  goto LAB_00448aa0;
LAB_0044a6dc:
  if (*(long *)(lVar9 + 0x28) == lStack_b8) {
    fn_13edb4();
LAB_0044a6f4:
    if (*(long *)(lVar9 + 0x28) != lStack_b8) goto LAB_0044ac40;
    fn_34b734();
LAB_0044a70c:
    iVar21 = fn_65eda8(0x76ac3f8);
    if (iVar21 != 0) {
      fn_1269d0(0x76a9760);
      imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
      fn_65eed8(0x76ac3f8);
      lVar52 = 0x76a97a8;
    }
    goto LAB_004498e0;
  }
  goto LAB_0044ac40;
LAB_0044a1bc:
  do {
    uVar39 = *puVar41;
    uVar23 = fn_139354(0x76a97a8,uVar39 + 0x28,4);
    if ((uVar23 & 1) == 0) {
      uVar20 = 0;
LAB_0044a1e8:
      uVar23 = fn_139354(0x76a97a8,uVar39 + 0x20,8);
      if ((((uVar23 & 1) != 0) && (lVar22 = *(long *)(uVar39 + 0x20), lVar22 != 0)) &&
         (uVar23 = fn_139354(0x76a97a8,lVar22 + 0x18,8), (uVar23 & 1) != 0)) {
        uVar39 = *(ulong *)(lVar22 + 0x18);
        uVar23 = uVar39;
        if (0xf < uVar39) {
          uVar23 = 0x10;
        }
        if (uVar39 != 0) {
          plVar30 = (long *)(lVar22 + 0x20);
          uVar29 = 0x41;
          if (uVar20 != 0) {
            uVar29 = 0x42;
          }
          do {
            uVar39 = fn_139354(0x76a97a8,plVar30,8);
            fVar56 = fVar55;
            uVar13 = uVar45;
            if ((((uVar39 & 1) != 0) && (lVar22 = *plVar30, lVar22 != 0)) &&
               (uVar39 = fn_139354(0x76a97a8,lVar22 + 0x28,0xc), (uVar39 & 1) != 0)) {
              fVar76 = *(float *)(lVar22 + 0x28);
              fVar78 = *(float *)(lVar22 + 0x2c);
              fVar77 = *(float *)(lVar22 + 0x30);
              uVar39 = fn_139354(0x76a97a8,lVar22 + 0x34,0xc);
              if ((uVar39 & 1) != 0) {
                fVar75 = *(float *)(lVar22 + 0x34);
                fVar74 = *(float *)(lVar22 + 0x38);
                fVar73 = *(float *)(lVar22 + 0x3c);
                uVar39 = fn_139354(0x76a97a8,(float *)(lVar22 + 0x40),0x10);
                if ((((uVar39 & 1) != 0) && (ABS(fVar76) != INFINITY)) && (ABS(fVar78) != INFINITY))
                {
                  fVar57 = ABS(fVar77);
                  if ((fVar57 < INFINITY) || (fVar57 != INFINITY && fVar57 >= INFINITY)) {
                    fVar80 = *(float *)(lVar22 + 0x40);
                    fVar56 = (float)*(undefined8 *)(lVar22 + 0x44);
                    fVar58 = (float)((ulong)*(undefined8 *)(lVar22 + 0x44) >> 0x20);
                    fVar61 = -fVar56;
                    fVar69 = (fVar60 + 1.0) - fVar78;
                    fVar71 = (fVar54 + 0.0) - fVar76;
                    fVar56 = fVar56 * -2.0;
                    fVar67 = fVar58 * -2.0;
                    fVar63 = *(float *)(lVar22 + 0x4c);
                    fVar57 = fVar56 * fVar61;
                    fVar58 = fVar67 * -fVar58;
                    fVar68 = -fVar80 * fVar56;
                    fVar81 = -fVar80 * fVar67;
                    fVar79 = (fVar62 + 0.0) - fVar77;
                    uVar53 = NEON_fmadd(1.0 - (fVar57 + fVar58),fVar71,
                                        fVar69 * (fVar68 - fVar63 * fVar67));
                    fVar82 = (float)NEON_fmadd(fVar81 + fVar63 * fVar56,fVar79,uVar53);
                    if (ABS(fVar82) <= fVar75 * 0.5) {
                      fVar61 = fVar61 * fVar67;
                      fVar82 = -(fVar80 * fVar80 * -2.0);
                      fVar75 = fVar63 * fVar80 * -2.0;
                      uVar53 = NEON_fmadd(fVar63 * fVar67 + fVar68,fVar71,
                                          fVar69 * (1.0 - (fVar58 + fVar82)));
                      uVar66 = NEON_fmadd(fVar81 - fVar63 * fVar56,fVar71,fVar69 * (fVar61 + fVar75)
                                         );
                      fVar75 = (float)NEON_fmadd(fVar61 - fVar75,fVar79,uVar53);
                      fVar56 = (float)NEON_fmadd(1.0 - (fVar57 + fVar82),fVar79,uVar66);
                      fVar73 = fVar73 * 0.5;
                      bVar15 = ABS(fVar75) <= fVar74 * 0.5;
                      if (bVar15 && ABS(fVar56) < fVar73 || bVar15 && ABS(fVar56) == fVar73)
                      goto LAB_0044a444;
                    }
                    uVar53 = NEON_fmadd(fVar76 - fVar54,fVar76 - fVar54,
                                        (fVar78 - fVar60) * (fVar78 - fVar60));
                    fVar76 = (float)NEON_fmadd(fVar77 - fVar62,fVar77 - fVar62,uVar53);
                    fVar56 = SQRT(fVar76);
                    uVar13 = uVar29;
                    if (fVar55 <= SQRT(fVar76)) {
                      fVar56 = fVar55;
                      uVar13 = uVar45;
                    }
                  }
                }
              }
            }
            fVar55 = fVar56;
            uVar23 = uVar23 - 1;
            plVar30 = plVar30 + 1;
            uVar45 = uVar13;
          } while (uVar23 != 0);
        }
      }
    }
    else {
      uVar20 = *(uint *)(uVar39 + 0x28);
      if (uVar20 < 2) goto LAB_0044a1e8;
    }
    uVar29 = uVar45;
    puVar41 = puVar41 + 1;
    uVar45 = uVar29;
  } while (puVar41 != puVar48);
LAB_0044a444:
  if (uStack_240 != (ulong *)0x0) {
    puStack_238 = uStack_240;
    fn_6790c8(uStack_240);
  }
LAB_0044a468:
  uRam0000000006d35ca8 = uVar29;
  if (((bVar49 != 0) && (cVar17 = fn_34b3c8(lVar52,0x24), cVar17 == '\0')) &&
     (cVar18 = fn_34b3c8(lVar52,0x25), uVar64 = uStack_ed8, cVar17 = cStack_ee0, uVar26 = uStack_ee8
     , cVar18 == '\0')) {
    uStack_298 = 1;
    lStack_290 = lStack_f48;
    uStack_27c = uRam0000000006d35ca8;
    uStack_278._4_4_ = (float)uRam0000000006d35cac;
    fStack_288 = fVar54;
    fStack_284 = fVar60;
    fStack_280 = fVar62;
    fVar56 = (float)fn_34b75c(lVar52,0x18);
    fVar55 = 0.0;
    if (ABS(fVar56) != INFINITY) {
      uVar53 = (undefined4)uVar64;
      uVar66 = (undefined4)((ulong)uVar64 >> 0x20);
      if (cVar17 != '\0') {
        uVar53 = (undefined4)uVar26;
        uVar66 = (undefined4)((ulong)uVar26 >> 0x20);
      }
      fVar76 = (fVar56 + (float)uRam0000000006d35cac) - (float)(double)CONCAT44(uVar66,uVar53);
      fVar56 = (float)uRam0000000006d35cac;
      if (fVar76 <= (float)uRam0000000006d35cac) {
        fVar56 = fVar76;
      }
      fVar55 = 0.0;
      if (0.0 <= fVar76) {
        fVar55 = fVar56;
      }
    }
    uStack_278 = CONCAT44(uStack_278._4_4_,fVar55);
    lVar22 = fn_34b810(lVar52);
    if (lVar22 != 0) {
      fVar56 = (float)fn_34b75c(lVar52,0x20);
      uVar20 = (uint)fVar56 & 0x7fffffff;
      fVar76 = (float)fn_34b75c(lVar52,0x1c);
      uStack_270 = 1;
      fVar55 = 10.0;
      if (fVar56 <= 30.0 &&
          ((uVar20 < 0x7f800001 &&
           (uVar20 != 0x7f800000 &&
           (uVar20 != 0 && (-1 < (int)fVar56 || 0x7ffffe < ((uint)fVar56 & 0x7fffffff) - 1)))) &&
          (-1 < (int)fVar56 || 0x7e < ((uint)fVar56 & 0x7fffffff) - 0x800000 >> 0x18))) {
        fVar55 = fVar56;
      }
      fVar56 = fVar55;
      if (ABS(fVar76) != INFINITY) {
        fVar76 = fVar55 - fVar76;
        fVar77 = fVar55;
        if (fVar76 <= fVar55) {
          fVar77 = fVar76;
        }
        fVar56 = 0.0;
        if (0.0 <= fVar76) {
          fVar56 = fVar77;
        }
      }
      uStack_26c = CONCAT44(fVar55,fVar56);
    }
    bStack_f20 = 0;
    uStack_f1f = 0;
    uStack_f30 = 0;
    if ((puStack_f90 != (undefined8 *)0x0) &&
       (uVar23 = fn_43241c(&bStack_f20,&uStack_f30), (uVar23 & 1) != 0)) {
      pfVar36 = (float *)((ulong)&uStack_f40 | 4);
      pfVar5 = afStack_f38;
      if (!bVar8) {
        pfVar36 = (float *)0x4;
      }
      if (!bVar8) {
        pfVar5 = (float *)0x8;
      }
      uVar53 = NEON_fmadd(fVar54 - *(float *)puStack_f90,fVar54 - *(float *)puStack_f90,
                          (fVar60 - *pfVar36) * (fVar60 - *pfVar36));
      fVar54 = (float)NEON_fmadd(fVar62 - *pfVar5,fVar62 - *pfVar5,uVar53);
      fn_34b8c0(&uStack_240,SQRT(fVar54),uRam0000000006d35cac._4_4_,CONCAT11(uStack_f1f,bStack_f20),
                uStack_f30);
      iStack_260 = (int)puStack_238._0_4_;
      uStack_25c = (undefined)uStack_230;
      uStack_264 = ((char)uStack_240 != '\0' && puStack_238._0_4_ != 0.0) &&
                   ((char)uStack_240 == '\0' || -1 < (int)puStack_238._0_4_);
    }
  }
LAB_00449e28:
  if (bVar14 != 0) {
    uVar23 = fn_198128(uRam0000000006d35cb8);
    if ((uVar23 & 1) == 0) {
      uRam0000000006d35cb8 = 0;
      lVar22 = fn_639800();
      if ((iRam0000000006d35cc8 < 5) && (999999999 < lVar22 - lRam0000000006d35cc0)) {
        iRam0000000006d35cc8 = iRam0000000006d35cc8 + 1;
        lRam0000000006d35cc0 = lVar22;
        lVar22 = fn_19ac74();
        if (lVar22 != 0) {
          fn_198538(&uStack_240,lVar22,1,0x1000);
          puVar48 = puStack_238;
          if (uStack_240 != puStack_238) {
            puVar41 = uStack_240;
            do {
              uVar39 = *puVar41;
              fn_198468(&bStack_f20,uVar39);
              uVar23 = (ulong)(bStack_f20 >> 1);
              if ((bStack_f20 & 1) != 0) {
                uVar23 = CONCAT44(uStack_f14,fStack_f18);
              }
              if (uVar23 == 0x17) {
                plVar30 = (long *)((ulong)&bStack_f20 | 1);
                if ((bStack_f20 & 1) != 0) {
                  plVar30 = plStack_f10;
                }
                bVar15 = (*plVar30 == 0x6c707845626d6f42 && plVar30[1] == 0x77654e6e6f69736f) &&
                         *(long *)((long)plVar30 + 0xf) == 0x29656e6f6c432877;
              }
              else {
                bVar15 = false;
              }
              if ((bStack_f20 & 1) != 0) {
                fn_6790c8(plStack_f10);
              }
              if (bVar15) {
                uRam0000000006d35cb8 = uVar39;
                if ((bRam00000000076ac3f8 & 1) == 0) {
LAB_0044aa80:
                  iVar21 = fn_65eda8(0x76ac3f8);
                  if (iVar21 != 0) {
                    fn_1269d0(0x76a9760);
                    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                    fn_65eed8(0x76ac3f8);
                  }
                }
                break;
              }
              puVar41 = puVar41 + 1;
            } while (puVar41 != puVar48);
          }
          if (uStack_240 != (ulong *)0x0) {
            puStack_238 = uStack_240;
            fn_6790c8(uStack_240);
          }
        }
      }
    }
LAB_00449f6c:
    uVar23 = fn_198128(uRam0000000006d35cb8);
    if ((uVar23 & 1) != 0) {
      fn_33b6e0(3,uRam0000000006d35cb8);
    }
  }
LAB_00449f88:
  fn_34ba8c(&uStack_ea0);
LAB_00448aa0:
  if (*(long *)(lVar9 + 0x28) == lStack_b8) {
    return;
  }
LAB_0044ac40:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

