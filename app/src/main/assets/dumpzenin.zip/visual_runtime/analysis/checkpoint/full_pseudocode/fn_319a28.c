
// ================================================================================
// Source code from @imguisource_bot
// Primary: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Secondary: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x319a28 */

void fn_319a28(void)

{
  if (cRam0000000007760ed0 != '\0') {
    return;
  }
  uRam0000000007760e68 = fn_19e714(&UNK_007f9661);
  uRam0000000007760e6c = fn_19e714(&UNK_007fd1c5);
  uRam0000000007760e70 = fn_19e714(&UNK_00798750);
  uRam0000000007760e74 = fn_19e714(&UNK_007ceb46);
  uRam0000000007760e78 = fn_19e714(&UNK_007f18a0);
  uRam0000000007760e7c = fn_19e714(&UNK_007ac37e);
  uRam0000000007760e80 = fn_19e714(&UNK_007937ea);
  uRam0000000007760e84 = fn_19e714(&UNK_007cb2f4);
  uRam0000000007760e88 = fn_19e714(&UNK_007f5923);
  uRam0000000007760e8c = fn_19e714(&UNK_007cb302);
  uRam0000000007760e90 = fn_19e714(&UNK_007b0124);
  uRam0000000007760e94 = fn_19e714(&UNK_007ceb53);
  uRam0000000007760e98 = fn_19e714(&UNK_007fd1d0);
  uRam0000000007760e9c = fn_19e714(&UNK_007b0135);
  uRam0000000007760ea0 = fn_19e714(&UNK_007f18af);
  uRam0000000007760ea4 = fn_19e714(&UNK_007f5936);
  uRam0000000007760ea8 = fn_19e714(&UNK_0079875c);
  uRam0000000007760eac = fn_19e714(&UNK_0078bd39);
  uRam0000000007760eb0 = fn_19e714(&UNK_007c7bba);
  uRam0000000007760eb4 = fn_19e714(&UNK_007d2300);
  uRam0000000007760eb8 = fn_19e714(&UNK_007e9f4d);
  uRam0000000007760ebc = fn_19e714(&UNK_007f18b9);
  uRam0000000007760ec0 = fn_19e714(&UNK_007937f8);
  uRam0000000007760ec4 = fn_19e714(&UNK_007f18c8);
  uRam0000000007760ec8 = fn_19e714(&UNK_007bfafb);
  uRam0000000007760ecc = fn_19e714(&UNK_007da526);
  cRam0000000007760ed0 = 1;
  return;
}

