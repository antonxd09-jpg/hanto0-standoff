
// ================================================================================
// Bot: @imguisource_bot
// Channel #1: @ImGui_Source_FIXNEY | ImGui Source
// Channel #2: @il2cpp_src | shit src 🧨
// ================================================================================

/* ORIGINAL_RVA: 0x34ba8c */

void fn_34ba8c(undefined8 param_1)

{
  fn_63d380(0x7873040);
  imp_memcpy(0x7874e78,param_1,0xc5c);
  imp_pthread_mutex_unlock(0x7873040);
  return;
}

