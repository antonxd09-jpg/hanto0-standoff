
// ================================================================================
// Проверенные сурсы в боте @imguisource_bot
// Официальный канал: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Второй канал: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x34ac44 */

void fn_34ac44(void)

{
  long *plVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 *puVar4;
  long *plVar5;
  ulong uVar6;
  long *plVar7;
  ulong uVar8;
  long *plVar9;
  long *plVar10;
  long lVar11;
  long lVar12;
  
  fn_34bad0();
  uRam0000000007871db8 = uRam0000000007871db0;
  uRam0000000007871de0 = 0;
  uRam0000000007871da0 = uRam0000000007871d98;
  uRam0000000007871df0 = 0;
  uRam0000000007871de8 = 0;
  uRam0000000007871e00 = 0;
  uRam0000000007871df8 = 0;
  uRam0000000007871e10 = 0;
  uRam0000000007871e08 = 0;
  uRam0000000007871e20 = 0;
  uRam0000000007871e18 = 0;
  uRam0000000007871e30 = 0;
  uRam0000000007871e28 = 0;
  uRam0000000007871e40 = 0;
  uRam0000000007871e38 = 0;
  uRam0000000007871e50 = 0;
  uRam0000000007871e48 = 0;
  uRam0000000007871e60 = 0;
  uRam0000000007871e58 = 0;
  uRam0000000007871e70 = 0;
  uRam0000000007871e68 = 0;
  uRam0000000007871e80 = 0;
  uRam0000000007871e78 = 0;
  uRam0000000007871e90 = 0;
  uRam0000000007871e88 = 0;
  uRam0000000007871ea0 = 0;
  uRam0000000007871e98 = 0;
  uRam0000000007871eb0 = 0;
  uRam0000000007871ea8 = 0;
  uRam0000000007871ec0 = 0;
  uRam0000000007871eb8 = 0;
  uRam0000000007871ed0 = 0;
  uRam0000000007871ec8 = 0;
  uRam0000000007871ee0 = 0;
  uRam0000000007871ed8 = 0;
  uRam0000000007871ef0 = 0;
  uRam0000000007871ee8 = 0;
  uRam0000000007871f00 = 0;
  uRam0000000007871ef8 = 0;
  uRam0000000007871f10 = 0;
  uRam0000000007871f08 = 0;
  uRam0000000007871f20 = 0;
  uRam0000000007871f18 = 0;
  uRam0000000007871f30 = 0;
  uRam0000000007871f28 = 0;
  uRam0000000007871f40 = 0;
  uRam0000000007871f38 = 0;
  uRam0000000007871f50 = 0;
  uRam0000000007871f48 = 0;
  uRam0000000007871f60 = 0;
  uRam0000000007871f58 = 0;
  uRam0000000006d35ca0 = 0;
  uRam0000000006d35cb8 = 0;
  uRam000000000776b1f3 = 0;
  if (plRam000000000776b1c8 != plRam000000000776b1c0) {
    uVar8 = 0;
    plVar7 = plRam000000000776b1c0;
    plVar9 = plRam000000000776b1c8;
    do {
      if ((8U >> (ulong)(*(uint *)(plVar7 + uVar8 * 6 + 1) & 0x1f) & 1) == 0) {
        uVar8 = uVar8 + 1;
        plVar5 = plRam000000000776b1c8;
      }
      else {
        puVar4 = (undefined8 *)plVar7[uVar8 * 6 + 3];
        puVar2 = (undefined8 *)plVar7[uVar8 * 6 + 2];
        plVar5 = plVar9;
        for (; puVar2 != puVar4; puVar2 = puVar2 + 3) {
          if (((puVar2[2] != 0) && (uVar6 = fn_198128(*puVar2), (uVar6 & 1) != 0)) &&
             (uVar6 = fn_198128(puVar2[1]), (uVar6 & 1) != 0)) {
            fn_369c04(*puVar2,puVar2[1]);
          }
          puVar2[2] = 0;
          plVar7 = plRam000000000776b1c0;
          plVar5 = plRam000000000776b1c8;
        }
        plVar9 = plVar7 + uVar8 * 6;
        plVar10 = plVar5;
        if (plVar9 + 6 != plVar5) {
          plVar7 = plVar7 + uVar8 * 6 + 3;
          do {
            plVar7[-3] = plVar7[3];
            *(undefined4 *)(plVar7 + -2) = *(undefined4 *)(plVar7 + 4);
            if (plVar7[-1] != 0) {
              *plVar7 = plVar7[-1];
              fn_6790c8();
              *plVar7 = 0;
              plVar7[1] = 0;
            }
            lVar3 = plVar7[7];
            plVar9 = plVar9 + 6;
            lVar12 = plVar7[6];
            lVar11 = plVar7[5];
            plVar7[6] = 0;
            plVar7[7] = 0;
            plVar7[5] = 0;
            plVar7[1] = lVar3;
            plVar7[2] = plVar7[8];
            plVar1 = plVar7 + 9;
            *plVar7 = lVar12;
            plVar7[-1] = lVar11;
            plVar7 = plVar7 + 6;
            plVar10 = plRam000000000776b1c8;
          } while (plVar1 != plVar5);
        }
        for (; plVar7 = plRam000000000776b1c0, plVar5 = plVar9, plVar10 != plVar9;
            plVar10 = plVar10 + -6) {
          if (plVar10[-4] != 0) {
            plVar10[-3] = plVar10[-4];
            fn_6790c8();
          }
        }
      }
      plRam000000000776b1c8 = plVar5;
    } while (uVar8 < (ulong)(((long)plVar9 - (long)plVar7 >> 4) * -0x5555555555555555));
  }
  return;
}

