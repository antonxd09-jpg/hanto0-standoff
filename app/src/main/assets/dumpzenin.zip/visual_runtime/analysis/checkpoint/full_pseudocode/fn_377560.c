
// ================================================================================
// Shared via @imguisource_bot
// Follow ImGui Source: https://t.me/ImGui_Source_FIXNEY
// Follow shit src 🧨: https://t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x377560 */

long ** fn_377560(void)

{
  long **pplVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  undefined8 *in_x3;
  long lVar5;
  long *plVar6;
  long **pplVar7;
  long lVar8;
  ulong uVar9;
  long **pplVar10;
  long *plVar11;
  long *plVar12;
  long *plVar13;
  long *unaff_x26;
  undefined2 uVar14;
  undefined8 uVar15;
  float fVar16;
  undefined auVar17 [16];
  
  fn_139930(&UNK_007df23f);
  auVar17 = fn_139930(&UNK_007df23f);
  plVar4 = auVar17._0_8_;
  lVar3 = tpidr_el0;
  lVar5 = *(long *)(lVar3 + 0x28);
  plVar6 = *auVar17._8_8_;
  plVar12 = (long *)plVar4[1];
  uVar9 = ((ulong)(uint)((int)plVar6 << 3) + 8 ^ (ulong)plVar6 >> 0x20) * -0x622015f714c7d297;
  uVar9 = ((ulong)plVar6 >> 0x20 ^ uVar9 >> 0x2f ^ uVar9) * -0x622015f714c7d297;
  plVar13 = (long *)((uVar9 ^ uVar9 >> 0x2f) * -0x622015f714c7d297);
  if (plVar12 != (long *)0x0) {
    uVar15 = NEON_cnt(plVar12,1);
    uVar14 = NEON_uaddlv(uVar15,1);
    uVar9 = CONCAT62((int6)((ulong)uVar15 >> 0x10),uVar14) & 0xffffffff;
    if (uVar9 < 2) {
      unaff_x26 = (long *)((ulong)plVar13 & (long)plVar12 - 1U);
    }
    else {
      unaff_x26 = plVar13;
      if (plVar12 <= plVar13) {
        uVar2 = 0;
        if (plVar12 != (long *)0x0) {
          uVar2 = (ulong)plVar13 / (ulong)plVar12;
        }
        unaff_x26 = (long *)((long)plVar13 - uVar2 * (long)plVar12);
      }
    }
    pplVar10 = *(long ***)(*plVar4 + (long)unaff_x26 * 8);
    if ((pplVar10 != (long **)0x0) && (pplVar10 = (long **)*pplVar10, pplVar10 != (long **)0x0)) {
      do {
        plVar11 = pplVar10[1];
        if (plVar11 == plVar13) {
          if (pplVar10[2] == plVar6) {
            uVar15 = 0;
            goto code_r0x004778b4;
          }
        }
        else {
          if (uVar9 < 2) {
            plVar11 = (long *)((ulong)plVar11 & (long)plVar12 - 1U);
          }
          else if (plVar12 <= plVar11) {
            uVar2 = 0;
            if (plVar12 != (long *)0x0) {
              uVar2 = (ulong)plVar11 / (ulong)plVar12;
            }
            plVar11 = (long *)((long)plVar11 - uVar2 * (long)plVar12);
          }
          if (plVar11 != unaff_x26) break;
        }
        pplVar10 = (long **)*pplVar10;
      } while (pplVar10 != (long **)0x0);
    }
  }
  pplVar1 = (long **)(plVar4 + 2);
  pplVar10 = (long **)fn_679020(0xa8);
  pplVar7 = (long **)*in_x3;
  *pplVar10 = (long *)0x0;
  fVar16 = *(float *)(plVar4 + 4);
  plVar6 = *pplVar7;
  pplVar10[1] = plVar13;
  pplVar10[2] = plVar6;
  pplVar10[0x10] = (long *)0x0;
  pplVar10[0xf] = (long *)0x0;
  pplVar10[0x12] = (long *)0x0;
  pplVar10[0x11] = (long *)0x0;
  pplVar10[0x10] = (long *)0xffffffffffffffff;
  pplVar10[0x11] = (long *)0xffffffffffffffff;
  *(undefined4 *)(pplVar10 + 0x12) = 0xffffffff;
  lVar8 = plVar4[3];
  pplVar10[0x14] = (long *)0x0;
  pplVar10[0x13] = (long *)0x0;
  pplVar10[0xe] = (long *)0x0;
  pplVar10[0xd] = (long *)0x0;
  pplVar10[0xc] = (long *)0x0;
  pplVar10[0xb] = (long *)0x0;
  pplVar10[10] = (long *)0x0;
  pplVar10[9] = (long *)0x0;
  pplVar10[8] = (long *)0x0;
  pplVar10[7] = (long *)0x0;
  pplVar10[6] = (long *)0x0;
  pplVar10[5] = (long *)0x0;
  pplVar10[4] = (long *)0x0;
  pplVar10[3] = (long *)0x0;
  *(undefined8 *)((long)pplVar10 + 0x9b) = 0;
  *(undefined8 *)((long)pplVar10 + 0x94) = 0;
  pplVar7 = pplVar10;
  if ((plVar12 == (long *)0x0) || (fVar16 * (float)ZEXT89(plVar12) < (float)(unkuint9)(lVar8 + 1)))
  {
    if (plVar12 < (long *)0x3) {
      uVar9 = 1;
    }
    else {
      uVar9 = (ulong)(((ulong)plVar12 & (long)plVar12 - 1U) != 0);
    }
    plVar6 = (long *)(uVar9 | (long)plVar12 << 1);
    plVar11 = (long *)(long)((float)(unkuint9)(lVar8 + 1) / fVar16);
    if (plVar6 <= plVar11) {
      plVar6 = plVar11;
    }
    if ((long)plVar6 - 1U == 0) {
      plVar6 = (long *)0x2;
    }
    else if (((ulong)plVar6 & (long)plVar6 - 1U) != 0) {
      pplVar7 = (long **)fn_639934(plVar6);
      plVar12 = (long *)plVar4[1];
      plVar6 = (long *)pplVar7;
    }
    if (plVar12 < plVar6) {
code_r0x0047778c:
      pplVar7 = (long **)func_0x00477958(plVar4,plVar6);
    }
    else if (plVar6 < plVar12) {
      pplVar7 = (long **)(long)((float)(unkuint9)(ulong)plVar4[3] / *(float *)(plVar4 + 4));
      if (plVar12 < (long *)0x3) {
code_r0x004777fc:
        pplVar7 = (long **)fn_639934();
      }
      else {
        uVar15 = NEON_cnt(plVar12,1);
        uVar14 = NEON_uaddlv(uVar15,1);
        if (1 < (CONCAT62((int6)((ulong)uVar15 >> 0x10),uVar14) & 0xffffffff))
        goto code_r0x004777fc;
        if ((long *)0x1 < pplVar7) {
          pplVar7 = (long **)(1L << (-LZCOUNT((long)pplVar7 + -1) & 0x3fU));
        }
      }
      if (plVar6 <= pplVar7) {
        plVar6 = (long *)pplVar7;
      }
      if (plVar6 < plVar12) goto code_r0x0047778c;
    }
    plVar12 = (long *)plVar4[1];
    if (((ulong)plVar12 & (long)plVar12 - 1U) == 0) {
      unaff_x26 = (long *)((long)plVar12 - 1U & (ulong)plVar13);
    }
    else {
      unaff_x26 = plVar13;
      if (plVar12 <= plVar13) {
        uVar9 = 0;
        if (plVar12 != (long *)0x0) {
          uVar9 = (ulong)plVar13 / (ulong)plVar12;
        }
        unaff_x26 = (long *)((long)plVar13 - uVar9 * (long)plVar12);
      }
    }
  }
  lVar8 = *plVar4;
  plVar6 = *(long **)(lVar8 + (long)unaff_x26 * 8);
  if (plVar6 == (long *)0x0) {
    plVar6 = *pplVar1;
    *pplVar1 = (long *)pplVar10;
    *pplVar10 = plVar6;
    *(long ***)(lVar8 + (long)unaff_x26 * 8) = pplVar1;
    if (*pplVar10 == (long *)0x0) goto code_r0x004778a4;
    plVar6 = *(long **)((long)*pplVar10 + 8);
    if (((ulong)plVar12 & (long)plVar12 - 1U) == 0) {
      plVar6 = (long *)((ulong)plVar6 & (long)plVar12 - 1U);
    }
    else if (plVar12 <= plVar6) {
      uVar9 = 0;
      if (plVar12 != (long *)0x0) {
        uVar9 = (ulong)plVar6 / (ulong)plVar12;
      }
      plVar6 = (long *)((long)plVar6 - uVar9 * (long)plVar12);
    }
    plVar6 = (long *)(*plVar4 + (long)plVar6 * 8);
  }
  else {
    *pplVar10 = (long *)*plVar6;
  }
  *plVar6 = (long)pplVar10;
code_r0x004778a4:
  uVar15 = 1;
  plVar4[3] = plVar4[3] + 1;
  plVar4 = (long *)pplVar7;
code_r0x004778b4:
  if (*(long *)(lVar3 + 0x28) != lVar5) {
                    /* WARNING: Subroutine does not return */
    imp___stack_chk_fail(plVar4,uVar15);
  }
  return pplVar10;
}

