
// ================================================================================
// Telegram:
// - Bot: https://t.me/imguisource_bot
// - ImGui Source: https://t.me/ImGui_Source_FIXNEY
// - shit src 🧨: https://t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x3756cc */

void fn_3756cc(float param_1,undefined8 param_2,long param_3,uint *param_4,undefined4 param_5)

{
  long lVar1;
  int iVar2;
  long lVar3;
  undefined4 uVar4;
  float fVar5;
  float fVar6;
  uint uVar7;
  undefined8 uStack_70;
  undefined8 uStack_68;
  long lStack_58;
  
  lVar1 = tpidr_el0;
  lStack_58 = *(long *)(lVar1 + 0x28);
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar2 = fn_65eda8(0x787c6a0), iVar2 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    uRam000000000787c580 = 0;
    uRam000000000787c578 = 0;
    uRam000000000787c590 = 0;
    uRam000000000787c588 = 0;
    uRam000000000787c5a0 = 0;
    uRam000000000787c598 = 0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c688 = 0;
    uRam000000000787c68c = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  fVar5 = 1.0;
  if (param_1 <= 1.0) {
    fVar5 = param_1;
  }
  fVar6 = 0.0;
  if (0.0 <= param_1) {
    fVar6 = fVar5;
  }
  param_4[4] = (uint)(fVar6 * (float)param_4[4]);
  param_4[8] = (uint)(fVar6 * (float)param_4[8]);
  lVar3 = fn_19cbdc(param_2);
  if (lVar3 != param_3) {
    fn_19cca8(param_2,param_3);
  }
  fn_19cf1c(param_2,param_5);
  fn_19d360(param_4[0xd],param_2,uRam000000000787c5d8 & 0xffffffff);
  fn_19d360(0,param_2,uRam000000000787c5d8._4_4_);
  uStack_68 = *(undefined8 *)(param_4 + 3);
  uStack_70 = *(undefined8 *)(param_4 + 1);
  fn_19d5a8(param_2,uRam000000000787c5d0 & 0xffffffff,&uStack_70);
  uStack_68 = *(undefined8 *)(param_4 + 7);
  uStack_70 = *(undefined8 *)(param_4 + 5);
  fn_19d5a8(param_2,uRam000000000787c5d0._4_4_,&uStack_70);
  uVar7 = *param_4;
  if ((int)uVar7 < 6) {
    if ((int)uVar7 < 3) {
      if (uVar7 < 2) goto LAB_00475870;
LAB_00475894:
      if (uVar7 == 2) {
        fn_19d360(param_4[0x11],param_2,uRam000000000787c5e8._4_4_);
        fn_19d360(param_4[0x12],param_2,uRam000000000787c5f0 & 0xffffffff);
        fn_19d360(param_4[0x13],param_2,uRam000000000787c5f0._4_4_);
        uStack_68 = *(undefined8 *)(param_4 + 0xb);
        uStack_70 = *(undefined8 *)(param_4 + 9);
        fn_19d5a8(param_2,uRam000000000787c5f8 & 0xffffffff,&uStack_70);
      }
      goto LAB_00475b60;
    }
    if (1 < uVar7 - 3) {
      if (uVar7 != 5) goto LAB_00475b60;
      fn_19d360(param_4[0x18],param_2,uRam000000000787c608._4_4_);
      uVar7 = param_4[0x19];
      uVar4 = (undefined4)uRam000000000787c610;
      goto LAB_00475b58;
    }
LAB_00475870:
    fn_19d360(param_4[0xe],param_2,uRam000000000787c5e0 & 0xffffffff);
    if ((int)uVar7 < 3) {
      if (uVar7 != 1) goto LAB_00475894;
      fn_19d360(param_4[0xf],param_2,uRam000000000787c5e0._4_4_);
      uVar7 = param_4[0x10];
      uVar4 = (undefined4)uRam000000000787c5e8;
    }
    else {
      if (uVar7 == 3) {
        fn_19d360(param_4[0x14],param_2,uRam000000000787c5f8._4_4_);
        fn_19d360(param_4[0x10],param_2,uRam000000000787c5e8 & 0xffffffff);
        fn_19d360(param_4[0x15],param_2,uRam000000000787c600 & 0xffffffff);
        goto LAB_00475b54;
      }
      if (uVar7 != 4) goto LAB_00475b60;
      uVar7 = param_4[0x17];
      uVar4 = (undefined4)uRam000000000787c608;
    }
  }
  else if ((int)uVar7 < 9) {
    if (uVar7 == 6) {
      fn_19d360(param_4[0x1a],param_2,uRam000000000787c610._4_4_);
      fn_19d360(param_4[0x1b],param_2,uRam000000000787c618 & 0xffffffff);
      fn_19d360(param_4[0x1c],param_2,uRam000000000787c618._4_4_);
      uStack_68 = *(undefined8 *)(param_4 + 0xb);
      uStack_70 = *(undefined8 *)(param_4 + 9);
      fn_19d5a8(param_2,uRam000000000787c5f8 & 0xffffffff,&uStack_70);
      fn_19d360(param_4[0x1d],param_2,uRam000000000787c620 & 0xffffffff);
      fn_19d360(param_4[0x1e],param_2,uRam000000000787c620._4_4_);
      fn_19d360(param_4[0x1f],param_2,uRam000000000787c628 & 0xffffffff);
      uVar7 = param_4[0x20];
      uVar4 = uRam000000000787c628._4_4_;
    }
    else if (uVar7 == 7) {
      fn_19d360(param_4[0x21],param_2,uRam000000000787c630 & 0xffffffff);
      fn_19d360(param_4[0x22],param_2,uRam000000000787c630._4_4_);
      fn_19d360(param_4[0x23],param_2,uRam000000000787c638 & 0xffffffff);
      fn_19d360(param_4[0x24],param_2,uRam000000000787c638._4_4_);
      fn_19d360(param_4[0x25],param_2,uRam000000000787c640 & 0xffffffff);
      uVar7 = param_4[0x26];
      uVar4 = uRam000000000787c640._4_4_;
    }
    else {
      if (uVar7 != 8) goto LAB_00475b60;
      fn_19d360(param_4[0x27],param_2,uRam000000000787c648 & 0xffffffff);
      uVar7 = 0;
      uVar4 = uRam000000000787c648._4_4_;
    }
  }
  else if ((int)uVar7 < 0xb) {
    if (uVar7 == 9) {
      fn_19d360(param_4[0x28],param_2,uRam000000000787c650 & 0xffffffff);
      fn_19d360(param_4[0x29],param_2,uRam000000000787c650._4_4_);
      uVar7 = param_4[0x2a];
      uVar4 = (undefined4)uRam000000000787c658;
    }
    else {
      if (uVar7 != 10) goto LAB_00475b60;
      fn_19d360(param_4[0x2b],param_2,uRam000000000787c658._4_4_);
      uVar7 = param_4[0x2c];
      uVar4 = (undefined4)uRam000000000787c660;
LAB_004759d4:
      fn_19d360(uVar7,param_2,uVar4);
      uVar7 = param_4[0x32];
      uVar4 = (undefined4)uRam000000000787c678;
    }
    fn_19d360(uVar7,param_2,uVar4);
    fn_19d360(param_4[0x15],param_2,uRam000000000787c600 & 0xffffffff);
LAB_00475b54:
    uVar7 = param_4[0x16];
    uVar4 = uRam000000000787c600._4_4_;
  }
  else {
    if (uVar7 == 0xb) {
      fn_19d360(param_4[0x2d],param_2,uRam000000000787c660._4_4_);
      uVar7 = param_4[0x2e];
      uVar4 = (undefined4)uRam000000000787c668;
      goto LAB_004759d4;
    }
    if (uVar7 != 0xc) goto LAB_00475b60;
    fn_19d360(param_4[0x2f],param_2,uRam000000000787c668._4_4_);
    fn_19d360(param_4[0x30],param_2,uRam000000000787c670 & 0xffffffff);
    uVar7 = param_4[0x31];
    uVar4 = uRam000000000787c670._4_4_;
  }
LAB_00475b58:
  fn_19d360(uVar7,param_2,uVar4);
LAB_00475b60:
  if (0.0 < (float)param_4[0x33]) {
    uStack_68 = *(undefined8 *)(param_4 + 0x37);
    uStack_70 = *(undefined8 *)(param_4 + 0x35);
    fn_19d5a8(param_2,uRam000000000787c678._4_4_,&uStack_70);
    uStack_68 = *(undefined8 *)(param_4 + 0x3b);
    uStack_70 = *(undefined8 *)(param_4 + 0x39);
    fn_19d5a8(param_2,uRam000000000787c680 & 0xffffffff,&uStack_70);
    fn_19d360(param_4[0x33],param_2,uRam000000000787c680._4_4_);
    fn_19d360(param_4[0x34],param_2,uRam000000000787c688);
  }
  if (*(long *)(lVar1 + 0x28) != lStack_58) {
                    /* WARNING: Subroutine does not return */
    imp___stack_chk_fail();
  }
  return;
}

