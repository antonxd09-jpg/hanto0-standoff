
// ================================================================================
// Source provider: @imguisource_bot
// Channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Channel: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x375dfc */

undefined8 fn_375dfc(uint param_1)

{
  int iVar1;
  ulong uVar2;
  undefined8 uVar3;
  
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar1 = fn_65eda8(0x787c6a0), iVar1 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    uRam000000000787c580 = 0;
    uRam000000000787c578 = 0;
    uRam000000000787c590 = 0;
    uRam000000000787c588 = 0;
    uRam000000000787c5a0 = 0;
    uRam000000000787c598 = 0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c688 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c689 = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  if ((param_1 < 2) && (uVar2 = fn_371bd4(), (uVar2 & 1) != 0)) {
    uVar3 = *(undefined8 *)((long)(int)param_1 * 8 + 0x787c4e0);
    uVar2 = fn_198128(uVar3);
    if ((uVar2 & 1) == 0) {
      uVar3 = 0;
    }
  }
  else {
    uVar3 = 0;
  }
  return uVar3;
}

