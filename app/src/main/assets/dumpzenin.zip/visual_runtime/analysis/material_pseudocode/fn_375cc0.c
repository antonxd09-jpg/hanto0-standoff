
// ================================================================================
// TG Project: @imguisource_bot
// Main: @ImGui_Source_FIXNEY - ImGui Source
// Additional: @il2cpp_src - shit src 🧨
// ================================================================================

/* ORIGINAL_RVA: 0x375cc0 */

void fn_375cc0(undefined4 param_1,undefined8 param_2,long param_3,byte param_4)

{
  undefined4 uVar1;
  undefined *puVar2;
  long lVar3;
  ulong uVar4;
  undefined *puVar5;
  long lVar6;
  undefined auStack_14c [200];
  undefined4 uStack_84;
  long lStack_58;
  
  lVar3 = tpidr_el0;
  lStack_58 = *(long *)(lVar3 + 0x28);
  uVar4 = fn_198128();
  if ((uVar4 & 1) != 0) {
    puVar5 = (undefined *)imp_wmemchr(&UNK_00803ca8,*(undefined4 *)(param_3 + 0x120),0xb);
    puVar2 = &UNK_00803cd4;
    if (puVar5 != (undefined *)0x0) {
      puVar2 = puVar5;
    }
    uVar1 = 2;
    if (puVar2 != &UNK_00803cd4) {
      uVar1 = *(undefined4 *)(param_3 + 0x120);
    }
    lVar6 = fn_37509c(uVar1);
    if (lVar6 == 0) goto LAB_00475dc8;
    uVar4 = fn_3752a8();
    if ((uVar4 & 1) != 0) {
      puVar5 = (undefined *)imp_wmemchr(&UNK_00803ca8,*(undefined4 *)(param_3 + 0x120),0xb);
      puVar2 = &UNK_00803cd4;
      if (puVar5 != (undefined *)0x0) {
        puVar2 = puVar5;
      }
      uVar1 = 2;
      if (puVar2 != &UNK_00803cd4) {
        uVar1 = *(undefined4 *)(param_3 + 0x120);
      }
      fn_36f44c(auStack_14c,param_3 + 0x120,uVar1,param_4 & *(char *)(param_3 + 0x11d) != '\0');
      uStack_84 = 0x3f800000;
      fn_3756cc(param_1,param_2,lVar6,auStack_14c,0xc1d);
      lVar6 = 1;
      goto LAB_00475dc8;
    }
  }
  lVar6 = 0;
LAB_00475dc8:
  if (*(long *)(lVar3 + 0x28) == lStack_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(lVar6);
}

