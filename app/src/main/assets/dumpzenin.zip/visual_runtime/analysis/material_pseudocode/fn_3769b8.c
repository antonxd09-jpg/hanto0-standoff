
// ================================================================================
// +------------------------------------------------+
// | TG Bot: @imguisource_bot                       |
// | ImGui Source: @ImGui_Source_FIXNEY                        |
// | shit src 🧨: @il2cpp_src                        |
// +------------------------------------------------+
// ================================================================================

/* ORIGINAL_RVA: 0x3769b8 */

/* WARNING: Removing unreachable block (ram,0x004771d4) */

void fn_3769b8(ulong *param_1,ulong **param_2,uint param_3)

{
  ulong *puVar1;
  ulong **ppuVar2;
  long lVar3;
  bool bVar4;
  ulong **ppuVar5;
  undefined4 uVar6;
  int iVar7;
  ulong uVar8;
  ulong *puVar9;
  undefined8 uVar10;
  ulong uVar11;
  ulong uVar12;
  long lVar13;
  ulong *puVar14;
  ulong **ppuVar15;
  long lVar16;
  ulong *puVar17;
  ulong **ppuVar18;
  ulong uVar19;
  ulong *puVar20;
  ulong *puVar21;
  ulong uVar22;
  ulong *puStack_88;
  ulong *puStack_80;
  ulong *puStack_78;
  ulong **ppuStack_70;
  ulong **ppuStack_68;
  
  lVar3 = tpidr_el0;
  ppuStack_68 = *(ulong ***)(lVar3 + 0x28);
  uVar8 = fn_377038(param_2,1);
  if ((uVar8 & 1) != 0) {
    param_2[0xc] = (ulong *)0x0;
    *(undefined4 *)(param_2 + 0xd) = 0xffffffff;
    *(undefined4 *)(param_2 + 0xf) = 0xffffffff;
    uVar8 = fn_198128(param_1);
    if ((uVar8 & 1) != 0) {
      param_2[6] = param_1;
      puVar9 = (ulong *)fn_439970(param_1);
      param_2[7] = puVar9;
      if (puVar9 == (ulong *)0x0) {
        if (*(ulong ***)(lVar3 + 0x28) != ppuStack_68) goto LAB_00476ebc;
        lVar3 = tpidr_el0;
        lVar16 = *(long *)(lVar3 + 0x28);
        ppuVar15 = param_2 + 6;
        *(undefined *)((long)param_2 + 0x8a) = 1;
        uVar8 = fn_198128(*ppuVar15);
        puVar9 = *param_2;
        if (((uVar8 & 1) != 0) && ((puVar9 != param_2[1] || (param_2[4] != (ulong *)0x0)))) {
          ppuStack_70 = (ulong **)0x0;
          ppuStack_68 = (ulong **)0x0;
          uVar10 = fn_19b000(*ppuVar15);
          uVar8 = fn_19b0cc(uVar10,&ppuStack_70);
          ppuVar5 = ppuStack_68;
          if ((uVar8 & 1) == 0) {
            bVar4 = true;
          }
          else {
            if (ppuStack_70 == ppuStack_68) {
              bVar4 = false;
            }
            else {
              bVar4 = false;
              ppuVar18 = ppuStack_70;
              do {
                if (*ppuVar18 != (ulong *)0x0) {
                  for (ppuVar2 = (ulong **)*param_2; ppuVar2 != (ulong **)param_2[1];
                      ppuVar2 = ppuVar2 + 3) {
                    if (ppuVar2[1] == *ppuVar18) {
                      uVar8 = fn_198128(*ppuVar2);
                      puVar9 = *ppuVar2;
                      bVar4 = true;
                      if ((uVar8 & 1) == 0) {
                        puVar9 = (ulong *)0x0;
                      }
                      *ppuVar18 = puVar9;
                      break;
                    }
                  }
                }
                ppuVar18 = ppuVar18 + 1;
              } while (ppuVar18 != ppuVar5);
            }
            ppuVar5 = ppuStack_70;
            ppuVar18 = ppuStack_70;
            if (param_2[4] != (ulong *)0x0) {
              for (; (ppuVar5 != ppuStack_68 && (ppuVar18 = ppuVar5, *ppuVar5 != param_2[4]));
                  ppuVar5 = ppuVar5 + 1) {
                ppuVar18 = ppuStack_68;
              }
              ppuVar5 = ppuVar18;
              if (ppuVar18 != ppuStack_68) {
                while (ppuVar5 = ppuVar5 + 1, ppuVar5 != ppuStack_68) {
                  if (*ppuVar5 != param_2[4]) {
                    *ppuVar18 = *ppuVar5;
                    ppuVar18 = ppuVar18 + 1;
                  }
                }
              }
              bVar4 = (bool)(bVar4 | ppuVar18 != ppuStack_68);
              if (ppuVar18 != ppuStack_68) {
                ppuStack_68 = ppuVar18;
              }
            }
            if (bVar4) {
              puStack_88 = (ulong *)0x0;
              puStack_80 = (ulong *)0x0;
              puStack_78 = (ulong *)0x0;
              uVar8 = fn_19b0cc(param_2[8],&puStack_88);
              if ((((uVar8 & 1) == 0) ||
                  ((long)puStack_80 - (long)puStack_88 != (long)ppuStack_68 - (long)ppuStack_70)) ||
                 (iVar7 = imp_memcmp(), iVar7 != 0)) {
                puVar9 = (ulong *)fn_19b32c(&ppuStack_70);
              }
              else {
                puVar9 = param_2[8];
              }
              lVar13 = fn_439970(puVar9);
              if (lVar13 != 0) {
                fn_19b4fc(*ppuVar15,puVar9);
                fn_439c54(lVar13);
                uVar10 = fn_19b000(*ppuVar15);
                uVar8 = fn_19b0cc(uVar10,&ppuStack_70);
                if (((uVar8 & 1) != 0) &&
                   (uVar8 = fn_378900(ppuStack_70,ppuStack_68,param_2), (uVar8 & 1) == 0)) {
                  if (puStack_88 != (ulong *)0x0) {
                    puStack_80 = puStack_88;
                    fn_6790c8();
                  }
                  bVar4 = false;
                  goto joined_r0x00477394;
                }
              }
              if (puStack_88 != (ulong *)0x0) {
                puStack_80 = puStack_88;
                fn_6790c8();
              }
              bVar4 = true;
            }
          }
joined_r0x00477394:
          if (ppuStack_70 != (ulong **)0x0) {
            ppuStack_68 = ppuStack_70;
            fn_6790c8();
          }
          if (bVar4) {
            uVar10 = 0;
            goto LAB_00477350;
          }
          puVar9 = *param_2;
        }
        puVar20 = param_2[1];
        if (puVar9 != puVar20) {
          do {
            uVar8 = fn_198128(puVar9[1]);
            if ((uVar8 & 1) != 0) {
              fn_198eac(puVar9[1]);
            }
            fn_439c54(puVar9[2]);
            *puVar9 = 0;
            puVar9[1] = 0;
            puVar9[2] = 0;
            puVar9 = puVar9 + 3;
          } while (puVar9 != puVar20);
          puVar9 = *param_2;
        }
        param_2[1] = puVar9;
        uVar8 = fn_198128(param_2[4]);
        if ((uVar8 & 1) != 0) {
          fn_198eac(param_2[4]);
        }
        fn_439c54(param_2[5]);
        param_2[3] = (ulong *)0x0;
        param_2[4] = (ulong *)0x0;
        param_2[5] = (ulong *)0x0;
        fn_439c54(param_2[0xb]);
        fn_439c54(param_2[9]);
        fn_439c54(param_2[7]);
        uVar10 = 1;
        *(undefined *)((long)param_2 + 0x8a) = 0;
        param_2[7] = (ulong *)0x0;
        *ppuVar15 = (ulong *)0x0;
        param_2[9] = (ulong *)0x0;
        param_2[8] = (ulong *)0x0;
        param_2[0xb] = (ulong *)0x0;
        param_2[10] = (ulong *)0x0;
LAB_00477350:
        if (*(long *)(lVar3 + 0x28) != lVar16) {
                    /* WARNING: Subroutine does not return */
          imp___stack_chk_fail(uVar10);
        }
        return;
      }
      uVar10 = fn_1997d4(param_1);
      uVar8 = fn_198128();
      if ((uVar8 & 1) == 0) {
        uVar6 = 0xffffffff;
      }
      else {
        uVar6 = fn_199ea0(uVar10);
      }
      *(undefined4 *)(param_2 + 0xf) = uVar6;
      uVar6 = fn_3773f4(param_1);
      *(undefined4 *)((long)param_2 + 0x7c) = uVar6;
      puVar9 = (ulong *)fn_19b000(param_1);
      param_2[8] = puVar9;
      puVar9 = (ulong *)fn_439970();
      puStack_80 = (ulong *)0x0;
      puStack_78 = (ulong *)0x0;
      param_2[9] = puVar9;
      ppuStack_70 = (ulong **)0x0;
      if (((puVar9 == (ulong *)0x0) || (uVar8 = fn_19b0cc(param_2[8],&puStack_80), (uVar8 & 1) == 0)
          ) || (puStack_88 = puStack_78, puVar9 = puStack_80, puStack_80 == puStack_78)) {
LAB_00476df4:
        fn_377038(param_2,1);
      }
      else {
        do {
          uVar8 = *puVar9;
          if (uVar8 != 0) {
            uVar11 = fn_198128(uVar8);
            if ((uVar11 & 1) != 0) {
              uVar11 = fn_19b1d0(*puVar9);
              uVar12 = fn_439970();
              puVar20 = param_2[1];
              if (puVar20 < param_2[2]) {
                *puVar20 = uVar8;
                puVar20[1] = uVar11;
                puVar14 = puVar20 + 3;
                puVar20[2] = uVar12;
              }
              else {
                puVar21 = *param_2;
                lVar16 = (long)puVar20 - (long)puVar21 >> 3;
                uVar22 = lVar16 * -0x5555555555555555 + 1;
                if (0xaaaaaaaaaaaaaaa < uVar22) goto LAB_00476e58;
                lVar13 = (long)param_2[2] - (long)puVar21 >> 3;
                uVar19 = lVar13 * 0x5555555555555556;
                if (uVar19 < uVar22 || uVar19 - uVar22 == 0) {
                  uVar19 = uVar22;
                }
                if (0x555555555555554 < (ulong)(lVar13 * -0x5555555555555555)) {
                  uVar19 = 0xaaaaaaaaaaaaaaa;
                }
                if (uVar19 == 0) {
                  lVar13 = 0;
                }
                else {
                  if (0xaaaaaaaaaaaaaaa < uVar19) goto LAB_00476e70;
                  lVar13 = fn_679020(uVar19 * 0x18);
                }
                puVar14 = (ulong *)(lVar13 + lVar16 * 8);
                *puVar14 = uVar8;
                puVar14[1] = uVar11;
                puVar14[2] = uVar12;
                puVar17 = puVar14;
                if (puVar20 != puVar21) {
                  do {
                    puVar1 = puVar20 + -1;
                    uVar22 = puVar20[-2];
                    uVar8 = puVar20[-3];
                    puVar20 = puVar20 + -3;
                    puVar17[-1] = *puVar1;
                    puVar17[-2] = uVar22;
                    puVar17[-3] = uVar8;
                    puVar17 = puVar17 + -3;
                  } while (puVar20 != puVar21);
                  puVar20 = *param_2;
                }
                puVar14 = puVar14 + 3;
                *param_2 = puVar17;
                param_2[1] = puVar14;
                param_2[2] = (ulong *)(lVar13 + uVar19 * 0x18);
                if (puVar20 != (ulong *)0x0) {
                  fn_6790c8(puVar20);
                }
              }
              param_2[1] = puVar14;
              if (uVar12 != 0) {
                fn_19cbdc(uVar11);
                uVar8 = fn_198128();
                if ((uVar8 & 1) != 0) {
                  *puVar9 = uVar11;
                  goto LAB_00476b08;
                }
              }
            }
            fn_377038(param_2,1);
            goto LAB_00476e00;
          }
          puVar20 = param_2[1];
          if (puVar20 < param_2[2]) {
            *puVar20 = 0;
            puVar20[1] = 0;
            puVar21 = puVar20 + 3;
            puVar20[2] = 0;
          }
          else {
            puVar14 = *param_2;
            lVar16 = (long)puVar20 - (long)puVar14 >> 3;
            uVar8 = lVar16 * -0x5555555555555555 + 1;
            if (0xaaaaaaaaaaaaaaa < uVar8) {
LAB_00476e58:
              if (*(ulong ***)(lVar3 + 0x28) == ppuStack_68) {
                fn_377c24(param_2);
LAB_00476e70:
                if (*(ulong ***)(lVar3 + 0x28) == ppuStack_68) {
                  uVar10 = fn_13edb4();
                  if (puStack_80 != (ulong *)0x0) {
                    puStack_78 = puStack_80;
                    fn_6790c8();
                  }
                  if (*(ulong ***)(lVar3 + 0x28) == ppuStack_68) {
                    /* WARNING: Subroutine does not return */
                    fn_67b74c(uVar10);
                  }
                }
              }
              goto LAB_00476ebc;
            }
            lVar13 = (long)param_2[2] - (long)puVar14 >> 3;
            uVar11 = lVar13 * 0x5555555555555556;
            if (uVar11 < uVar8 || uVar11 - uVar8 == 0) {
              uVar11 = uVar8;
            }
            if (0x555555555555554 < (ulong)(lVar13 * -0x5555555555555555)) {
              uVar11 = 0xaaaaaaaaaaaaaaa;
            }
            if (uVar11 == 0) {
              lVar13 = 0;
            }
            else {
              if (0xaaaaaaaaaaaaaaa < uVar11) goto LAB_00476e70;
              lVar13 = fn_679020(uVar11 * 0x18);
            }
            puVar21 = (ulong *)(lVar13 + lVar16 * 8);
            *puVar21 = 0;
            puVar21[1] = 0;
            puVar21[2] = 0;
            puVar17 = puVar21;
            if (puVar20 != puVar14) {
              do {
                puVar1 = puVar20 + -1;
                uVar12 = puVar20[-2];
                uVar8 = puVar20[-3];
                puVar20 = puVar20 + -3;
                puVar17[-1] = *puVar1;
                puVar17[-2] = uVar12;
                puVar17[-3] = uVar8;
                puVar17 = puVar17 + -3;
              } while (puVar20 != puVar14);
              puVar20 = *param_2;
            }
            puVar21 = puVar21 + 3;
            *param_2 = puVar17;
            param_2[1] = puVar21;
            param_2[2] = (ulong *)(lVar13 + uVar11 * 0x18);
            if (puVar20 != (ulong *)0x0) {
              fn_6790c8(puVar20);
            }
          }
          param_2[1] = puVar21;
LAB_00476b08:
          puVar9 = puVar9 + 1;
        } while (puVar9 != puStack_88);
        if ((param_3 & 1) == 0) {
LAB_00476dc0:
          puVar9 = (ulong *)fn_19b32c(&puStack_80);
          param_2[10] = puVar9;
          puVar9 = (ulong *)fn_439970();
          param_2[0xb] = puVar9;
          if (puVar9 != (ulong *)0x0) {
            fn_19b4fc(param_1,param_2[10]);
            uVar8 = fn_376858(param_1,param_2);
            if ((uVar8 & 1) == 0) {
              *(undefined *)((long)param_2 + 0x8a) = 0;
              goto LAB_00476e00;
            }
          }
          goto LAB_00476df4;
        }
        ppuVar15 = (ulong **)param_2[1];
        do {
          if (ppuVar15 == (ulong **)*param_2) goto LAB_00476d98;
          ppuVar15 = ppuVar15 + -3;
        } while (*ppuVar15 == (ulong *)0x0);
        param_2[3] = *ppuVar15;
        puVar9 = (ulong *)fn_19b1d0(*ppuVar15);
        param_2[4] = puVar9;
        puVar9 = (ulong *)fn_439970();
        param_2[5] = puVar9;
LAB_00476d98:
        if (param_2[5] != (ulong *)0x0) {
          fn_19cbdc(param_2[4]);
          uVar8 = fn_198128();
          if ((uVar8 & 1) != 0) {
            fn_377ab4(&puStack_80,param_2 + 4);
            goto LAB_00476dc0;
          }
        }
        fn_377038(param_2,1);
      }
LAB_00476e00:
      if (puStack_80 != (ulong *)0x0) {
        puStack_78 = puStack_80;
        fn_6790c8();
      }
    }
  }
  if (*(ulong ***)(lVar3 + 0x28) == ppuStack_68) {
    return;
  }
LAB_00476ebc:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

