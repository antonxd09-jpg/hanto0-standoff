
// ================================================================================
// Source published by: @imguisource_bot
// Follow: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Backup: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x376ec0 */

long fn_376ec0(long param_1,ulong param_2,ulong param_3)

{
  long lVar1;
  ulong uStack_50;
  long lStack_48;
  
  lVar1 = tpidr_el0;
  lStack_48 = *(long *)(lVar1 + 0x28);
  uStack_50 = (((ulong)*(byte *)(param_1 + 0x11c) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
              (ulong)*(byte *)(param_1 + 0x11d)) * 0x100000001b3;
  fn_377c38(&uStack_50,param_1);
  uStack_50 = (((((((((uStack_50 ^ param_2 & 0xff) * 0x100000001b3 ^ param_2 >> 8 & 0xff) *
                     0x100000001b3 ^ param_2 >> 0x10 & 0xff) * 0x100000001b3 ^
                   param_2 >> 0x18 & 0xff) * 0x100000001b3 ^ param_2 >> 0x20 & 0xff) * 0x100000001b3
                 ^ param_2 >> 0x28 & 0xff) * 0x100000001b3 ^ param_2 >> 0x30 & 0xff) * 0x100000001b3
               ^ param_2 >> 0x38) * 0x100000001b3 ^ (ulong)*(byte *)(param_1 + 0x11e)) *
              0x100000001b3;
  fn_377c38(&uStack_50,param_1 + 0x120);
  if (*(long *)(lVar1 + 0x28) == lStack_48) {
    return ((((((((uStack_50 ^ param_3 & 0xff) * 0x100000001b3 ^ param_3 >> 8 & 0xff) *
                 0x100000001b3 ^ param_3 >> 0x10 & 0xff) * 0x100000001b3 ^ param_3 >> 0x18 & 0xff) *
               0x100000001b3 ^ param_3 >> 0x20 & 0xff) * 0x100000001b3 ^ param_3 >> 0x28 & 0xff) *
             0x100000001b3 ^ param_3 >> 0x30 & 0xff) * 0x100000001b3 ^ param_3 >> 0x38) *
           0x100000001b3;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

