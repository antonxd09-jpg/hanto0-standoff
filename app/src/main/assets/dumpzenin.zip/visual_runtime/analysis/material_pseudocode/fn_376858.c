
// ================================================================================
// Source provider: @imguisource_bot
// Channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Channel: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x376858 */

bool fn_376858(undefined8 param_1,long *param_2)

{
  long lVar1;
  bool bVar2;
  undefined8 uVar3;
  ulong uVar4;
  long lVar5;
  long *plVar6;
  long *plVar7;
  long *plStack_50;
  long *plStack_48;
  undefined8 uStack_40;
  long lStack_38;
  
  lVar1 = tpidr_el0;
  lStack_38 = *(long *)(lVar1 + 0x28);
  plStack_50 = (long *)0x0;
  plStack_48 = (long *)0x0;
  uStack_40 = 0;
  lVar5 = (param_2[1] - *param_2 >> 3) * -0x5555555555555555;
  if (param_2[4] != 0) {
    lVar5 = lVar5 + 1;
  }
  uVar3 = fn_19b000();
  uVar4 = fn_19b0cc(uVar3,&plStack_50);
  if (((uVar4 & 1) == 0) || (lVar5 != (long)plStack_48 - (long)plStack_50 >> 3)) {
    bVar2 = true;
  }
  else {
    lVar5 = param_2[1] - *param_2;
    if (lVar5 != 0) {
      plVar6 = (long *)(*param_2 + 8);
      uVar4 = (lVar5 >> 3) * -0x5555555555555555;
      plVar7 = plStack_50;
      if (uVar4 < 2) {
        uVar4 = 1;
      }
      do {
        if (*plVar7 != *plVar6) {
          bVar2 = true;
          goto LAB_00476940;
        }
        uVar4 = uVar4 - 1;
        plVar6 = plVar6 + 3;
        plVar7 = plVar7 + 1;
      } while (uVar4 != 0);
    }
    if (param_2[4] == 0) {
      bVar2 = false;
    }
    else {
      bVar2 = plStack_48[-1] != param_2[4];
    }
  }
  if (plStack_50 != (long *)0x0) {
LAB_00476940:
    plStack_48 = plStack_50;
    fn_6790c8();
  }
  if (*(long *)(lVar1 + 0x28) == lStack_38) {
    return bVar2;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail();
}

