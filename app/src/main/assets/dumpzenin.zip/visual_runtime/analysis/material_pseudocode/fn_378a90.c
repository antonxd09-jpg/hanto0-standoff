
// ================================================================================
// Источник: @imguisource_bot | ImGui Source: @ImGui_Source_FIXNEY | shit src 🧨: @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x378a90 */

undefined  [16] fn_378a90(void)

{
  ulong uVar1;
  long *plVar2;
  undefined8 *in_x3;
  long *plVar3;
  long **pplVar4;
  long lVar5;
  ulong uVar6;
  long **pplVar7;
  long *plVar8;
  long *plVar9;
  long *plVar10;
  long *unaff_x24;
  undefined2 uVar11;
  undefined8 uVar12;
  float fVar13;
  undefined auVar14 [16];
  
  auVar14 = fn_139930(&UNK_007df23f);
  plVar2 = auVar14._0_8_;
  plVar3 = *auVar14._8_8_;
  plVar9 = (long *)plVar2[1];
  uVar6 = ((ulong)(uint)((int)plVar3 << 3) + 8 ^ (ulong)plVar3 >> 0x20) * -0x622015f714c7d297;
  uVar6 = ((ulong)plVar3 >> 0x20 ^ uVar6 >> 0x2f ^ uVar6) * -0x622015f714c7d297;
  plVar10 = (long *)((uVar6 ^ uVar6 >> 0x2f) * -0x622015f714c7d297);
  if (plVar9 != (long *)0x0) {
    uVar12 = NEON_cnt(plVar9,1);
    uVar11 = NEON_uaddlv(uVar12,1);
    uVar6 = CONCAT62((int6)((ulong)uVar12 >> 0x10),uVar11) & 0xffffffff;
    if (uVar6 < 2) {
      unaff_x24 = (long *)((ulong)plVar10 & (long)plVar9 - 1U);
    }
    else {
      unaff_x24 = plVar10;
      if (plVar9 <= plVar10) {
        uVar1 = 0;
        if (plVar9 != (long *)0x0) {
          uVar1 = (ulong)plVar10 / (ulong)plVar9;
        }
        unaff_x24 = (long *)((long)plVar10 - uVar1 * (long)plVar9);
      }
    }
    pplVar7 = *(long ***)(*plVar2 + (long)unaff_x24 * 8);
    if ((pplVar7 != (long **)0x0) && (pplVar7 = (long **)*pplVar7, pplVar7 != (long **)0x0)) {
      do {
        plVar8 = pplVar7[1];
        if (plVar8 == plVar10) {
          if (pplVar7[2] == plVar3) {
            uVar12 = 0;
            goto code_r0x00478d7c;
          }
        }
        else {
          if (uVar6 < 2) {
            plVar8 = (long *)((ulong)plVar8 & (long)plVar9 - 1U);
          }
          else if (plVar9 <= plVar8) {
            uVar1 = 0;
            if (plVar9 != (long *)0x0) {
              uVar1 = (ulong)plVar8 / (ulong)plVar9;
            }
            plVar8 = (long *)((long)plVar8 - uVar1 * (long)plVar9);
          }
          if (plVar8 != unaff_x24) break;
        }
        pplVar7 = (long **)*pplVar7;
      } while (pplVar7 != (long **)0x0);
    }
  }
  pplVar7 = (long **)fn_679020(0x28);
  lVar5 = plVar2[3];
  pplVar4 = (long **)*in_x3;
  *pplVar7 = (long *)0x0;
  fVar13 = *(float *)(plVar2 + 4);
  plVar3 = *pplVar4;
  *(undefined4 *)(pplVar7 + 3) = 0;
  pplVar7[4] = (long *)0x0;
  pplVar7[1] = plVar10;
  pplVar7[2] = plVar3;
  if ((plVar9 == (long *)0x0) || (fVar13 * (float)ZEXT89(plVar9) < (float)(unkuint9)(lVar5 + 1))) {
    if (plVar9 < (long *)0x3) {
      uVar6 = 1;
    }
    else {
      uVar6 = (ulong)(((ulong)plVar9 & (long)plVar9 - 1U) != 0);
    }
    plVar3 = (long *)(uVar6 | (long)plVar9 << 1);
    plVar8 = (long *)(long)((float)(unkuint9)(lVar5 + 1) / fVar13);
    if (plVar3 <= plVar8) {
      plVar3 = plVar8;
    }
    if ((long)plVar3 - 1U == 0) {
      plVar3 = (long *)0x2;
    }
    else if (((ulong)plVar3 & (long)plVar3 - 1U) != 0) {
      plVar3 = (long *)fn_639934(plVar3);
      plVar9 = (long *)plVar2[1];
    }
    if (plVar9 < plVar3) {
code_r0x00478c50:
      func_0x00478da8(plVar2,plVar3);
    }
    else if (plVar3 < plVar9) {
      plVar8 = (long *)(long)((float)(unkuint9)(ulong)plVar2[3] / *(float *)(plVar2 + 4));
      if (plVar9 < (long *)0x3) {
code_r0x00478cc0:
        plVar8 = (long *)fn_639934();
      }
      else {
        uVar12 = NEON_cnt(plVar9,1);
        uVar11 = NEON_uaddlv(uVar12,1);
        if (1 < (CONCAT62((int6)((ulong)uVar12 >> 0x10),uVar11) & 0xffffffff))
        goto code_r0x00478cc0;
        if ((long *)0x1 < plVar8) {
          plVar8 = (long *)(1L << (-LZCOUNT((long)plVar8 - 1) & 0x3fU));
        }
      }
      if (plVar3 <= plVar8) {
        plVar3 = plVar8;
      }
      if (plVar3 < plVar9) goto code_r0x00478c50;
    }
    plVar9 = (long *)plVar2[1];
    if (((ulong)plVar9 & (long)plVar9 - 1U) == 0) {
      unaff_x24 = (long *)((long)plVar9 - 1U & (ulong)plVar10);
    }
    else {
      unaff_x24 = plVar10;
      if (plVar9 <= plVar10) {
        uVar6 = 0;
        if (plVar9 != (long *)0x0) {
          uVar6 = (ulong)plVar10 / (ulong)plVar9;
        }
        unaff_x24 = (long *)((long)plVar10 - uVar6 * (long)plVar9);
      }
    }
  }
  lVar5 = *plVar2;
  plVar3 = *(long **)(lVar5 + (long)unaff_x24 * 8);
  if (plVar3 == (long *)0x0) {
    pplVar4 = (long **)(plVar2 + 2);
    plVar3 = *pplVar4;
    *pplVar4 = (long *)pplVar7;
    *pplVar7 = plVar3;
    *(long ***)(lVar5 + (long)unaff_x24 * 8) = pplVar4;
    if (*pplVar7 == (long *)0x0) goto code_r0x00478d6c;
    plVar3 = *(long **)((long)*pplVar7 + 8);
    if (((ulong)plVar9 & (long)plVar9 - 1U) == 0) {
      plVar3 = (long *)((ulong)plVar3 & (long)plVar9 - 1U);
    }
    else if (plVar9 <= plVar3) {
      uVar6 = 0;
      if (plVar9 != (long *)0x0) {
        uVar6 = (ulong)plVar3 / (ulong)plVar9;
      }
      plVar3 = (long *)((long)plVar3 - uVar6 * (long)plVar9);
    }
    plVar3 = (long *)(*plVar2 + (long)plVar3 * 8);
  }
  else {
    *pplVar7 = (long *)*plVar3;
  }
  *plVar3 = (long)pplVar7;
code_r0x00478d6c:
  uVar12 = 1;
  plVar2[3] = plVar2[3] + 1;
code_r0x00478d7c:
  auVar14._8_8_ = uVar12;
  auVar14._0_8_ = pplVar7;
  return auVar14;
}

