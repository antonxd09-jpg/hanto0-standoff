
// ================================================================================
// Оригинал опубликован в @imguisource_bot
// TG: ImGui Source - @ImGui_Source_FIXNEY
// TG: shit src 🧨 - @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x3751bc */

void fn_3751bc(undefined4 param_1,undefined8 param_2,uint *param_3,byte param_4)

{
  uint uVar1;
  long lVar2;
  ulong uVar3;
  long lVar4;
  undefined auStack_14c [244];
  long lStack_58;
  
  lVar2 = tpidr_el0;
  lStack_58 = *(long *)(lVar2 + 0x28);
  uVar3 = fn_198128();
  if ((uVar3 & 1) != 0) {
    uVar1 = *param_3;
    if (0xb < (int)uVar1) {
      uVar1 = 0xc;
    }
    lVar4 = fn_37509c(uVar1 & ((int)uVar1 >> 0x1f ^ 0xffffffffU));
    if (lVar4 == 0) goto LAB_00475278;
    uVar3 = fn_3752a8();
    if ((uVar3 & 1) != 0) {
      uVar1 = *param_3;
      if (0xb < (int)uVar1) {
        uVar1 = 0xc;
      }
      fn_36f44c(auStack_14c,param_3,uVar1 & ((int)uVar1 >> 0x1f ^ 0xffffffffU),
                param_4 & *(char *)((long)param_3 + 0x11d) != '\0');
      fn_3756cc(param_1,param_2,lVar4,auStack_14c,0xc1c);
      lVar4 = 1;
      goto LAB_00475278;
    }
  }
  lVar4 = 0;
LAB_00475278:
  if (*(long *)(lVar2 + 0x28) == lStack_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(lVar4);
}

