
// ================================================================================
// Проверенные сурсы в боте @imguisource_bot
// Официальный канал: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Второй канал: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x3773f4 */

uint fn_3773f4(undefined8 param_1)

{
  uint uVar1;
  int iVar2;
  undefined8 uVar3;
  ulong uVar4;
  long lVar5;
  
  if (((bRam00000000076ac3f8 & 1) == 0) && (iVar2 = fn_65eda8(0x76ac3f8), iVar2 != 0)) {
    fn_1269d0(0x76a9760);
    imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
    fn_65eed8(0x76ac3f8);
  }
  uVar3 = fn_18e160();
  uVar4 = fn_43da88(0x76a9768,param_1,uVar3);
  if ((uVar4 & 1) == 0) {
    if (((bRam000000000787c6b0 & 1) == 0) && (iVar2 = fn_65eda8(0x787c6b0), iVar2 != 0)) {
      lVar5 = fn_126488();
      lRam000000000787c6a8 = fn_43d1bc(lVar5 + 8,&UNK_007e9f57);
      fn_65eed8(0x787c6b0);
    }
    if (lRam000000000787c6a8 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = fn_19992c(param_1);
    }
    uVar4 = fn_198128(uVar3);
    if ((uVar4 & 1) == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = fn_36ad40(uVar3);
    }
  }
  else {
    uVar3 = fn_19c120(param_1);
  }
  uVar4 = fn_198128(uVar3);
  if ((uVar4 & 1) == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = fn_36b0d8(uVar3);
    uVar1 = uVar1 & ((int)uVar1 >> 0x1f ^ 0xffffffffU);
  }
  return uVar1;
}

