
// ================================================================================
// Get latest sources from @imguisource_bot
// Join ImGui Source: t.me/ImGui_Source_FIXNEY
// Join shit src 🧨: t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x3760f8 */

void fn_3760f8(long param_1,ulong param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined4 uVar6;
  int iVar7;
  long lVar8;
  ulong uVar9;
  ulong uVar10;
  ulong uVar11;
  char *pcVar12;
  undefined8 uVar13;
  long lVar14;
  
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar7 = fn_65eda8(0x787c6a0), iVar7 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    puRam000000000787c580 = (undefined8 *)0x0;
    puRam000000000787c578 = (undefined8 *)0x0;
    uRam000000000787c590 = 0;
    puRam000000000787c588 = (undefined8 *)0x0;
    uRam000000000787c5a0 = 0;
    uRam000000000787c598 = 0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c688 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c689 = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  uVar10 = 0;
  uVar9 = (long)puRam000000000787c580 - (long)puRam000000000787c578 >> 4;
  if (param_1 != 0 && param_2 != 0) {
    uVar11 = 0;
    pcVar12 = (char *)(param_1 + 9);
    do {
      if ((*pcVar12 != '\0') && ((byte)(pcVar12[-1] | 4U) != 4)) {
        if ((uVar9 <= uVar10) || (puRam000000000787c578[uVar10 * 2] != *(long *)(pcVar12 + -9)))
        goto LAB_004761b8;
        uVar10 = uVar10 + 1;
      }
      uVar11 = uVar11 + 1;
      pcVar12 = pcVar12 + 0x10;
    } while (uVar11 < param_2);
  }
  if (uVar10 != uVar9) {
LAB_004761b8:
    puRam000000000787c580 = puRam000000000787c578;
    if (param_1 != 0 && param_2 != 0) {
      uVar10 = 0;
      do {
        puVar1 = (undefined8 *)(param_1 + uVar10 * 0x10);
        if ((*(char *)((long)puVar1 + 9) != '\0') && ((*(byte *)(puVar1 + 1) | 4) != 4)) {
          uVar13 = *puVar1;
          uVar9 = fn_198128(uVar13);
          if ((uVar9 & 1) == 0) {
            uVar6 = 0;
          }
          else {
            uVar6 = fn_3773f4(*puVar1);
          }
          puVar1 = puRam000000000787c580;
          puVar5 = puRam000000000787c578;
          if (puRam000000000787c580 < puRam000000000787c588) {
            *puRam000000000787c580 = uVar13;
            *(undefined4 *)(puRam000000000787c580 + 1) = uVar6;
            puRam000000000787c580 = puRam000000000787c580 + 2;
          }
          else {
            lVar14 = (long)puRam000000000787c580 - (long)puRam000000000787c578 >> 4;
            uVar9 = lVar14 + 1;
            if (uVar9 >> 0x3c != 0) {
              fn_377560(0x787c578);
LAB_004763d8:
              uVar13 = fn_13edb4();
              fn_65ef80(0x787c6a0);
                    /* WARNING: Subroutine does not return */
              fn_67b74c(uVar13);
            }
            uVar11 = (long)puRam000000000787c588 - (long)puRam000000000787c578 >> 3;
            if (uVar11 <= uVar9) {
              uVar11 = uVar9;
            }
            if (0x7fffffffffffffef <
                (ulong)((long)puRam000000000787c588 - (long)puRam000000000787c578)) {
              uVar11 = 0xfffffffffffffff;
            }
            if (uVar11 == 0) {
              lVar8 = 0;
            }
            else {
              if (uVar11 >> 0x3c != 0) goto LAB_004763d8;
              lVar8 = fn_679020(uVar11 << 4);
            }
            puVar2 = (undefined8 *)(lVar8 + lVar14 * 0x10);
            *puVar2 = uVar13;
            *(undefined4 *)(puVar2 + 1) = uVar6;
            puVar3 = puVar2;
            puVar4 = puVar1;
            while (puVar1 != puVar5) {
              uVar6 = *(undefined4 *)(puVar1 + -1);
              puVar3[-2] = puVar1[-2];
              *(undefined4 *)(puVar3 + -1) = uVar6;
              puVar3 = puVar3 + -2;
              puVar1 = puVar1 + -2;
              puVar4 = puRam000000000787c578;
            }
            puRam000000000787c588 = (undefined8 *)(lVar8 + uVar11 * 0x10);
            puVar2 = puVar2 + 2;
            puRam000000000787c578 = puVar3;
            puRam000000000787c580 = puVar2;
            if (puVar4 != (undefined8 *)0x0) {
              fn_6790c8(puVar4);
              puRam000000000787c580 = puVar2;
            }
          }
        }
        uVar10 = uVar10 + 1;
      } while (uVar10 < param_2);
    }
  }
  return;
}

