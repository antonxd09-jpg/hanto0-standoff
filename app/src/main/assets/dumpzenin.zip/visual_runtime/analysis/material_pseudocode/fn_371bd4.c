
// ================================================================================
// Find more on @imguisource_bot | @ImGui_Source_FIXNEY | @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x371bd4 */

ulong fn_371bd4(void)

{
  long lVar1;
  long lVar2;
  int iVar3;
  uint uVar4;
  ulong uVar5;
  ulong uVar6;
  undefined8 uVar7;
  ulong uVar8;
  long lVar9;
  long lStack_2f8;
  long lStack_2f0;
  undefined8 auStack_2e0 [5];
  undefined8 auStack_2b8 [60];
  undefined8 auStack_d8 [13];
  long lStack_70;
  
  lVar2 = tpidr_el0;
  lStack_70 = *(long *)(lVar2 + 0x28);
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar3 = fn_65eda8(0x787c6a0), iVar3 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    uRam000000000787c580 = 0;
    uRam000000000787c578 = 0;
    uRam000000000787c590 = 0;
    uRam000000000787c588 = 0;
    uRam000000000787c5a0 = 0;
    uRam000000000787c598 = 0;
    uRam000000000787c5b0 = 0;
    uRam000000000787c5a8 = 0;
    uRam000000000787c5c0 = 0;
    uRam000000000787c5b8 = 0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c680 = 0;
    _uRam000000000787c691 = 0;
    uRam000000000787c688 = 0;
    iRam000000000787c68c = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  if ((lRam000000000787bfc0 == 0) || (uVar5 = fn_198128(), (uVar5 & 1) == 0)) {
    if (iRam000000000787c68c < uRam000000000787c691._3_4_) goto LAB_00471d64;
    fn_378f04(1);
    fn_384b18(&lStack_2f8);
    lRam000000000787bfc0 = fn_19e998(lStack_2f8,lStack_2f0 - lStack_2f8);
    uVar5 = fn_198128();
    if ((uVar5 & 1) == 0) {
      uVar5 = 0;
      lRam000000000787bfc0 = 0;
      uRam000000000787c691 = CONCAT43(iRam000000000787c68c + 0x1e,(undefined3)uRam000000000787c691);
    }
    else {
      uRam000000000787bfc8 = fn_439970(lRam000000000787bfc0);
      lVar9 = lRam000000000787bfc0;
      uVar4 = fn_198de0(lRam000000000787bfc0);
      fn_199704(lVar9,uVar4 | 0x20);
      lVar9 = lRam000000000787bfc0;
      if (((bRam000000000787c6f8 & 1) == 0) && (iVar3 = fn_65eda8(0x787c6f8), iVar3 != 0)) {
        uRam000000000787c6eb = 0;
        uRam000000000787c6e8 = 0;
        uRam000000000787c6d0 = 0;
        uRam000000000787c6c8 = 0;
        uRam000000000787c6e0 = 0;
        uRam000000000787c6e3 = 0;
        uRam000000000787c6d8 = 0;
        uRam000000000787c6c0 = 0;
        uRam000000000787c6b8 = 0;
        fn_126978(&UNK_02f48593,0x787c6b8,0x3b,0x7544fbcd80fb8b3c);
        fn_65eed8(0x787c6f8);
      }
      uRam000000000787bfd0 = fn_19f170(lVar9,0x787c6b8);
      uVar5 = fn_198128();
      if ((uVar5 & 1) == 0) {
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        fn_378f04(1);
      }
      else {
        uRam000000000787bfd8 = fn_439970(uRam000000000787bfd0);
        if (((bRam000000000787c730 & 1) == 0) && (iVar3 = fn_65eda8(0x787c730), iVar3 != 0)) {
          uRam000000000787c718 = 0;
          uRam000000000787c710 = 0;
          uRam000000000787c728 = 0;
          uRam000000000787c720 = 0;
          uRam000000000787c708 = 0;
          uRam000000000787c700 = 0;
          fn_126978(&UNK_02f485ce,0x787c700,0x30,0x87682c451b6e045e);
          fn_65eed8(0x787c730);
        }
        auStack_d8[0] = 0x787c700;
        if (((bRam000000000787c770 & 1) == 0) && (iVar3 = fn_65eda8(0x787c770), iVar3 != 0)) {
          uRam000000000787c768 = 0;
          uRam000000000787c750 = 0;
          uRam000000000787c748 = 0;
          uRam000000000787c760 = 0;
          uRam000000000787c758 = 0;
          uRam000000000787c740 = 0;
          uRam000000000787c738 = 0;
          fn_126978(&UNK_02f485fe,0x787c738,0x31,0xe9dde122e1ea7073);
          fn_65eed8(0x787c770);
        }
        auStack_d8[1] = 0x787c738;
        if (((bRam000000000787c7a8 & 1) == 0) && (iVar3 = fn_65eda8(0x787c7a8), iVar3 != 0)) {
          uRam000000000787c79f = 0;
          uRam000000000787c798 = 0;
          uRam000000000787c780 = 0;
          uRam000000000787c778 = 0;
          uRam000000000787c790 = 0;
          uRam000000000787c797 = 0;
          uRam000000000787c788 = 0;
          fn_126978(&UNK_02f4862f,0x787c778,0x2f,0x53b21c26b49d8506);
          fn_65eed8(0x787c7a8);
        }
        auStack_d8[2] = 0x787c778;
        if (((bRam000000000787c7e8 & 1) == 0) && (iVar3 = fn_65eda8(0x787c7e8), iVar3 != 0)) {
          uRam000000000787c7e0 = 0;
          uRam000000000787c7c8 = 0;
          uRam000000000787c7c0 = 0;
          uRam000000000787c7d8 = 0;
          uRam000000000787c7dd = 0;
          uRam000000000787c7d0 = 0;
          uRam000000000787c7b8 = 0;
          uRam000000000787c7b0 = 0;
          fn_126978(&UNK_02f4865e,0x787c7b0,0x35,0x72521421cbecec50);
          fn_65eed8(0x787c7e8);
        }
        auStack_d8[3] = 0x787c7b0;
        if (((bRam000000000787c828 & 1) == 0) && (iVar3 = fn_65eda8(0x787c828), iVar3 != 0)) {
          uRam000000000787c820 = 0;
          uRam000000000787c808 = 0;
          uRam000000000787c800 = 0;
          uRam000000000787c818 = 0;
          uRam000000000787c81d = 0;
          uRam000000000787c810 = 0;
          uRam000000000787c7f8 = 0;
          uRam000000000787c7f0 = 0;
          fn_126978(&UNK_02f48693,0x787c7f0,0x35,0x6c1ed3792c29f71e);
          fn_65eed8(0x787c828);
        }
        auStack_d8[4] = 0x787c7f0;
        if (((bRam000000000787c868 & 1) == 0) && (iVar3 = fn_65eda8(0x787c868), iVar3 != 0)) {
          uRam000000000787c860 = 0;
          uRam000000000787c848 = 0;
          uRam000000000787c840 = 0;
          uRam000000000787c858 = 0;
          uRam000000000787c850 = 0;
          uRam000000000787c838 = 0;
          uRam000000000787c830 = 0;
          fn_126978(&UNK_02f486c8,0x787c830,0x31,0x89bd960104fd9b3f);
          fn_65eed8(0x787c868);
        }
        auStack_d8[5] = 0x787c830;
        if (((bRam000000000787c8a8 & 1) == 0) && (iVar3 = fn_65eda8(0x787c8a8), iVar3 != 0)) {
          uRam000000000787c8a0 = 0;
          uRam000000000787c888 = 0;
          uRam000000000787c880 = 0;
          uRam000000000787c898 = 0;
          uRam000000000787c890 = 0;
          uRam000000000787c878 = 0;
          uRam000000000787c870 = 0;
          fn_126978(&UNK_02f486f9,0x787c870,0x34,0x3fb073c9e091f4e);
          fn_65eed8(0x787c8a8);
        }
        auStack_d8[6] = 0x787c870;
        if (((bRam000000000787c8e0 & 1) == 0) && (iVar3 = fn_65eda8(0x787c8e0), iVar3 != 0)) {
          uRam000000000787c8c8 = 0;
          uRam000000000787c8c0 = 0;
          uRam000000000787c8d8 = 0;
          uRam000000000787c8d0 = 0;
          uRam000000000787c8b8 = 0;
          uRam000000000787c8b0 = 0;
          fn_126978(&UNK_02f4872d,0x787c8b0,0x30,0x8aeabc80668f5d9a);
          fn_65eed8(0x787c8e0);
        }
        auStack_d8[7] = 0x787c8b0;
        if (((bRam000000000787c918 & 1) == 0) && (iVar3 = fn_65eda8(0x787c918), iVar3 != 0)) {
          uRam000000000787c90f = 0;
          uRam000000000787c908 = 0;
          uRam000000000787c8f0 = 0;
          uRam000000000787c8e8 = 0;
          uRam000000000787c900 = 0;
          uRam000000000787c907 = 0;
          uRam000000000787c8f8 = 0;
          fn_126978(&UNK_02f4875d,0x787c8e8,0x2f,0x2c66d98cbdb9ea2a);
          fn_65eed8(0x787c918);
        }
        auStack_d8[8] = 0x787c8e8;
        if (((bRam000000000787c958 & 1) == 0) && (iVar3 = fn_65eda8(0x787c958), iVar3 != 0)) {
          uRam000000000787c950 = 0;
          uRam000000000787c938 = 0;
          uRam000000000787c930 = 0;
          uRam000000000787c948 = 0;
          uRam000000000787c940 = 0;
          uRam000000000787c928 = 0;
          uRam000000000787c920 = 0;
          fn_126978(&UNK_02f4878c,0x787c920,0x32,0x36afb4c40376632d);
          fn_65eed8(0x787c958);
        }
        auStack_d8[9] = 0x787c920;
        if (((bRam000000000787c990 & 1) == 0) && (iVar3 = fn_65eda8(0x787c990), iVar3 != 0)) {
          uRam000000000787c987 = 0;
          uRam000000000787c980 = 0;
          uRam000000000787c968 = 0;
          uRam000000000787c960 = 0;
          uRam000000000787c978 = 0;
          uRam000000000787c97f = 0;
          uRam000000000787c970 = 0;
          fn_126978(&UNK_02f487be,0x787c960,0x2f,0x1f7bd41abc98786c);
          fn_65eed8(0x787c990);
        }
        auStack_d8[10] = 0x787c960;
        if (((bRam000000000787c9c8 & 1) == 0) && (iVar3 = fn_65eda8(0x787c9c8), iVar3 != 0)) {
          uRam000000000787c9be = 0;
          uRam000000000787c9b8 = 0;
          uRam000000000787c9a0 = 0;
          uRam000000000787c998 = 0;
          uRam000000000787c9b0 = 0;
          uRam000000000787c9b6 = 0;
          uRam000000000787c9a8 = 0;
          fn_126978(&UNK_02f487ed,0x787c998,0x2e,0x1d460ac63ac91d91);
          fn_65eed8(0x787c9c8);
        }
        auStack_d8[11] = 0x787c998;
        if (((bRam000000000787ca08 & 1) == 0) && (iVar3 = fn_65eda8(0x787ca08), iVar3 != 0)) {
          uRam000000000787ca00 = 0;
          uRam000000000787c9e8 = 0;
          uRam000000000787c9e0 = 0;
          uRam000000000787c9f8 = 0;
          uRam000000000787c9fe = 0;
          uRam000000000787c9f0 = 0;
          uRam000000000787c9d8 = 0;
          uRam000000000787c9d0 = 0;
          fn_126978(&UNK_02f4881b,0x787c9d0,0x36,0x831e2b48b4653bd4);
          fn_65eed8(0x787ca08);
        }
        auStack_d8[12] = 0x787c9d0;
        lVar9 = 0;
        do {
          uVar7 = fn_19f170(lRam000000000787bfc0,*(undefined8 *)((long)auStack_d8 + lVar9));
          *(undefined8 *)(lVar9 + 0x787bfe0) = uVar7;
          uVar5 = fn_198128();
          if ((uVar5 & 1) == 0) {
            if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
              fn_1269d0(0x76a9760);
              imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
              fn_65eed8(0x76ac3f8);
            }
            fn_378f04(1);
            goto LAB_004727e0;
          }
          uVar7 = fn_439970(*(undefined8 *)(lVar9 + 0x787bfe0));
          lVar1 = lVar9 + 8;
          *(undefined8 *)(lVar9 + 0x787c048) = uVar7;
          lVar9 = lVar1;
        } while (lVar1 != 0x68);
        if (((bRam000000000787ca48 & 1) == 0) && (iVar3 = fn_65eda8(0x787ca48), iVar3 != 0)) {
          uRam000000000787ca40 = 0;
          uRam000000000787ca28 = 0;
          uRam000000000787ca20 = 0;
          uRam000000000787ca38 = 0;
          uRam000000000787ca3d = 0;
          uRam000000000787ca30 = 0;
          uRam000000000787ca18 = 0;
          uRam000000000787ca10 = 0;
          fn_126978(&UNK_02f48851,0x787ca10,0x35,0xe60c8caaaa3f860d);
          fn_65eed8(0x787ca48);
        }
        if (((bRam000000000787ca90 & 1) == 0) && (iVar3 = fn_65eda8(0x787ca90), iVar3 != 0)) {
          uRam000000000787ca83 = 0;
          uRam000000000787ca80 = 0;
          uRam000000000787ca68 = 0;
          uRam000000000787ca60 = 0;
          uRam000000000787ca78 = 0;
          uRam000000000787ca7b = 0;
          uRam000000000787ca70 = 0;
          uRam000000000787ca58 = 0;
          uRam000000000787ca50 = 0;
          fn_126978(&UNK_02f48886,0x787ca50,0x3b,0x503a1104bf60c26b);
          fn_65eed8(0x787ca90);
        }
        uRam000000000787c0b0 = fn_19f170(lRam000000000787bfc0,0x787ca10);
        uVar5 = fn_198128();
        if ((uVar5 & 1) != 0) {
          uRam000000000787c0c0 = fn_439970(uRam000000000787c0b0);
          uRam000000000787c0b8 = fn_19f170(lRam000000000787bfc0,0x787ca50);
          uVar5 = fn_198128();
          if ((uVar5 & 1) != 0) {
            uRam000000000787c0c8 = fn_439970(uRam000000000787c0b8);
            if (((bRam000000000787cad0 & 1) == 0) && (iVar3 = fn_65eda8(0x787cad0), iVar3 != 0)) {
              uRam000000000787cac8 = 0;
              uRam000000000787cab0 = 0;
              uRam000000000787caa8 = 0;
              uRam000000000787cac0 = 0;
              uRam000000000787cac6 = 0;
              uRam000000000787cab8 = 0;
              uRam000000000787caa0 = 0;
              uRam000000000787ca98 = 0;
              fn_126978(&UNK_02f488c1,0x787ca98,0x36,0x36f90c068a418c6f);
              fn_65eed8(0x787cad0);
            }
            auStack_2b8[0] = 0x787ca98;
            if (((bRam000000000787cb10 & 1) == 0) && (iVar3 = fn_65eda8(0x787cb10), iVar3 != 0)) {
              uRam000000000787cb08 = 0;
              uRam000000000787caf0 = 0;
              uRam000000000787cae8 = 0;
              uRam000000000787cb00 = 0;
              uRam000000000787caf8 = 0;
              uRam000000000787cae0 = 0;
              uRam000000000787cad8 = 0;
              fn_126978(&UNK_02f488f7,0x787cad8,0x38,0x81b875e4e8090355);
              fn_65eed8(0x787cb10);
            }
            auStack_2b8[1] = 0x787cad8;
            if (((bRam000000000787cb50 & 1) == 0) && (iVar3 = fn_65eda8(0x787cb50), iVar3 != 0)) {
              uRam000000000787cb48 = 0;
              uRam000000000787cb30 = 0;
              uRam000000000787cb28 = 0;
              uRam000000000787cb40 = 0;
              uRam000000000787cb45 = 0;
              uRam000000000787cb38 = 0;
              uRam000000000787cb20 = 0;
              uRam000000000787cb18 = 0;
              fn_126978(&UNK_02f4892f,0x787cb18,0x35,0xe06651fc5b912420);
              fn_65eed8(0x787cb50);
            }
            auStack_2b8[2] = 0x787cb18;
            if (((bRam000000000787cb90 & 1) == 0) && (iVar3 = fn_65eda8(0x787cb90), iVar3 != 0)) {
              uRam000000000787cb70 = 0;
              uRam000000000787cb68 = 0;
              uRam000000000787cb80 = 0;
              uRam000000000787cb87 = 0;
              uRam000000000787cb78 = 0;
              uRam000000000787cb60 = 0;
              uRam000000000787cb58 = 0;
              fn_126978(&UNK_02f48964,0x787cb58,0x33,0x80cf30c5fe7acf4);
              fn_65eed8(0x787cb90);
            }
            auStack_2b8[3] = 0x787cb58;
            if (((bRam000000000787cbd8 & 1) == 0) && (iVar3 = fn_65eda8(0x787cbd8), iVar3 != 0)) {
              uRam000000000787cbcb = 0;
              uRam000000000787cbc8 = 0;
              uRam000000000787cbb0 = 0;
              uRam000000000787cba8 = 0;
              uRam000000000787cbc0 = 0;
              uRam000000000787cbc3 = 0;
              uRam000000000787cbb8 = 0;
              uRam000000000787cba0 = 0;
              uRam000000000787cb98 = 0;
              fn_126978(&UNK_02f48997,0x787cb98,0x3b,0x8e90591339a78ac1);
              fn_65eed8(0x787cbd8);
            }
            auStack_2b8[4] = 0x787cb98;
            if (((bRam000000000787cc20 & 1) == 0) && (iVar3 = fn_65eda8(0x787cc20), iVar3 != 0)) {
              uRam000000000787cc15 = 0;
              uRam000000000787cc10 = 0;
              uRam000000000787cbf8 = 0;
              uRam000000000787cbf0 = 0;
              uRam000000000787cc08 = 0;
              uRam000000000787cc0d = 0;
              uRam000000000787cc00 = 0;
              uRam000000000787cbe8 = 0;
              uRam000000000787cbe0 = 0;
              fn_126978(&UNK_02f489d2,0x787cbe0,0x3d,0x5aebd60a4045cf99);
              fn_65eed8(0x787cc20);
            }
            auStack_2b8[5] = 0x787cbe0;
            if (((bRam000000000787cc68 & 1) == 0) && (iVar3 = fn_65eda8(0x787cc68), iVar3 != 0)) {
              uRam000000000787cc5a = 0;
              uRam000000000787cc58 = 0;
              uRam000000000787cc40 = 0;
              uRam000000000787cc38 = 0;
              uRam000000000787cc50 = 0;
              uRam000000000787cc52 = 0;
              uRam000000000787cc48 = 0;
              uRam000000000787cc30 = 0;
              uRam000000000787cc28 = 0;
              fn_126978(&UNK_02f48a0f,0x787cc28,0x3a,0xd3c209feab65927a);
              fn_65eed8(0x787cc68);
            }
            auStack_2b8[6] = 0x787cc28;
            if (((bRam000000000787cca8 & 1) == 0) && (iVar3 = fn_65eda8(0x787cca8), iVar3 != 0)) {
              uRam000000000787cca0 = 0;
              uRam000000000787cc88 = 0;
              uRam000000000787cc80 = 0;
              uRam000000000787cc98 = 0;
              uRam000000000787cc90 = 0;
              uRam000000000787cc78 = 0;
              uRam000000000787cc70 = 0;
              fn_126978(&UNK_02f48a49,0x787cc70,0x38,0xd27acb52a36828b7);
              fn_65eed8(0x787cca8);
            }
            auStack_2b8[7] = 0x787cc70;
            if (((bRam000000000787ccf0 & 1) == 0) && (iVar3 = fn_65eda8(0x787ccf0), iVar3 != 0)) {
              uRam000000000787cce1 = 0;
              uRam000000000787cce0 = 0;
              uRam000000000787ccc8 = 0;
              uRam000000000787ccc0 = 0;
              uRam000000000787ccd8 = 0;
              uRam000000000787ccd9 = 0;
              uRam000000000787ccd0 = 0;
              uRam000000000787ccb8 = 0;
              uRam000000000787ccb0 = 0;
              fn_126978(&UNK_02f48a81,0x787ccb0,0x39,0x4160b23482aef6c0);
              fn_65eed8(0x787ccf0);
            }
            auStack_2b8[8] = 0x787ccb0;
            if (((bRam000000000787cd40 & 1) == 0) && (iVar3 = fn_65eda8(0x787cd40), iVar3 != 0)) {
              uRam000000000787cd00 = 0;
              uRam000000000787ccf8 = 0;
              uRam000000000787cd10 = 0;
              uRam000000000787cd08 = 0;
              uRam000000000787cd20 = 0;
              uRam000000000787cd18 = 0;
              uRam000000000787cd30 = 0;
              uRam000000000787cd37 = 0;
              uRam000000000787cd28 = 0;
              fn_126978(&UNK_02f48aba,0x787ccf8,0x43,0x89de72178c610149);
              fn_65eed8(0x787cd40);
            }
            auStack_2b8[9] = 0x787ccf8;
            if (((bRam000000000787cd80 & 1) == 0) && (iVar3 = fn_65eda8(0x787cd80), iVar3 != 0)) {
              uRam000000000787cd60 = 0;
              uRam000000000787cd58 = 0;
              uRam000000000787cd70 = 0;
              uRam000000000787cd77 = 0;
              uRam000000000787cd68 = 0;
              uRam000000000787cd50 = 0;
              uRam000000000787cd48 = 0;
              fn_126978(&UNK_02f48afd,0x787cd48,0x33,0xccb848a8920f7a90);
              fn_65eed8(0x787cd80);
            }
            auStack_2b8[10] = 0x787cd48;
            if (((bRam000000000787cdc8 & 1) == 0) && (iVar3 = fn_65eda8(0x787cdc8), iVar3 != 0)) {
              uRam000000000787cdb9 = 0;
              uRam000000000787cdb8 = 0;
              uRam000000000787cda0 = 0;
              uRam000000000787cd98 = 0;
              uRam000000000787cdb0 = 0;
              uRam000000000787cdb1 = 0;
              uRam000000000787cda8 = 0;
              uRam000000000787cd90 = 0;
              uRam000000000787cd88 = 0;
              fn_126978(&UNK_02f48b30,0x787cd88,0x39,0x628c267afaed69b8);
              fn_65eed8(0x787cdc8);
            }
            auStack_2b8[11] = 0x787cd88;
            if (((bRam000000000787ce10 & 1) == 0) && (iVar3 = fn_65eda8(0x787ce10), iVar3 != 0)) {
              uRam000000000787ce03 = 0;
              uRam000000000787ce00 = 0;
              uRam000000000787cde8 = 0;
              uRam000000000787cde0 = 0;
              uRam000000000787cdf8 = 0;
              uRam000000000787cdfb = 0;
              uRam000000000787cdf0 = 0;
              uRam000000000787cdd8 = 0;
              uRam000000000787cdd0 = 0;
              fn_126978(&UNK_02f48b69,0x787cdd0,0x3b,0x8d17a2c39b6f1a6);
              fn_65eed8(0x787ce10);
            }
            auStack_2b8[12] = 0x787cdd0;
            if (((bRam000000000787ce58 & 1) == 0) && (iVar3 = fn_65eda8(0x787ce58), iVar3 != 0)) {
              uRam000000000787ce4d = 0;
              uRam000000000787ce48 = 0;
              uRam000000000787ce30 = 0;
              uRam000000000787ce28 = 0;
              uRam000000000787ce40 = 0;
              uRam000000000787ce45 = 0;
              uRam000000000787ce38 = 0;
              uRam000000000787ce20 = 0;
              uRam000000000787ce18 = 0;
              fn_126978(&UNK_02f48ba4,0x787ce18,0x3d,0x146a9ee074c7add7);
              fn_65eed8(0x787ce58);
            }
            auStack_2b8[13] = 0x787ce18;
            if (((bRam000000000787cea0 & 1) == 0) && (iVar3 = fn_65eda8(0x787cea0), iVar3 != 0)) {
              uRam000000000787ce92 = 0;
              uRam000000000787ce90 = 0;
              uRam000000000787ce78 = 0;
              uRam000000000787ce70 = 0;
              uRam000000000787ce88 = 0;
              uRam000000000787ce8a = 0;
              uRam000000000787ce80 = 0;
              uRam000000000787ce68 = 0;
              uRam000000000787ce60 = 0;
              fn_126978(&UNK_02f48be1,0x787ce60,0x3a,0x262e512c367ac90e);
              fn_65eed8(0x787cea0);
            }
            auStack_2b8[14] = 0x787ce60;
            if (((bRam000000000787cee0 & 1) == 0) && (iVar3 = fn_65eda8(0x787cee0), iVar3 != 0)) {
              uRam000000000787ced8 = 0;
              uRam000000000787cec0 = 0;
              uRam000000000787ceb8 = 0;
              uRam000000000787ced0 = 0;
              uRam000000000787cec8 = 0;
              uRam000000000787ceb0 = 0;
              uRam000000000787cea8 = 0;
              fn_126978(&UNK_02f48c1b,0x787cea8,0x38,0xb61a7f71155a9e1a);
              fn_65eed8(0x787cee0);
            }
            auStack_2b8[15] = 0x787cea8;
            if (((bRam000000000787cf28 & 1) == 0) && (iVar3 = fn_65eda8(0x787cf28), iVar3 != 0)) {
              uRam000000000787cf19 = 0;
              uRam000000000787cf18 = 0;
              uRam000000000787cf00 = 0;
              uRam000000000787cef8 = 0;
              uRam000000000787cf10 = 0;
              uRam000000000787cf11 = 0;
              uRam000000000787cf08 = 0;
              uRam000000000787cef0 = 0;
              uRam000000000787cee8 = 0;
              fn_126978(&UNK_02f48c53,0x787cee8,0x39,0xdb6dc02f3de0099f);
              fn_65eed8(0x787cf28);
            }
            auStack_2b8[16] = 0x787cee8;
            if (((bRam000000000787cf78 & 1) == 0) && (iVar3 = fn_65eda8(0x787cf78), iVar3 != 0)) {
              uRam000000000787cf38 = 0;
              uRam000000000787cf30 = 0;
              uRam000000000787cf48 = 0;
              uRam000000000787cf40 = 0;
              uRam000000000787cf58 = 0;
              uRam000000000787cf50 = 0;
              uRam000000000787cf68 = 0;
              uRam000000000787cf6f = 0;
              uRam000000000787cf60 = 0;
              fn_126978(&UNK_02f48c8c,0x787cf30,0x43,0x3b63a0b820ffff8d);
              fn_65eed8(0x787cf78);
            }
            auStack_2b8[17] = 0x787cf30;
            if (((bRam000000000787cfb8 & 1) == 0) && (iVar3 = fn_65eda8(0x787cfb8), iVar3 != 0)) {
              uRam000000000787cfb0 = 0;
              uRam000000000787cf98 = 0;
              uRam000000000787cf90 = 0;
              uRam000000000787cfa8 = 0;
              uRam000000000787cfa0 = 0;
              uRam000000000787cf88 = 0;
              uRam000000000787cf80 = 0;
              fn_126978(&UNK_02f48ccf,0x787cf80,0x34,0x646e108ca64b6ca7);
              fn_65eed8(0x787cfb8);
            }
            auStack_2b8[18] = 0x787cf80;
            if (((bRam000000000787cff8 & 1) == 0) && (iVar3 = fn_65eda8(0x787cff8), iVar3 != 0)) {
              uRam000000000787cff0 = 0;
              uRam000000000787cfd8 = 0;
              uRam000000000787cfd0 = 0;
              uRam000000000787cfe8 = 0;
              uRam000000000787cfe0 = 0;
              uRam000000000787cfc8 = 0;
              uRam000000000787cfc0 = 0;
              fn_126978(&UNK_02f48d03,0x787cfc0,0x34,0xcb825437404b6876);
              fn_65eed8(0x787cff8);
            }
            auStack_2b8[19] = 0x787cfc0;
            if (((bRam000000000787d038 & 1) == 0) && (iVar3 = fn_65eda8(0x787d038), iVar3 != 0)) {
              uRam000000000787d030 = 0;
              uRam000000000787d018 = 0;
              uRam000000000787d010 = 0;
              uRam000000000787d028 = 0;
              uRam000000000787d02d = 0;
              uRam000000000787d020 = 0;
              uRam000000000787d008 = 0;
              uRam000000000787d000 = 0;
              fn_126978(&UNK_02f48d37,0x787d000,0x35,0xc7532d6b1f802092);
              fn_65eed8(0x787d038);
            }
            auStack_2b8[20] = 0x787d000;
            if (((bRam000000000787d080 & 1) == 0) && (iVar3 = fn_65eda8(0x787d080), iVar3 != 0)) {
              uRam000000000787d075 = 0;
              uRam000000000787d070 = 0;
              uRam000000000787d058 = 0;
              uRam000000000787d050 = 0;
              uRam000000000787d068 = 0;
              uRam000000000787d06d = 0;
              uRam000000000787d060 = 0;
              uRam000000000787d048 = 0;
              uRam000000000787d040 = 0;
              fn_126978(&UNK_02f48d6c,0x787d040,0x3d,0xde814c76529b73ec);
              fn_65eed8(0x787d080);
            }
            auStack_2b8[21] = 0x787d040;
            if (((bRam000000000787d0c8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d0c8), iVar3 != 0)) {
              uRam000000000787d0bf = 0;
              uRam000000000787d0b8 = 0;
              uRam000000000787d0a0 = 0;
              uRam000000000787d098 = 0;
              uRam000000000787d0b0 = 0;
              uRam000000000787d0b7 = 0;
              uRam000000000787d0a8 = 0;
              uRam000000000787d090 = 0;
              uRam000000000787d088 = 0;
              fn_126978(&UNK_02f48da9,0x787d088,0x3f,0x27efb2f9dd51192a);
              fn_65eed8(0x787d0c8);
            }
            auStack_2b8[22] = 0x787d088;
            if (((bRam000000000787d110 & 1) == 0) && (iVar3 = fn_65eda8(0x787d110), iVar3 != 0)) {
              uRam000000000787d104 = 0;
              uRam000000000787d100 = 0;
              uRam000000000787d0e8 = 0;
              uRam000000000787d0e0 = 0;
              uRam000000000787d0f8 = 0;
              uRam000000000787d0fc = 0;
              uRam000000000787d0f0 = 0;
              uRam000000000787d0d8 = 0;
              uRam000000000787d0d0 = 0;
              fn_126978(&UNK_02f48de8,0x787d0d0,0x3c,0x9472fc9c88018c1f);
              fn_65eed8(0x787d110);
            }
            auStack_2b8[23] = 0x787d0d0;
            if (((bRam000000000787d158 & 1) == 0) && (iVar3 = fn_65eda8(0x787d158), iVar3 != 0)) {
              uRam000000000787d14a = 0;
              uRam000000000787d148 = 0;
              uRam000000000787d130 = 0;
              uRam000000000787d128 = 0;
              uRam000000000787d140 = 0;
              uRam000000000787d142 = 0;
              uRam000000000787d138 = 0;
              uRam000000000787d120 = 0;
              uRam000000000787d118 = 0;
              fn_126978(&UNK_02f48e24,0x787d118,0x3a,0xf50b0036aa28c1ef);
              fn_65eed8(0x787d158);
            }
            auStack_2b8[24] = 0x787d118;
            if (((bRam000000000787d1a0 & 1) == 0) && (iVar3 = fn_65eda8(0x787d1a0), iVar3 != 0)) {
              uRam000000000787d193 = 0;
              uRam000000000787d190 = 0;
              uRam000000000787d178 = 0;
              uRam000000000787d170 = 0;
              uRam000000000787d188 = 0;
              uRam000000000787d18b = 0;
              uRam000000000787d180 = 0;
              uRam000000000787d168 = 0;
              uRam000000000787d160 = 0;
              fn_126978(&UNK_02f48e5e,0x787d160,0x3b,0x65ffeed413495dd);
              fn_65eed8(0x787d1a0);
            }
            auStack_2b8[25] = 0x787d160;
            if (((bRam000000000787d1f0 & 1) == 0) && (iVar3 = fn_65eda8(0x787d1f0), iVar3 != 0)) {
              uRam000000000787d1e8 = 0;
              uRam000000000787d1b0 = 0;
              uRam000000000787d1a8 = 0;
              uRam000000000787d1c0 = 0;
              uRam000000000787d1b8 = 0;
              uRam000000000787d1d0 = 0;
              uRam000000000787d1c8 = 0;
              uRam000000000787d1e0 = 0;
              uRam000000000787d1e5 = 0;
              uRam000000000787d1d8 = 0;
              fn_126978(&UNK_02f48e99,0x787d1a8,0x45,0x5092e8293abd7c95);
              fn_65eed8(0x787d1f0);
            }
            auStack_2b8[26] = 0x787d1a8;
            if (((bRam000000000787d238 & 1) == 0) && (iVar3 = fn_65eda8(0x787d238), iVar3 != 0)) {
              uRam000000000787d22d = 0;
              uRam000000000787d228 = 0;
              uRam000000000787d210 = 0;
              uRam000000000787d208 = 0;
              uRam000000000787d220 = 0;
              uRam000000000787d225 = 0;
              uRam000000000787d218 = 0;
              uRam000000000787d200 = 0;
              uRam000000000787d1f8 = 0;
              fn_126978(&UNK_02f48ede,0x787d1f8,0x3d,0x4b9f7b470c1aeb98);
              fn_65eed8(0x787d238);
            }
            auStack_2b8[27] = 0x787d1f8;
            if (((bRam000000000787d280 & 1) == 0) && (iVar3 = fn_65eda8(0x787d280), iVar3 != 0)) {
              uRam000000000787d277 = 0;
              uRam000000000787d270 = 0;
              uRam000000000787d258 = 0;
              uRam000000000787d250 = 0;
              uRam000000000787d268 = 0;
              uRam000000000787d26f = 0;
              uRam000000000787d260 = 0;
              uRam000000000787d248 = 0;
              uRam000000000787d240 = 0;
              fn_126978(&UNK_02f48f1b,0x787d240,0x3f,0x88d4649dabda2e01);
              fn_65eed8(0x787d280);
            }
            auStack_2b8[28] = 0x787d240;
            if (((bRam000000000787d2c8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d2c8), iVar3 != 0)) {
              uRam000000000787d2bc = 0;
              uRam000000000787d2b8 = 0;
              uRam000000000787d2a0 = 0;
              uRam000000000787d298 = 0;
              uRam000000000787d2b0 = 0;
              uRam000000000787d2b4 = 0;
              uRam000000000787d2a8 = 0;
              uRam000000000787d290 = 0;
              uRam000000000787d288 = 0;
              fn_126978(&UNK_02f48f5a,0x787d288,0x3c,0x91f8c87798c2f478);
              fn_65eed8(0x787d2c8);
            }
            auStack_2b8[29] = 0x787d288;
            if (((bRam000000000787d310 & 1) == 0) && (iVar3 = fn_65eda8(0x787d310), iVar3 != 0)) {
              uRam000000000787d302 = 0;
              uRam000000000787d300 = 0;
              uRam000000000787d2e8 = 0;
              uRam000000000787d2e0 = 0;
              uRam000000000787d2f8 = 0;
              uRam000000000787d2fa = 0;
              uRam000000000787d2f0 = 0;
              uRam000000000787d2d8 = 0;
              uRam000000000787d2d0 = 0;
              fn_126978(&UNK_02f48f96,0x787d2d0,0x3a,0xe49c2e97ff34db);
              fn_65eed8(0x787d310);
            }
            auStack_2b8[30] = 0x787d2d0;
            if (((bRam000000000787d358 & 1) == 0) && (iVar3 = fn_65eda8(0x787d358), iVar3 != 0)) {
              uRam000000000787d34b = 0;
              uRam000000000787d348 = 0;
              uRam000000000787d330 = 0;
              uRam000000000787d328 = 0;
              uRam000000000787d340 = 0;
              uRam000000000787d343 = 0;
              uRam000000000787d338 = 0;
              uRam000000000787d320 = 0;
              uRam000000000787d318 = 0;
              fn_126978(&UNK_02f48fd0,0x787d318,0x3b,0xc6f43141a5b16fba);
              fn_65eed8(0x787d358);
            }
            auStack_2b8[31] = 0x787d318;
            if (((bRam000000000787d3a8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d3a8), iVar3 != 0)) {
              uRam000000000787d3a0 = 0;
              uRam000000000787d368 = 0;
              uRam000000000787d360 = 0;
              uRam000000000787d378 = 0;
              uRam000000000787d370 = 0;
              uRam000000000787d388 = 0;
              uRam000000000787d380 = 0;
              uRam000000000787d398 = 0;
              uRam000000000787d39d = 0;
              uRam000000000787d390 = 0;
              fn_126978(&UNK_02f4900b,0x787d360,0x45,0x676e2e8e5eebdb68);
              fn_65eed8(0x787d3a8);
            }
            auStack_2b8[32] = 0x787d360;
            if (((bRam000000000787d3e8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d3e8), iVar3 != 0)) {
              uRam000000000787d3e0 = 0;
              uRam000000000787d3c8 = 0;
              uRam000000000787d3c0 = 0;
              uRam000000000787d3d8 = 0;
              uRam000000000787d3df = 0;
              uRam000000000787d3d0 = 0;
              uRam000000000787d3b8 = 0;
              uRam000000000787d3b0 = 0;
              fn_126978(&UNK_02f49050,0x787d3b0,0x37,0xfc12ebf31791d34a);
              fn_65eed8(0x787d3e8);
            }
            auStack_2b8[33] = 0x787d3b0;
            if (((bRam000000000787d428 & 1) == 0) && (iVar3 = fn_65eda8(0x787d428), iVar3 != 0)) {
              uRam000000000787d420 = 0;
              uRam000000000787d408 = 0;
              uRam000000000787d400 = 0;
              uRam000000000787d418 = 0;
              uRam000000000787d41f = 0;
              uRam000000000787d410 = 0;
              uRam000000000787d3f8 = 0;
              uRam000000000787d3f0 = 0;
              fn_126978(&UNK_02f49087,0x787d3f0,0x37,0x18acce7203879f73);
              fn_65eed8(0x787d428);
            }
            auStack_2b8[34] = 0x787d3f0;
            if (((bRam000000000787d468 & 1) == 0) && (iVar3 = fn_65eda8(0x787d468), iVar3 != 0)) {
              uRam000000000787d460 = 0;
              uRam000000000787d448 = 0;
              uRam000000000787d440 = 0;
              uRam000000000787d458 = 0;
              uRam000000000787d45f = 0;
              uRam000000000787d450 = 0;
              uRam000000000787d438 = 0;
              uRam000000000787d430 = 0;
              fn_126978(&UNK_02f490be,0x787d430,0x37,0x595fcab41fc36ddb);
              fn_65eed8(0x787d468);
            }
            auStack_2b8[35] = 0x787d430;
            if (((bRam000000000787d4a8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d4a8), iVar3 != 0)) {
              uRam000000000787d4a0 = 0;
              uRam000000000787d488 = 0;
              uRam000000000787d480 = 0;
              uRam000000000787d498 = 0;
              uRam000000000787d490 = 0;
              uRam000000000787d478 = 0;
              uRam000000000787d470 = 0;
              fn_126978(&UNK_02f490f5,0x787d470,0x38,0xd5faef6cdbfe753);
              fn_65eed8(0x787d4a8);
            }
            auStack_2b8[36] = 0x787d470;
            if (((bRam000000000787d4e8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d4e8), iVar3 != 0)) {
              uRam000000000787d4e0 = 0;
              uRam000000000787d4c8 = 0;
              uRam000000000787d4c0 = 0;
              uRam000000000787d4d8 = 0;
              uRam000000000787d4de = 0;
              uRam000000000787d4d0 = 0;
              uRam000000000787d4b8 = 0;
              uRam000000000787d4b0 = 0;
              fn_126978(&UNK_02f4912d,0x787d4b0,0x36,0x2c2e364a25bfc0db);
              fn_65eed8(0x787d4e8);
            }
            auStack_2b8[37] = 0x787d4b0;
            if (((bRam000000000787d528 & 1) == 0) && (iVar3 = fn_65eda8(0x787d528), iVar3 != 0)) {
              uRam000000000787d520 = 0;
              uRam000000000787d508 = 0;
              uRam000000000787d500 = 0;
              uRam000000000787d518 = 0;
              uRam000000000787d510 = 0;
              uRam000000000787d4f8 = 0;
              uRam000000000787d4f0 = 0;
              fn_126978(&UNK_02f49163,0x787d4f0,0x34,0xe2c6efb7d30e184);
              fn_65eed8(0x787d528);
            }
            auStack_2b8[38] = 0x787d4f0;
            if (((bRam000000000787d568 & 1) == 0) && (iVar3 = fn_65eda8(0x787d568), iVar3 != 0)) {
              uRam000000000787d560 = 0;
              uRam000000000787d548 = 0;
              uRam000000000787d540 = 0;
              uRam000000000787d558 = 0;
              uRam000000000787d55e = 0;
              uRam000000000787d550 = 0;
              uRam000000000787d538 = 0;
              uRam000000000787d530 = 0;
              fn_126978(&UNK_02f49197,0x787d530,0x36,0xa07412835530dc09);
              fn_65eed8(0x787d568);
            }
            auStack_2b8[39] = 0x787d530;
            if (((bRam000000000787d5b0 & 1) == 0) && (iVar3 = fn_65eda8(0x787d5b0), iVar3 != 0)) {
              uRam000000000787d5a2 = 0;
              uRam000000000787d5a0 = 0;
              uRam000000000787d588 = 0;
              uRam000000000787d580 = 0;
              uRam000000000787d598 = 0;
              uRam000000000787d59a = 0;
              uRam000000000787d590 = 0;
              uRam000000000787d578 = 0;
              uRam000000000787d570 = 0;
              fn_126978(&UNK_02f491cd,0x787d570,0x3a,0xe6f8cdf7d8f35e25);
              fn_65eed8(0x787d5b0);
            }
            auStack_2b8[40] = 0x787d570;
            if (((bRam000000000787d5f8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d5f8), iVar3 != 0)) {
              uRam000000000787d5ed = 0;
              uRam000000000787d5e8 = 0;
              uRam000000000787d5d0 = 0;
              uRam000000000787d5c8 = 0;
              uRam000000000787d5e0 = 0;
              uRam000000000787d5e5 = 0;
              uRam000000000787d5d8 = 0;
              uRam000000000787d5c0 = 0;
              uRam000000000787d5b8 = 0;
              fn_126978(&UNK_02f49207,0x787d5b8,0x3d,0x26052d43b6f37697);
              fn_65eed8(0x787d5f8);
            }
            auStack_2b8[41] = 0x787d5b8;
            if (((bRam000000000787d638 & 1) == 0) && (iVar3 = fn_65eda8(0x787d638), iVar3 != 0)) {
              uRam000000000787d630 = 0;
              uRam000000000787d618 = 0;
              uRam000000000787d610 = 0;
              uRam000000000787d628 = 0;
              uRam000000000787d62e = 0;
              uRam000000000787d620 = 0;
              uRam000000000787d608 = 0;
              uRam000000000787d600 = 0;
              fn_126978(&UNK_02f49244,0x787d600,0x36,0x9b7a7453ff4acd38);
              fn_65eed8(0x787d638);
            }
            auStack_2b8[42] = 0x787d600;
            if (((bRam000000000787d680 & 1) == 0) && (iVar3 = fn_65eda8(0x787d680), iVar3 != 0)) {
              uRam000000000787d648 = 0;
              uRam000000000787d640 = 0;
              uRam000000000787d658 = 0;
              uRam000000000787d650 = 0;
              uRam000000000787d668 = 0;
              uRam000000000787d660 = 0;
              uRam000000000787d678 = 0;
              uRam000000000787d670 = 0;
              fn_126978(&UNK_02f4927a,0x787d640,0x40,0x2c9ab29e40b98aba);
              fn_65eed8(0x787d680);
            }
            auStack_2b8[43] = 0x787d640;
            if (((bRam000000000787d6d0 & 1) == 0) && (iVar3 = fn_65eda8(0x787d6d0), iVar3 != 0)) {
              uRam000000000787d6c8 = 0;
              uRam000000000787d690 = 0;
              uRam000000000787d688 = 0;
              uRam000000000787d6a0 = 0;
              uRam000000000787d698 = 0;
              uRam000000000787d6b0 = 0;
              uRam000000000787d6a8 = 0;
              uRam000000000787d6c0 = 0;
              uRam000000000787d6b8 = 0;
              fn_126978(&UNK_02f492ba,0x787d688,0x42,0xe317793ffa547332);
              fn_65eed8(0x787d6d0);
            }
            auStack_2b8[44] = 0x787d688;
            if (((bRam000000000787d718 & 1) == 0) && (iVar3 = fn_65eda8(0x787d718), iVar3 != 0)) {
              uRam000000000787d70f = 0;
              uRam000000000787d708 = 0;
              uRam000000000787d6f0 = 0;
              uRam000000000787d6e8 = 0;
              uRam000000000787d700 = 0;
              uRam000000000787d707 = 0;
              uRam000000000787d6f8 = 0;
              uRam000000000787d6e0 = 0;
              uRam000000000787d6d8 = 0;
              fn_126978(&UNK_02f492fc,0x787d6d8,0x3f,0x9f4dc1318edcbca8);
              fn_65eed8(0x787d718);
            }
            auStack_2b8[45] = 0x787d6d8;
            if (((bRam000000000787d760 & 1) == 0) && (iVar3 = fn_65eda8(0x787d760), iVar3 != 0)) {
              uRam000000000787d755 = 0;
              uRam000000000787d750 = 0;
              uRam000000000787d738 = 0;
              uRam000000000787d730 = 0;
              uRam000000000787d748 = 0;
              uRam000000000787d74d = 0;
              uRam000000000787d740 = 0;
              uRam000000000787d728 = 0;
              uRam000000000787d720 = 0;
              fn_126978(&UNK_02f4933b,0x787d720,0x3d,0x51783d2ae1f415ef);
              fn_65eed8(0x787d760);
            }
            auStack_2b8[46] = 0x787d720;
            if (((bRam000000000787d7a8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d7a8), iVar3 != 0)) {
              uRam000000000787d79e = 0;
              uRam000000000787d798 = 0;
              uRam000000000787d780 = 0;
              uRam000000000787d778 = 0;
              uRam000000000787d790 = 0;
              uRam000000000787d796 = 0;
              uRam000000000787d788 = 0;
              uRam000000000787d770 = 0;
              uRam000000000787d768 = 0;
              fn_126978(&UNK_02f49378,0x787d768,0x3e,0x67980d2b05de0669);
              fn_65eed8(0x787d7a8);
            }
            auStack_2b8[47] = 0x787d768;
            if (((bRam000000000787d7f8 & 1) == 0) && (iVar3 = fn_65eda8(0x787d7f8), iVar3 != 0)) {
              uRam000000000787d7f0 = 0;
              uRam000000000787d7b8 = 0;
              uRam000000000787d7b0 = 0;
              uRam000000000787d7c8 = 0;
              uRam000000000787d7c0 = 0;
              uRam000000000787d7d8 = 0;
              uRam000000000787d7d0 = 0;
              uRam000000000787d7e8 = 0;
              uRam000000000787d7e0 = 0;
              fn_126978(&UNK_02f493b6,0x787d7b0,0x48,0xc69db61cd8e7ad73);
              fn_65eed8(0x787d7f8);
            }
            auStack_2b8[48] = 0x787d7b0;
            if (((bRam000000000787d840 & 1) == 0) && (iVar3 = fn_65eda8(0x787d840), iVar3 != 0)) {
              uRam000000000787d834 = 0;
              uRam000000000787d830 = 0;
              uRam000000000787d818 = 0;
              uRam000000000787d810 = 0;
              uRam000000000787d828 = 0;
              uRam000000000787d82c = 0;
              uRam000000000787d820 = 0;
              uRam000000000787d808 = 0;
              uRam000000000787d800 = 0;
              fn_126978(&UNK_02f493fe,0x787d800,0x3c,0xb0e697f6ef03825c);
              fn_65eed8(0x787d840);
            }
            auStack_2b8[49] = 0x787d800;
            if (((bRam000000000787d888 & 1) == 0) && (iVar3 = fn_65eda8(0x787d888), iVar3 != 0)) {
              uRam000000000787d87e = 0;
              uRam000000000787d878 = 0;
              uRam000000000787d860 = 0;
              uRam000000000787d858 = 0;
              uRam000000000787d870 = 0;
              uRam000000000787d876 = 0;
              uRam000000000787d868 = 0;
              uRam000000000787d850 = 0;
              uRam000000000787d848 = 0;
              fn_126978(&UNK_02f4943a,0x787d848,0x3e,0xf0017ec86fd34db3);
              fn_65eed8(0x787d888);
            }
            auStack_2b8[50] = 0x787d848;
            if (((bRam000000000787d8d0 & 1) == 0) && (iVar3 = fn_65eda8(0x787d8d0), iVar3 != 0)) {
              uRam000000000787d8c3 = 0;
              uRam000000000787d8c0 = 0;
              uRam000000000787d8a8 = 0;
              uRam000000000787d8a0 = 0;
              uRam000000000787d8b8 = 0;
              uRam000000000787d8bb = 0;
              uRam000000000787d8b0 = 0;
              uRam000000000787d898 = 0;
              uRam000000000787d890 = 0;
              fn_126978(&UNK_02f49478,0x787d890,0x3b,0x9f448bdbff186fbe);
              fn_65eed8(0x787d8d0);
            }
            auStack_2b8[51] = 0x787d890;
            if (((bRam000000000787d918 & 1) == 0) && (iVar3 = fn_65eda8(0x787d918), iVar3 != 0)) {
              uRam000000000787d909 = 0;
              uRam000000000787d908 = 0;
              uRam000000000787d8f0 = 0;
              uRam000000000787d8e8 = 0;
              uRam000000000787d900 = 0;
              uRam000000000787d901 = 0;
              uRam000000000787d8f8 = 0;
              uRam000000000787d8e0 = 0;
              uRam000000000787d8d8 = 0;
              fn_126978(&UNK_02f494b3,0x787d8d8,0x39,0x2e86a32a1a304fb4);
              fn_65eed8(0x787d918);
            }
            auStack_2b8[52] = 0x787d8d8;
            if (((bRam000000000787d960 & 1) == 0) && (iVar3 = fn_65eda8(0x787d960), iVar3 != 0)) {
              uRam000000000787d952 = 0;
              uRam000000000787d950 = 0;
              uRam000000000787d938 = 0;
              uRam000000000787d930 = 0;
              uRam000000000787d948 = 0;
              uRam000000000787d94a = 0;
              uRam000000000787d940 = 0;
              uRam000000000787d928 = 0;
              uRam000000000787d920 = 0;
              fn_126978(&UNK_02f494ec,0x787d920,0x3a,0xbeee227edc9ff88b);
              fn_65eed8(0x787d960);
            }
            auStack_2b8[53] = 0x787d920;
            if (((bRam000000000787d9b0 & 1) == 0) && (iVar3 = fn_65eda8(0x787d9b0), iVar3 != 0)) {
              uRam000000000787d9a8 = 0;
              uRam000000000787d970 = 0;
              uRam000000000787d968 = 0;
              uRam000000000787d980 = 0;
              uRam000000000787d978 = 0;
              uRam000000000787d990 = 0;
              uRam000000000787d988 = 0;
              uRam000000000787d9a0 = 0;
              uRam000000000787d998 = 0;
              fn_126978(&UNK_02f49526,0x787d968,0x44,0xe0192292f9915be1);
              fn_65eed8(0x787d9b0);
            }
            auStack_2b8[54] = 0x787d968;
            if (((bRam000000000787d9f0 & 1) == 0) && (iVar3 = fn_65eda8(0x787d9f0), iVar3 != 0)) {
              uRam000000000787d9e8 = 0;
              uRam000000000787d9d0 = 0;
              uRam000000000787d9c8 = 0;
              uRam000000000787d9e0 = 0;
              uRam000000000787d9e6 = 0;
              uRam000000000787d9d8 = 0;
              uRam000000000787d9c0 = 0;
              uRam000000000787d9b8 = 0;
              fn_126978(&UNK_02f4956a,0x787d9b8,0x36,0x2a7df82abc143fd1);
              fn_65eed8(0x787d9f0);
            }
            auStack_2b8[55] = 0x787d9b8;
            if (((bRam000000000787da30 & 1) == 0) && (iVar3 = fn_65eda8(0x787da30), iVar3 != 0)) {
              uRam000000000787da28 = 0;
              uRam000000000787da10 = 0;
              uRam000000000787da08 = 0;
              uRam000000000787da20 = 0;
              uRam000000000787da25 = 0;
              uRam000000000787da18 = 0;
              uRam000000000787da00 = 0;
              uRam000000000787d9f8 = 0;
              fn_126978(&UNK_02f495a0,0x787d9f8,0x35,0x8897f7d3b4b76ebf);
              fn_65eed8(0x787da30);
            }
            auStack_2b8[56] = 0x787d9f8;
            if (((bRam000000000787da70 & 1) == 0) && (iVar3 = fn_65eda8(0x787da70), iVar3 != 0)) {
              uRam000000000787da68 = 0;
              uRam000000000787da50 = 0;
              uRam000000000787da48 = 0;
              uRam000000000787da60 = 0;
              uRam000000000787da67 = 0;
              uRam000000000787da58 = 0;
              uRam000000000787da40 = 0;
              uRam000000000787da38 = 0;
              fn_126978(&UNK_02f495d5,0x787da38,0x37,0xeb095d2d00591f10);
              fn_65eed8(0x787da70);
            }
            auStack_2b8[57] = 0x787da38;
            if (((bRam000000000787dab0 & 1) == 0) && (iVar3 = fn_65eda8(0x787dab0), iVar3 != 0)) {
              uRam000000000787daa8 = 0;
              uRam000000000787da90 = 0;
              uRam000000000787da88 = 0;
              uRam000000000787daa0 = 0;
              uRam000000000787daa5 = 0;
              uRam000000000787da98 = 0;
              uRam000000000787da80 = 0;
              uRam000000000787da78 = 0;
              fn_126978(&UNK_02f4960c,0x787da78,0x35,0xe25d978b9e3ffd68);
              fn_65eed8(0x787dab0);
            }
            auStack_2b8[58] = 0x787da78;
            if (((bRam000000000787daf0 & 1) == 0) && (iVar3 = fn_65eda8(0x787daf0), iVar3 != 0)) {
              uRam000000000787dae8 = 0;
              uRam000000000787dad0 = 0;
              uRam000000000787dac8 = 0;
              uRam000000000787dae0 = 0;
              uRam000000000787dae7 = 0;
              uRam000000000787dad8 = 0;
              uRam000000000787dac0 = 0;
              uRam000000000787dab8 = 0;
              fn_126978(&UNK_02f49641,0x787dab8,0x37,0x4490cc243eecf83);
              fn_65eed8(0x787daf0);
            }
            lVar9 = 0;
            auStack_2b8[59] = 0x787dab8;
            do {
              uVar7 = fn_19f170(lRam000000000787bfc0,*(undefined8 *)((long)auStack_2b8 + lVar9));
              *(undefined8 *)(lVar9 + 0x787c0d0) = uVar7;
              uVar5 = fn_198128();
              if ((uVar5 & 1) == 0) {
                *(undefined8 *)(lVar9 + 0x787c0d0) = 0;
                if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0))
                {
                  fn_1269d0(0x76a9760);
                  imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                  fn_65eed8(0x76ac3f8);
                }
              }
              else {
                uVar7 = fn_439970(*(undefined8 *)(lVar9 + 0x787c0d0));
                *(undefined8 *)(lVar9 + 0x787c2b0) = uVar7;
              }
              lVar9 = lVar9 + 8;
            } while (lVar9 != 0x1e0);
            if (((bRam000000000787db20 & 1) == 0) && (iVar3 = fn_65eda8(0x787db20), iVar3 != 0)) {
              uRam000000000787db18 = 0;
              uRam000000000787db00 = 0;
              uRam000000000787daf8 = 0;
              uRam000000000787db10 = 0;
              uRam000000000787db17 = 0;
              uRam000000000787db08 = 0;
              fn_126978(&UNK_02f49678,0x787daf8,0x27,0x936748ac98b8013);
              fn_65eed8(0x787db20);
            }
            auStack_2e0[0] = 0x787daf8;
            if (((bRam000000000787db58 & 1) == 0) && (iVar3 = fn_65eda8(0x787db58), iVar3 != 0)) {
              uRam000000000787db4c = 0;
              uRam000000000787db48 = 0;
              uRam000000000787db30 = 0;
              uRam000000000787db28 = 0;
              uRam000000000787db40 = 0;
              uRam000000000787db44 = 0;
              uRam000000000787db38 = 0;
              fn_126978(&UNK_02f4969f,0x787db28,0x2c,0xd4e6c8c22fd72c56);
              fn_65eed8(0x787db58);
            }
            auStack_2e0[1] = 0x787db28;
            if (((bRam000000000787db90 & 1) == 0) && (iVar3 = fn_65eda8(0x787db90), iVar3 != 0)) {
              uRam000000000787db82 = 0;
              uRam000000000787db80 = 0;
              uRam000000000787db68 = 0;
              uRam000000000787db60 = 0;
              uRam000000000787db78 = 0;
              uRam000000000787db7a = 0;
              uRam000000000787db70 = 0;
              fn_126978(&UNK_02f496cb,0x787db60,0x2a,0xd6d5dfbc17215183);
              fn_65eed8(0x787db90);
            }
            auStack_2e0[2] = 0x787db60;
            if (((bRam000000000787dbc8 & 1) == 0) && (iVar3 = fn_65eda8(0x787dbc8), iVar3 != 0)) {
              uRam000000000787dbbb = 0;
              uRam000000000787dbb8 = 0;
              uRam000000000787dba0 = 0;
              uRam000000000787db98 = 0;
              uRam000000000787dbb0 = 0;
              uRam000000000787dbb3 = 0;
              uRam000000000787dba8 = 0;
              fn_126978(&UNK_02f496f5,0x787db98,0x2b,0xefa045e796a3293f);
              fn_65eed8(0x787dbc8);
            }
            auStack_2e0[3] = 0x787db98;
            if (((bRam000000000787dbf8 & 1) == 0) && (iVar3 = fn_65eda8(0x787dbf8), iVar3 != 0)) {
              uRam000000000787dbf0 = 0;
              uRam000000000787dbd8 = 0;
              uRam000000000787dbd0 = 0;
              uRam000000000787dbe8 = 0;
              uRam000000000787dbed = 0;
              uRam000000000787dbe0 = 0;
              fn_126978(&UNK_02f49720,0x787dbd0,0x25,0x462678e4dc63e89f);
              fn_65eed8(0x787dbf8);
            }
            lVar9 = 0;
            auStack_2e0[4] = 0x787dbd0;
            do {
              uVar7 = fn_19f29c(lRam000000000787bfc0,*(undefined8 *)((long)auStack_2e0 + lVar9));
              *(undefined8 *)(lVar9 + 0x787c490) = uVar7;
              uVar5 = fn_198128();
              if ((uVar5 & 1) == 0) {
                *(undefined8 *)(lVar9 + 0x787c490) = 0;
                if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0))
                {
                  fn_1269d0(0x76a9760);
                  imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                  fn_65eed8(0x76ac3f8);
                }
              }
              else {
                uVar7 = fn_439970(*(undefined8 *)(lVar9 + 0x787c490));
                *(undefined8 *)(lVar9 + 0x787c4b8) = uVar7;
              }
              lVar9 = lVar9 + 8;
            } while (lVar9 != 0x28);
            if (((bRam000000000787dc40 & 1) == 0) && (iVar3 = fn_65eda8(0x787dc40), iVar3 != 0)) {
              uRam000000000787dc32 = 0;
              uRam000000000787dc30 = 0;
              uRam000000000787dc18 = 0;
              uRam000000000787dc10 = 0;
              uRam000000000787dc28 = 0;
              uRam000000000787dc2a = 0;
              uRam000000000787dc20 = 0;
              uRam000000000787dc08 = 0;
              uRam000000000787dc00 = 0;
              fn_126978(&UNK_02f49745,0x787dc00,0x3a,0xda5838141a95ae48);
              fn_65eed8(0x787dc40);
            }
            if (((bRam000000000787dc78 & 1) == 0) && (iVar3 = fn_65eda8(0x787dc78), iVar3 != 0)) {
              uRam000000000787dc6e = 0;
              uRam000000000787dc68 = 0;
              uRam000000000787dc50 = 0;
              uRam000000000787dc48 = 0;
              uRam000000000787dc60 = 0;
              uRam000000000787dc66 = 0;
              uRam000000000787dc58 = 0;
              fn_126978(&UNK_02f4977f,0x787dc48,0x2e,0xe417aee69583db55);
              fn_65eed8(0x787dc78);
            }
            uRam000000000787c4e0 = fn_19f29c(lRam000000000787bfc0,0x787dc00);
            uVar5 = fn_198128();
            if ((uVar5 & 1) == 0) {
              uRam000000000787c4e0 = 0;
              if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
                fn_1269d0(0x76a9760);
                imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                fn_65eed8(0x76ac3f8);
              }
            }
            else {
              uRam000000000787c4f0 = fn_439970(uRam000000000787c4e0);
            }
            uRam000000000787c4e8 = fn_19f29c(lRam000000000787bfc0,0x787dc48);
            uVar5 = fn_198128();
            if ((uVar5 & 1) == 0) {
              uRam000000000787c4e8 = 0;
              if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
                fn_1269d0(0x76a9760);
                imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
                fn_65eed8(0x76ac3f8);
              }
            }
            else {
              uRam000000000787c4f8 = fn_439970(uRam000000000787c4e8);
            }
            if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
              fn_1269d0(0x76a9760);
              imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
              fn_65eed8(0x76ac3f8);
            }
            uVar5 = 1;
            goto joined_r0x00472710;
          }
        }
        if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
          fn_1269d0(0x76a9760);
          imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
          fn_65eed8(0x76ac3f8);
        }
        fn_378f04(1);
      }
LAB_004727e0:
      uVar5 = 0;
      uRam000000000787c691 = CONCAT43(iRam000000000787c68c + 0x1e,(undefined3)uRam000000000787c691);
    }
joined_r0x00472710:
    if (lStack_2f8 != 0) {
      fn_6790c8(lStack_2f8);
    }
  }
  else {
    uVar5 = fn_198128(uRam000000000787bfd0);
    if (((((((uVar5 & 1) != 0) && (uVar5 = fn_198128(uRam000000000787bfe0), (uVar5 & 1) != 0)) &&
          (uVar5 = fn_198128(uRam000000000787bfe8), (uVar5 & 1) != 0)) &&
         ((uVar5 = fn_198128(uRam000000000787bff0), (uVar5 & 1) != 0 &&
          (uVar5 = fn_198128(uRam000000000787bff8), (uVar5 & 1) != 0)))) &&
        (((uVar5 = fn_198128(uRam000000000787c000), (uVar5 & 1) != 0 &&
          ((uVar5 = fn_198128(uRam000000000787c008), (uVar5 & 1) != 0 &&
           (uVar5 = fn_198128(uRam000000000787c010), (uVar5 & 1) != 0)))) &&
         (uVar5 = fn_198128(uRam000000000787c018), (uVar5 & 1) != 0)))) &&
       ((((uVar5 = fn_198128(uRam000000000787c020), (uVar5 & 1) != 0 &&
          (uVar5 = fn_198128(uRam000000000787c028), (uVar5 & 1) != 0)) &&
         (uVar5 = fn_198128(uRam000000000787c030), (uVar5 & 1) != 0)) &&
        (((uVar5 = fn_198128(uRam000000000787c038), (uVar5 & 1) != 0 &&
          (uVar5 = fn_198128(uRam000000000787c040), (uVar5 & 1) != 0)) &&
         (uVar6 = fn_198128(uRam000000000787c0b0), uVar5 = uRam000000000787c0b8, (uVar6 & 1) != 0)))
        ))) {
      if (*(long *)(lVar2 + 0x28) == lStack_70) {
        if (uRam000000000787c0b8 != 0) {
          if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
            fn_1269d0(0x76a9760);
            imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
            fn_65eed8(0x76ac3f8);
          }
          uVar6 = fn_139354(0x76a97a8,uVar5,0x18);
          if ((uVar6 & 1) != 0) {
            if (((bRam00000000076ac3f8 & 1) == 0) && (iVar3 = fn_65eda8(0x76ac3f8), iVar3 != 0)) {
              fn_1269d0(0x76a9760);
              imp___cxa_atexit(&UNK_00237910,0x76a9760,&DAT_064e5160);
              fn_65eed8(0x76ac3f8);
            }
            uVar8 = (ulong)uRam00000000076aa1d8;
            uVar6 = fn_139354(0x76a97a8,uVar8 + uVar5,8);
            if ((uVar6 & 1) != 0) {
              return (ulong)(*(long *)(uVar8 + uVar5) != 0);
            }
          }
          uVar5 = 0;
        }
        return uVar5;
      }
      goto LAB_0047482c;
    }
LAB_00471d64:
    uVar5 = 0;
  }
  if (*(long *)(lVar2 + 0x28) == lStack_70) {
    return uVar5;
  }
LAB_0047482c:
                    /* WARNING: Subroutine does not return */
  imp___stack_chk_fail(uVar5);
}

