
// ================================================================================
// Проверенные сурсы в боте @imguisource_bot
// Официальный канал: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Второй канал: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

/* ORIGINAL_RVA: 0x37895c */

void fn_37895c(long **param_1,long *param_2,long **param_3)

{
  ulong uVar1;
  long **pplVar2;
  long *plVar3;
  long lVar4;
  long *plVar5;
  long **pplVar6;
  ulong uVar7;
  long *plVar8;
  long *plVar9;
  undefined2 uVar10;
  undefined8 uVar11;
  
  plVar5 = (long *)param_2[1];
  plVar3 = param_3[1];
  uVar11 = NEON_cnt(plVar5,1);
  uVar10 = NEON_uaddlv(uVar11,1);
  uVar7 = CONCAT62((int6)((ulong)uVar11 >> 0x10),uVar10) & 0xffffffff;
  if (uVar7 < 2) {
    plVar3 = (long *)((long)plVar5 - 1U & (ulong)plVar3);
  }
  else if (plVar5 <= plVar3) {
    uVar1 = 0;
    if (plVar5 != (long *)0x0) {
      uVar1 = (ulong)plVar3 / (ulong)plVar5;
    }
    plVar3 = (long *)((long)plVar3 - uVar1 * (long)plVar5);
  }
  pplVar2 = *(long ***)(*param_2 + (long)plVar3 * 8);
  do {
    pplVar6 = pplVar2;
    pplVar2 = (long **)*pplVar6;
  } while ((long **)*pplVar6 != param_3);
  if (pplVar6 != (long **)(param_2 + 2)) {
    plVar8 = pplVar6[1];
    if (uVar7 < 2) {
      plVar8 = (long *)((ulong)plVar8 & (long)plVar5 - 1U);
    }
    else if (plVar5 <= plVar8) {
      uVar1 = 0;
      if (plVar5 != (long *)0x0) {
        uVar1 = (ulong)plVar8 / (ulong)plVar5;
      }
      plVar8 = (long *)((long)plVar8 - uVar1 * (long)plVar5);
    }
    if (plVar8 == plVar3) goto LAB_00478a28;
  }
  if (*param_3 != (long *)0x0) {
    plVar8 = (long *)(*param_3)[1];
    if (uVar7 < 2) {
      plVar8 = (long *)((ulong)plVar8 & (long)plVar5 - 1U);
    }
    else if (plVar5 <= plVar8) {
      uVar1 = 0;
      if (plVar5 != (long *)0x0) {
        uVar1 = (ulong)plVar8 / (ulong)plVar5;
      }
      plVar8 = (long *)((long)plVar8 - uVar1 * (long)plVar5);
    }
    if (plVar8 == plVar3) goto LAB_00478a28;
  }
  *(undefined8 *)(*param_2 + (long)plVar3 * 8) = 0;
LAB_00478a28:
  plVar8 = *param_3;
  if (plVar8 != (long *)0x0) {
    plVar9 = (long *)plVar8[1];
    if (uVar7 < 2) {
      plVar9 = (long *)((ulong)plVar9 & (long)plVar5 - 1U);
    }
    else if (plVar5 <= plVar9) {
      uVar7 = 0;
      if (plVar5 != (long *)0x0) {
        uVar7 = (ulong)plVar9 / (ulong)plVar5;
      }
      plVar9 = (long *)((long)plVar9 - uVar7 * (long)plVar5);
    }
    if (plVar9 != plVar3) {
      *(long ***)(*param_2 + (long)plVar9 * 8) = pplVar6;
      plVar8 = *param_3;
    }
  }
  lVar4 = param_2[3];
  *pplVar6 = plVar8;
  *param_3 = (long *)0x0;
  *param_1 = (long *)param_3;
  param_1[1] = param_2 + 2;
  param_2[3] = lVar4 + -1;
  *(undefined *)(param_1 + 2) = 1;
  return;
}

