
// ================================================================================
// ==================================================
//  Bot:     t.me/imguisource_bot
//  Channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
//  Channel: t.me/il2cpp_src (shit src 🧨)
// ==================================================
// ================================================================================

/* ORIGINAL_RVA: 0x377588 */

long ** fn_377588(long *param_1,long **param_2,undefined8 param_3,undefined8 *param_4)

{
  long **pplVar1;
  ulong uVar2;
  long lVar3;
  long lVar4;
  long *plVar5;
  long **pplVar6;
  long lVar7;
  ulong uVar8;
  long **pplVar9;
  long *plVar10;
  long *plVar11;
  long *plVar12;
  long *unaff_x26;
  undefined2 uVar13;
  undefined8 uVar14;
  float fVar15;
  
  lVar3 = tpidr_el0;
  lVar4 = *(long *)(lVar3 + 0x28);
  plVar5 = *param_2;
  plVar11 = (long *)param_1[1];
  uVar8 = ((ulong)(uint)((int)plVar5 << 3) + 8 ^ (ulong)plVar5 >> 0x20) * -0x622015f714c7d297;
  uVar8 = ((ulong)plVar5 >> 0x20 ^ uVar8 >> 0x2f ^ uVar8) * -0x622015f714c7d297;
  plVar12 = (long *)((uVar8 ^ uVar8 >> 0x2f) * -0x622015f714c7d297);
  if (plVar11 != (long *)0x0) {
    uVar14 = NEON_cnt(plVar11,1);
    uVar13 = NEON_uaddlv(uVar14,1);
    uVar8 = CONCAT62((int6)((ulong)uVar14 >> 0x10),uVar13) & 0xffffffff;
    if (uVar8 < 2) {
      unaff_x26 = (long *)((ulong)plVar12 & (long)plVar11 - 1U);
    }
    else {
      unaff_x26 = plVar12;
      if (plVar11 <= plVar12) {
        uVar2 = 0;
        if (plVar11 != (long *)0x0) {
          uVar2 = (ulong)plVar12 / (ulong)plVar11;
        }
        unaff_x26 = (long *)((long)plVar12 - uVar2 * (long)plVar11);
      }
    }
    pplVar9 = *(long ***)(*param_1 + (long)unaff_x26 * 8);
    if ((pplVar9 != (long **)0x0) && (pplVar9 = (long **)*pplVar9, pplVar9 != (long **)0x0)) {
      do {
        plVar10 = pplVar9[1];
        if (plVar10 == plVar12) {
          if (pplVar9[2] == plVar5) {
            uVar14 = 0;
            goto LAB_004778b4;
          }
        }
        else {
          if (uVar8 < 2) {
            plVar10 = (long *)((ulong)plVar10 & (long)plVar11 - 1U);
          }
          else if (plVar11 <= plVar10) {
            uVar2 = 0;
            if (plVar11 != (long *)0x0) {
              uVar2 = (ulong)plVar10 / (ulong)plVar11;
            }
            plVar10 = (long *)((long)plVar10 - uVar2 * (long)plVar11);
          }
          if (plVar10 != unaff_x26) break;
        }
        pplVar9 = (long **)*pplVar9;
      } while (pplVar9 != (long **)0x0);
    }
  }
  pplVar1 = (long **)(param_1 + 2);
  pplVar9 = (long **)fn_679020(0xa8);
  pplVar6 = (long **)*param_4;
  *pplVar9 = (long *)0x0;
  fVar15 = *(float *)(param_1 + 4);
  plVar5 = *pplVar6;
  pplVar9[1] = plVar12;
  pplVar9[2] = plVar5;
  pplVar9[0x10] = (long *)0x0;
  pplVar9[0xf] = (long *)0x0;
  pplVar9[0x12] = (long *)0x0;
  pplVar9[0x11] = (long *)0x0;
  pplVar9[0x10] = (long *)0xffffffffffffffff;
  pplVar9[0x11] = (long *)0xffffffffffffffff;
  *(undefined4 *)(pplVar9 + 0x12) = 0xffffffff;
  lVar7 = param_1[3];
  pplVar9[0x14] = (long *)0x0;
  pplVar9[0x13] = (long *)0x0;
  pplVar9[0xe] = (long *)0x0;
  pplVar9[0xd] = (long *)0x0;
  pplVar9[0xc] = (long *)0x0;
  pplVar9[0xb] = (long *)0x0;
  pplVar9[10] = (long *)0x0;
  pplVar9[9] = (long *)0x0;
  pplVar9[8] = (long *)0x0;
  pplVar9[7] = (long *)0x0;
  pplVar9[6] = (long *)0x0;
  pplVar9[5] = (long *)0x0;
  pplVar9[4] = (long *)0x0;
  pplVar9[3] = (long *)0x0;
  *(undefined8 *)((long)pplVar9 + 0x9b) = 0;
  *(undefined8 *)((long)pplVar9 + 0x94) = 0;
  pplVar6 = pplVar9;
  if ((plVar11 == (long *)0x0) || (fVar15 * (float)ZEXT89(plVar11) < (float)(unkuint9)(lVar7 + 1)))
  {
    if (plVar11 < (long *)0x3) {
      uVar8 = 1;
    }
    else {
      uVar8 = (ulong)(((ulong)plVar11 & (long)plVar11 - 1U) != 0);
    }
    plVar5 = (long *)(uVar8 | (long)plVar11 << 1);
    plVar10 = (long *)(long)((float)(unkuint9)(lVar7 + 1) / fVar15);
    if (plVar5 <= plVar10) {
      plVar5 = plVar10;
    }
    if ((long)plVar5 - 1U == 0) {
      plVar5 = (long *)0x2;
    }
    else if (((ulong)plVar5 & (long)plVar5 - 1U) != 0) {
      pplVar6 = (long **)fn_639934(plVar5);
      plVar11 = (long *)param_1[1];
      plVar5 = (long *)pplVar6;
    }
    if (plVar11 < plVar5) {
LAB_0047778c:
      pplVar6 = (long **)fn_377958(param_1,plVar5);
    }
    else if (plVar5 < plVar11) {
      pplVar6 = (long **)(long)((float)(unkuint9)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if (plVar11 < (long *)0x3) {
LAB_004777fc:
        pplVar6 = (long **)fn_639934();
      }
      else {
        uVar14 = NEON_cnt(plVar11,1);
        uVar13 = NEON_uaddlv(uVar14,1);
        if (1 < (CONCAT62((int6)((ulong)uVar14 >> 0x10),uVar13) & 0xffffffff)) goto LAB_004777fc;
        if ((long *)0x1 < pplVar6) {
          pplVar6 = (long **)(1L << (-LZCOUNT((long)pplVar6 + -1) & 0x3fU));
        }
      }
      if (plVar5 <= pplVar6) {
        plVar5 = (long *)pplVar6;
      }
      if (plVar5 < plVar11) goto LAB_0047778c;
    }
    plVar11 = (long *)param_1[1];
    if (((ulong)plVar11 & (long)plVar11 - 1U) == 0) {
      unaff_x26 = (long *)((long)plVar11 - 1U & (ulong)plVar12);
    }
    else {
      unaff_x26 = plVar12;
      if (plVar11 <= plVar12) {
        uVar8 = 0;
        if (plVar11 != (long *)0x0) {
          uVar8 = (ulong)plVar12 / (ulong)plVar11;
        }
        unaff_x26 = (long *)((long)plVar12 - uVar8 * (long)plVar11);
      }
    }
  }
  lVar7 = *param_1;
  plVar5 = *(long **)(lVar7 + (long)unaff_x26 * 8);
  if (plVar5 == (long *)0x0) {
    plVar5 = *pplVar1;
    *pplVar1 = (long *)pplVar9;
    *pplVar9 = plVar5;
    *(long ***)(lVar7 + (long)unaff_x26 * 8) = pplVar1;
    if (*pplVar9 == (long *)0x0) goto LAB_004778a4;
    plVar5 = *(long **)((long)*pplVar9 + 8);
    if (((ulong)plVar11 & (long)plVar11 - 1U) == 0) {
      plVar5 = (long *)((ulong)plVar5 & (long)plVar11 - 1U);
    }
    else if (plVar11 <= plVar5) {
      uVar8 = 0;
      if (plVar11 != (long *)0x0) {
        uVar8 = (ulong)plVar5 / (ulong)plVar11;
      }
      plVar5 = (long *)((long)plVar5 - uVar8 * (long)plVar11);
    }
    plVar5 = (long *)(*param_1 + (long)plVar5 * 8);
  }
  else {
    *pplVar9 = (long *)*plVar5;
  }
  *plVar5 = (long)pplVar9;
LAB_004778a4:
  uVar14 = 1;
  param_1[3] = param_1[3] + 1;
  param_1 = (long *)pplVar6;
LAB_004778b4:
  if (*(long *)(lVar3 + 0x28) != lVar4) {
                    /* WARNING: Subroutine does not return */
    imp___stack_chk_fail(param_1,uVar14);
  }
  return pplVar9;
}

