
// ================================================================================
// Find more on @imguisource_bot | @ImGui_Source_FIXNEY | @il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x3763f4 */

void fn_3763f4(long param_1,ulong param_2,char param_3)

{
  byte bVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  int iVar5;
  ulong uVar6;
  undefined8 *puVar7;
  long lVar8;
  long lVar9;
  undefined8 *puVar10;
  ulong uVar11;
  long *plVar12;
  undefined8 *puVar13;
  ulong uVar14;
  char *pcVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  
  if (((bRam000000000787c6a0 & 1) == 0) && (iVar5 = fn_65eda8(0x787c6a0), iVar5 != 0)) {
    fn_15adac(0x787aa08);
    imp_memset(0x787bfc0,0,0x5b0);
    uRam000000000787c570 = 0x3f800000;
    uRam000000000787c5c8 = 0x3f800000;
    uRam000000000787c580 = 0;
    uRam000000000787c578 = 0;
    puRam000000000787c590 = (undefined8 *)0x0;
    uRam000000000787c588 = 0;
    puRam000000000787c5a0 = (undefined8 *)0x0;
    puRam000000000787c598 = (undefined8 *)0x0;
    lRam000000000787c5b0 = 0;
    lRam000000000787c5a8 = 0;
    lRam000000000787c5c0 = 0;
    plRam000000000787c5b8 = (long *)0x0;
    uRam000000000787c5d8 = 0;
    uRam000000000787c5d0 = 0;
    uRam000000000787c5e8 = 0;
    uRam000000000787c5e0 = 0;
    uRam000000000787c5f8 = 0;
    uRam000000000787c5f0 = 0;
    uRam000000000787c608 = 0;
    uRam000000000787c600 = 0;
    uRam000000000787c618 = 0;
    uRam000000000787c610 = 0;
    uRam000000000787c628 = 0;
    uRam000000000787c620 = 0;
    uRam000000000787c638 = 0;
    uRam000000000787c630 = 0;
    uRam000000000787c648 = 0;
    uRam000000000787c640 = 0;
    uRam000000000787c658 = 0;
    uRam000000000787c650 = 0;
    uRam000000000787c668 = 0;
    uRam000000000787c660 = 0;
    uRam000000000787c678 = 0;
    uRam000000000787c670 = 0;
    uRam000000000787c688 = 0;
    uRam000000000787c680 = 0;
    uRam000000000787c691 = 0;
    uRam000000000787c689 = 0;
    uRam000000000787c690 = 0;
    imp___cxa_atexit(&UNK_00476040,0x787aa08,&DAT_064e5160);
    fn_65eed8(0x787c6a0);
  }
  puRam000000000787c598 = puRam000000000787c590;
  if ((((((cRam000000000787be2c == '\0') && (cRam000000000787be50 == '\0')) &&
        (cRam000000000787be74 == '\0')) &&
       (((cRam000000000787be98 == '\0' && (cRam000000000787bebc == '\0')) &&
        ((cRam000000000787bee0 == '\0' &&
         ((cRam000000000787bf04 == '\0' && (cRam000000000787bf28 == '\0')))))))) &&
      (cRam000000000787bf4c == '\0')) &&
     ((cRam000000000787bf70 == '\0' && (cRam000000000787bf94 == '\0')))) {
    lVar9 = lRam000000000787c5b0;
    plVar12 = plRam000000000787c5b8;
    if (lRam000000000787c5c0 != 0) {
      while (lRam000000000787c5b0 = lVar9, plVar12 != (long *)0x0) {
        plVar12 = (long *)*plVar12;
        fn_6790c8();
        lVar9 = lRam000000000787c5b0;
      }
      plRam000000000787c5b8 = (long *)0x0;
      if (lVar9 != 0) {
        lVar8 = 0;
        do {
          *(undefined8 *)(lRam000000000787c5a8 + lVar8 * 8) = 0;
          lVar8 = lVar8 + 1;
        } while (lVar9 != lVar8);
      }
      lRam000000000787c5c0 = 0;
    }
  }
  else if ((param_1 != 0) && (param_2 != 0)) {
    uVar14 = 0;
    do {
      pcVar15 = (char *)0x787bebc;
      puVar7 = (undefined8 *)(param_1 + uVar14 * 0x10);
      bVar1 = *(byte *)(puVar7 + 1);
      if (bVar1 < 3) {
        if (bVar1 == 1) {
          cVar2 = *(char *)((long)puVar7 + 9);
          pcVar15 = (char *)0x787bee0;
joined_r0x004765e8:
          if (cVar2 == '\0') goto LAB_00476564;
        }
        else {
          if (bVar1 == 2) {
            cVar2 = *(char *)((long)puVar7 + 9);
            goto joined_r0x004765e8;
          }
LAB_004765b0:
          pcVar15 = (char *)0x787be74;
          if (*(char *)((long)puVar7 + 9) == '\0') {
            if ((param_3 == '\0') || (*(char *)((long)puVar7 + 0xc) == '\0')) goto LAB_00476564;
            pcVar15 = (char *)0x787be50;
            if (*(char *)((long)puVar7 + 0xc) != param_3) {
              pcVar15 = (char *)0x787be2c;
            }
          }
        }
LAB_004765fc:
        if (((*pcVar15 != '\0') && (*(char *)((long)puVar7 + 10) != '\0')) &&
           (uVar6 = fn_198128(*puVar7), puVar13 = puRam000000000787c598,
           puVar4 = puRam000000000787c590, (uVar6 & 1) != 0)) {
          uVar16 = *puVar7;
          bVar1 = *(byte *)((long)puVar7 + 9) ^ 1;
          if (puRam000000000787c598 < puRam000000000787c5a0) {
            *puRam000000000787c598 = uVar16;
            puRam000000000787c598[1] = pcVar15;
            *(byte *)(puRam000000000787c598 + 2) = bVar1;
            puRam000000000787c598 = puRam000000000787c598 + 3;
          }
          else {
            lVar9 = (long)puRam000000000787c598 - (long)puRam000000000787c590 >> 3;
            uVar6 = lVar9 * -0x5555555555555555 + 1;
            if (0xaaaaaaaaaaaaaaa < uVar6) {
              fn_377574(0x787c590);
LAB_0047683c:
              uVar16 = fn_13edb4();
              fn_65ef80(0x787c6a0);
                    /* WARNING: Subroutine does not return */
              fn_67b74c(uVar16);
            }
            lVar8 = (long)puRam000000000787c5a0 - (long)puRam000000000787c590 >> 3;
            uVar11 = lVar8 * 0x5555555555555556;
            if (uVar11 < uVar6 || uVar11 - uVar6 == 0) {
              uVar11 = uVar6;
            }
            if (0x555555555555554 < (ulong)(lVar8 * -0x5555555555555555)) {
              uVar11 = 0xaaaaaaaaaaaaaaa;
            }
            if (uVar11 == 0) {
              lVar8 = 0;
            }
            else {
              if (0xaaaaaaaaaaaaaaa < uVar11) goto LAB_0047683c;
              lVar8 = fn_679020(uVar11 * 0x18);
            }
            puVar7 = (undefined8 *)(lVar8 + lVar9 * 8);
            *puVar7 = uVar16;
            puVar7[1] = pcVar15;
            *(byte *)(puVar7 + 2) = bVar1;
            puVar10 = puVar7;
            puVar3 = puVar13;
            for (; puVar13 != puVar4; puVar13 = puVar13 + -3) {
              uVar17 = puVar13[-2];
              uVar16 = puVar13[-3];
              *(undefined *)(puVar10 + -1) = *(undefined *)(puVar13 + -1);
              puVar10[-2] = uVar17;
              puVar10[-3] = uVar16;
              puVar10 = puVar10 + -3;
              puVar3 = puRam000000000787c590;
            }
            puVar7 = puVar7 + 3;
            puRam000000000787c5a0 = (undefined8 *)(lVar8 + uVar11 * 0x18);
            puRam000000000787c590 = puVar10;
            puRam000000000787c598 = puVar7;
            if (puVar3 != (undefined8 *)0x0) {
              fn_6790c8(puVar3);
              puRam000000000787c598 = puVar7;
            }
          }
        }
      }
      else if (bVar1 == 3) {
        pcVar15 = (char *)0x787be98;
        if (*(char *)((long)puVar7 + 9) != '\0') goto LAB_004765fc;
      }
      else if (bVar1 != 4) goto LAB_004765b0;
LAB_00476564:
      uVar14 = uVar14 + 1;
    } while (uVar14 < param_2);
  }
  return;
}

