
// ================================================================================
// +------------------------------------------------+
// | TG Bot: @imguisource_bot                       |
// | ImGui Source: @ImGui_Source_FIXNEY                        |
// | shit src 🧨: @il2cpp_src                        |
// +------------------------------------------------+
// ================================================================================

/* ORIGINAL_RVA: 0x377c38 */

void fn_377c38(ulong *param_1,byte *param_2)

{
  ulong uVar1;
  
  uVar1 = ((((*param_1 ^ (ulong)*param_2) * 0x100000001b3 ^ (ulong)param_2[1]) * 0x100000001b3 ^
           (ulong)param_2[2]) * 0x100000001b3 ^ (ulong)param_2[3]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[4]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((((((((((((((uVar1 ^ param_2[8]) * 0x100000001b3 ^ (ulong)param_2[9]) * 0x100000001b3 ^
                       (ulong)param_2[10]) * 0x100000001b3 ^ (ulong)param_2[0xb]) * 0x100000001b3 ^
                     (ulong)param_2[0xc]) * 0x100000001b3 ^ (ulong)param_2[0xd]) * 0x100000001b3 ^
                   (ulong)param_2[0xe]) * 0x100000001b3 ^ (ulong)param_2[0xf]) * 0x100000001b3 ^
                 (ulong)param_2[0x10]) * 0x100000001b3 ^ (ulong)param_2[0x11]) * 0x100000001b3 ^
               (ulong)param_2[0x12]) * 0x100000001b3 ^ (ulong)param_2[0x13]) * 0x100000001b3 ^
             (ulong)param_2[0x14]) * 0x100000001b3 ^ (ulong)param_2[0x15]) * 0x100000001b3 ^
           (ulong)param_2[0x16]) * 0x100000001b3 ^ (ulong)param_2[0x17]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((((((((((((((uVar1 ^ param_2[0x18]) * 0x100000001b3 ^ (ulong)param_2[0x19]) *
                        0x100000001b3 ^ (ulong)param_2[0x1a]) * 0x100000001b3 ^ (ulong)param_2[0x1b]
                      ) * 0x100000001b3 ^ (ulong)param_2[0x1c]) * 0x100000001b3 ^
                    (ulong)param_2[0x1d]) * 0x100000001b3 ^ (ulong)param_2[0x1e]) * 0x100000001b3 ^
                  (ulong)param_2[0x1f]) * 0x100000001b3 ^ (ulong)param_2[0x20]) * 0x100000001b3 ^
                (ulong)param_2[0x21]) * 0x100000001b3 ^ (ulong)param_2[0x22]) * 0x100000001b3 ^
              (ulong)param_2[0x23]) * 0x100000001b3 ^ (ulong)param_2[0x24]) * 0x100000001b3 ^
            (ulong)param_2[0x25]) * 0x100000001b3 ^ (ulong)param_2[0x26]) * 0x100000001b3 ^
          (ulong)param_2[0x27]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x28]) * 0x100000001b3 ^ (ulong)param_2[0x29]) * 0x100000001b3 ^
           (ulong)param_2[0x2a]) * 0x100000001b3 ^ (ulong)param_2[0x2b]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x2c]) * 0x100000001b3 ^ (ulong)param_2[0x2d]) * 0x100000001b3 ^
           (ulong)param_2[0x2e]) * 0x100000001b3 ^ (ulong)param_2[0x2f]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x30]) * 0x100000001b3 ^ (ulong)param_2[0x31]) * 0x100000001b3 ^
           (ulong)param_2[0x32]) * 0x100000001b3 ^ (ulong)param_2[0x33]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0x34]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0x35]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((((((((((((((uVar1 ^ param_2[0x38]) * 0x100000001b3 ^ (ulong)param_2[0x39]) *
                        0x100000001b3 ^ (ulong)param_2[0x3a]) * 0x100000001b3 ^ (ulong)param_2[0x3b]
                      ) * 0x100000001b3 ^ (ulong)param_2[0x3c]) * 0x100000001b3 ^
                    (ulong)param_2[0x3d]) * 0x100000001b3 ^ (ulong)param_2[0x3e]) * 0x100000001b3 ^
                  (ulong)param_2[0x3f]) * 0x100000001b3 ^ (ulong)param_2[0x40]) * 0x100000001b3 ^
                (ulong)param_2[0x41]) * 0x100000001b3 ^ (ulong)param_2[0x42]) * 0x100000001b3 ^
              (ulong)param_2[0x43]) * 0x100000001b3 ^ (ulong)param_2[0x44]) * 0x100000001b3 ^
            (ulong)param_2[0x45]) * 0x100000001b3 ^ (ulong)param_2[0x46]) * 0x100000001b3 ^
          (ulong)param_2[0x47]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x48]) * 0x100000001b3 ^ (ulong)param_2[0x49]) * 0x100000001b3 ^
           (ulong)param_2[0x4a]) * 0x100000001b3 ^ (ulong)param_2[0x4b]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x4c]) * 0x100000001b3 ^ (ulong)param_2[0x4d]) * 0x100000001b3 ^
           (ulong)param_2[0x4e]) * 0x100000001b3 ^ (ulong)param_2[0x4f]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0x50]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x54]) * 0x100000001b3 ^ (ulong)param_2[0x55]) * 0x100000001b3 ^
           (ulong)param_2[0x56]) * 0x100000001b3 ^ (ulong)param_2[0x57]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x58]) * 0x100000001b3 ^ (ulong)param_2[0x59]) * 0x100000001b3 ^
           (ulong)param_2[0x5a]) * 0x100000001b3 ^ (ulong)param_2[0x5b]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x5c]) * 0x100000001b3 ^ (ulong)param_2[0x5d]) * 0x100000001b3 ^
           (ulong)param_2[0x5e]) * 0x100000001b3 ^ (ulong)param_2[0x5f]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x60]) * 0x100000001b3 ^ (ulong)param_2[0x61]) * 0x100000001b3 ^
           (ulong)param_2[0x62]) * 0x100000001b3 ^ (ulong)param_2[99]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[100]) * 0x100000001b3 ^ (ulong)param_2[0x65]) * 0x100000001b3 ^
           (ulong)param_2[0x66]) * 0x100000001b3 ^ (ulong)param_2[0x67]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x68]) * 0x100000001b3 ^ (ulong)param_2[0x69]) * 0x100000001b3 ^
           (ulong)param_2[0x6a]) * 0x100000001b3 ^ (ulong)param_2[0x6b]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x6c]) * 0x100000001b3 ^ (ulong)param_2[0x6d]) * 0x100000001b3 ^
           (ulong)param_2[0x6e]) * 0x100000001b3 ^ (ulong)param_2[0x6f]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0x70]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0x71]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((((((((((((((uVar1 ^ param_2[0x74]) * 0x100000001b3 ^ (ulong)param_2[0x75]) *
                        0x100000001b3 ^ (ulong)param_2[0x76]) * 0x100000001b3 ^ (ulong)param_2[0x77]
                      ) * 0x100000001b3 ^ (ulong)param_2[0x78]) * 0x100000001b3 ^
                    (ulong)param_2[0x79]) * 0x100000001b3 ^ (ulong)param_2[0x7a]) * 0x100000001b3 ^
                  (ulong)param_2[0x7b]) * 0x100000001b3 ^ (ulong)param_2[0x7c]) * 0x100000001b3 ^
                (ulong)param_2[0x7d]) * 0x100000001b3 ^ (ulong)param_2[0x7e]) * 0x100000001b3 ^
              (ulong)param_2[0x7f]) * 0x100000001b3 ^ (ulong)param_2[0x80]) * 0x100000001b3 ^
            (ulong)param_2[0x81]) * 0x100000001b3 ^ (ulong)param_2[0x82]) * 0x100000001b3 ^
          (ulong)param_2[0x83]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0x84]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x88]) * 0x100000001b3 ^ (ulong)param_2[0x89]) * 0x100000001b3 ^
           (ulong)param_2[0x8a]) * 0x100000001b3 ^ (ulong)param_2[0x8b]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x8c]) * 0x100000001b3 ^ (ulong)param_2[0x8d]) * 0x100000001b3 ^
           (ulong)param_2[0x8e]) * 0x100000001b3 ^ (ulong)param_2[0x8f]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x90]) * 0x100000001b3 ^ (ulong)param_2[0x91]) * 0x100000001b3 ^
           (ulong)param_2[0x92]) * 0x100000001b3 ^ (ulong)param_2[0x93]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x94]) * 0x100000001b3 ^ (ulong)param_2[0x95]) * 0x100000001b3 ^
           (ulong)param_2[0x96]) * 0x100000001b3 ^ (ulong)param_2[0x97]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0x98]) * 0x100000001b3 ^ (ulong)param_2[0x99]) * 0x100000001b3 ^
           (ulong)param_2[0x9a]) * 0x100000001b3 ^ (ulong)param_2[0x9b]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0x9c]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xa0]) * 0x100000001b3 ^ (ulong)param_2[0xa1]) * 0x100000001b3 ^
           (ulong)param_2[0xa2]) * 0x100000001b3 ^ (ulong)param_2[0xa3]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xa4]) * 0x100000001b3 ^ (ulong)param_2[0xa5]) * 0x100000001b3 ^
           (ulong)param_2[0xa6]) * 0x100000001b3 ^ (ulong)param_2[0xa7]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xa8]) * 0x100000001b3 ^ (ulong)param_2[0xa9]) * 0x100000001b3 ^
           (ulong)param_2[0xaa]) * 0x100000001b3 ^ (ulong)param_2[0xab]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xac]) * 0x100000001b3 ^ (ulong)param_2[0xad]) * 0x100000001b3 ^
           (ulong)param_2[0xae]) * 0x100000001b3 ^ (ulong)param_2[0xaf]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xb0]) * 0x100000001b3 ^ (ulong)param_2[0xb1]) * 0x100000001b3 ^
           (ulong)param_2[0xb2]) * 0x100000001b3 ^ (ulong)param_2[0xb3]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xb4]) * 0x100000001b3 ^ (ulong)param_2[0xb5]) * 0x100000001b3 ^
           (ulong)param_2[0xb6]) * 0x100000001b3 ^ (ulong)param_2[0xb7]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0xb8]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xbc]) * 0x100000001b3 ^ (ulong)param_2[0xbd]) * 0x100000001b3 ^
           (ulong)param_2[0xbe]) * 0x100000001b3 ^ (ulong)param_2[0xbf]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xc0]) * 0x100000001b3 ^ (ulong)param_2[0xc1]) * 0x100000001b3 ^
           (ulong)param_2[0xc2]) * 0x100000001b3 ^ (ulong)param_2[0xc3]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xc4]) * 0x100000001b3 ^ (ulong)param_2[0xc5]) * 0x100000001b3 ^
           (ulong)param_2[0xc6]) * 0x100000001b3 ^ (ulong)param_2[199]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[200]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xcc]) * 0x100000001b3 ^ (ulong)param_2[0xcd]) * 0x100000001b3 ^
           (ulong)param_2[0xce]) * 0x100000001b3 ^ (ulong)param_2[0xcf]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xd0]) * 0x100000001b3 ^ (ulong)param_2[0xd1]) * 0x100000001b3 ^
           (ulong)param_2[0xd2]) * 0x100000001b3 ^ (ulong)param_2[0xd3]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xd4]) * 0x100000001b3 ^ (ulong)param_2[0xd5]) * 0x100000001b3 ^
           (ulong)param_2[0xd6]) * 0x100000001b3 ^ (ulong)param_2[0xd7]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0xd8]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xdc]) * 0x100000001b3 ^ (ulong)param_2[0xdd]) * 0x100000001b3 ^
           (ulong)param_2[0xde]) * 0x100000001b3 ^ (ulong)param_2[0xdf]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xe0]) * 0x100000001b3 ^ (ulong)param_2[0xe1]) * 0x100000001b3 ^
           (ulong)param_2[0xe2]) * 0x100000001b3 ^ (ulong)param_2[0xe3]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xe4]) * 0x100000001b3 ^ (ulong)param_2[0xe5]) * 0x100000001b3 ^
           (ulong)param_2[0xe6]) * 0x100000001b3 ^ (ulong)param_2[0xe7]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xe8]) * 0x100000001b3 ^ (ulong)param_2[0xe9]) * 0x100000001b3 ^
           (ulong)param_2[0xea]) * 0x100000001b3 ^ (ulong)param_2[0xeb]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0xec]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xf0]) * 0x100000001b3 ^ (ulong)param_2[0xf1]) * 0x100000001b3 ^
           (ulong)param_2[0xf2]) * 0x100000001b3 ^ (ulong)param_2[0xf3]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((uVar1 ^ param_2[0xf4]) * 0x100000001b3 ^ (ulong)param_2[0xf5]) * 0x100000001b3 ^
           (ulong)param_2[0xf6]) * 0x100000001b3 ^ (ulong)param_2[0xf7]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = (uVar1 ^ param_2[0xf8]) * 0x100000001b3;
  *param_1 = uVar1;
  uVar1 = ((((((((((((((((uVar1 ^ param_2[0xfc]) * 0x100000001b3 ^ (ulong)param_2[0xfd]) *
                        0x100000001b3 ^ (ulong)param_2[0xfe]) * 0x100000001b3 ^ (ulong)param_2[0xff]
                      ) * 0x100000001b3 ^ (ulong)param_2[0x100]) * 0x100000001b3 ^
                    (ulong)param_2[0x101]) * 0x100000001b3 ^ (ulong)param_2[0x102]) * 0x100000001b3
                  ^ (ulong)param_2[0x103]) * 0x100000001b3 ^ (ulong)param_2[0x104]) * 0x100000001b3
                ^ (ulong)param_2[0x105]) * 0x100000001b3 ^ (ulong)param_2[0x106]) * 0x100000001b3 ^
              (ulong)param_2[0x107]) * 0x100000001b3 ^ (ulong)param_2[0x108]) * 0x100000001b3 ^
            (ulong)param_2[0x109]) * 0x100000001b3 ^ (ulong)param_2[0x10a]) * 0x100000001b3 ^
          (ulong)param_2[0x10b]) * 0x100000001b3;
  *param_1 = uVar1;
  *param_1 = ((((((((((((((((uVar1 ^ param_2[0x10c]) * 0x100000001b3 ^ (ulong)param_2[0x10d]) *
                           0x100000001b3 ^ (ulong)param_2[0x10e]) * 0x100000001b3 ^
                         (ulong)param_2[0x10f]) * 0x100000001b3 ^ (ulong)param_2[0x110]) *
                        0x100000001b3 ^ (ulong)param_2[0x111]) * 0x100000001b3 ^
                      (ulong)param_2[0x112]) * 0x100000001b3 ^ (ulong)param_2[0x113]) *
                     0x100000001b3 ^ (ulong)param_2[0x114]) * 0x100000001b3 ^ (ulong)param_2[0x115])
                   * 0x100000001b3 ^ (ulong)param_2[0x116]) * 0x100000001b3 ^ (ulong)param_2[0x117])
                 * 0x100000001b3 ^ (ulong)param_2[0x118]) * 0x100000001b3 ^ (ulong)param_2[0x119]) *
               0x100000001b3 ^ (ulong)param_2[0x11a]) * 0x100000001b3 ^ (ulong)param_2[0x11b]) *
             0x100000001b3;
  return;
}

