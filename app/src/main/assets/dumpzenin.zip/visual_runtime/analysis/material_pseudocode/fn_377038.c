
// ================================================================================
// Telegram:
// - Bot: https://t.me/imguisource_bot
// - ImGui Source: https://t.me/ImGui_Source_FIXNEY
// - shit src 🧨: https://t.me/il2cpp_src
// ================================================================================

/* ORIGINAL_RVA: 0x377038 */

/* WARNING: Removing unreachable block (ram,0x004771d4) */

void fn_377038(long **param_1,ulong param_2)

{
  long **pplVar1;
  long lVar2;
  bool bVar3;
  long **pplVar4;
  int iVar5;
  ulong uVar6;
  undefined8 uVar7;
  long lVar8;
  long **pplVar9;
  long *plVar10;
  long *plVar11;
  long **pplVar12;
  long lStack_88;
  long lStack_80;
  undefined8 uStack_78;
  long **pplStack_70;
  long **pplStack_68;
  undefined8 uStack_60;
  long lStack_58;
  
  lVar2 = tpidr_el0;
  lStack_58 = *(long *)(lVar2 + 0x28);
  pplVar12 = param_1 + 6;
  *(undefined *)((long)param_1 + 0x8a) = 1;
  uVar6 = fn_198128(*pplVar12);
  plVar11 = *param_1;
  if (((uVar6 & 1) != 0) && ((plVar11 != param_1[1] || (param_1[4] != (long *)0x0)))) {
    pplStack_70 = (long **)0x0;
    pplStack_68 = (long **)0x0;
    uStack_60 = 0;
    uVar7 = fn_19b000(*pplVar12);
    uVar6 = fn_19b0cc(uVar7,&pplStack_70);
    pplVar4 = pplStack_68;
    if ((uVar6 & 1) == 0) {
      bVar3 = true;
    }
    else {
      if (pplStack_70 == pplStack_68) {
        bVar3 = false;
      }
      else {
        bVar3 = false;
        pplVar9 = pplStack_70;
        do {
          if (*pplVar9 != (long *)0x0) {
            for (pplVar1 = (long **)*param_1; pplVar1 != (long **)param_1[1]; pplVar1 = pplVar1 + 3)
            {
              if (pplVar1[1] == *pplVar9) {
                uVar6 = fn_198128(*pplVar1);
                plVar11 = *pplVar1;
                bVar3 = true;
                if ((uVar6 & 1) == 0) {
                  plVar11 = (long *)0x0;
                }
                *pplVar9 = plVar11;
                break;
              }
            }
          }
          pplVar9 = pplVar9 + 1;
        } while (pplVar9 != pplVar4);
      }
      pplVar4 = pplStack_70;
      pplVar9 = pplStack_70;
      if (param_1[4] != (long *)0x0) {
        for (; (pplVar4 != pplStack_68 && (pplVar9 = pplVar4, *pplVar4 != param_1[4]));
            pplVar4 = pplVar4 + 1) {
          pplVar9 = pplStack_68;
        }
        pplVar4 = pplVar9;
        if (pplVar9 != pplStack_68) {
          while (pplVar4 = pplVar4 + 1, pplVar4 != pplStack_68) {
            if (*pplVar4 != param_1[4]) {
              *pplVar9 = *pplVar4;
              pplVar9 = pplVar9 + 1;
            }
          }
        }
        bVar3 = (bool)(bVar3 | pplVar9 != pplStack_68);
        if (pplVar9 != pplStack_68) {
          pplStack_68 = pplVar9;
        }
      }
      if ((bVar3) && ((param_2 & 1) != 0)) {
        lStack_88 = 0;
        lStack_80 = 0;
        uStack_78 = 0;
        uVar6 = fn_19b0cc(param_1[8],&lStack_88);
        if (((uVar6 & 1) == 0) ||
           ((lStack_80 - lStack_88 != (long)pplStack_68 - (long)pplStack_70 ||
            (iVar5 = imp_memcmp(), iVar5 != 0)))) {
          plVar11 = (long *)fn_19b32c(&pplStack_70);
        }
        else {
          plVar11 = param_1[8];
        }
        lVar8 = fn_439970(plVar11);
        if (lVar8 != 0) {
          fn_19b4fc(*pplVar12,plVar11);
          fn_439c54(lVar8);
          uVar7 = fn_19b000(*pplVar12);
          uVar6 = fn_19b0cc(uVar7,&pplStack_70);
          if (((uVar6 & 1) != 0) &&
             (uVar6 = fn_378900(pplStack_70,pplStack_68,param_1), (uVar6 & 1) == 0)) {
            if (lStack_88 != 0) {
              lStack_80 = lStack_88;
              fn_6790c8();
            }
            bVar3 = false;
            goto joined_r0x00477394;
          }
        }
        if (lStack_88 != 0) {
          lStack_80 = lStack_88;
          fn_6790c8();
        }
        bVar3 = true;
      }
    }
joined_r0x00477394:
    if (pplStack_70 != (long **)0x0) {
      pplStack_68 = pplStack_70;
      fn_6790c8();
    }
    if (bVar3) {
      uVar7 = 0;
      goto LAB_00477350;
    }
    plVar11 = *param_1;
  }
  plVar10 = param_1[1];
  if (plVar11 != plVar10) {
    do {
      uVar6 = fn_198128(plVar11[1]);
      if ((uVar6 & 1) != 0) {
        fn_198eac(plVar11[1]);
      }
      fn_439c54(plVar11[2]);
      *plVar11 = 0;
      plVar11[1] = 0;
      plVar11[2] = 0;
      plVar11 = plVar11 + 3;
    } while (plVar11 != plVar10);
    plVar11 = *param_1;
  }
  param_1[1] = plVar11;
  uVar6 = fn_198128(param_1[4]);
  if ((uVar6 & 1) != 0) {
    fn_198eac(param_1[4]);
  }
  fn_439c54(param_1[5]);
  param_1[3] = (long *)0x0;
  param_1[4] = (long *)0x0;
  param_1[5] = (long *)0x0;
  fn_439c54(param_1[0xb]);
  fn_439c54(param_1[9]);
  fn_439c54(param_1[7]);
  uVar7 = 1;
  *(undefined *)((long)param_1 + 0x8a) = 0;
  param_1[7] = (long *)0x0;
  *pplVar12 = (long *)0x0;
  param_1[9] = (long *)0x0;
  param_1[8] = (long *)0x0;
  param_1[0xb] = (long *)0x0;
  param_1[10] = (long *)0x0;
LAB_00477350:
  if (*(long *)(lVar2 + 0x28) != lStack_58) {
                    /* WARNING: Subroutine does not return */
    imp___stack_chk_fail(uVar7);
  }
  return;
}

