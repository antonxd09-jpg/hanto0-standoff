
// ================================================================================
// Do not re-upload without credits:
// Bot: @imguisource_bot
// ImGui Source: @ImGui_Source_FIXNEY
// shit src 🧨: @il2cpp_src
// ================================================================================

#include "material_parameters.hpp"
#include <algorithm>

namespace material_parameters {
namespace {
struct Binding { Property property; std::size_t word; };
constexpr std::size_t ConstantZero = 0;
// Пары property/word получены из загрузок S0 и W1 перед native 0x19d360.
constexpr Binding Style0[]{{Property::Overlay,14}};
constexpr Binding Style1[]{{Property::Overlay,14},{Property::Metallic,15},{Property::Roughness,16}};
constexpr Binding Style2[]{{Property::Exponent,17},{Property::FresnelFilling,18},{Property::OriginalOverlay,19}};
constexpr Binding Style3[]{{Property::Overlay,14},{Property::Strength,20},{Property::Roughness,16},{Property::EnableAnim,21},{Property::AnimSpeed,22}};
constexpr Binding Style4[]{{Property::Overlay,14},{Property::Speed,23}};
constexpr Binding Style5[]{{Property::Gloss,24},{Property::Fresnel,25}};
constexpr Binding Style6A[]{{Property::WireThickness,26},{Property::WireSmoothing,27},{Property::Glow,28}};
constexpr Binding Style6B[]{{Property::OriginalTexture,29},{Property::EnablePulse,30},{Property::Pulse,31},{Property::PulseMin,32}};
constexpr Binding Style7[]{{Property::Distortion,33},{Property::Opacity,34},{Property::Reflection,35},{Property::EnableBlur,36},{Property::BlurStrength,37},{Property::Grain,38}};
constexpr Binding Style8[]{{Property::BlurSize,39},{Property::Tint,ConstantZero}};
constexpr Binding Style9[]{{Property::Reflectivity,40},{Property::Facets,41},{Property::HueSpread,42},{Property::EnableAnim,21},{Property::AnimSpeed,22}};
constexpr Binding Style10[]{{Property::Heat,43},{Property::Plates,44},{Property::OverlayLayer,50},{Property::EnableAnim,21},{Property::AnimSpeed,22}};
constexpr Binding Style11[]{{Property::Frost,45},{Property::Cracks,46},{Property::OverlayLayer,50},{Property::EnableAnim,21},{Property::AnimSpeed,22}};
constexpr Binding Style12[]{{Property::GlyphSize,47},{Property::Background,48},{Property::RainSpeed,49}};
float& word(Packet& packet, std::size_t index) noexcept { return packet.values[index - 1]; }
Color color(const Packet& packet, std::size_t start) noexcept {
    Color value;
    std::copy_n(packet.values.data() + start - 1, value.size(), value.data());
    return value;
}
}
const std::array<const char*, Config::PropertyCount>& property_names() noexcept {
    static constexpr std::array<const char*, Config::PropertyCount> names{
        "_Color","_HiddenColor","_BehindWalls","_WeaponMode","_Overlay","_Metallic",
        "_Roughness","_Exponent","_FresnelFilling","_OriginalOverlay","_FillColor",
        "_Strength","_EnableAnim","_AnimSpeed","_Speed","_Gloss","_Fresnel",
        "_WireThickness","_WireSmoothing","_Glow","_OriginalTexture","_EnablePulse",
        "_Pulse","_PulseMin","_Distortion","_Opacity","_Reflection","_EnableBlur",
        "_BlurStrength","_Grain","_BlurSize","_Tint","_Reflectivity","_Facets",
        "_HueSpread","_Heat","_Plates","_Frost","_Cracks","_GlyphSize","_Background",
        "_RainSpeed","_OverlayLayer","_BloomColor","_BloomHiddenColor","_BloomIntensity","_BloomRadius"
    };
    return names;
}
void apply(float alpha, Object material, Object shaderObject, Packet& packet,
           std::int32_t queue, const PropertyIds& properties, Backend& backend) {
    if (alpha > Config::MaxAlpha) alpha = Config::MaxAlpha;
    if (alpha < Config::MinAlpha) alpha = Config::MinAlpha;
    word(packet, Config::FirstAlphaWord) *= alpha;
    word(packet, Config::SecondAlphaWord) *= alpha;
    if (backend.shader(material) != shaderObject) backend.set_shader(material, shaderObject);
    backend.set_queue(material, queue);
    const auto id = [&](Property property) { return properties[static_cast<std::size_t>(property)]; };
    const auto scalar = [&](Property property, float value) { backend.set_float(material, id(property), value); };
    const auto vector = [&](Property property, std::size_t start) { backend.set_vector(material, id(property), color(packet, start)); };
    const auto set = [&](const auto& bindings) {
        for (const auto& binding : bindings) scalar(binding.property,
            binding.word == ConstantZero ? Config::Zero : word(packet, binding.word));
    };
    scalar(Property::BehindWalls, word(packet, Config::BehindWallsWord));
    scalar(Property::WeaponMode, Config::Zero);
    vector(Property::Color, Config::FirstColorWord);
    vector(Property::HiddenColor, Config::SecondColorWord);
    switch (packet.style) {
        case 0: set(Style0); break;
        case 1: set(Style1); break;
        case 2: set(Style2); vector(Property::FillColor, Config::FillColorWord); break;
        case 3: set(Style3); break;
        case 4: set(Style4); break;
        case 5: set(Style5); break;
        case 6: set(Style6A); vector(Property::FillColor, Config::FillColorWord); set(Style6B); break;
        case 7: set(Style7); break;
        case 8: set(Style8); break;
        case 9: set(Style9); break;
        case 10: set(Style10); break;
        case 11: set(Style11); break;
        case 12: set(Style12); break;
        default: break;
    }
    if (word(packet, Config::BloomIntensityWord) > Config::Zero) {
        vector(Property::BloomColor, Config::BloomColorWord);
        vector(Property::BloomHiddenColor, Config::BloomHiddenColorWord);
        scalar(Property::BloomIntensity, word(packet, Config::BloomIntensityWord));
        scalar(Property::BloomRadius, word(packet, Config::BloomRadiusWord));
    }
}
}
