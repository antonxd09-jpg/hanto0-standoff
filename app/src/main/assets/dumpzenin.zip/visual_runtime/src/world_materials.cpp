
// ================================================================================
// Official Telegram Bot: t.me/imguisource_bot
// Official Channels:
// 1. ImGui Source -> t.me/ImGui_Source_FIXNEY
// 2. shit src 🧨 -> t.me/il2cpp_src
// ================================================================================

#include "world_materials.hpp"
#include <array>
namespace world_materials {
namespace {
struct Entry {std::string_view name;Family family;bool variant;};
constexpr std::array<Entry,9> Names{{
    {"Mobile/Diffuse",Family::diffuse,false},
    {"SO2/Maps/Fog/HalloweenFogDiffuse",Family::fog,false},
    {"SO2/Transparent/Diffuse AlphaTest DoubleSided",Family::cutout,false},
    {"SO2/Maps/VertexWind",Family::wind,false},
    {"Legacy Shaders/Transparent/Diffuse",Family::transparent,false},
    {"SO2/Maps/Fog/HalloweenFogDiffuseTransparent",Family::transparent_fog,false},
    {"Standard",Family::standard,true},
    {"Custom/MobileDiffuseWithLightmap",Family::standard,true},
    {"SO2/Maps/Window",Family::window,true}
}};
}
Family classify(std::string_view name,std::uint32_t variantFlags) noexcept {
    const bool variant=(variantFlags&Config::VariantBit)!=0;
    for(const auto& entry:Names)if(name==entry.name)return entry.variant&&!variant?Family::fallback:entry.family;
    return variant?Family::other:Family::fallback;
}
}
