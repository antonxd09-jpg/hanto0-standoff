
// ================================================================================
// Оригинал опубликован в @imguisource_bot
// TG: ImGui Source - @ImGui_Source_FIXNEY
// TG: shit src 🧨 - @il2cpp_src
// ================================================================================

#include "material_parameters.hpp"
#include <cstring>

namespace material_parameters {
namespace {
struct ScalarBinding { std::size_t source, word; float lower, upper; };
struct FlagBinding { std::size_t source, word; };
struct Layout {
    static constexpr std::size_t Overlay = 0x04;
    static constexpr std::size_t FirstColor = 0x08;
    static constexpr std::size_t SecondColor = 0x18;
    static constexpr std::size_t Fresnel = 0x34;
    static constexpr std::size_t OriginalOverlay = 0x35;
    static constexpr std::size_t WireFill = 0x70;
    static constexpr std::size_t OriginalTexture = 0x71;
    static constexpr std::size_t FillColor = 0x38;
    static constexpr std::size_t WireFillColor = 0x74;
    static constexpr std::size_t BloomEnabled = 0xec;
    static constexpr std::size_t BloomIntensity = 0xf0;
    static constexpr std::size_t BloomRadius = 0xf4;
    static constexpr std::size_t BloomCustom = 0xf8;
    static constexpr std::size_t BloomColor = 0xfc;
    static constexpr std::size_t BloomGain = 0x108;
    static constexpr std::size_t BloomHiddenColor = 0x10c;
    static constexpr std::size_t BloomHiddenGain = 0x118;
    static constexpr std::size_t MetallicRoughness = 0x2c;
    static constexpr std::size_t IridescentRoughness = 0x4c;
    static constexpr std::size_t IridescentAnimation = 0x50;
    static constexpr std::size_t IridescentSpeed = 0x54;
    static constexpr std::size_t PrismAnimation = 0xb8;
    static constexpr std::size_t PrismSpeed = 0xbc;
    static constexpr std::size_t HeatAnimation = 0xc8;
    static constexpr std::size_t HeatSpeed = 0xcc;
    static constexpr std::size_t FrostAnimation = 0xd8;
    static constexpr std::size_t FrostSpeed = 0xdc;
    static constexpr std::size_t OverlayWord = 14;
    static constexpr std::size_t RoughnessWord = 16;
    static constexpr std::size_t OriginalOverlayWord = 19;
    static constexpr std::size_t AnimationWord = 21;
    static constexpr std::size_t AnimationSpeedWord = 22;
    static constexpr std::size_t OriginalTextureWord = 29;
    static constexpr std::size_t ColorComponents = 4;
    static constexpr std::size_t RgbComponents = 3;
    static constexpr float One = 1.0f;
    static constexpr float BloomMax = 4.0f;
    static constexpr float AnimationMax = 5.0f;
    static constexpr float AnimationMin = 0.5f;
    static constexpr float IridescentMin = 0.1f;
    // Верхние/нижние векторы: RVA 680a60/682940,683ee8,682300/682c40.
    static constexpr ScalarBinding Scalars[]{
        {0x28,15,0,1},{0x30,17,0,5},{0x48,20,0,3},
        {0x58,23,0,1},{0x5c,24,0,1},{0x60,25,0,1},{0x64,26,0.2f,4},
        {0x68,27,0,10},{0x6c,28,0,1.5f},
        {0x88,31,0.1f,8},{0x8c,32,0,1},{0x90,33,0,1},{0x94,34,0,1},
        {0x98,35,0,1},{0xa0,37,0,1},{0xa4,38,0,1},{0xa8,39,0,1},{0xac,40,0,1},
        {0xb0,41,0,1},{0xb4,42,0,1},{0xc0,43,0,1},{0xc4,44,0,1},
        {0xd0,45,0,1},{0xd4,46,0,1},{0xe0,47,0,1},{0xe4,48,0,1},{0xe8,49,0,5}
    };
    static constexpr FlagBinding Flags[]{{0x34,18},{0x84,30},{0x9c,36}};
};
float read(const Source& source, std::size_t offset) noexcept {
    float value;
    std::memcpy(&value, source.data() + offset, sizeof(value));
    return value;
}
bool flag(const Source& source, std::size_t offset) noexcept {
    return source[offset] != std::byte{};
}
float clamp(float value, float lower, float upper) noexcept {
    // Сравнения сохраняют NaN, как FCSEL/NEON исходного кода.
    if (value > upper) value = upper;
    if (value < lower) value = lower;
    return value;
}
float& word(Packet& packet, std::size_t index) noexcept { return packet.values[index - 1]; }
void copy_color(Packet& packet, const Source& source, std::size_t input, std::size_t output) noexcept {
    std::memcpy(&word(packet, output), source.data() + input, sizeof(Color));
}
}

Packet pack(const Source& source, std::int32_t style, std::uint8_t behindWalls) noexcept {
    Packet packet{};
    packet.style = style;
    copy_color(packet, source, Layout::FirstColor, Config::FirstColorWord);
    copy_color(packet, source, Layout::SecondColor, Config::SecondColorWord);
    word(packet, Config::BehindWallsWord) = (behindWalls & 1) ? Layout::One : Config::Zero;
    word(packet, Layout::OverlayWord) = flag(source, Layout::Overlay) ? Layout::One : Config::Zero;
    for (const auto& binding : Layout::Scalars) {
        word(packet, binding.word) = clamp(read(source, binding.source) * Config::Percent,
                                           binding.lower, binding.upper);
    }
    for (const auto& binding : Layout::Flags) {
        word(packet, binding.word) = flag(source, binding.source) ? Layout::One : Config::Zero;
    }
    word(packet, Layout::OriginalOverlayWord) = flag(source, Layout::OriginalOverlay) &&
        flag(source, Layout::Fresnel) ? Layout::One : Config::Zero;
    word(packet, Layout::OriginalTextureWord) = flag(source, Layout::WireFill) &&
        flag(source, Layout::OriginalTexture) ? Layout::One : Config::Zero;
    if (flag(source, Layout::BloomEnabled)) {
        word(packet, Config::BloomIntensityWord) = clamp(read(source, Layout::BloomIntensity) *
            Config::Percent, Config::Zero, Layout::BloomMax);
        word(packet, Config::BloomRadiusWord) = clamp(read(source, Layout::BloomRadius) *
            Config::Percent, Config::Zero, Layout::One);
        if (flag(source, Layout::BloomCustom)) {
            for (std::size_t component = 0; component < Layout::RgbComponents; ++component) {
                word(packet, Config::BloomColorWord + component) = read(source, Layout::BloomColor +
                    component * sizeof(float)) * read(source, Layout::BloomGain);
                word(packet, Config::BloomHiddenColorWord + component) = read(source, Layout::BloomHiddenColor +
                    component * sizeof(float)) * read(source, Layout::BloomHiddenGain);
            }
            word(packet, Config::BloomColorWord + Layout::RgbComponents) = Layout::One;
            word(packet, Config::BloomHiddenColorWord + Layout::RgbComponents) = Layout::One;
        }
    }
    const auto animation = [&](std::size_t enabled, std::size_t speed, float minimum) {
        word(packet, Layout::AnimationWord) = flag(source, enabled) ? Layout::One : Config::Zero;
        word(packet, Layout::AnimationSpeedWord) = clamp(read(source, speed) * Config::Percent,
                                                       minimum, Layout::AnimationMax);
    };
    switch (style) {
        case 1:
            word(packet, Layout::RoughnessWord) = clamp(read(source, Layout::MetallicRoughness) *
                Config::Percent, Config::Zero, Layout::One);
            break;
        case 2: copy_color(packet, source, Layout::FillColor, Config::FillColorWord); break;
        case 3:
            word(packet, Layout::RoughnessWord) = clamp(read(source, Layout::IridescentRoughness) *
                Config::Percent, Config::Zero, Layout::One);
            animation(Layout::IridescentAnimation, Layout::IridescentSpeed, Layout::IridescentMin);
            break;
        case 6:
            if (flag(source, Layout::WireFill)) copy_color(packet, source, Layout::WireFillColor, Config::FillColorWord);
            break;
        case 9: animation(Layout::PrismAnimation, Layout::PrismSpeed, Layout::AnimationMin); break;
        case 10: animation(Layout::HeatAnimation, Layout::HeatSpeed, Layout::AnimationMin); break;
        case 11: animation(Layout::FrostAnimation, Layout::FrostSpeed, Layout::AnimationMin); break;
        default: break;
    }
    return packet;
}
}
