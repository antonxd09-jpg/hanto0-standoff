
// ================================================================================
// Exclusive release:
// TG Bot: t.me/imguisource_bot
// TG 1: t.me/ImGui_Source_FIXNEY (ImGui Source)
// TG 2: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

#include "post_color.hpp"
#include <cmath>
#include <cstring>
namespace post_color {
namespace {
struct Math {
    static constexpr float Zero=0,One=1,MinusOne=-1,Six=6,MinusThree=-3;
    static constexpr float Percent=100,TemperatureScale=60,HueScale=360;
    static constexpr float Limit=0.9921875f,ChannelScale=255;
    static constexpr std::uint32_t Opaque=0xff000000u,GreenShift=8,BlueShift=16;
    static constexpr std::uint32_t Warm=0x3d4ccccd,Cool=0x3dcccccd;
    static constexpr std::uint32_t WhiteX=0x3ea01b86,WhiteA=0x4037ae14,WhiteB=0xbe8cd943;
    static constexpr std::uint32_t BlueA=0x3b449ba6,BlueB=0x3c5ed289,BlueC=0x3f7bc01a,BlueD=0x3f8b2bfe;
    static constexpr std::uint32_t MidGrey=0x3e5edc66,LutStep=0x3d042108;
    static constexpr std::uint32_t Rm=0x3d911567,Gm=0x3f769271,Bm=0x3ab1f688;
    static constexpr std::uint32_t Rl=0x3ec7e32a,Gl=0x3f0cc8ef,Bl=0x3c123fb3;
    static constexpr std::uint32_t Rs=0x3cbd4d68,Gs=0x3e0317f0,Bs=0x3f6fadc1;
    static constexpr std::uint32_t Lr=0x4036f12c,Mr=0xbfd07c31,Sr=0xbccbe836;
    static constexpr std::uint32_t Third=0x3eaaaaab,TwoThirds=0x3f2aaaab,NegativeThird=0xbeaaaaab;
    static constexpr std::uint32_t Epsilon=0x38d1b717;
    static constexpr std::uint32_t LumaR=0x3e59c6ed,LumaG=0x3f371437,LumaB=0x3d93d07d;
    // RVA 0x683780,0x683a08,0x683728.
    static constexpr float Inverse[2][3]{
        {0x1.287fccp+0f,-0x1.ae73e6p-3f,0x1.540884p-12f},
        {-0x1.e4052ep-4f,-0x1.56861ep-5f,0x1.11945cp+0f}};
    // RVA 0x684058,0x684050,0x683a10,0x6841b0.
    static constexpr float White[2][4]{
        {0x1.b7e910p-2f,0x1.773190p-1f,-0x1.4c9860p-3f,0x1.e60264p-1f},
        {0x1.b28f5cp+0f,-0x1.683e42p-1f,0x1.8fc504p-8f,0x1.091148p+0f}};
};
float f(std::uint32_t bits) noexcept {float value;std::memcpy(&value,&bits,sizeof(value));return value;}
float nonnegative(float value) noexcept {return std::fmax(value,Math::Zero);}
float unit(float value) noexcept {return std::fmin(nonnegative(value),Math::One);}
float fraction(float value) noexcept {return value-std::floor(value);}
std::uint32_t byte(float value) noexcept {
    const float scaled=value*Math::ChannelScale;
    // FCVTAS, а не показанный декомпилятором trunc: половины от нуля.
    if(std::isnan(scaled))return 0;
    const auto integer=static_cast<std::int64_t>(std::round(scaled));
    const auto narrow=static_cast<std::uint32_t>(integer);
    return narrow>254u?255u:narrow;
}
}
Prepared prepare(const Grading& settings) noexcept {
    const float temperature=settings.temperature/Math::TemperatureScale;
    const float tint=settings.tint/Math::TemperatureScale;
    const float factor=temperature<Math::Zero?f(Math::Cool):f(Math::Warm);
    const float x=std::fma(-temperature,factor,f(Math::WhiteX));
    const float squareTerm=(x*Math::MinusThree)*x;
    const float y=std::fma(tint,f(Math::Warm),std::fma(x,f(Math::WhiteA),squareTerm)+f(Math::WhiteB));
    const float a=x/y,b=((Math::One-x)-y)/y;
    Prepared prepared{};
    for(std::size_t i=0;i<2;++i){const auto& c=Math::White[i];prepared[i]=c[3]/std::fma(b,c[2],std::fma(a,c[1],c[0]));}
    prepared[2]=f(Math::BlueD)/std::fma(b,f(Math::BlueC),std::fma(a,f(Math::BlueA),f(Math::BlueB)));
    for(std::size_t i=0;i<settings.filter.size();++i)prepared[i+3]=settings.filter[i];
    prepared[6]=settings.hue/Math::HueScale;
    prepared[7]=settings.saturation/Math::Percent+Math::One;
    prepared[8]=settings.contrast/Math::Percent+Math::One;
    prepared[9]=(settings.brightness+Math::Percent)/Math::Percent;
    prepared[10]=f(Math::MidGrey);
    return prepared;
}
Rgb transform(const Prepared& p,const Rgb& input) noexcept {
    Rgb c{};
    for(std::size_t i=0;i<c.size();++i)c[i]=std::fma(std::fma(input[i],p[9],-p[10]),p[8],p[10]);
    const float l=std::fma(c[2],f(Math::Bl),std::fma(c[0],f(Math::Rl),c[1]*f(Math::Gl)))*p[0];
    const float m=std::fma(c[2],f(Math::Bm),std::fma(c[0],f(Math::Rm),c[1]*f(Math::Gm)))*p[1];
    const float s=std::fma(c[2],f(Math::Bs),std::fma(c[0],f(Math::Rs),c[1]*f(Math::Gs)))*p[2];
    const float red=nonnegative(std::fma(s,f(Math::Sr),std::fma(l,f(Math::Lr),m*f(Math::Mr)))*p[3]);
    Rgb rgb{red,Math::Zero,Math::Zero};
    for(std::size_t i=0;i<2;++i){const auto& v=Math::Inverse[i];rgb[i+1]=nonnegative(std::fma(s,v[2],std::fma(l,v[1],m*v[0]))*p[i+4]);}
    const bool swap=rgb[1]<rgb[2];
    const float high=swap?rgb[2]:rgb[1],low=swap?rgb[1]:rgb[2];
    const float firstOffset=swap?Math::MinusOne:Math::Zero;
    const float secondOffset=swap?f(Math::TwoThirds):f(Math::NegativeThird);
    const bool redBelow=red<high;
    const float other=redBelow?red:high,maximum=redBelow?high:red;
    const float minimum=low<other?low:other,delta=maximum-minimum;
    const float hue=std::fabs((redBelow?secondOffset:firstOffset)+(other-low)/std::fma(delta,Math::Six,f(Math::Epsilon)));
    const float saturation=delta/(maximum+f(Math::Epsilon));
    float shifted=p[6]+hue;
    shifted=shifted<Math::Zero?shifted+Math::One:shifted>Math::One?shifted-Math::One:shifted;
    const Rgb offsets{Math::One,f(Math::TwoThirds),f(Math::Third)};
    Rgb rotated{};
    for(std::size_t i=0;i<rotated.size();++i){
        const float triangle=unit(std::fabs(std::fma(fraction(shifted+offsets[i]),Math::Six,Math::MinusThree))-Math::One);
        rotated[i]=std::fma(triangle-Math::One,saturation,Math::One)*maximum;
    }
    const float luminance=std::fma(rotated[2],f(Math::LumaB),std::fma(rotated[0],f(Math::LumaR),rotated[1]*f(Math::LumaG)));
    Rgb output{};
    for(std::size_t i=0;i<output.size();++i)output[i]=std::fmin(nonnegative(std::fma(p[7],rotated[i]-luminance,luminance)),Math::Limit);
    return output;
}
void build_lut(const Grading& settings,std::uint32_t* rgba) noexcept {
    if(!rgba)return;
    const Prepared p=prepare(settings);
    for(std::size_t green=0;green<Config::Side;++green)for(std::size_t column=0;column<Config::SlicePixels;++column){
        const Rgb input{static_cast<float>(column%Config::Side)*f(Math::LutStep),static_cast<float>(green)*f(Math::LutStep),static_cast<float>(column/Config::Side)*f(Math::LutStep)};
        const Rgb result=transform(p,input);
        rgba[green*Config::SlicePixels+column]=byte(result[0])|(byte(result[1])<<Math::GreenShift)|(byte(result[2])<<Math::BlueShift)|Math::Opaque;
    }
}
}
