
// ================================================================================
// Telegram:
// - Bot: https://t.me/imguisource_bot
// - ImGui Source: https://t.me/ImGui_Source_FIXNEY
// - shit src 🧨: https://t.me/il2cpp_src
// ================================================================================

#include "render_commands.hpp"
#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <type_traits>

namespace render_commands {
namespace {
template<class T> T read(const Cache& cache, std::size_t offset) noexcept {
    static_assert(std::is_trivially_copyable_v<T>);
    T value;
    std::memcpy(&value, cache.data() + offset, sizeof(value));
    return value;
}
void require_validator(ObjectValidator validator) {
    if (!validator) throw std::invalid_argument("ObjectValidator");
}
template<class Action>
void each_renderer(const Cache& cache, ObjectValidator validator, void* context,
                   Action&& action) {
    const auto count = read<std::uint64_t>(cache, Config::RendererCount);
    for (std::uint64_t index = 0; index < count; ++index) {
        if (index == Config::RendererLimit) throw std::out_of_range("RendererLimit");
        const auto offset = static_cast<std::size_t>(index) * Config::RendererStride;
        const auto renderer = read<std::uint64_t>(cache, offset + Config::RendererPointer);
        if (validator(renderer, context)) {
            action(renderer, read<std::int32_t>(cache, offset + Config::RendererSlot));
        }
    }
}
}

void gather_material_commands(const CacheBank& caches,
                              std::vector<MaterialCommand>& output,
                              ObjectValidator validator, void* context) {
    require_validator(validator);
    for (const auto& cache : caches) {
        if (!read<std::uint8_t>(cache, Config::Active)) continue;
        const auto first = read<std::uint64_t>(cache, Config::FirstMaterial);
        const auto second = read<std::uint64_t>(cache, Config::SecondMaterial);
        const bool firstValid = read<std::uint8_t>(cache, Config::FirstEnabled) &&
                                validator(first, context);
        const bool secondValid = read<std::uint8_t>(cache, Config::SecondEnabled) &&
                                 second && validator(second, context);
        if (!firstValid && !secondValid) continue;
        const auto firstStyle = std::clamp(read<std::int32_t>(cache, Config::FirstStyle),
                                          Config::StyleMin, Config::StyleMax);
        const auto candidate = read<std::int32_t>(cache, Config::SecondStyle);
        const auto secondStyle = std::find(Config::SecondStyles.begin(),
                                           Config::SecondStyles.end(), candidate) !=
                                 Config::SecondStyles.end() ? candidate : Config::FallbackStyle;
        const auto flags = read<std::uint8_t>(cache, Config::Flags);
        const auto mode = read<std::int32_t>(cache, Config::SecondMode);
        each_renderer(cache, validator, context, [&](std::uint64_t renderer, std::int32_t slot) {
            if (firstValid) output.push_back({renderer, first, Config::FirstMode,
                                               firstStyle, flags, {}, slot});
            if (secondValid) output.push_back({renderer, second, mode, secondStyle,
                                                flags, {}, slot});
        });
    }
}

void gather_color_commands(const CacheBank& caches, const ColorSettings& settings,
                           std::vector<ColorCommand>& output,
                           ObjectValidator validator, void* context) {
    require_validator(validator);
    if (!settings.enabled) return;
    const std::array<float, 4> second = settings.secondEnabled ? settings.second :
                                                              std::array<float, 4>{};
    for (const auto& cache : caches) {
        if (!read<std::uint8_t>(cache, Config::Active)) continue;
        each_renderer(cache, validator, context, [&](std::uint64_t renderer, std::int32_t slot) {
            output.push_back({renderer, Config::ColorMode, settings.first, second, slot});
        });
    }
}
}
