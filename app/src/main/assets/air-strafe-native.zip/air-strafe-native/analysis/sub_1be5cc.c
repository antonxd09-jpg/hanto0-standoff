extern char g_64693e0;
extern unsigned long long g_75e1788;
extern float g_75e1790;
extern float g_75e17a8;
extern float g_75e17ac;
extern float g_75e17b0;
extern float g_75e17b4;
extern float g_75e17b8;
extern float g_75e17bc;
extern float g_75e17c0;
extern unsigned int g_75e17c4;
extern unsigned int g_75e17c8;
extern unsigned int g_75e17cc;
extern float g_75e17d0;
extern unsigned int g_75e17d4;
extern unsigned int g_75e17d8;
extern unsigned int g_75e17dc;
extern unsigned int g_75e17e0;
extern char g_75e17e4;
extern char g_75e17e5;
extern float g_75e17e8;
extern float g_75e17ec;
extern float g_75e17f0;
extern char g_75e17f4;

uint128_t sub_1be5cc(uint128_t a0, unsigned long a1, float a2, float a3)
{
    uint128_t v9;  // x0
    unsigned long long v10;  // x19
    float v19;  // s10
    unsigned long long v109;  // 4102
    unsigned long long v110;  // 4112
    unsigned long long v111;  // 4102
    float v112;  // s1
    unsigned long long v113;  // 4102
    float v114;  // s1
    float v115;  // s2
    unsigned long long v116;  // 4102
    unsigned long long v117;  // 4134
    unsigned long long v118;  // 4110
    unsigned long idx;  // x22
    unsigned long v119;  // cc_dep1
    unsigned long long v120;  // 4128
    unsigned int v121;  // w8
    unsigned int v122;  // w8
    unsigned int v123;  // w9
    unsigned long v124;  // 4112
    unsigned long v125;  // cc_op
    unsigned long v126;  // cc_dep1
    unsigned long v127;  // cc_dep2
    unsigned long long v128;  // 4114
    float v21;  // s15
    unsigned long v129;  // 4112
    unsigned long long v130;  // 4114
    unsigned long long v131;  // 4112
    unsigned long long v132;  // 4102
    unsigned long long v133;  // 4112
    unsigned long long v134;  // 4102
    unsigned long long v135;  // 4132
    float v136;  // s2
    float v137;  // s3
    unsigned long long v138;  // 4140
    float v22;  // s14
    unsigned long long v139;  // 4158
    unsigned long long v140;  // 4102
    float v141;  // s3
    float v142;  // s7
    unsigned long long v143;  // 4141
    unsigned long v144;  // cc_dep1
    float v145;  // s3
    unsigned long long v146;  // 4164
    float v147;  // s6
    unsigned long long v148;  // 4106
    float v23;  // s13
    unsigned long long v149;  // 4106
    unsigned long long v150;  // 4110
    unsigned long long v151;  // 4129
    float v152;  // s3
    unsigned long long v153;  // 4110
    unsigned long long v154;  // 4110
    unsigned long long v155;  // 4129
    float v156;  // s4
    unsigned long long v157;  // 4110
    unsigned long long v158;  // x0
    unsigned long v24;  // x22
    unsigned long long *v159;  // x22
    unsigned int v160;  // w9
    unsigned int v161;  // w9
    unsigned int v162;  // w10
    unsigned long v163;  // cc_op
    unsigned long v164;  // cc_dep1
    unsigned long v165;  // cc_dep2
    unsigned long v166;  // cc_ndep
    unsigned long v167;  // 4112
    unsigned long v168;  // cc_op
    float *v25;  // x22
    unsigned long v169;  // cc_dep1
    unsigned long v170;  // cc_dep2
    unsigned long long v171;  // 4114
    unsigned long v172;  // 4112
    unsigned long long v173;  // 4114
    float *v26;  // x22
    unsigned long long v174;  // 4112
    unsigned long long v175;  // 4102
    unsigned long long v176;  // 4112
    float *v27;  // x22
    unsigned long long v177;  // 4102
    unsigned int *v178;  // x22
    unsigned int v28;  // w23
    float v179;  // s8
    unsigned int v180;  // w8
    unsigned int v181;  // w9
    unsigned long v182;  // cc_dep1
    unsigned int v183;  // w10
    unsigned long long v184;  // 4106
    unsigned long long v185;  // 4106
    unsigned int v186;  // w9
    unsigned int v187;  // w8
    unsigned long v188;  // cc_dep1
    uint128_t v11;  // x0
    unsigned int v29;  // w24
    unsigned int v189;  // w8
    unsigned long long v190;  // 4107
    unsigned long long v191;  // 4107
    unsigned long long v192;  // 4128
    unsigned int *v193;  // x20
    float v194;  // s0
    unsigned int v195;  // w8
    unsigned int v196;  // w9
    unsigned long v197;  // cc_dep1
    unsigned int v198;  // w10
    unsigned int *v30;  // x22
    unsigned long long v199;  // 4106
    unsigned long long v200;  // 4106
    unsigned int v201;  // w9
    unsigned int v202;  // w8
    unsigned long v203;  // cc_dep1
    unsigned int v204;  // w8
    unsigned long long v205;  // 4107
    unsigned long long v206;  // 4107
    unsigned long long v207;  // 4128
    unsigned long long v208;  // 4236
    int *v31;  // x22
    unsigned long idx1;  // x19
    char v210;  // x8
    float v211;  // s1
    unsigned long long v212;  // 4102
    float v213;  // s1
    float v214;  // s2
    unsigned long long v215;  // 4102
    float v216;  // s2
    float v217;  // s3
    unsigned long long v218;  // 4102
    int *v32;  // x22
    uint128_t v219;  // x0
    unsigned int *v33;  // x22
    float v34;  // s0
    unsigned long long v35;  // 4102
    float v36;  // s0
    unsigned long long v37;  // 4102
    float v38;  // s0
    unsigned long v12;  // x24
    unsigned long long v39;  // 4102
    unsigned int v40;  // w9
    unsigned int v41;  // w10
    unsigned long v42;  // cc_dep1
    unsigned int v43;  // w11
    unsigned long long v44;  // 4106
    unsigned long long v45;  // 4106
    unsigned int v46;  // w10
    unsigned int v47;  // w9
    unsigned long v48;  // cc_dep1
    unsigned long long v13;  // x20
    unsigned long long v49;  // 4107
    unsigned long long v50;  // 4107
    unsigned long long v51;  // 4107
    unsigned long v52;  // cc_dep1
    unsigned long long v53;  // 4125
    int v54;  // w9
    unsigned int v55;  // w11
    unsigned int v56;  // w10
    unsigned long v57;  // 4112
    unsigned long v58;  // cc_op
    unsigned int v14;  // w26
    unsigned long v59;  // cc_dep1
    unsigned long v60;  // cc_dep2
    unsigned long long v61;  // 4112
    unsigned long v62;  // 4112
    unsigned long long v63;  // 4112
    unsigned long v64;  // 4112
    unsigned long v65;  // cc_op
    unsigned long v66;  // cc_dep1
    unsigned long v67;  // cc_dep2
    unsigned long long v68;  // 4102
    unsigned int v15;  // w25
    unsigned long v69;  // 4112
    unsigned long long v70;  // 4102
    int v71;  // w10
    unsigned int v72;  // w10
    unsigned int v73;  // w11
    unsigned long v74;  // 4112
    unsigned long v75;  // cc_op
    unsigned long v76;  // cc_dep1
    unsigned long v77;  // cc_dep2
    unsigned long long v78;  // 4112
    unsigned long index;  // x22
    unsigned long v79;  // 4112
    unsigned long long v80;  // 4112
    unsigned long v81;  // 4112
    unsigned long v82;  // cc_op
    unsigned long v83;  // cc_dep1
    unsigned long v84;  // cc_dep2
    unsigned long long v85;  // 4102
    unsigned long v86;  // 4112
    unsigned long long v87;  // 4102
    unsigned int v88;  // s0
    float v17;  // s12
    unsigned int v89;  // w8
    unsigned int v90;  // w9
    unsigned int v91;  // w8
    unsigned int v92;  // w10
    unsigned long long v93;  // 4150
    unsigned long v94;  // 4112
    unsigned long v95;  // cc_op
    unsigned long v96;  // cc_dep1
    unsigned long v97;  // cc_dep2
    unsigned long long v98;  // 4113
    float v18;  // s11
    unsigned long v99;  // 4112
    unsigned long long v100;  // 4113
    unsigned long v101;  // 4112
    unsigned long v102;  // cc_op
    unsigned long v103;  // cc_dep1
    unsigned long v104;  // cc_dep2
    unsigned long long v105;  // 4112
    unsigned long v106;  // 4112
    unsigned long long v107;  // 4112
    unsigned long long v108;  // 4112
    int v0;  // [bp-0xac]
    int v1;  // [bp-0xa8]
    float v2;  // [bp-0xa4]
    float v3;  // [bp-0xa0]
    float v4;  // [bp-0x9c]
    unsigned long long *v5;  // [bp-0x98]
    float v6;  // [bp-0x98]
    char *v7;  // [bp-0x50]
    char v8;  // [bp+0x0]

    v7 = &v8;
    /* unsupported instruction */;
    if (a0)
    {
        v5 = *(long long *)0x75e1798;
        /* unsupported instruction */;
        if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
        {
            sub_1269d0(123377504);
            6813216();
            sub_65eed8(123388920);
        }
        /* unsupported instruction */;
        if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
        {
            sub_1269d0(123377504);
            6813216();
            sub_65eed8(123388920);
        }
        v9 = sub_1be348(a0);
        if (v9 & 1)
        {
            if (sub_139354(123377576, *(short *)0x75aafe8 + a0, 8) & 1)
                v10 = *(long long *)(*(short *)0x75aafe8 + a0);
            else
                v10 = 0;
            v11 = sub_139354(123377576, *(short *)0x75aafea + a0, 8);
            if (v11 & 1)
            {
                v12 = *(long long *)(*(short *)0x75aafea + a0);
                if (v12)
                {
                    v11 = sub_139354(123377576, *(short *)0x75aaff0 + v12, 8);
                    if (v11 & 1)
                    {
                        v13 = *(long long *)(*(short *)0x75aaff0 + v12);
                        v14 = v10 != 0;
                        v12 = 1;
                        v15 = v13 != 0;
                        if (v10 && v13)
                        {
                            v11 = sub_1be488(a0);
                            if (!(v11 & 1))
                            {
                                if (sub_67b370(0, 123606944))
                                    sub_1bef48();
                                v11 = sub_411964(a0);
                            }
                            v15 = 1;
                            v14 = 1;
                            goto LABEL_1be780;
                        }
                    }
                    else
                    {
                        v12 = 1;
                    }
                }
            }
            else
            {
                v12 = 0;
            }
        }
        else
        {
            v12 = 0;
            v10 = 0;
            v11 = v9;
        }
        v15 = 0;
        v13 = 0;
        v14 = v10 != 0;
LABEL_1be780:
        if (v5)
            v11 = v5(a0, a1);
        if (!(v9 & 1))
            return v11;
        if (v15 & 1 & v14 & 1 & v12 & 1 && (index = *(short *)0x75aaffc + v10, v11 = sub_139354(123377576, index, 12), v11 & 1))
        {
            v17 = *(float *)index;
            v18 = *(float *)(index + 4);
            v19 = *(float *)&*(int *)(index + 8);
            idx = *(short *)0x75aaffa + v10;
            v11 = sub_139354(123377576, idx, 12);
            if (v11 & 1)
            {
                v21 = *(float *)idx;
                v22 = *(float *)(idx + 4);
                v23 = *(float *)&*(int *)(idx + 8);
                v24 = *(short *)0x75aaffe + v10;
                v11 = sub_139354(123377576, v24, 4);
                if (...)
                {
                    v40 = __float_as_int(a3);
                    v41 = v40 & 0x7fffffff;
                    v42 = v40;
                    if (0 <= (int)v40)
                    {
                        v43 = 0;
                        v44 = arm64g_calculate_condition(163, v42, 0, 0);
                        if (!(v44 & 1))
                            goto LABEL_1be9b6;
LABEL_1be9b5:
                        v46 = 0;
                    }
                    else
                    {
                        v43 = 127 > v41 - 0x800000 >> 24;
                        v45 = arm64g_calculate_condition(163, v42, 0, 0);
                        if (v45 & 1)
                            goto LABEL_1be9b5;
LABEL_1be9b6:
                        v46 = 0x7fffff > v41 - 1;
                    }
                    v47 = v40 & 0x7fffffff;
                    if (!(v40 & 0x7fffffff))
                        v46 = 1;
                    v48 = v47;
                    if (v47 != inff)
                    {
                        v49 = arm64g_calculate_condition(211, v48, 0x7f800000, 0);
                        if (!(v49 & 1))
                            goto LABEL_1be9ca;
LABEL_1be9c9:
                    }
                    else
                    {
                        v46 = 1;
                        v50 = arm64g_calculate_condition(211, v48, 0x7f800000, 0);
                        if (v50 & 1)
                            goto LABEL_1be9c9;
LABEL_1be9ca:
                        v46 = 1;
                    }
                    if (!(v46 & 1) && !(v43 & 1) && (v51 = (isnan(a3) ? 2 : a3 == 0.25f ? 2 : 0) | a3 < 0.25f, v52 = (((v51 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(a3)) * 0x10000000, v53 = arm64g_calculate_condition(192, (((v51 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(a3)) * 0x10000000, 0, 0), !(v53 & 1)))
                    {
                        v54 = v1;
                        v55 = v54 - 1;
                        v56 = (v54 & 0x7fffffff) - 0x800000 >> 24;
                        if (0 <= v54)
                        {
                            v57 = arm64g_calculate_condition(160, v52, 0, 0);
                            v58 = 3;
                            v59 = (v57 & 1 ? v56 : 0x20000000);
                            v60 = (v57 & 1 ? 126 : 0);
                            v61 = arm64g_calculate_condition(131, v59, v60, 0);
                            if (!(v61 & 1))
                                goto LABEL_1bea06;
LABEL_1bea05:
                            v64 = arm64g_calculate_condition(v58 | 128, v59, v60, 0);
                            v65 = 3;
                            v66 = (v64 & 1 ? v55 : 0);
                            v67 = (v64 & 1 ? 0x7ffffe : 0);
                            v68 = arm64g_calculate_condition(131, v66, v67, 0);
                            if (!(v68 & 1))
                                goto LABEL_1bea0c;
                        }
                        else
                        {
                            v62 = arm64g_calculate_condition(160, v52, 0, 0);
                            v58 = 0;
                            v59 = (v62 & 1 ? v56 : 0x20000000);
                            v60 = (v62 & 1 ? 126 : 0);
                            v63 = arm64g_calculate_condition(128, v59, v60, 0);
                            if (v63 & 1)
                                goto LABEL_1bea05;
LABEL_1bea06:
                            v69 = arm64g_calculate_condition(v58 | 128, v59, v60, 0);
                            v65 = 0;
                            v66 = (v69 & 1 ? v55 : 0);
                            v67 = (v69 & 1 ? 0x7ffffe : 0);
                            v70 = arm64g_calculate_condition(128, v66, v67, 0);
                            if (!(v70 & 1))
                            {
LABEL_1bea0c:
                                v71 = v0;
                                v72 = v71 - 1;
                                v73 = (v71 & 0x7fffffff) - 0x800000 >> 24;
                                if (0 <= v71)
                                {
                                    v74 = arm64g_calculate_condition(v65 | 160, v66, v67, 0);
                                    v75 = 3;
                                    v76 = (v74 & 1 ? v73 : 0x20000000);
                                    v77 = (v74 & 1 ? 126 : 0);
                                    v78 = arm64g_calculate_condition(131, v76, v77, 0);
                                    if (!(v78 & 1))
                                        goto LABEL_1bea2a;
                                    goto LABEL_1bea29;
                                }
                                else
                                {
                                    v79 = arm64g_calculate_condition(v65 | 160, v66, v67, 0);
                                    v75 = 0;
                                    v76 = (v79 & 1 ? v73 : 0x20000000);
                                    v77 = (v79 & 1 ? 126 : 0);
                                    v80 = arm64g_calculate_condition(128, v76, v77, 0);
                                    if (v80 & 1)
                                    {
LABEL_1bea29:
                                        v81 = arm64g_calculate_condition(v75 | 128, v76, v77, 0);
                                        v82 = 3;
                                        v83 = (v81 & 1 ? v72 : 0);
                                        v84 = (v81 & 1 ? 0x7ffffe : 0);
                                        v85 = arm64g_calculate_condition(131, v83, v84, 0);
                                        if (!(v85 & 1))
                                            goto LABEL_1bea30;
                                    }
                                    else
                                    {
LABEL_1bea2a:
                                        v86 = arm64g_calculate_condition(v75 | 128, v76, v77, 0);
                                        v82 = 0;
                                        v83 = (v86 & 1 ? v72 : 0);
                                        v84 = (v86 & 1 ? 0x7ffffe : 0);
                                        v87 = arm64g_calculate_condition(128, v83, v84, 0);
                                        if (!(v87 & 1))
                                        {
LABEL_1bea30:
                                            v88 = *v33;
                                            v89 = __float_as_int(v88);
                                            v90 = v89 & 0x7fffffff;
                                            v91 = v89 - 1;
                                            v92 = v90 - 0x800000 >> 24;
                                            v93 = arm64g_calculate_condition(193, v89, 1, 0);
                                            if (v93 & 1)
                                            {
                                                v94 = arm64g_calculate_condition(v82 | 192, v83, v84, 0);
                                                v95 = 3;
                                                v96 = (v94 & 1 ? v92 : 0x20000000);
                                                v97 = (v94 & 1 ? 127 : 0);
                                                v98 = arm64g_calculate_condition(35, v96, v97, 0);
                                                if (!(v98 & 1))
                                                    goto LABEL_1bea5a;
                                                goto LABEL_1bea59;
                                            }
                                            else
                                            {
                                                v99 = arm64g_calculate_condition(v82 | 192, v83, v84, 0);
                                                v95 = 0;
                                                v96 = (v99 & 1 ? v92 : 0x20000000);
                                                v97 = (v99 & 1 ? 127 : 0);
                                                v100 = arm64g_calculate_condition(32, v96, v97, 0);
                                                if (v100 & 1)
                                                {
LABEL_1bea59:
                                                    v101 = arm64g_calculate_condition(v95 | 32, v96, v97, 0);
                                                    v102 = 3;
                                                    v103 = (v101 & 1 ? v91 : 0);
                                                    v104 = (v101 & 1 ? 0x7fffff : 0);
                                                    v105 = arm64g_calculate_condition(35, v103, v104, 0);
                                                    if (!(v105 & 1))
                                                        goto LABEL_1bea5e;
                                                    goto LABEL_1bea5d;
                                                }
                                                else
                                                {
LABEL_1bea5a:
                                                    v106 = arm64g_calculate_condition(v95 | 32, v96, v97, 0);
                                                    v102 = 0;
                                                    v103 = (v106 & 1 ? v91 : 0);
                                                    v104 = (v106 & 1 ? 0x7fffff : 0);
                                                    v107 = arm64g_calculate_condition(32, v103, v104, 0);
                                                    if (v107 & 1)
                                                    {
LABEL_1bea5d:
                                                        v108 = arm64g_calculate_condition(v102 | 32, v103, v104, 0);
                                                        v109 = arm64g_calculate_condition(19, (v108 & 1 ? v90 : 0x40000000), 0, 0);
                                                        if (!(v109 & 1))
                                                            goto LABEL_1bea64;
                                                    }
                                                    else
                                                    {
LABEL_1bea5e:
                                                        v110 = arm64g_calculate_condition(v102 | 32, v103, v104, 0);
                                                        v111 = arm64g_calculate_condition(16, (v110 & 1 ? v90 : 0x40000000), 0, 0);
                                                        if (!(v111 & 1))
                                                        {
LABEL_1bea64:
                                                            v112 = fabsf(v6);
                                                            if (v112 != inff && (v113 = arm64g_calculate_condition(96, (((((char)(CmpF(__float_as_int(v112), inff)) >> 5 & 3 | v112 < inff) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v112)) * 0x10000000, 0, 0), !(v113 & 1) && (v114 = *v25 * v4 * v3, v115 = fabsf(v114), v115 != inff && (v116 = arm64g_calculate_condition(96, (((((char)(CmpF(__float_as_int(v115), inff)) >> 5 & 3 | v115 < inff) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v115)) * 0x10000000, 0, 0), !(v116 & 1) && (v117 = arm64g_calculate_condition(144, (((((char)(CmpF(__float_as_int(v114), 0.009999999776482582f)) >> 5 & 3 | v114 < 0.009999999776482582f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v114)) * 0x10000000, 0, 0), !(v117 & 1) && (v118 = (isnan(v114) ? 2 : v114 == 50.0f ? 2 : 0) | v114 < 50.0f, v119 = (((v118 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v114)) * 0x10000000, v120 = arm64g_calculate_condition(192, (((v118 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v114)) * 0x10000000, 0, 0), !(v120 & 1)))))))
                                                            {
                                                                v121 = *(unsigned int *)&v2;
                                                                v122 = v121 - 1;
                                                                v123 = (v121 & 0x7fffffff) - 0x800000 >> 24;
                                                                if (0 <= (int)v121)
                                                                {
                                                                    v124 = arm64g_calculate_condition(160, v119, 0, 0);
                                                                    v125 = 3;
                                                                    v126 = (v124 & 1 ? v123 : 0x20000000);
                                                                    v127 = (v124 & 1 ? 126 : 0);
                                                                    v128 = arm64g_calculate_condition(131, v126, v127, 0);
                                                                    if (!(v128 & 1))
                                                                        goto LABEL_1beaea;
                                                                    goto LABEL_1beae9;
                                                                }
                                                                else
                                                                {
                                                                    v129 = arm64g_calculate_condition(160, v119, 0, 0);
                                                                    v125 = 0;
                                                                    v126 = (v129 & 1 ? v123 : 0x20000000);
                                                                    v127 = (v129 & 1 ? 126 : 0);
                                                                    v130 = arm64g_calculate_condition(128, v126, v127, 0);
                                                                    if (v130 & 1)
                                                                    {
LABEL_1beae9:
                                                                        v131 = arm64g_calculate_condition(v125 | 128, v126, v127, 0);
                                                                        v132 = arm64g_calculate_condition(131, (v131 & 1 ? v122 : 0), (v131 & 1 ? 0x7ffffe : 0), 0);
                                                                        if (!(v132 & 1))
                                                                            goto LABEL_1beaf0;
                                                                    }
                                                                    else
                                                                    {
LABEL_1beaea:
                                                                        v133 = arm64g_calculate_condition(v125 | 128, v126, v127, 0);
                                                                        v134 = arm64g_calculate_condition(128, (v133 & 1 ? v122 : 0), (v133 & 1 ? 0x7ffffe : 0), 0);
                                                                        if (!(v134 & 1))
                                                                        {
LABEL_1beaf0:
                                                                            v135 = arm64g_calculate_condition(192, (((((char)(CmpF(*(unsigned int *)&v2, 100.0f)) >> 5 & 3 | v2 < 100.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
                                                                            if (!(v135 & 1))
                                                                            {
                                                                                v136 = v17 * v17 + v19 * v19;
                                                                                v137 = fabsf(v136);
                                                                                v138 = (isnan(v137) ? 2 : v137 == inff ? 2 : 0) | v137 < inff;
                                                                                v139 = arm64g_calculate_condition(64, (((v138 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v137)) * 0x10000000, 0, 0);
                                                                                if (v139 & 1 || !(v140 = arm64g_calculate_condition(192, (((v138 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v137)) * 0x10000000, 0, 0), !(v140 & 1)))
                                                                                {
                                                                                    v141 = fabsf(v21);
                                                                                    v142 = fabsf(v23);
                                                                                    g_75e17a8 = v17;
                                                                                    g_75e17ac = v18;
                                                                                    v143 = (isnan(v141) ? 2 : v141 == inff ? 2 : 0) | v141 < inff;
                                                                                    v144 = (((v143 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v141)) * 0x10000000;
                                                                                    v145 = fabsf(v22);
                                                                                    g_75e17b0 = v19;
                                                                                    v146 = arm64g_calculate_condition(64, (((v143 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v141)) * 0x10000000, 0, 0);
                                                                                    if (v146 & 1)
                                                                                    {
                                                                                        v147 = v21;
                                                                                        v148 = arm64g_calculate_condition(192, v144, 0, 0);
                                                                                        if (!(v148 & 1))
                                                                                            goto LABEL_1bec32;
LABEL_1bec31:
                                                                                        v147 = v21;
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        v147 = 0;
                                                                                        v149 = arm64g_calculate_condition(192, v144, 0, 0);
                                                                                        if (v149 & 1)
                                                                                            goto LABEL_1bec31;
LABEL_1bec32:
                                                                                    }
                                                                                    v150 = (isnan(v145) ? 2 : v145 == inff ? 2 : 0) | v145 < inff;
                                                                                    v151 = arm64g_calculate_condition(64, (((v150 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v145)) * 0x10000000, 0, 0);
                                                                                    if (v151 & 1)
                                                                                        v152 = v22;
                                                                                    else
                                                                                        v152 = 0;
                                                                                    g_75e17b4 = v147;
                                                                                    v153 = arm64g_calculate_condition(192, (((v150 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v145)) * 0x10000000, 0, 0);
                                                                                    if (v153 & 1)
                                                                                        v152 = v22;
                                                                                    v154 = (isnan(v142) ? 2 : v142 == inff ? 2 : 0) | v142 < inff;
                                                                                    v155 = arm64g_calculate_condition(64, (((v154 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v142)) * 0x10000000, 0, 0);
                                                                                    if (v155 & 1)
                                                                                        v156 = v23;
                                                                                    else
                                                                                        v156 = 0;
                                                                                    g_75e17b8 = v152;
                                                                                    v157 = arm64g_calculate_condition(192, (((v154 ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v142)) * 0x10000000, 0, 0);
                                                                                    if (v157 & 1)
                                                                                        v156 = v23;
                                                                                    g_75e17bc = v156;
                                                                                    g_75e17c0 = a3;
                                                                                    g_75e17c4 = v1;
                                                                                    g_75e17c8 = v0;
                                                                                    g_75e17cc = v88;
                                                                                    g_75e1790 = sqrtf(v136);
                                                                                    g_75e17d0 = v114;
                                                                                    *(float *)&g_75e17d4 = v2;
                                                                                    v158 = sub_43bc24(sub_126488() + 8);
                                                                                    v159 = *(long long *)0x75ab018 + v158;
                                                                                    if (sub_139584(123377576, v159, 8) & 1)
                                                                                    {
                                                                                        v159(v10, 0);
                                                                                        v160 = *(unsigned int *)&v2;
                                                                                        v161 = v160 - 1;
                                                                                        v162 = (v160 & 0x7fffffff) - 0x800000 >> 24;
                                                                                        if (0 <= (int)v160)
                                                                                        {
                                                                                            v167 = arm64g_calculate_condition(v163 | 160, v164, v165, v166);
                                                                                            v168 = 3;
                                                                                            v169 = (v167 & 1 ? v162 : 0x20000000);
                                                                                            v170 = (v167 & 1 ? 126 : 0);
                                                                                            v171 = arm64g_calculate_condition(131, v169, v170, 0);
                                                                                            if (!(v171 & 1))
                                                                                                goto LABEL_1becfa;
LABEL_1becf9:
                                                                                            v174 = arm64g_calculate_condition(v168 | 128, v169, v170, 0);
                                                                                            v175 = arm64g_calculate_condition(131, (v174 & 1 ? v161 : 0), (v174 & 1 ? 0x7ffffe : 0), 0);
                                                                                            if (!(v175 & 1))
                                                                                                goto LABEL_1bed00;
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            v172 = arm64g_calculate_condition(v163 | 160, v164, v165, v166);
                                                                                            v168 = 0;
                                                                                            v169 = (v172 & 1 ? v162 : 0x20000000);
                                                                                            v170 = (v172 & 1 ? 126 : 0);
                                                                                            v173 = arm64g_calculate_condition(128, v169, v170, 0);
                                                                                            if (v173 & 1)
                                                                                                goto LABEL_1becf9;
LABEL_1becfa:
                                                                                            v176 = arm64g_calculate_condition(v168 | 128, v169, v170, 0);
                                                                                            v177 = arm64g_calculate_condition(128, (v176 & 1 ? v161 : 0), (v176 & 1 ? 0x7ffffe : 0), 0);
                                                                                            if (!(v177 & 1))
                                                                                            {
LABEL_1bed00:
                                                                                                *(float *)&g_75e17d8 = v2;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    v178 = *(short *)0x75ab022 + v13;
                                                                                    if (sub_139354(123377576, v178, 4) & 1)
                                                                                    {
                                                                                        v179 = *(float *)&*v178;
                                                                                        v180 = __float_as_int(v179);
                                                                                        v181 = v180 & 0x7fffffff;
                                                                                        v182 = v180;
                                                                                        if (0 <= (int)v180)
                                                                                        {
                                                                                            v183 = 0;
                                                                                            v184 = arm64g_calculate_condition(163, v182, 0, 0);
                                                                                            if (!(v184 & 1))
                                                                                                goto LABEL_1bed5e;
LABEL_1bed5d:
                                                                                            v186 = 0;
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            v183 = 127 > v181 - 0x800000 >> 24;
                                                                                            v185 = arm64g_calculate_condition(163, v182, 0, 0);
                                                                                            if (v185 & 1)
                                                                                                goto LABEL_1bed5d;
LABEL_1bed5e:
                                                                                            v186 = 0x7fffff > v181 - 1;
                                                                                        }
                                                                                        v187 = v180 & 0x7fffffff;
                                                                                        if (!(v180 & 0x7fffffff))
                                                                                            v186 = 1;
                                                                                        v188 = v187;
                                                                                        if (v187 != inff)
                                                                                        {
                                                                                            v189 = v186;
                                                                                            v190 = arm64g_calculate_condition(211, v188, 0x7f800000, 0);
                                                                                            if (!(v190 & 1))
                                                                                                goto LABEL_1bed72;
LABEL_1bed71:
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            v189 = 1;
                                                                                            v191 = arm64g_calculate_condition(211, v188, 0x7f800000, 0);
                                                                                            if (v191 & 1)
                                                                                                goto LABEL_1bed71;
LABEL_1bed72:
                                                                                            v189 = 1;
                                                                                        }
                                                                                        if (!(v189 & 1) && !(v183 & 1) && !(v192 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v179), 1000.0f)) >> 5 & 3 | v179 < 1000.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v179)) * 0x10000000, 0, 0), !(v192 & 1)))
                                                                                            goto LABEL_1bed90;
                                                                                    }
                                                                                    v179 = 0;
LABEL_1bed90:
                                                                                    v193 = *(short *)0x75ab024 + v13;
                                                                                    if (sub_139354(123377576, v193, 4) & 1)
                                                                                    {
                                                                                        v194 = *(float *)&*v193;
                                                                                        v195 = __float_as_int(v194);
                                                                                        v196 = v195 & 0x7fffffff;
                                                                                        v197 = v195;
                                                                                        if (0 <= (int)v195)
                                                                                        {
                                                                                            v198 = 0;
                                                                                            v199 = arm64g_calculate_condition(163, v197, 0, 0);
                                                                                            if (!(v199 & 1))
                                                                                                goto LABEL_1bede6;
LABEL_1bede5:
                                                                                            v201 = 0;
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            v198 = 127 > v196 - 0x800000 >> 24;
                                                                                            v200 = arm64g_calculate_condition(163, v197, 0, 0);
                                                                                            if (v200 & 1)
                                                                                                goto LABEL_1bede5;
LABEL_1bede6:
                                                                                            v201 = 0x7fffff > v196 - 1;
                                                                                        }
                                                                                        v202 = v195 & 0x7fffffff;
                                                                                        if (!(v195 & 0x7fffffff))
                                                                                            v201 = 1;
                                                                                        v203 = v202;
                                                                                        if (v202 != inff)
                                                                                        {
                                                                                            v204 = v201;
                                                                                            v205 = arm64g_calculate_condition(211, v203, 0x7f800000, 0);
                                                                                            if (!(v205 & 1))
                                                                                                goto LABEL_1bedfa;
LABEL_1bedf9:
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            v204 = 1;
                                                                                            v206 = arm64g_calculate_condition(211, v203, 0x7f800000, 0);
                                                                                            if (v206 & 1)
                                                                                                goto LABEL_1bedf9;
LABEL_1bedfa:
                                                                                            v204 = 1;
                                                                                        }
                                                                                        if (!(v204 & 1) && !(v198 & 1) && !(v207 = arm64g_calculate_condition(208, (((((char)(CmpF(__float_as_int(v194), 1000.0f)) >> 5 & 3 | v194 < 1000.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v194)) * 0x10000000, 0, 0), !(v207 & 1)))
                                                                                            goto LABEL_1bee18;
                                                                                    }
                                                                                    v194 = 0;
LABEL_1bee18:
                                                                                    *(float *)&g_75e17dc = v179;
                                                                                    *(float *)&g_75e17e0 = v194;
                                                                                    g_64693e0 = *(char *)(*(short *)0x75ab00a + v10) != 0;
                                                                                    g_75e17e4 = *(char *)(*(short *)0x75ab010 + v10) != 0;
                                                                                    v208 = arm64g_calculate_condition(208, (((((char)(CmpF(*(unsigned int *)&v6, 0.5f)) >> 5 & 3 | v6 < 0.5f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v6)) * 0x10000000, 0, 0);
                                                                                    g_75e17e5 = !(v208 & 1);
                                                                                    idx1 = *(short *)0x75aaff8 + v10;
                                                                                    if (sub_139354(123377576, idx1, 12) & 1)
                                                                                    {
                                                                                        v210 = 0;
                                                                                        v211 = __int_as_float(fabs(*(int *)idx1));
                                                                                        if (v211 != inff)
                                                                                        {
                                                                                            v212 = arm64g_calculate_condition(96, (((((char)(CmpF(__float_as_int(v211), inff)) >> 5 & 3 | v211 < inff) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v211)) * 0x10000000, 0, 0);
                                                                                            if (!(v212 & 1))
                                                                                            {
                                                                                                v213 = *(float *)&*(int *)(idx1 + 4);
                                                                                                v214 = fabsf(v213);
                                                                                                if (v214 != inff)
                                                                                                {
                                                                                                    v215 = arm64g_calculate_condition(96, (((((char)(CmpF(__float_as_int(v214), inff)) >> 5 & 3 | v214 < inff) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v214)) * 0x10000000, 0, 0);
                                                                                                    if (!(v215 & 1))
                                                                                                    {
                                                                                                        v216 = *(float *)&*(int *)(idx1 + 8);
                                                                                                        v217 = fabsf(v216);
                                                                                                        if (v217 != inff)
                                                                                                        {
                                                                                                            v218 = arm64g_calculate_condition(96, (((((char)(CmpF(__float_as_int(v217), inff)) >> 5 & 3 | v217 < inff) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v217)) * 0x10000000, 0, 0);
                                                                                                            if (!(v218 & 1))
                                                                                                            {
                                                                                                                *(int *)&g_75e17e8 = *(int *)idx1;
                                                                                                                v210 = 1;
                                                                                                                g_75e17ec = v213;
                                                                                                                g_75e17f0 = v216;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        v210 = 0;
                                                                                    }
                                                                                    g_75e17f4 = v210;
                                                                                    v219 = sub_639800();
                                                                                    /* unsupported instruction */;
                                                                                    g_75e1788 = (unsigned long long)((int128_t)(v219 * 4835703278458516699) >> 82) + (unsigned long long)(v219 * 4835703278458516699 >> 127);
                                                                                    return v219;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        /* unsupported instruction */;
        g_75e1788 = 0;
        *(unsigned int *)&g_75e1790 = 0;
        return v11;
    }
    if (!*(long long *)0x75e1798)
        return a0;
    goto *((void *)(*(long long *)0x75e1798));
}
