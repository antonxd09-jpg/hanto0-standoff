1c1308: ldrb w8, [x0]
1c130c: adrp x9, #0x75e1000
1c1310: add x9, x9, #0x800
1c1314: adrp x10, #0x75e1000
1c1318: add x10, x10, #0x801
1c131c: stlrb w8, [x9]
1c1320: ldrb w9, [x0, #0xc]
1c1324: stlrb w9, [x10]
1c1328: mov w10, #0x7f800000
1c132c: ldr s0, [x0, #8]
1c1330: fmov s2, w10
1c1334: mov w10, #0x3f400000
1c1338: fabs s1, s0
1c133c: fcmp s1, s2
1c1340: b.eq #0x1c1364
1c1344: b.vs #0x1c1364
1c1348: fmov s1, #1.00000000
1c134c: movi d2, #0000000000000000
1c1350: fcmp s0, s1
1c1354: fcsel s1, s1, s0, gt
1c1358: fcmp s0, #0.0
1c135c: fcsel s0, s2, s1, mi
1c1360: fmov w10, s0
1c1364: adrp x11, #0x6469000
1c1368: orr w8, w8, w9
1c136c: str w10, [x11, #0x3e4]
1c1370: cbz w8, #0x1c1378
1c1374: ret 
1c1378: adrp x8, #0x75e1000
1c137c: add x8, x8, #0x7a0
1c1380: stlr xzr, [x8]
1c1384: ret 
