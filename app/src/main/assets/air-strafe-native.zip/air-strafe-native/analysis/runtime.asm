
FUNCTION 0x1bef48
1bef48: sub sp, sp, #0x120
1bef4c: stp d15, d14, [sp, #0x80]
1bef50: stp d13, d12, [sp, #0x90]
1bef54: stp d11, d10, [sp, #0xa0]
1bef58: stp d9, d8, [sp, #0xb0]
1bef5c: stp x29, x30, [sp, #0xc0]
1bef60: stp x28, x27, [sp, #0xd0]
1bef64: stp x26, x25, [sp, #0xe0]
1bef68: stp x24, x23, [sp, #0xf0]
1bef6c: stp x22, x21, [sp, #0x100]
1bef70: stp x20, x19, [sp, #0x110]
1bef74: add x29, sp, #0xc0
1bef78: mrs x24, tpidr_el0
1bef7c: adrp x9, #0x75e1000
1bef80: mov x22, x1
1bef84: ldr x8, [x24, #0x28]
1bef88: mov x19, x0
1bef8c: adrp x1, #0x75e1000
1bef90: add x1, x1, #0x818
1bef94: mov x0, xzr
1bef98: fmov s9, s0
1bef9c: stur x8, [x29, #-0x50]
1befa0: adrp x8, #0x75e1000
1befa4: mov x21, x2
1befa8: ldrb w26, [x8, #0x800]
1befac: ldrb w25, [x9, #0x801]
1befb0: bl #0x67b370
1befb4: adrp x8, #0x75e1000
1befb8: cmp x0, #0
1befbc: ldr w27, [x8, #0x814]
1befc0: adrp x8, #0x75e1000
1befc4: ccmp x0, x19, #0, ne
1befc8: ldr s8, [x8, #0x810]
1befcc: orr w8, w25, w26
1befd0: cset w28, eq
1befd4: tbnz w8, #0, #0x1befdc
1befd8: cbz w28, #0x1bf52c
1befdc: bl #0x1858b0
1befe0: tbnz w0, #0, #0x1bf52c
1befe4: bl #0x639800
1befe8: mov x8, #0x34db
1befec: adrp x10, #0x75e1000
1beff0: movk x8, #0xd7b6, lsl #16
1beff4: movk x8, #0xde82, lsl #32
1beff8: movk x8, #0x431b, lsl #48
1beffc: smulh x8, x0, x8
1bf000: asr x9, x8, #0x12
1bf004: add x8, x9, x8, lsr #63
1bf008: ldr x9, [x10, #0x808]
1bf00c: sub x8, x8, x9
1bf010: cmp x8, #0xfa
1bf014: b.hi #0x1bf52c
1bf018: adrp x20, #0x75ac000
1bf01c: add x20, x20, #0x3f8
1bf020: ldarb w8, [x20]
1bf024: tbz w8, #0, #0x1bf3bc
1bf028: ldarb w8, [x20]
1bf02c: tbz w8, #0, #0x1bf404
1bf030: adrp x20, #0x75a9000
1bf034: add x20, x20, #0x7a8
1bf038: mov w2, #4
1bf03c: ldrh w23, [x20, #0x1652]
1bf040: mov x0, x20
1bf044: add x1, x23, x19
1bf048: bl #0x139354
1bf04c: tbz w0, #0, #0x1bf52c
1bf050: ldr w8, [x23, x19]
1bf054: str w8, [sp, #0x28]
1bf058: cbz w8, #0x1bf52c
1bf05c: ldrh w23, [x20, #0x165a]
1bf060: mov x0, x20
1bf064: mov w2, #1
1bf068: add x1, x23, x19
1bf06c: bl #0x139354
1bf070: tbz w0, #0, #0x1bf52c
1bf074: ldrb w8, [x23, x19]
1bf078: cbz w8, #0x1bf52c
1bf07c: ldrh w8, [x20, #0x165e]
1bf080: mov x0, x20
1bf084: mov w2, #4
1bf088: add x23, x8, x19
1bf08c: mov x1, x23
1bf090: bl #0x139354
1bf094: tbz w0, #0, #0x1bf52c
1bf098: ldrh w8, [x20, #0x166c]
1bf09c: ldr s10, [x23]
1bf0a0: mov x0, x20
1bf0a4: mov w2, #8
1bf0a8: add x23, x8, x19
1bf0ac: mov x1, x23
1bf0b0: bl #0x139354
1bf0b4: tbz w0, #0, #0x1bf52c
1bf0b8: ldp s11, s12, [x23]
1bf0bc: mov x0, x20
1bf0c0: ldrh w23, [x20, #0x1658]
1bf0c4: mov w2, #1
1bf0c8: add x1, x23, x19
1bf0cc: bl #0x139354
1bf0d0: tbz w0, #0, #0x1bf52c
1bf0d4: ldrb w8, [x23, x19]
1bf0d8: ldrh w23, [x20, #0x1656]
1bf0dc: mov x0, x20
1bf0e0: mov w2, #1
1bf0e4: add x1, x23, x19
1bf0e8: str w8, [sp, #0x24]
1bf0ec: bl #0x139354
1bf0f0: tbz w0, #0, #0x1bf52c
1bf0f4: ldrb w8, [x23, x19]
1bf0f8: mov x0, x20
1bf0fc: mov w2, #0xc
1bf100: strh wzr, [sp, #0x38]
1bf104: str w8, [sp, #0x20]
1bf108: adrp x8, #0x684000
1bf10c: ldr d0, [x8, #0x28]
1bf110: ldrh w8, [x20, #0x1852]
1bf114: stur xzr, [sp, #0x3c]
1bf118: str wzr, [sp, #0x44]
1bf11c: add x23, x8, x22
1bf120: stur d0, [sp, #0x4c]
1bf124: mov x1, x23
1bf128: stp xzr, xzr, [sp, #0x60]
1bf12c: str xzr, [sp, #0x58]
1bf130: bl #0x139354
1bf134: tbz w0, #0, #0x1bf52c
1bf138: ldr s14, [x23]
1bf13c: ldr s13, [x23, #8]
1bf140: mov x0, x20
1bf144: ldrh w23, [x20, #0x1862]
1bf148: mov w2, #1
1bf14c: add x1, x23, x22
1bf150: bl #0x139354
1bf154: tbz w0, #0, #0x1bf52c
1bf158: ldrb w8, [x23, x22]
1bf15c: ldrh w23, [x20, #0x1868]
1bf160: mov x0, x20
1bf164: mov w2, #1
1bf168: add x1, x23, x22
1bf16c: str w8, [sp, #0x1c]
1bf170: bl #0x139354
1bf174: tbz w0, #0, #0x1bf52c
1bf178: ldrh w8, [x20, #0x185a]
1bf17c: ldrb w9, [x23, x22]
1bf180: mov x0, x20
1bf184: mov w2, #4
1bf188: add x23, x8, x22
1bf18c: str w9, [sp, #0x18]
1bf190: mov x1, x23
1bf194: bl #0x139354
1bf198: tbz w0, #0, #0x1bf52c
1bf19c: ldrh w8, [x20, #0x185c]
1bf1a0: ldr s15, [x23]
1bf1a4: mov x0, x20
1bf1a8: mov w2, #4
1bf1ac: add x23, x8, x22
1bf1b0: mov x1, x23
1bf1b4: bl #0x139354
1bf1b8: tbz w0, #0, #0x1bf52c
1bf1bc: ldrh w8, [x20, #0x185e]
1bf1c0: ldr s0, [x23]
1bf1c4: mov x0, x20
1bf1c8: mov w2, #4
1bf1cc: add x22, x8, x22
1bf1d0: str s0, [sp, #0x14]
1bf1d4: mov x1, x22
1bf1d8: bl #0x139354
1bf1dc: tbz w0, #0, #0x1bf52c
1bf1e0: ldrh w8, [x20, #0x1880]
1bf1e4: ldr s0, [x22]
1bf1e8: mov x0, x20
1bf1ec: mov w2, #4
1bf1f0: add x22, x8, x21
1bf1f4: str s0, [sp, #0x10]
1bf1f8: mov x1, x22
1bf1fc: bl #0x139354
1bf200: tbz w0, #0, #0x1bf52c
1bf204: ldr s0, [x22]
1bf208: ldrh w22, [x20, #0x1882]
1bf20c: mov x0, x20
1bf210: mov w2, #4
1bf214: add x1, x22, x21
1bf218: str s0, [sp, #0xc]
1bf21c: bl #0x139354
1bf220: tbz w0, #0, #0x1bf52c
1bf224: ldr w8, [x22, x21]
1bf228: ldrh w22, [x20, #0x1884]
1bf22c: mov x0, x20
1bf230: mov w2, #4
1bf234: add x1, x22, x21
1bf238: str w8, [sp, #0x48]
1bf23c: bl #0x139354
1bf240: tbz w0, #0, #0x1bf52c
1bf244: ldrh w9, [x20, #0x187a]
1bf248: ldr w8, [x22, x21]
1bf24c: mov x0, x20
1bf250: mov w2, #4
1bf254: add x22, x9, x21
1bf258: str w8, [sp, #0x54]
1bf25c: mov x1, x22
1bf260: bl #0x139354
1bf264: tbz w0, #0, #0x1bf52c
1bf268: ldrh w8, [x20, #0x187c]
1bf26c: ldr s0, [x22]
1bf270: mov x0, x20
1bf274: mov w2, #4
1bf278: add x22, x8, x21
1bf27c: str s0, [sp, #8]
1bf280: mov x1, x22
1bf284: bl #0x139354
1bf288: tbz w0, #0, #0x1bf52c
1bf28c: ldrh w8, [x20, #0x187e]
1bf290: ldr s0, [x22]
1bf294: mov x0, x20
1bf298: mov w2, #4
1bf29c: add x21, x8, x21
1bf2a0: str s0, [sp, #4]
1bf2a4: mov x1, x21
1bf2a8: bl #0x139354
1bf2ac: tbz w0, #0, #0x1bf52c
1bf2b0: fmov w8, s9
1bf2b4: mov w11, #0x7fffff
1bf2b8: ands w9, w8, #0x7fffffff
1bf2bc: sub w10, w9, #0x800, lsl #12
1bf2c0: sub w9, w9, #1
1bf2c4: lsr w10, w10, #0x18
1bf2c8: cmp w9, w11
1bf2cc: mov w11, #0x7f800000
1bf2d0: cset w9, lo
1bf2d4: cmp w10, #0x7f
1bf2d8: cset w10, lo
1bf2dc: cmp w8, #0
1bf2e0: csel w10, wzr, w10, ge
1bf2e4: csel w9, wzr, w9, ge
1bf2e8: ands w8, w8, #0x7fffffff
1bf2ec: csinc w9, w9, wzr, ne
1bf2f0: cmp w8, w11
1bf2f4: csinc w8, w9, wzr, ne
1bf2f8: csinc w8, w8, wzr, le
1bf2fc: orr w8, w8, w10
1bf300: tbnz w8, #0, #0x1bf52c
1bf304: fmov s0, #0.25000000
1bf308: fcmp s9, s0
1bf30c: b.gt #0x1bf52c
1bf310: ldr w8, [sp, #0x1c]
1bf314: ldr s1, [sp, #0xc]
1bf318: ldr s0, [x21]
1bf31c: stp s14, s13, [sp, #0x3c]
1bf320: cmp w8, #0
1bf324: fmul s2, s1, s9
1bf328: ldr s1, [sp, #0x14]
1bf32c: cset w8, ne
1bf330: strb w8, [sp, #0x38]
1bf334: ldr w8, [sp, #0x18]
1bf338: fmul s1, s15, s1
1bf33c: cmp w8, #0
1bf340: str s2, [sp, #0x44]
1bf344: ldr s2, [sp, #0x10]
1bf348: cset w8, ne
1bf34c: strb w8, [sp, #0x39]
1bf350: adrp x8, #0x6469000
1bf354: fmul s2, s1, s2
1bf358: ldr w8, [x8, #0x3e4]
1bf35c: str w8, [sp, #0x50]
1bf360: adrp x8, #0x75e1000
1bf364: ldr s3, [x8, #0x7d8]
1bf368: ldp s5, s4, [sp, #4]
1bf36c: ldr w8, [sp, #0x20]
1bf370: fmul s3, s3, s9
1bf374: fmul s4, s4, s9
1bf378: fmul s5, s5, s9
1bf37c: stp s2, s3, [sp, #0x58]
1bf380: stp s4, s5, [sp, #0x60]
1bf384: cbz w8, #0x1bf44c
1bf388: fmov w8, s0
1bf38c: mov w10, #0x7e
1bf390: and w9, w8, #0x7fffffff
1bf394: cmp w8, #0
1bf398: sub w8, w8, #1
1bf39c: sub w9, w9, #0x800, lsl #12
1bf3a0: lsr w9, w9, #0x18
1bf3a4: ccmp w9, w10, #2, ge
1bf3a8: mov w9, #0x7ffffe
1bf3ac: ccmp w8, w9, #0, hi
1bf3b0: b.hi #0x1bf44c
1bf3b4: stp s1, s0, [sp, #0x68]
1bf3b8: b #0x1bf450
1bf3bc: adrp x0, #0x75ac000
1bf3c0: add x0, x0, #0x3f8
1bf3c4: bl #0x65eda8
1bf3c8: cbz w0, #0x1bf028
1bf3cc: adrp x0, #0x75a9000
1bf3d0: add x0, x0, #0x760
1bf3d4: bl #0x1269d0
1bf3d8: nop 
1bf3dc: adr x0, #0x137910
1bf3e0: adrp x1, #0x75a9000
1bf3e4: add x1, x1, #0x760
1bf3e8: adrp x2, #0x63e5000
1bf3ec: add x2, x2, #0x160
1bf3f0: bl #0x67f620
1bf3f4: adrp x0, #0x75ac000
1bf3f8: add x0, x0, #0x3f8
1bf3fc: bl #0x65eed8
1bf400: b #0x1bf028
1bf404: adrp x0, #0x75ac000
1bf408: add x0, x0, #0x3f8
1bf40c: bl #0x65eda8
1bf410: cbz w0, #0x1bf030
1bf414: adrp x0, #0x75a9000
1bf418: add x0, x0, #0x760
1bf41c: bl #0x1269d0
1bf420: nop 
1bf424: adr x0, #0x137910
1bf428: adrp x1, #0x75a9000
1bf42c: add x1, x1, #0x760
1bf430: adrp x2, #0x63e5000
1bf434: add x2, x2, #0x160
1bf438: bl #0x67f620
1bf43c: adrp x0, #0x75ac000
1bf440: add x0, x0, #0x3f8
1bf444: bl #0x65eed8
1bf448: b #0x1bf030
1bf44c: str s2, [sp, #0x68]
1bf450: ldr w8, [sp, #0x28]
1bf454: str xzr, [sp, #0x30]
1bf458: cmp w27, w8
1bf45c: csel w8, wzr, w28, ne
1bf460: cmp w8, #1
1bf464: b.ne #0x1bf48c
1bf468: fmov s0, s8
1bf46c: fmov s1, s10
1bf470: add x8, sp, #0x30
1bf474: add x0, sp, #0x38
1bf478: add x1, sp, #0x30
1bf47c: orr x2, x8, #4
1bf480: bl #0x1bf7ac
1bf484: tbnz w0, #0, #0x1bf50c
1bf488: b #0x1bf52c
1bf48c: tbz w26, #0, #0x1bf4e4
1bf490: adrp x21, #0x6469000
1bf494: fmov s0, s11
1bf498: fmov s1, s12
1bf49c: ldr w8, [x21, #0x3e8]
1bf4a0: fmov s2, s10
1bf4a4: add x2, sp, #0x38
1bf4a8: ldp w9, w10, [sp, #0x20]
1bf4ac: str w8, [sp, #0x2c]
1bf4b0: add x8, sp, #0x30
1bf4b4: add x3, sp, #0x2c
1bf4b8: add x4, sp, #0x30
1bf4bc: orr x5, x8, #4
1bf4c0: cmp w10, #0
1bf4c4: cset w0, ne
1bf4c8: cmp w9, #0
1bf4cc: cset w1, ne
1bf4d0: bl #0x1bf928
1bf4d4: tbz w0, #0, #0x1bf4e4
1bf4d8: ldr w8, [sp, #0x2c]
1bf4dc: str w8, [x21, #0x3e8]
1bf4e0: b #0x1bf50c
1bf4e4: tbz w25, #0, #0x1bf52c
1bf4e8: fmov s0, s11
1bf4ec: fmov s1, s12
1bf4f0: add x8, sp, #0x30
1bf4f4: fmov s2, s10
1bf4f8: add x0, sp, #0x38
1bf4fc: add x1, sp, #0x30
1bf500: orr x2, x8, #4
1bf504: bl #0x1bfbe8
1bf508: tbz w0, #0, #0x1bf52c
1bf50c: ldrh w21, [x20, #0x166c]
1bf510: mov x0, x20
1bf514: mov w2, #8
1bf518: add x1, x21, x19
1bf51c: bl #0x13955c
1bf520: tbz w0, #0, #0x1bf52c
1bf524: ldr x8, [sp, #0x30]
1bf528: str x8, [x21, x19]
1bf52c: ldr x8, [x24, #0x28]
1bf530: ldur x9, [x29, #-0x50]
1bf534: cmp x8, x9
1bf538: b.ne #0x1bf598
1bf53c: ldp x20, x19, [sp, #0x110]
1bf540: ldp x22, x21, [sp, #0x100]
1bf544: ldp x24, x23, [sp, #0xf0]
1bf548: ldp x26, x25, [sp, #0xe0]
1bf54c: ldp x28, x27, [sp, #0xd0]
1bf550: ldp x29, x30, [sp, #0xc0]
1bf554: ldp d9, d8, [sp, #0xb0]
1bf558: ldp d11, d10, [sp, #0xa0]
1bf55c: ldp d13, d12, [sp, #0x90]
1bf560: ldp d15, d14, [sp, #0x80]
1bf564: add sp, sp, #0x120
1bf568: ret 
1bf56c: b #0x1bf570
1bf570: ldr x8, [x24, #0x28]
1bf574: ldur x9, [x29, #-0x50]
1bf578: mov x19, x0
1bf57c: cmp x8, x9
1bf580: b.ne #0x1bf598
1bf584: adrp x0, #0x75ac000
1bf588: add x0, x0, #0x3f8
1bf58c: bl #0x65ef80
1bf590: mov x0, x19
1bf594: bl #0x67b74c
1bf598: bl #0x67f680

FUNCTION 0x1bf59c
1bf59c: stp x29, x30, [sp, #-0x20]!
1bf5a0: str x19, [sp, #0x10]
1bf5a4: mov x29, sp
1bf5a8: adrp x8, #0x75e1000
1bf5ac: add x8, x8, #0x7f8
1bf5b0: mov x19, x1
1bf5b4: ldar x8, [x8]
1bf5b8: cbz x8, #0x1bf5c4
1bf5bc: mov x1, x19
1bf5c0: blr x8
1bf5c4: cbz x19, #0x1bf610
1bf5c8: adrp x8, #0x75e1000
1bf5cc: ldrb w8, [x8, #0x800]
1bf5d0: tbnz w8, #0, #0x1bf5e8
1bf5d4: adrp x8, #0x75e1000
1bf5d8: ldrb w8, [x8, #0x801]
1bf5dc: tbnz w8, #0, #0x1bf5e8
1bf5e0: mov x19, xzr
1bf5e4: b #0x1bf610
1bf5e8: bl #0x639800
1bf5ec: mov x8, #0x34db
1bf5f0: movk x8, #0xd7b6, lsl #16
1bf5f4: movk x8, #0xde82, lsl #32
1bf5f8: movk x8, #0x431b, lsl #48
1bf5fc: smulh x8, x0, x8
1bf600: asr x9, x8, #0x12
1bf604: add x8, x9, x8, lsr #63
1bf608: adrp x9, #0x75e1000
1bf60c: str x8, [x9, #0x808]
1bf610: adrp x8, #0x75e1000
1bf614: add x8, x8, #0x7a0
1bf618: stlr x19, [x8]
1bf61c: ldr x19, [sp, #0x10]
1bf620: ldp x29, x30, [sp], #0x20
1bf624: ret 

FUNCTION 0x1bf628
1bf628: str d8, [sp, #-0x30]!
1bf62c: stp x29, x30, [sp, #0x10]
1bf630: stp x20, x19, [sp, #0x20]
1bf634: add x29, sp, #0x10
1bf638: cbz x0, #0x1bf6f0
1bf63c: fmov s8, s0
1bf640: fabs s0, s0
1bf644: mov w8, #0x7f800000
1bf648: fmov s1, w8
1bf64c: fcmp s0, s1
1bf650: b.eq #0x1bf6f0
1bf654: b.vs #0x1bf6f0
1bf658: adrp x20, #0x75ac000
1bf65c: add x20, x20, #0x3f8
1bf660: mov x19, x0
1bf664: ldarb w8, [x20]
1bf668: tbz w8, #0, #0x1bf700
1bf66c: ldarb w8, [x20]
1bf670: tbz w8, #0, #0x1bf748
1bf674: adrp x0, #0x75a9000
1bf678: add x0, x0, #0x7a8
1bf67c: mov w2, #4
1bf680: ldrh w20, [x0, #0x1652]
1bf684: add x1, x20, x19
1bf688: bl #0x139354
1bf68c: tbz w0, #0, #0x1bf6f0
1bf690: ldr w8, [x20, x19]
1bf694: cbz w8, #0x1bf6f0
1bf698: movi d0, #0000000000000000
1bf69c: fcmp s8, #0.0
1bf6a0: adrp x9, #0x75e1000
1bf6a4: adrp x10, #0x75e1000
1bf6a8: fcsel s0, s0, s8, mi
1bf6ac: str s0, [x9, #0x810]
1bf6b0: adrp x9, #0x75e1000
1bf6b4: str w8, [x10, #0x814]
1bf6b8: str x19, [x9, #0x818]
1bf6bc: bl #0x639800
1bf6c0: mov x8, #0x34db
1bf6c4: movk x8, #0xd7b6, lsl #16
1bf6c8: movk x8, #0xde82, lsl #32
1bf6cc: movk x8, #0x431b, lsl #48
1bf6d0: smulh x8, x0, x8
1bf6d4: asr x9, x8, #0x12
1bf6d8: add x8, x9, x8, lsr #63
1bf6dc: adrp x9, #0x75e1000
1bf6e0: str x8, [x9, #0x808]
1bf6e4: adrp x8, #0x75e1000
1bf6e8: add x8, x8, #0x7a0
1bf6ec: stlr x19, [x8]
1bf6f0: ldp x20, x19, [sp, #0x20]
1bf6f4: ldp x29, x30, [sp, #0x10]
1bf6f8: ldr d8, [sp], #0x30
1bf6fc: ret 
1bf700: adrp x0, #0x75ac000
1bf704: add x0, x0, #0x3f8
1bf708: bl #0x65eda8
1bf70c: cbz w0, #0x1bf66c
1bf710: adrp x0, #0x75a9000
1bf714: add x0, x0, #0x760
1bf718: bl #0x1269d0
1bf71c: nop 
1bf720: adr x0, #0x137910
1bf724: adrp x1, #0x75a9000
1bf728: add x1, x1, #0x760
1bf72c: adrp x2, #0x63e5000
1bf730: add x2, x2, #0x160
1bf734: bl #0x67f620
1bf738: adrp x0, #0x75ac000
1bf73c: add x0, x0, #0x3f8
1bf740: bl #0x65eed8
1bf744: b #0x1bf66c
1bf748: adrp x0, #0x75ac000
1bf74c: add x0, x0, #0x3f8
1bf750: bl #0x65eda8
1bf754: cbz w0, #0x1bf674
1bf758: adrp x0, #0x75a9000
1bf75c: add x0, x0, #0x760
1bf760: bl #0x1269d0
1bf764: nop 
1bf768: adr x0, #0x137910
1bf76c: adrp x1, #0x75a9000
1bf770: add x1, x1, #0x760
1bf774: adrp x2, #0x63e5000
1bf778: add x2, x2, #0x160
1bf77c: bl #0x67f620
1bf780: adrp x0, #0x75ac000
1bf784: add x0, x0, #0x3f8
1bf788: bl #0x65eed8
1bf78c: b #0x1bf674
1bf790: b #0x1bf794
1bf794: mov x19, x0
1bf798: adrp x0, #0x75ac000
1bf79c: add x0, x0, #0x3f8
1bf7a0: bl #0x65ef80
1bf7a4: mov x0, x19
1bf7a8: bl #0x67b74c
