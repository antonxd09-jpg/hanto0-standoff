extern unsigned long long g_75e17a0;
extern unsigned long g_75e1808;

void sub_1bf59c(unsigned long a0, unsigned long long a1)
{
    unsigned long long v2;  // x19
    uint128_t v3;  // x0
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    v2 = a1;
    /* unsupported instruction */;
    if (*(long long *)0x75e17f8)
        (*(long long *)0x75e17f8)();
    if (v2)
    {
        if (!(*0x75e1800 & 1) && !(*0x75e1801 & 1))
        {
            v2 = 0;
        }
        else
        {
            v3 = sub_639800();
            g_75e1808 = (unsigned long long)((int128_t)(v3 * 4835703278458516699) >> 82) + (unsigned long long)(v3 * 4835703278458516699 >> 127);
        }
    }
    /* unsupported instruction */;
    g_75e17a0 = v2;
    return;
}
