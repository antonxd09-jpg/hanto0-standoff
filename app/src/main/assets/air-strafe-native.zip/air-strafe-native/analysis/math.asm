
FUNCTION 0x1bf7ac
1bf7ac: ldrb w8, [x0]
1bf7b0: cbnz w8, #0x1bf870
1bf7b4: ldrb w8, [x0, #1]
1bf7b8: cbz w8, #0x1bf870
1bf7bc: fabs s2, s0
1bf7c0: mov w8, #0x7f800000
1bf7c4: fmov s3, w8
1bf7c8: mov w8, wzr
1bf7cc: fcmp s2, s3
1bf7d0: b.eq #0x1bf920
1bf7d4: b.vs #0x1bf920
1bf7d8: fabs s2, s1
1bf7dc: mov w9, #0x7f800000
1bf7e0: fmov s3, w9
1bf7e4: fcmp s2, s3
1bf7e8: b.eq #0x1bf920
1bf7ec: b.vs #0x1bf920
1bf7f0: ldr s2, [x0, #0xc]
1bf7f4: mov w10, #0x7e
1bf7f8: fmov w8, s2
1bf7fc: and w9, w8, #0x7fffffff
1bf800: cmp w8, #0
1bf804: sub w8, w8, #1
1bf808: sub w9, w9, #0x800, lsl #12
1bf80c: lsr w9, w9, #0x18
1bf810: ccmp w9, w10, #2, ge
1bf814: mov w9, #0x7ffffe
1bf818: ccmp w8, w9, #0, hi
1bf81c: mov w8, wzr
1bf820: b.hi #0x1bf920
1bf824: ldp s5, s3, [x0, #4]
1bf828: mov w9, #0x7f800000
1bf82c: fmov s7, w9
1bf830: fmul s4, s3, s3
1bf834: fmadd s4, s5, s5, s4
1bf838: fsqrt s4, s4
1bf83c: fabs s6, s4
1bf840: fcmp s6, s7
1bf844: b.eq #0x1bf920
1bf848: b.vs #0x1bf920
1bf84c: movi d6, #0000000000000000
1bf850: fcmp s0, #0.0
1bf854: fcsel s0, s6, s0, mi
1bf858: fmov s6, #0.50000000
1bf85c: fmadd s0, s2, s6, s0
1bf860: fcmp s4, s0
1bf864: b.gt #0x1bf874
1bf868: mov w0, wzr
1bf86c: ret 
1bf870: b #0x1c1388
1bf874: sub sp, sp, #0x40
1bf878: stp d9, d8, [sp, #0x10]
1bf87c: stp x29, x30, [sp, #0x20]
1bf880: stp x20, x19, [sp, #0x30]
1bf884: add x29, sp, #0x20
1bf888: fneg s0, s5
1bf88c: mov w8, #0xfa35
1bf890: add x0, sp, #0xc
1bf894: movk w8, #0x3c8e, lsl #16
1bf898: mov x19, x1
1bf89c: add x1, sp, #8
1bf8a0: mov x20, x2
1bf8a4: fdiv s8, s0, s4
1bf8a8: fneg s0, s3
1bf8ac: fdiv s9, s0, s4
1bf8b0: fmov s0, w8
1bf8b4: fmul s0, s1, s0
1bf8b8: bl #0x67f8c0
1bf8bc: ldp s1, s0, [sp, #8]
1bf8c0: mov w8, #0x7f800000
1bf8c4: fnmul s2, s9, s0
1bf8c8: fmul s3, s1, s9
1bf8cc: fmadd s1, s8, s1, s2
1bf8d0: fmadd s0, s8, s0, s3
1bf8d4: fmov s2, w8
1bf8d8: str s1, [x19]
1bf8dc: str s0, [x20]
1bf8e0: ldr s1, [x19]
1bf8e4: fabs s1, s1
1bf8e8: fcmp s1, s2
1bf8ec: mov w8, wzr
1bf8f0: ldp x20, x19, [sp, #0x30]
1bf8f4: ldp x29, x30, [sp, #0x20]
1bf8f8: ldp d9, d8, [sp, #0x10]
1bf8fc: add sp, sp, #0x40
1bf900: b.eq #0x1bf920
1bf904: b.vs #0x1bf920
1bf908: fabs s0, s0
1bf90c: mov w8, #0x7f800000
1bf910: fmov s1, w8
1bf914: fcmp s0, s1
1bf918: cset w8, mi
1bf91c: csinc w8, w8, wzr, le
1bf920: mov w0, w8
1bf924: ret 

FUNCTION 0x1bf928
1bf928: sub sp, sp, #0xa0
1bf92c: str d14, [sp, #0x30]
1bf930: stp d13, d12, [sp, #0x38]
1bf934: stp d11, d10, [sp, #0x48]
1bf938: stp d9, d8, [sp, #0x58]
1bf93c: stp x29, x30, [sp, #0x68]
1bf940: str x23, [sp, #0x78]
1bf944: stp x22, x21, [sp, #0x80]
1bf948: stp x20, x19, [sp, #0x90]
1bf94c: add x29, sp, #0x68
1bf950: fabs s3, s0
1bf954: mov w8, #0x7f800000
1bf958: mrs x21, tpidr_el0
1bf95c: fmov s4, w8
1bf960: ldr x8, [x21, #0x28]
1bf964: mov w0, wzr
1bf968: str x8, [sp, #0x28]
1bf96c: fcmp s3, s4
1bf970: b.eq #0x1bfbac
1bf974: b.vs #0x1bfbac
1bf978: fabs s3, s1
1bf97c: mov w8, #0x7f800000
1bf980: fmov s4, w8
1bf984: fcmp s3, s4
1bf988: b.eq #0x1bfbac
1bf98c: b.vs #0x1bfbac
1bf990: fmul s3, s1, s1
1bf994: mov w8, #0xcccd
1bf998: mov w0, wzr
1bf99c: movk w8, #0x3d4c, lsl #16
1bf9a0: fmadd s3, s0, s0, s3
1bf9a4: fsqrt s12, s3
1bf9a8: fmov s3, w8
1bf9ac: fcmp s12, s3
1bf9b0: b.lt #0x1bfbac
1bf9b4: fabs s3, s2
1bf9b8: mov w8, #0x7f800000
1bf9bc: fmov s4, w8
1bf9c0: fcmp s3, s4
1bf9c4: b.eq #0x1bfbac
1bf9c8: b.vs #0x1bfbac
1bf9cc: mov w8, #0xfa35
1bf9d0: fmov s9, s0
1bf9d4: add x0, sp, #4
1bf9d8: movk w8, #0x3c8e, lsl #16
1bf9dc: mov x1, sp
1bf9e0: mov x19, x3
1bf9e4: fmov s0, w8
1bf9e8: mov x22, x5
1bf9ec: mov x23, x4
1bf9f0: fdiv s8, s1, s12
1bf9f4: mov x20, x2
1bf9f8: fmul s0, s2, s0
1bf9fc: bl #0x67f8c0
1bfa00: fmov s0, #-0.25000000
1bfa04: ldrb w9, [x20]
1bfa08: mov x8, x20
1bfa0c: mov w0, wzr
1bfa10: fcmp s8, s0
1bfa14: cset w20, mi
1bfa18: cbnz w9, #0x1bfbac
1bfa1c: ldrb w9, [x8, #1]
1bfa20: cbz w9, #0x1bfbac
1bfa24: fdiv s0, s9, s12
1bfa28: ldp s14, s13, [sp]
1bfa2c: fmov s3, #-0.25000000
1bfa30: ldur q4, [x8, #0xc]
1bfa34: str xzr, [sp, #8]
1bfa38: fmul s1, s8, s13
1bfa3c: fmul s2, s8, s14
1bfa40: str q4, [sp, #0x10]
1bfa44: fcmp s8, s3
1bfa48: ldp s10, s8, [x8, #4]
1bfa4c: str wzr, [sp, #0x18]
1bfa50: fmadd s11, s0, s14, s1
1bfa54: fmsub s9, s0, s13, s2
1bfa58: b.pl #0x1bfafc
1bfa5c: fmov s0, s11
1bfa60: fmov s1, s9
1bfa64: mov x2, x19
1bfa68: fmov s2, s10
1bfa6c: fmov s3, s8
1bfa70: add x0, sp, #0x10
1bfa74: add x3, sp, #8
1bfa78: mov w1, #1
1bfa7c: bl #0x1c1650
1bfa80: tbz w0, #0, #0x1bfba8
1bfa84: ldp s2, s0, [sp, #8]
1bfa88: fmov s3, #1.00000000
1bfa8c: mov w8, #0x7f800000
1bfa90: mov w0, wzr
1bfa94: fnmul s1, s0, s13
1bfa98: fmul s0, s14, s0
1bfa9c: fcmp s12, s3
1bfaa0: fmadd s1, s2, s14, s1
1bfaa4: fmadd s0, s2, s13, s0
1bfaa8: fcsel s2, s3, s12, gt
1bfaac: str s1, [x23]
1bfab0: str s0, [x22]
1bfab4: ldr s0, [x23]
1bfab8: fmul s0, s2, s0
1bfabc: str s0, [x23]
1bfac0: ldr s0, [x22]
1bfac4: fmul s0, s2, s0
1bfac8: fmov s2, w8
1bfacc: str s0, [x22]
1bfad0: ldr s1, [x23]
1bfad4: fabs s1, s1
1bfad8: fcmp s1, s2
1bfadc: b.eq #0x1bfbac
1bfae0: b.vs #0x1bfbac
1bfae4: fabs s0, s0
1bfae8: fmov s1, w8
1bfaec: fcmp s0, s1
1bfaf0: cset w8, mi
1bfaf4: csinc w0, w8, wzr, le
1bfaf8: b #0x1bfbac
1bfafc: fmul s0, s8, s8
1bfb00: mov w8, #0xb717
1bfb04: fmov s2, #1.00000000
1bfb08: movk w8, #0x38d1, lsl #16
1bfb0c: fmadd s0, s10, s10, s0
1bfb10: fsqrt s1, s0
1bfb14: fmov s0, w8
1bfb18: fcmp s1, s0
1bfb1c: fmov s0, #1.00000000
1bfb20: b.le #0x1bfb30
1bfb24: fmul s2, s9, s8
1bfb28: fmadd s2, s11, s10, s2
1bfb2c: fdiv s2, s2, s1
1bfb30: fcmp s2, s0
1bfb34: fmov s1, #-1.00000000
1bfb38: fcsel s0, s0, s2, gt
1bfb3c: fcmp s2, s1
1bfb40: fcsel s0, s1, s0, mi
1bfb44: bl #0x67f970
1bfb48: mov w8, #0xb8c2
1bfb4c: add x0, sp, #0x10
1bfb50: movk w8, #0x3db2, lsl #16
1bfb54: fmov s1, w8
1bfb58: fcmp s0, s1
1bfb5c: b.le #0x1bfb84
1bfb60: fmov s0, s11
1bfb64: fmov s1, s9
1bfb68: add x2, sp, #8
1bfb6c: fmov s2, s10
1bfb70: fmov s3, s8
1bfb74: mov x1, x19
1bfb78: bl #0x1c18f4
1bfb7c: tbz w0, #0, #0x1bfba8
1bfb80: b #0x1bfa84
1bfb84: fmov s0, s11
1bfb88: fmov s1, s9
1bfb8c: add x3, sp, #8
1bfb90: fmov s2, s10
1bfb94: fmov s3, s8
1bfb98: mov w1, w20
1bfb9c: mov x2, x19
1bfba0: bl #0x1c1650
1bfba4: tbnz w0, #0, #0x1bfa84
1bfba8: mov w0, wzr
1bfbac: ldr x8, [x21, #0x28]
1bfbb0: ldr x9, [sp, #0x28]
1bfbb4: cmp x8, x9
1bfbb8: b.ne #0x1bfbe4
1bfbbc: ldp x20, x19, [sp, #0x90]
1bfbc0: ldr x23, [sp, #0x78]
1bfbc4: ldp x22, x21, [sp, #0x80]
1bfbc8: ldr d14, [sp, #0x30]
1bfbcc: ldp x29, x30, [sp, #0x68]
1bfbd0: ldp d9, d8, [sp, #0x58]
1bfbd4: ldp d11, d10, [sp, #0x48]
1bfbd8: ldp d13, d12, [sp, #0x38]
1bfbdc: add sp, sp, #0xa0
1bfbe0: ret 
1bfbe4: bl #0x67f680

FUNCTION 0x1bfbe8
1bfbe8: sub sp, sp, #0x70
1bfbec: stp d11, d10, [sp, #0x20]
1bfbf0: stp d9, d8, [sp, #0x30]
1bfbf4: stp x29, x30, [sp, #0x40]
1bfbf8: str x21, [sp, #0x50]
1bfbfc: stp x20, x19, [sp, #0x60]
1bfc00: add x29, sp, #0x40
1bfc04: fabs s3, s0
1bfc08: mov w9, #0x7f800000
1bfc0c: mrs x19, tpidr_el0
1bfc10: fmov s4, w9
1bfc14: ldr x9, [x19, #0x28]
1bfc18: mov x8, x0
1bfc1c: mov w0, wzr
1bfc20: str x9, [sp, #0x18]
1bfc24: fcmp s3, s4
1bfc28: b.eq #0x1bfe04
1bfc2c: b.vs #0x1bfe04
1bfc30: fabs s3, s1
1bfc34: mov w9, #0x7f800000
1bfc38: fmov s4, w9
1bfc3c: fcmp s3, s4
1bfc40: b.eq #0x1bfe04
1bfc44: b.vs #0x1bfe04
1bfc48: fmul s3, s1, s1
1bfc4c: mov w9, #0xcccd
1bfc50: movk w9, #0x3d4c, lsl #16
1bfc54: fmov s4, w9
1bfc58: fmadd s3, s0, s0, s3
1bfc5c: fsqrt s3, s3
1bfc60: fcmp s3, s4
1bfc64: b.pl #0x1bfe00
1bfc68: ldrb w9, [x8]
1bfc6c: str xzr, [sp, #0x10]
1bfc70: cbnz w9, #0x1bfda0
1bfc74: ldrb w9, [x8, #1]
1bfc78: cbz w9, #0x1bfda0
1bfc7c: fabs s3, s2
1bfc80: mov w9, #0x7f800000
1bfc84: mov w0, wzr
1bfc88: fmov s4, w9
1bfc8c: fcmp s3, s4
1bfc90: b.eq #0x1bfe04
1bfc94: b.vs #0x1bfe04
1bfc98: ldr s3, [x8, #0xc]
1bfc9c: mov w11, #0x7e
1bfca0: mov w0, wzr
1bfca4: fmov w9, s3
1bfca8: and w10, w9, #0x7fffffff
1bfcac: cmp w9, #0
1bfcb0: sub w9, w9, #1
1bfcb4: sub w10, w10, #0x800, lsl #12
1bfcb8: lsr w10, w10, #0x18
1bfcbc: ccmp w10, w11, #2, ge
1bfcc0: mov w10, #0x7ffffe
1bfcc4: ccmp w9, w10, #0, hi
1bfcc8: b.hi #0x1bfe04
1bfccc: ldp s6, s4, [x8, #4]
1bfcd0: mov w8, #0x7f800000
1bfcd4: fmov s16, w8
1bfcd8: fmul s5, s4, s4
1bfcdc: fmadd s5, s6, s6, s5
1bfce0: fsqrt s5, s5
1bfce4: fabs s7, s5
1bfce8: fcmp s7, s16
1bfcec: b.eq #0x1bfe04
1bfcf0: b.vs #0x1bfe04
1bfcf4: movi d7, #0000000000000000
1bfcf8: fmov s16, #0.50000000
1bfcfc: fmadd s3, s3, s16, s7
1bfd00: fcmp s5, s3
1bfd04: b.le #0x1bfe04
1bfd08: fneg s3, s6
1bfd0c: mov w8, #0xfa35
1bfd10: fmov s10, s0
1bfd14: movk w8, #0x3c8e, lsl #16
1bfd18: add x0, sp, #0xc
1bfd1c: mov x20, x1
1bfd20: add x1, sp, #8
1bfd24: mov x21, x2
1bfd28: fmov s11, s1
1bfd2c: fdiv s8, s3, s5
1bfd30: fneg s3, s4
1bfd34: fdiv s9, s3, s5
1bfd38: fmov s3, w8
1bfd3c: fmul s2, s2, s3
1bfd40: fmov s0, s2
1bfd44: bl #0x67f8c0
1bfd48: ldp s4, s2, [sp, #8]
1bfd4c: mov w10, #0x7f800000
1bfd50: fmov s6, w10
1bfd54: mov w0, wzr
1bfd58: fnmul s0, s9, s2
1bfd5c: fmadd s0, s8, s4, s0
1bfd60: fabs s5, s0
1bfd64: fcmp s5, s6
1bfd68: b.eq #0x1bfe04
1bfd6c: b.vs #0x1bfe04
1bfd70: fmul s4, s4, s9
1bfd74: fmov s5, w10
1bfd78: fmov s3, s11
1bfd7c: fmov s1, s10
1bfd80: mov x9, x20
1bfd84: mov x8, x21
1bfd88: fmadd s2, s8, s2, s4
1bfd8c: fabs s4, s2
1bfd90: fcmp s4, s5
1bfd94: b.mi #0x1bfde0
1bfd98: b.gt #0x1bfde0
1bfd9c: b #0x1bfe04
1bfda0: fmov s8, s1
1bfda4: fmov s9, s0
1bfda8: mov x20, x1
1bfdac: movi d0, #0000000000000000
1bfdb0: fmov s1, s2
1bfdb4: mov x21, x2
1bfdb8: add x1, sp, #0x14
1bfdbc: add x2, sp, #0x10
1bfdc0: mov x0, x8
1bfdc4: bl #0x1c1388
1bfdc8: tbz w0, #0, #0x1bfe00
1bfdcc: fmov s1, s9
1bfdd0: fmov s3, s8
1bfdd4: mov x8, x21
1bfdd8: ldp s2, s0, [sp, #0x10]
1bfddc: mov x9, x20
1bfde0: fcmp s3, #0.0
1bfde4: b.ne #0x1bfe30
1bfde8: fcmp s1, #0.0
1bfdec: b.ne #0x1bfe30
1bfdf0: fcmp s0, #0.0
1bfdf4: b.ne #0x1bfe30
1bfdf8: fcmp s2, #0.0
1bfdfc: b.ne #0x1bfe30
1bfe00: mov w0, wzr
1bfe04: ldr x8, [x19, #0x28]
1bfe08: ldr x9, [sp, #0x18]
1bfe0c: cmp x8, x9
1bfe10: b.ne #0x1bfe40
1bfe14: ldp x20, x19, [sp, #0x60]
1bfe18: ldr x21, [sp, #0x50]
1bfe1c: ldp x29, x30, [sp, #0x40]
1bfe20: ldp d9, d8, [sp, #0x30]
1bfe24: ldp d11, d10, [sp, #0x20]
1bfe28: add sp, sp, #0x70
1bfe2c: ret 
1bfe30: mov w0, #1
1bfe34: str s0, [x9]
1bfe38: str s2, [x8]
1bfe3c: b #0x1bfe04
1bfe40: bl #0x67f680
