extern unsigned long long g_75e17a0;
extern unsigned long g_75e1808;
extern float g_75e1810;
extern unsigned int g_75e1814;
extern unsigned long long g_75e1818;

float sub_1bf628(unsigned long long a0, float a1)
{
    float v2;  // s8
    float v3;  // s0
    unsigned long long v4;  // 4102
    unsigned int v5;  // w8
    unsigned long long v6;  // 4130
    uint128_t v7;  // x0
    char *v0;  // [bp-0x20]
    char v1;  // [bp+0x0]

    v0 = &v1;
    if (!a0)
        return a1;
    v2 = a1;
    v3 = fabsf(a1);
    if (v3 == inff)
        return v3;
    v4 = arm64g_calculate_condition(96, (((((char)(CmpF(__float_as_int(v3), inff)) >> 5 & 3 | v3 < inff) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v3)) * 0x10000000, 0, 0);
    if (v4 & 1)
        return v3;
    /* unsupported instruction */;
    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
    {
        sub_1269d0(123377504);
        6813216();
        sub_65eed8(123388920);
    }
    /* unsupported instruction */;
    if (!(*0x75ac3f8 & 1) && sub_65eda8(123388920))
    {
        sub_1269d0(123377504);
        6813216();
        sub_65eed8(123388920);
    }
    if (!(sub_139354(123377576, *(short *)0x75aadfa + a0, 4) & 1))
        return v3;
    v5 = *(int *)(*(short *)0x75aadfa + a0);
    if (!v5)
        return v3;
    v6 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v2), 0.0f)) >> 5 & 3 | v2 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
    if (v6 & 1)
        v2 = 0;
    g_75e1810 = v2;
    g_75e1814 = v5;
    g_75e1818 = a0;
    v7 = sub_639800();
    g_75e1808 = (unsigned long long)((int128_t)(v7 * 4835703278458516699) >> 82) + (unsigned long long)(v7 * 4835703278458516699 >> 127);
    /* unsupported instruction */;
    g_75e17a0 = a0;
    return v2;
}
