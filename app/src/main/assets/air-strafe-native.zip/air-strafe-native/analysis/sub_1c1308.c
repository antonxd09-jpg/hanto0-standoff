extern unsigned int g_64693e4;
extern unsigned long long g_75e17a0;
extern char g_75e1800;
extern char g_75e1801;

char * sub_1c1308(char *a0)
{
    float v0;  // s0
    unsigned int v1;  // w10
    float v2;  // s1
    unsigned long long v3;  // 4102
    float v4;  // s1
    unsigned long long v5;  // 4130
    unsigned long long v6;  // 4129
    float v7;  // s0

    /* unsupported instruction */;
    g_75e1800 = *a0;
    /* unsupported instruction */;
    g_75e1801 = a0[12];
    v0 = *(float *)&a0[8];
    v1 = 0x3f400000;
    v2 = fabsf(v0);
    if (v2 != inff)
    {
        v3 = arm64g_calculate_condition(96, (((((char)(CmpF(__float_as_int(v2), inff)) >> 5 & 3 | v2 < inff) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v2)) * 0x10000000, 0, 0);
        if (!(v3 & 1))
        {
            v4 = 1.0f;
            v5 = arm64g_calculate_condition(192, (((((char)(CmpF(__float_as_int(v0), 1.0f)) >> 5 & 3 | v0 < 1.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v0)) * 0x10000000, 0, 0);
            if (!(v5 & 1))
                v4 = v0;
            v6 = arm64g_calculate_condition(64, (((((char)(CmpF(__float_as_int(v0), 0.0f)) >> 5 & 3 | v0 < 0.0f) ^ 1) * 0x4000000000000000 - 1 >> 61) + 1 - isnan(v0)) * 0x10000000, 0, 0);
            if (v6 & 1)
                v7 = 0;
            else
                v7 = v4;
            v1 = __float_as_int(v7);
        }
    }
    g_64693e4 = v1;
    if (!g_75e1800 && !g_75e1801)
    {
        /* unsupported instruction */;
        g_75e17a0 = 0;
        return a0;
    }
    return a0;
}
