#!/usr/bin/env python3
import ctypes,ctypes.util,json,pathlib,random,struct,sys,math,hashlib
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
root=pathlib.Path(__file__).resolve().parent;source=pathlib.Path(sys.argv[1]);artifact=root/'libair_strafe_math.so'
libm=ctypes.CDLL(ctypes.util.find_library('m'))
for name,n in [('acosf',1),('atan2f',2)]:
 fun=getattr(libm,name);fun.argtypes=[ctypes.c_float]*n;fun.restype=ctypes.c_float
libm.sincosf.argtypes=[ctypes.c_float,ctypes.POINTER(ctypes.c_float),ctypes.POINTER(ctypes.c_float)]
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def number(x):return struct.unpack('<f',struct.pack('<I',x&0xffffffff))[0]
def setup(path,bias):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 with path.open('rb') as f:
  e=ELFFile(f);segs=[s for s in e.iter_segments() if s['p_type']=='PT_LOAD'];lo=min(s['p_vaddr'] for s in segs)&~4095;hi=max(s['p_vaddr']+s['p_memsz'] for s in segs);u.mem_map(bias+lo,((hi-lo+4095)//4096)*4096)
  for s in segs:u.mem_write(bias+s['p_vaddr'],s.data())
  rel=e.get_section_by_name('.rela.dyn')
  if rel:
   for r in rel.iter_relocations():
    if r['r_info_type']==1027:u.mem_write(bias+r['r_offset'],struct.pack('<Q',bias+r['r_addend']))
  syms={}
  for name in ['.symtab','.dynsym']:
   s=e.get_section_by_name(name)
   if s:
    for x in s.iter_symbols():
     if x['st_value']:syms[x.name]=bias+x['st_value']
  imports={};rel=e.get_section_by_name('.rela.plt');plt=e.get_section_by_name('.plt');dyn=e.get_section_by_name('.dynsym')
  for i,r in enumerate(rel.iter_relocations()):imports[bias+plt['sh_addr']+32+16*i]=dyn.get_symbol(r['r_info_sym']).name
 u.mem_map(0x10000000,0x20000);u.mem_map(0x20000000,0x1000);u.reg_write(UC_ARM64_REG_TPIDR_EL0,0x20000000)
 def hook(uc,addr,size,data):
  name=imports[addr]
  if name=='__stack_chk_fail':raise AssertionError('Original stack canary failed')
  x=number(uc.reg_read(UC_ARM64_REG_S0))
  if name=='sincosf':
   s=ctypes.c_float();c=ctypes.c_float();libm.sincosf(x,ctypes.byref(s),ctypes.byref(c))
   uc.mem_write(uc.reg_read(UC_ARM64_REG_X0),struct.pack('<f',s.value));uc.mem_write(uc.reg_read(UC_ARM64_REG_X1),struct.pack('<f',c.value))
  elif name in ['acosf','atan2f']:
   args=[x]
   if name=='atan2f':args.append(number(uc.reg_read(UC_ARM64_REG_S1)))
   uc.reg_write(UC_ARM64_REG_S0,bits(getattr(libm,name)(*args)))
  else:raise AssertionError('Unexpected external call: '+name)
  uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30))
 for a,name in imports.items():
  if name in ['sincosf','acosf','atan2f','__stack_chk_fail']:u.hook_add(UC_HOOK_CODE,hook,begin=a,end=a)
 return u,syms
original,_=setup(source,0);rebuilt,syms=setup(artifact,0x40000000)
stop=0x1001f000;frame_addr=0x10000000;state_addr=0x10001000;outx=0x10002000;outy=outx+4
entries={'primary':0x1bf928,'secondary':0x1bfbe8,'reference':0x1bf7ac}
def run(u,which,frame,inputs,state,is_rebuilt):
 u.mem_write(frame_addr,frame);u.mem_write(state_addr,struct.pack('<i',state));u.mem_write(outx,bytes.fromhex('0000a03f000020c0'))
 if is_rebuilt:
  addr=syms['air_'+which]
  regs=[frame_addr,state_addr,outx,outy] if which=='primary' else [frame_addr,outx,outy]
 else:
  addr=entries[which];regs=[0,0,frame_addr,state_addr,outx,outy] if which=='primary' else [frame_addr,outx,outy]
 for i,v in enumerate(regs):u.reg_write(UC_ARM64_REG_X0+i,v)
 for i,v in enumerate(inputs):u.reg_write(UC_ARM64_REG_S0+i,bits(v))
 u.reg_write(UC_ARM64_REG_SP,0x1001e000);u.reg_write(UC_ARM64_REG_X30,stop)
 u.emu_start(addr,stop,count=200000)
 assert u.reg_read(UC_ARM64_REG_PC)==stop, ('Instruction budget reached',which)
 return (u.reg_read(UC_ARM64_REG_W0),bytes(u.mem_read(outx,8)),bytes(u.mem_read(state_addr,4)))
rng=random.Random(0xa711b4dd);counts={k:0 for k in entries};success={k:0 for k in entries}
for case in range(1200):
 flags=case%4
 floats=[rng.uniform(-450,450),rng.uniform(-450,450),rng.uniform(0.001,40),rng.uniform(0,400),rng.uniform(0,400),rng.uniform(0,1),rng.uniform(0,400),rng.uniform(0,30),rng.uniform(0,30),rng.uniform(0,30),rng.uniform(0,400),rng.uniform(0,400),rng.uniform(0,400)]
 if case<24:
  specials=[0.,-0.,1e-6,float('nan'),float('inf'),float('-inf')];floats[case%13]=specials[case%len(specials)]
 frame=bytes([flags&1,(flags>>1)&1,0,0])+struct.pack('<13f',*floats)
 inputs=[rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-720,720)]
 if case%3==0:inputs[0]=inputs[1]=0.
 state=rng.choice([-1,0,1])
 for which in entries:
  fp=inputs if which!='reference' else [rng.uniform(-5,400),inputs[2]]
  expected=run(original,which,frame,fp,state,False);actual=run(rebuilt,which,frame,fp,state,True)
  assert actual==expected, (case,which,expected,actual)
  counts[which]+=1;success[which]+=int(bool(actual[0]&1))
result={'status':'passed','cases':sum(counts.values()),'cases_by_entry':counts,'successful_output_cases':success,'comparison':'Exact return value, output float bytes, and direction-state bytes','original_addresses':{k:hex(v) for k,v in entries.items()},'binary_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'method':'Original ARM64 routines vs rebuilt ARM64 shared library including C++ entry wrappers, executed in Unicorn; both use the same host libm hooks','limits':['No Android device or game integration test','libm hooks test relocation/logic with a common math implementation, not Android-libm numerical identity','Frame semantics outside the extracted math component are not inferred']}
(root/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
