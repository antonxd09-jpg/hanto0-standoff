#include "air_strafe.h"
extern "C" unsigned int air_native_primary(int,int,const AirFrame*,int*,float*,float*,float,float,float);
extern "C" unsigned int air_native_secondary(const AirFrame*,float*,float*,float,float,float);
extern "C" unsigned int air_native_reference(const AirFrame*,float*,float*,float,float);
extern "C" unsigned int air_primary(const AirFrame* f,int* state,float x,float y,float yaw,float* out_x,float* out_y) {
 return air_native_primary(0,0,f,state,out_x,out_y,x,y,yaw);
}
extern "C" unsigned int air_secondary(const AirFrame* f,float x,float y,float yaw,float* out_x,float* out_y) {
 return air_native_secondary(f,out_x,out_y,x,y,yaw);
}
extern "C" unsigned int air_reference(const AirFrame* f,float speed,float yaw,float* out_x,float* out_y) {
 return air_native_reference(f,out_x,out_y,speed,yaw);
}
