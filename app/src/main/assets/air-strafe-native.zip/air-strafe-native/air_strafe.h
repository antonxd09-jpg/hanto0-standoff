#pragma once
// ARM64 native ABI; this header uses no runtime or standard-library facilities.
#ifdef __cplusplus
extern "C" {
#endif
// Original frame at SP+0x38 in function 0x1bef48. Slots retain source order.
// remaining[0..9] have not been assigned speculative engine-field names.
struct AirFrame {
 unsigned char flag_00;
 unsigned char flag_01;
 unsigned char reserved[2];
 float velocity_x;
 float velocity_y;
 float acceleration_step;
 float remaining[10];
};
// On false, output/state may still have been written, exactly as in the source.
unsigned int air_primary(const struct AirFrame*,int* direction_state,
                         float input_x,float input_y,float yaw_degrees,
                         float* output_x,float* output_y);
unsigned int air_secondary(const struct AirFrame*,float input_x,float input_y,
                           float yaw_degrees,float* output_x,float* output_y);
unsigned int air_reference(const struct AirFrame*,float reference_speed,
                           float yaw_degrees,float* output_x,float* output_y);
#ifdef __cplusplus
}
static_assert(sizeof(AirFrame)==56,"AirFrame ABI mismatch");
#endif
