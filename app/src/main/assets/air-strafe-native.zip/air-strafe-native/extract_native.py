#!/usr/bin/env python3
"""Lift the closed AirStrafe math component to relocatable AArch64 assembly.
Instruction bodies are preserved; only control-flow labels and imported calls change.
"""
import pathlib,json,re,sys,hashlib
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN
src=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
assert hashlib.sha256(src.read_bytes()).hexdigest()=='f8fccfbbc39e52bd5579ed87a6e232f39b6dfcfecf4644550cfea0c95e37b2db', 'Input build does not match the analyzed library'
with src.open('rb') as f:
 e=ELFFile(f);by={}
 for entry in e.get_dwarf_info().EH_CFI_entries():
  if hasattr(entry,'header') and 'initial_location' in entry.header:
   a=int(entry['initial_location']);by[a]={'address':a,'size':int(entry['address_range'])}
 t=e.get_section_by_name('.text');data=t.data();base=t['sh_addr'];md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
 imports={e.get_section_by_name('.plt')['sh_addr']+32+16*i:e.get_section_by_name('.dynsym').get_symbol(r['r_info_sym']).name for i,r in enumerate(e.get_section_by_name('.rela.plt').iter_relocations())}
 todo=[0x1bf7ac,0x1bf928,0x1bfbe8];functions={}
 while todo:
  a=todo.pop()
  if a in functions:continue
  r=by[a];ins=list(md.disasm(data[a-base:a-base+r['size']],a));functions[a]=ins
  assert sum(i.size for i in ins)==r['size']
  for i in ins:
   assert i.mnemonic not in ('adr','adrp'), 'Unexpected nonlocal data dependency'
   if i.mnemonic in ['b','bl']:
    target=int(i.op_str[1:],16)
    if not a<=target<a+r['size'] and target not in imports:todo.append(target)
 names={0x1bf7ac:'air_native_reference',0x1bf928:'air_native_primary',0x1bfbe8:'air_native_secondary'}
 names.update({a:f'air_math_{a:x}' for a in functions if a not in names})
 with (out/'air_math.S').open('w') as f:
  f.write('.text\n.p2align 2\n')
  for a,ins in sorted(functions.items()):
   name=names[a];f.write(f'\n.global {name}\n.hidden {name}\n.type {name}, %function\n{name}:\n')
   for i in ins:
    operands=i.op_str
    if i.mnemonic in ['b','bl']:
     dest=int(operands[1:],16);operands=imports[dest] if dest in imports else names.get(dest,f'.L_{dest:x}')
    elif i.mnemonic.startswith('b.') or i.mnemonic in ['cbz','cbnz','tbz','tbnz']:
     operands=re.sub(r'#0x([0-9a-f]+)$',lambda m:'.L_'+m[1],operands)
    f.write(f'.L_{i.address:x}:\n    {i.mnemonic} {operands}\n')
   f.write(f'.size {name}, .-{name}\n')
  f.write('.section .note.GNU-stack,"",%progbits\n')
 (out/'native_manifest.json').write_text(json.dumps([{'original_address':a,'size':by[a]['size'],'symbol':names[a]} for a in sorted(functions)],indent=2))
 print('Native math closure:',len(functions),'functions,',sum(by[a]['size'] for a in functions),'bytes')
