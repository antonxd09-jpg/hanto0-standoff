#!/usr/bin/env python3
import pathlib,subprocess,sys
import lief
root=pathlib.Path(__file__).resolve().parent;output=root/'libair_strafe_math.so'
subprocess.run([sys.executable,'-m','ziglang','c++','-target','aarch64-linux-android','-std=c++17','-O2','-fno-exceptions','-fno-rtti','-fno-stack-protector','-fPIC','-shared','-nostdlib',str(root/'air_strafe.cpp'),str(root/'air_math.S'),'-Wl,-soname,libair_strafe_math.so','-o',str(output)],check=True)
b=lief.parse(str(output));b.add_library('libm.so');b.add_library('libc.so');b.write(str(output))
print(output)
