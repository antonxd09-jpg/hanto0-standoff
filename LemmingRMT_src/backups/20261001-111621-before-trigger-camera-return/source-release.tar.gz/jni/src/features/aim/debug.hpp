#pragma once
#include "features/aim/core.hpp"
#include <android/log.h>
#include <chrono>
#include <cstdio>
#include <cstdarg>
#include <cerrno>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <unistd.h>
namespace lemming::aim::debug {
using Count=std::atomic<std::uint64_t>;
inline Count playerCalls{0},mainCalls{0},inactive{0},runtimeNotReady{0},wrongThread{0},validationAttempts{0},validationFailures{0},cameraAttempts{0},silentAttempts{0},cameraCalls{0},silentCalls{0};
inline Count captureCalls{0},captureLocal{0},captureSnapshot{0},captureWorld{0},captureArray{0},capturePose{0},hitboxes{0},badClass{0},unknownBone{0},badCollider{0},badNative{0},badVirtual{0},badBounds{0},farBounds{0},storedActors{0},storedVolumes{0};
inline Count selectCalls{0},selectActors{0},selectFresh{0},selectLive{0},selectVolumes{0},bodyReject{0},pointCandidates{0},rangeReject{0},fovReject{0},accepted{0};
inline Count rcsReads{0},rcsRejected{0},rcsApplied{0},visibilityRays{0},visibilityClear{0},visibilityTarget{0},visibilityBlocked{0},visibilityUnknown{0};
inline std::atomic<float> recoilPitch{0},recoilYaw{0};
inline std::atomic<int> boneMin{9999},boneMax{-1};
inline std::atomic<std::uintptr_t> mainBase{0},lastPlayer{0};
inline std::atomic<int> callbackTid{0},normalReason{0},silentReason{0};
inline std::atomic<int> localMask{0},localRaw{0},localHp{0},localTeam{0},attackRaw{-1};
inline std::atomic<int> normalInstallReason{0},silentInstallReason{0};
inline std::atomic<int> freshActors{0},freshVolumes{0};
inline std::atomic<float> nearestAngle{180},nearestDistance{0};
inline bool due(Count& c){auto n=c.fetch_add(1,std::memory_order_relaxed)+1;return n<=2||n%300==0;}
inline void log(const char* fmt,...){char text[1152];va_list a;va_start(a,fmt);vsnprintf(text,sizeof(text),fmt,a);va_end(a);__android_log_print(ANDROID_LOG_INFO,"LemmingRMT","AIM DEBUG %s",text);}
inline const char* reason(int r){switch(r){case 0:return "not-called";case 1:return "disabled";case 2:return "menu-paused";case 3:return "empty-body-mask";case 4:return "wrong-thread";case 5:return "functions-not-valid";case 6:return "no-local-player";case 7:return "camera-context-rejected";case 8:return "not-attacking";case 9:return "hit-transform-rejected";case 10:return "no-target";case 11:return "applied";case 12:return "ray-span-not-current-stack";case 13:return "foreign-shooter-or-world";case 14:return "non-finite-angles";case 15:return "visibility-not-ready";case 16:return "recoil-only";default:return "unknown";}}
inline const char* installReason(int r){switch(r){case 0:return "not-attempted";case 1:return "ready";case 2:return "camera-class-missing";case 3:return "vtable-scan-miss";case 4:return "vtable-write-probe-denied";case 5:return "callsite-word-mismatch";case 6:return "page-size-invalid";case 7:return "near-relay-allocation-failed";case 8:return "relay-RX-denied";case 9:return "text-RWX-denied";case 10:return "restore-RX-failed";case 11:return "unsupported-architecture";case 12:return "slot-verify-failed";case 13:return "profile-not-validated";default:return "unknown";}}
inline void boundsBone(int bone){auto lo=boneMin.load();while(bone<lo&&!boneMin.compare_exchange_weak(lo,bone)){}auto hi=boneMax.load();while(bone>hi&&!boneMax.compare_exchange_weak(hi,bone)){}}
inline void report(){auto c=configuration();log("heartbeat build=v12-angle-assists pid=%d enabled[angle=%d silent=%d] menu=%d pause=%d attackOnly=%d bodyMask[%02x,%02x] fov[%.2f,%.2f] range[%.1f,%.1f] threadTid=%d base=%p",getpid(),c.normal.enabled,c.silent.enabled,g_menuOpen.load(),c.pauseInMenu,c.normal.onAttack,c.normal.bodies,c.silent.bodies,c.normal.fov,c.silent.fov,c.normal.maxDistance,c.silent.maxDistance,callbackTid.load(),reinterpret_cast<void*>(mainBase.load()));
 log("callbacks player=%llu main=%llu inactive=%llu runtimeNotReady=%llu wrongThread=%llu validation=%llu failed=%llu normal=%llu silent=%llu",(unsigned long long)playerCalls.load(),(unsigned long long)mainCalls.load(),(unsigned long long)inactive.load(),(unsigned long long)runtimeNotReady.load(),(unsigned long long)wrongThread.load(),(unsigned long long)validationAttempts.load(),(unsigned long long)validationFailures.load(),(unsigned long long)cameraCalls.load(),(unsigned long long)silentCalls.load());
 log("hooks angle=%d attempts=%llu reason=%s silent=%d attempts=%llu reason=%s run[angle=%s silent=%s] applications[%llu,%llu]",g_normalHookReady.load(),(unsigned long long)cameraAttempts.load(),installReason(normalInstallReason.load()),g_silentHookReady.load(),(unsigned long long)silentAttempts.load(),installReason(silentInstallReason.load()),reason(normalReason.load()),reason(silentReason.load()),(unsigned long long)g_normalApplications.load(),(unsigned long long)g_silentApplications.load());
 log("capture calls=%llu skip[local=%llu snapshot=%llu world=%llu array=%llu pose=%llu] hitboxes=%llu reject[class=%llu bone=%llu collider=%llu native=%llu virtual=%llu bounds=%llu rootDistance=%llu] boneRange[%d,%d] stored[actors=%llu volumes=%llu] fresh[%d,%d]",(unsigned long long)captureCalls.load(),(unsigned long long)captureLocal.load(),(unsigned long long)captureSnapshot.load(),(unsigned long long)captureWorld.load(),(unsigned long long)captureArray.load(),(unsigned long long)capturePose.load(),(unsigned long long)hitboxes.load(),(unsigned long long)badClass.load(),(unsigned long long)unknownBone.load(),(unsigned long long)badCollider.load(),(unsigned long long)badNative.load(),(unsigned long long)badVirtual.load(),(unsigned long long)badBounds.load(),(unsigned long long)farBounds.load(),boneMin.load(),boneMax.load(),(unsigned long long)storedActors.load(),(unsigned long long)storedVolumes.load(),freshActors.load(),freshVolumes.load());
 log("local mask=%03x expected=fff rawLocal=%d hp=%d team=%d attackRaw=%d expectedAttack=1",localMask.load(),localRaw.load(),localHp.load(),localTeam.load(),attackRaw.load());
 log("selection calls=%llu actors=%llu fresh=%llu live=%llu volumes=%llu bodyReject=%llu points=%llu rangeReject=%llu fovReject=%llu accepted=%llu nearest[angle=%.3f distance=%.3f]",(unsigned long long)selectCalls.load(),(unsigned long long)selectActors.load(),(unsigned long long)selectFresh.load(),(unsigned long long)selectLive.load(),(unsigned long long)selectVolumes.load(),(unsigned long long)bodyReject.load(),(unsigned long long)pointCandidates.load(),(unsigned long long)rangeReject.load(),(unsigned long long)fovReject.load(),(unsigned long long)accepted.load(),nearestAngle.load(),nearestDistance.load());
 log("assists showFov=%d visible[enabled=%d ready=%d rays=%llu clear=%llu target=%llu blocked=%llu unknown=%llu] rcs[enabled=%d ready=%d strength=%.1f reads=%llu rejected=%llu applied=%llu] recoil[pitch=%.3f yaw=%.3f]",c.normal.showFov,c.normal.visibleCheck,g_visibilityReady.load(),(unsigned long long)visibilityRays.load(),(unsigned long long)visibilityClear.load(),(unsigned long long)visibilityTarget.load(),(unsigned long long)visibilityBlocked.load(),(unsigned long long)visibilityUnknown.load(),c.normal.rcs,g_rcsReady.load(),c.normal.rcsStrength,(unsigned long long)rcsReads.load(),(unsigned long long)rcsRejected.load(),(unsigned long long)rcsApplied.load(),recoilPitch.load(),recoilYaw.load());}
}
