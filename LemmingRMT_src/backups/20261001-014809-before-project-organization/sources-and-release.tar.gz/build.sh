#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
NDK="${ANDROID_NDK_HOME:-$ROOT/../android-ndk-r30-linux/android-ndk-r30}"
NDK_BUILD="$NDK/build/ndk-build"
ABIS=(arm64-v8a)

if [[ ! -x "$NDK_BUILD" ]]; then
  echo "NDK build tool not found: $NDK_BUILD" >&2
  exit 1
fi

cd "$ROOT"
if [[ "${1:-}" == "clean" ]]; then
  "$NDK_BUILD" NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk clean
  rm -rf out libs/armeabi-v7a obj/local/armeabi-v7a obj/local/armeabi-v7a
  exit 0
fi

"$NDK_BUILD" \
  NDK_PROJECT_PATH=. \
  APP_BUILD_SCRIPT=jni/Android.mk \
  NDK_APPLICATION_MK=jni/Application.mk \
  -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4)"

rm -rf out/armeabi-v7a libs/armeabi-v7a obj/local/armeabi-v7a

for ABI in "${ABIS[@]}"; do
  mkdir -p "out/$ABI"
  cp -f "libs/$ABI/liblemmingrmt.so" "out/$ABI/"
  echo "Built: $ROOT/out/$ABI/liblemmingrmt.so"
done
