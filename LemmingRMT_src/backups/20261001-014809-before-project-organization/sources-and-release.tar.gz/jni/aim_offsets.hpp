#pragma once
#include <cstdint>
#include <cstddef>
namespace lemming::aim_offsets {
// 1.0.0 ARM64: source hashes and provenance in docs/AIM_OFFSETS_1.0.0_ARM64.md.
inline constexpr std::uintptr_t kCameraTick=0xA0903DC; // ios::iqkr(ExecuteTime)
inline constexpr std::uintptr_t kCameraClamp=0xA08C2B4; // ios::kjuc(Vector2) -> Vector2
inline constexpr std::uintptr_t kCameraApply=0xA08C460; // ios::iwlo(Vector2)
inline constexpr std::uintptr_t kCameraRefresh=0xA08C4F8; // ios::jqcv()
inline constexpr std::uintptr_t kShotEmit=0x9739FA4; // jxy::rxjx(WeaponContext,Span<Ray>): actually emits shot data
inline constexpr std::uintptr_t kShotCallsite=0x973A9E0; // BL rxjx inside jxy::vrsg: 0x97fffd71
inline constexpr std::uint8_t kAttackState=1; // WeaponState.Attack _raw, _modifiers ignored
}
